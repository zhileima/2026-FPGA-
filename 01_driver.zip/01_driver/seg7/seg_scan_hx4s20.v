// HX4S20 common-anode panel: segments active LOW. FPGA digit-control polarity
// is configurable because the common-anode supply switch can invert SEL.
// The current board's observed wiring uses LOW-active FPGA digit controls.
// Each slot: disable digits, next clock load segments, next clock enable digit.
// Slot length includes the two blank clocks, so default refresh remains 200 Hz.
module seg_scan_hx4s20 #(
    parameter integer CLK_FREQ = 100000000,
    parameter integer SCAN_FREQ = 200,
    parameter integer SEL_ACTIVE_LOW = 1
)(
    input wire clk,
    input wire rst_n,
    output reg [7:0] seg_sel,
    output reg [7:0] seg_data,
    input wire [7:0] seg_data_0,
    input wire [7:0] seg_data_1,
    input wire [7:0] seg_data_2,
    input wire [7:0] seg_data_3,
    input wire [7:0] seg_data_4,
    input wire [7:0] seg_data_5,
    input wire [7:0] seg_data_6,
    input wire [7:0] seg_data_7
);
    // Divide in two steps to avoid integer overflow in SCAN_FREQ * 8.
    localparam integer STEP_CYCLES = (CLK_FREQ > 0 && SCAN_FREQ > 0) ?
                                     (CLK_FREQ / SCAN_FREQ / 8) : 0;
    function integer counter_width;
        input integer limit;
        integer value;
        begin
            value = limit - 1;
            counter_width = 0;
            while (value > 0) begin
                counter_width = counter_width + 1;
                value = value >> 1;
            end
            if (counter_width < 1) counter_width = 1;
        end
    endfunction
    localparam integer COUNT_WIDTH = counter_width(STEP_CYCLES);
    localparam [7:0] SELECT_OFF = SEL_ACTIVE_LOW ? 8'hff : 8'h00;
    reg [COUNT_WIDTH-1:0] scan_count;
    reg [2:0] scan_index;
    reg [7:0] selected_data;

    // synthesis translate_off
    initial begin
        if (CLK_FREQ <= 0 || SCAN_FREQ <= 0 || STEP_CYCLES < 3 ||
            (SEL_ACTIVE_LOW != 0 && SEL_ACTIVE_LOW != 1)) begin
            $display("ERROR seg_scan_hx4s20 requires positive frequencies and at least three clocks per digit");
            $finish;
        end
    end
    // synthesis translate_on

    always @* begin
        case (scan_index)
            3'd0: selected_data = seg_data_0;
            3'd1: selected_data = seg_data_1;
            3'd2: selected_data = seg_data_2;
            3'd3: selected_data = seg_data_3;
            3'd4: selected_data = seg_data_4;
            3'd5: selected_data = seg_data_5;
            3'd6: selected_data = seg_data_6;
            3'd7: selected_data = seg_data_7;
            default: selected_data = 8'hff;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scan_count <= {COUNT_WIDTH{1'b0}};
            scan_index <= 3'd0;
            seg_sel <= SELECT_OFF;
            seg_data <= 8'hff;
        end else begin
            if (scan_count == 0)
                seg_sel <= SELECT_OFF;
            else if (scan_count == 1)
                seg_data <= selected_data;
            else if (scan_count == 2)
                seg_sel <= SEL_ACTIVE_LOW ? ~(8'b00000001 << scan_index) :
                                            (8'b00000001 << scan_index);

            if (scan_count == STEP_CYCLES - 1) begin
                scan_count <= {COUNT_WIDTH{1'b0}};
                scan_index <= scan_index + 3'd1;
            end else begin
                scan_count <= scan_count + 1'b1;
            end
        end
    end
endmodule
