`timescale 1ns/1ps
// Recover the active-first 800 x 525 coordinates from the final, equally
// delayed sync bundle. Source timing: H=640/16/96/48, V=480/10/2/33.
// This keeps the SDRAM read pipeline unchanged and includes vertical blank.
module hdmi_video_position (
    input wire clk,
    input wire rst,
    input wire hsync,
    input wire vsync,
    input wire de,
    output wire [9:0] video_x,
    output wire video_next_line_active,
    output reg timing_locked,
    output reg coordinate_error
);
    reg previous_hsync, previous_vsync, seen_vsync_high;
    reg [9:0] pixel_x, line_y;
    wire hsync_fall = previous_hsync && !hsync;
    wire vsync_fall = previous_vsync && !vsync && seen_vsync_high;
    assign video_x = hsync_fall ? 10'd656 : pixel_x;
    // Hsync has advanced line_y by the time the next video preamble begins.
    assign video_next_line_active = timing_locked && line_y < 10'd480;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            previous_hsync <= 0;
            previous_vsync <= 0;
            seen_vsync_high <= 0;
            pixel_x <= 0;
            line_y <= 0;
            timing_locked <= 0;
            coordinate_error <= 0;
        end else begin
            previous_hsync <= hsync;
            previous_vsync <= vsync;
            if (vsync) seen_vsync_high <= 1;
            if (hsync_fall) begin
                if (timing_locked && pixel_x != 10'd656)
                    coordinate_error <= 1;
                pixel_x <= 10'd657;
                if (timing_locked)
                    line_y <= line_y == 10'd524 ? 10'd0 : line_y + 1'b1;
            end else begin
                pixel_x <= pixel_x == 10'd799 ? 10'd0 : pixel_x + 1'b1;
            end
            // Initial reset-low sync is deliberately not treated as a frame.
            if (vsync_fall) begin
                line_y <= 10'd490;
                timing_locked <= 1;
            end
            if (timing_locked && de != (video_x < 10'd640 && line_y < 10'd480))
                coordinate_error <= 1;
        end
    end
endmodule
