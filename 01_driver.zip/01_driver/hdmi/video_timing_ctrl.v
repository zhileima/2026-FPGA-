`timescale 1ns/1ps
// 25 MHz 640x480 timing: front porch -> sync -> back porch -> active.
// Vertical count advances at the horizontal sync boundary, as in color_bar.
// frame_start is decoded before the clock that lowers VS, so every consumer
// flushes/commits on that same edge. read_req holds until acknowledged without
// stopping either timing counter. x/y are zero-based active coordinates.
module video_timing_ctrl #(
    parameter integer H_ACT=640, parameter integer H_FP=16,
    parameter integer H_SYNC=96, parameter integer H_BP=48,
    parameter integer V_ACT=480, parameter integer V_FP=10,
    parameter integer V_SYNC=2, parameter integer V_BP=33
)(
    input wire video_clk, input wire rst, input wire read_req_ack,
    output reg read_req, output wire hs, output wire vs, output wire de,
    output wire frame_start, output wire vblank,
    output wire [11:0] x, output wire [11:0] y
);
    localparam integer H_TOTAL=H_ACT+H_FP+H_SYNC+H_BP;
    localparam integer V_TOTAL=V_ACT+V_FP+V_SYNC+V_BP;
    localparam integer H_BLANK=H_FP+H_SYNC+H_BP;
    localparam integer V_BLANK=V_FP+V_SYNC+V_BP;
    reg [11:0] h_count, v_count;
    initial begin
        if (H_ACT<1 || H_FP<1 || H_SYNC<1 || H_BP<1 ||
            V_ACT<1 || V_FP<1 || V_SYNC<1 || V_BP<1 ||
            H_TOTAL>4096 || V_TOTAL>4096) begin
            $display("VIDEO_TIMING_CONFIG_ERROR invalid timing dimensions");
            $finish;
        end
    end
    always @(posedge video_clk or posedge rst) begin
        if (rst) begin h_count<=0; v_count<=0; read_req<=0; end
        else begin
            if (h_count==H_TOTAL-1) h_count<=0;
            else h_count<=h_count+1'b1;
            if (h_count==H_FP-1) begin
                if (v_count==V_TOTAL-1) v_count<=0;
                else v_count<=v_count+1'b1;
            end
            if (frame_start) read_req<=1;
            else if (read_req_ack) read_req<=0;
        end
    end
    assign hs=~((h_count>=H_FP) && (h_count<H_FP+H_SYNC));
    assign vs=~((v_count>=V_FP) && (v_count<V_FP+V_SYNC));
    assign vblank=v_count<V_BLANK;
    assign de=(h_count>=H_BLANK) && !vblank;
    assign frame_start=!rst && (h_count==H_FP-1) && (v_count==V_FP-1);
    assign x=de ? h_count-H_BLANK : 12'd0;
    assign y=de ? v_count-V_BLANK : 12'd0;
endmodule
