`timescale 1ns/1ps
// UART transmitter: idle high, one start bit, eight LSB-first bits, one stop bit.
// A one-clock start pulse is accepted only when busy is low. data is latched.
module uart_tx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       start,
    input  wire [7:0] data,
    output reg        tx,
    output reg        busy
);
    function integer counter_width;
        input integer count;
        integer value;
        begin
            value = count - 1;
            counter_width = 0;
            while (value > 0) begin
                value = value >> 1;
                counter_width = counter_width + 1;
            end
            if (counter_width < 1)
                counter_width = 1;
        end
    endfunction

    // Integer rounding gives 434 clocks/bit at 50 MHz / 115200 baud.
    localparam integer BIT_CYCLES_RAW = (CLK_HZ + BAUD / 2) / BAUD;
    localparam integer BIT_CYCLES = BIT_CYCLES_RAW < 1 ? 1 : BIT_CYCLES_RAW;
    localparam integer TIMER_BITS = counter_width(BIT_CYCLES);
    reg [TIMER_BITS-1:0] bit_timer;
    reg [3:0] bit_index;
    reg [9:0] frame_shift;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tx          <= 1'b1;
            busy        <= 1'b0;
            bit_timer   <= {TIMER_BITS{1'b0}};
            bit_index   <= 4'd0;
            frame_shift <= 10'h3ff;
        end else if (!busy) begin
            tx <= 1'b1;
            if (start) begin
                frame_shift <= {1'b1, data, 1'b0};
                tx          <= 1'b0;
                busy        <= 1'b1;
                bit_timer   <= BIT_CYCLES - 1;
                bit_index   <= 4'd0;
            end
        end else if (bit_timer != 0) begin
            bit_timer <= bit_timer - 1'b1;
        end else if (bit_index == 4'd9) begin
            // Keep busy asserted through the complete stop bit.
            tx   <= 1'b1;
            busy <= 1'b0;
        end else begin
            frame_shift <= {1'b1, frame_shift[9:1]};
            tx          <= frame_shift[1];
            bit_index   <= bit_index + 1'b1;
            bit_timer   <= BIT_CYCLES - 1;
        end
    end
endmodule
