`timescale 1ns/1ps
// Transfer the committed image number, never the image being loaded. The
// payload is frozen before the request token, and kept until its returned ACK.
// Both resets assert from the same rst_async and release in their own clocks.
// If changes arrive while busy, the latest committed number is sent afterward.
module media_commit_cdc (
    input wire src_clk,
    input wire src_rst,
    input wire [3:0] image_number,
    input wire dst_clk,
    input wire dst_rst,
    output reg [1:0] media_id,
    output reg media_valid,
    output reg media_commit
);
    reg [3:0] src_hold_number;
    reg src_request_toggle;
    reg dst_ack_toggle;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg src_ack_sync1;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg src_ack_sync2;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_request_sync1;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_request_sync2;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_request_sync3;
    (* KEEP = "TRUE" *) reg [3:0] dst_data_sync1;
    reg [3:0] dst_data_sync2;
    always @(posedge src_clk or posedge src_rst) begin
        if (src_rst) begin
            src_hold_number <= 0;
            src_request_toggle <= 0;
            src_ack_sync1 <= 0;
            src_ack_sync2 <= 0;
        end else begin
            src_ack_sync1 <= dst_ack_toggle;
            src_ack_sync2 <= src_ack_sync1;
            if (src_request_toggle == src_ack_sync2 && image_number != src_hold_number) begin
                src_hold_number <= image_number;
                src_request_toggle <= ~src_request_toggle;
            end
        end
    end
    always @(posedge dst_clk or posedge dst_rst) begin
        if (dst_rst) begin
            dst_request_sync1 <= 0;
            dst_request_sync2 <= 0;
            dst_request_sync3 <= 0;
            dst_data_sync1 <= 0;
            dst_data_sync2 <= 0;
            dst_ack_toggle <= 0;
            media_id <= 0;
            media_valid <= 0;
            media_commit <= 0;
        end else begin
            dst_request_sync1 <= src_request_toggle;
            dst_request_sync2 <= dst_request_sync1;
            dst_request_sync3 <= dst_request_sync2;
            dst_data_sync1 <= src_hold_number;
            dst_data_sync2 <= dst_data_sync1;
            media_commit <= 0;
            if (dst_request_sync3 != dst_ack_toggle) begin
                dst_ack_toggle <= dst_request_sync3;
                media_valid <= dst_data_sync2 >= 1 && dst_data_sync2 <= 8;
                if (dst_data_sync2 >= 1 && dst_data_sync2 <= 8) begin
                    media_id <= dst_data_sync2[1:0] - 2'd1;
                    media_commit <= 1;
                end
            end
        end
    end
endmodule
