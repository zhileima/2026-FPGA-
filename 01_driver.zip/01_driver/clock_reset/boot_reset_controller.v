`timescale 1ns/1ps
// Reference-clock startup policy for the ACTUAL sys/video PLL pair. Domain
// reset_sync instances still perform their own asynchronous assertion and
// synchronous release. PLL reset must not depend on the PLL's lock output.
module boot_reset_controller #(
    parameter integer REF_CLK_HZ=50_000_000,
    parameter integer POR_MS=20,
    parameter integer LOCK_STABLE_US=1000
)(
    input wire ref_clk,
    input wire board_reset_n,
    input wire sys_pll_lock,
    input wire video_pll_lock,
    output wire pll_reset,
    output wire system_reset_async,
    output reg por_done,
    output reg pll_locks_stable
);
    localparam [63:0] POR_CYCLES=(64'd1*REF_CLK_HZ*POR_MS+999)/1000;
    localparam [63:0] LOCK_CYCLES=(64'd1*REF_CLK_HZ*LOCK_STABLE_US+999999)/1000000;
    localparam integer POR_BITS=POR_CYCLES<2 ? 1 : $clog2(POR_CYCLES);
    localparam integer LOCK_BITS=LOCK_CYCLES<2 ? 1 : $clog2(LOCK_CYCLES);
    reg [POR_BITS-1:0] por_count;
    reg [LOCK_BITS-1:0] lock_count;
    wire raw_clock_fault=!board_reset_n || !por_done || !sys_pll_lock || !video_pll_lock;
    wire all_locks_ref;

    // FPGA configuration initializes these four registers to zero. This also
    // starts POR when the external key is already released at configuration.
    initial begin
        por_done=1'b0;por_count=0;pll_locks_stable=1'b0;lock_count=0;
        if(REF_CLK_HZ<=0 || POR_MS<=0 || LOCK_STABLE_US<=0 ||
           POR_CYCLES<1 || POR_CYCLES>64'hffffffff ||
           LOCK_CYCLES<1 || LOCK_CYCLES>64'hffffffff) begin
            $display("BOOT_RESET_CONFIG_ERROR invalid startup timer configuration");
            $finish;
        end
    end
    assign pll_reset=!board_reset_n || !por_done;
    // The unsynchronized lock path is assertion-only: even a pulse shorter
    // than one reference clock resets all domains and restarts qualification.
    assign system_reset_async=raw_clock_fault || !pll_locks_stable;
    sync_2ff u_pll_locks_ref(
        .clk(ref_clk),.rst_n(!raw_clock_fault),
        .async_in(sys_pll_lock && video_pll_lock),.sync_out(all_locks_ref));

    always @(posedge ref_clk or negedge board_reset_n) begin
        if(!board_reset_n) begin por_done<=0;por_count<=0;end
        else if(!por_done) begin
            if(por_count>=POR_CYCLES-1) por_done<=1;
            else por_count<=por_count+1'b1;
        end
    end
    always @(posedge ref_clk or posedge raw_clock_fault) begin
        if(raw_clock_fault) begin pll_locks_stable<=0;lock_count<=0;end
        else if(!all_locks_ref) begin pll_locks_stable<=0;lock_count<=0;end
        else if(!pll_locks_stable) begin
            if(lock_count>=LOCK_CYCLES-1) pll_locks_stable<=1;
            else lock_count<=lock_count+1'b1;
        end
    end
endmodule
