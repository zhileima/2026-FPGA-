`timescale 1ns/1ps
// Each bank's dimensions are immutable after its complete-frame valid bit.
// Two payload stages settle before the third valid stage qualifies them.
// Bank selection is in the pixel domain and follows the actual RGB bank.
module image_resolution_cdc #(parameter integer BANK_BITS=2, parameter integer DIM_BITS=16) (
    input wire src_clk,src_rst,
    input wire [15:0] width0,height0,width1,height1,width2,height2,width3,height3,
    input wire [15:0] width4,height4,width5,height5,width6,height6,width7,height7,
    input wire [(1<<BANK_BITS)-1:0] valid_mask,
    input wire dst_clk,dst_rst, input wire [BANK_BITS-1:0] bank_index,
    output wire [15:0] width_out,height_out, output wire valid_out
);
    // The caller may narrow only dimensions whose accepted source bounds fit.
    // Keep all public ports 16-bit; DIM_BITS=16 preserves the original contract.
    localparam integer PAIR_BITS=2*DIM_BITS;
    initial begin
        if(DIM_BITS<1 || DIM_BITS>16) begin
            $display("image_resolution_cdc: DIM_BITS must be in 1..16");
            $finish;
        end
    end
    (* ASYNC_REG="TRUE", KEEP="TRUE" *) reg [PAIR_BITS*(1<<BANK_BITS)-1:0] dimensions_meta;
    reg [PAIR_BITS*(1<<BANK_BITS)-1:0] dimensions_sync;
    (* ASYNC_REG="TRUE", KEEP="TRUE" *) reg [(1<<BANK_BITS)-1:0] valid_meta;
    reg [(1<<BANK_BITS)-1:0] valid_sync,valid_qualified;
    always @(posedge dst_clk or posedge dst_rst) begin
        if(dst_rst) begin
            dimensions_meta<=0;dimensions_sync<=0;
            valid_meta<=0;valid_sync<=0;valid_qualified<=0;
        end else begin
            dimensions_meta<={width7[DIM_BITS-1:0],height7[DIM_BITS-1:0],width6[DIM_BITS-1:0],height6[DIM_BITS-1:0],width5[DIM_BITS-1:0],height5[DIM_BITS-1:0],width4[DIM_BITS-1:0],height4[DIM_BITS-1:0],width3[DIM_BITS-1:0],height3[DIM_BITS-1:0],width2[DIM_BITS-1:0],height2[DIM_BITS-1:0],width1[DIM_BITS-1:0],height1[DIM_BITS-1:0],width0[DIM_BITS-1:0],height0[DIM_BITS-1:0]};
            dimensions_sync<=dimensions_meta;
            valid_meta<=valid_mask;valid_sync<=valid_meta;valid_qualified<=valid_sync;
        end
    end
    wire [PAIR_BITS-1:0] selected=dimensions_sync[bank_index*PAIR_BITS +: PAIR_BITS];
    assign valid_out=valid_qualified[bank_index];
    assign width_out=valid_out ? {{(16-DIM_BITS){1'b0}},selected[PAIR_BITS-1:DIM_BITS]} : 16'd0;
    assign height_out=valid_out ? {{(16-DIM_BITS){1'b0}},selected[DIM_BITS-1:0]} : 16'd0;
    // src_clk/src_rst document the source-domain contract; storage ownership
    // and reset clearing of the immutable metadata belong to the player.
endmodule
