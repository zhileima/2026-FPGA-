`timescale 1ns/1ps
// Held mailbox + request/ACK transfer. Only complete configurations enter
// the video pipeline, and only at a raw timing frame boundary in blanking.
module image_adjust_cdc(
    input src_clk,input src_rst,
    input [7:0] brightness,input [7:0] contrast,
    input [7:0] sharpness,saturation,
    input [1:0] menu_mode,input [5:0] menu_step,
    input dst_clk,input dst_rst,input frame_start,
    output [7:0] brightness_out,output [7:0] contrast_out,
    output [7:0] sharpness_out,saturation_out,
    output [1:0] menu_mode_out,output [5:0] menu_step_out
);
    localparam [39:0] DEFAULT_CONFIG={8'd0,8'd50,2'd0,6'd1,8'd255,8'd128};
    wire [39:0] source_config={sharpness,saturation,menu_mode,menu_step,brightness,contrast};
    reg [39:0] payload_hold;
    reg request_toggle,ack_toggle;
    (* ASYNC_REG="TRUE",keep="true" *) reg [1:0] ack_sync;
    (* ASYNC_REG="TRUE",keep="true" *) reg [39:0] payload_meta,payload_sync;
    (* ASYNC_REG="TRUE",keep="true" *) reg [2:0] request_sync;
    reg [39:0] pending_config,active_config;
    wire new_request=(request_sync[2]!=ack_toggle);
    assign {sharpness_out,saturation_out,menu_mode_out,menu_step_out,brightness_out,contrast_out}=active_config;

    always @(posedge src_clk or posedge src_rst) begin
        if(src_rst) begin
            payload_hold<=DEFAULT_CONFIG;request_toggle<=0;ack_sync<=0;
        end else begin
            ack_sync<={ack_sync[0],ack_toggle};
            // Latest value wins while busy; in-flight payload never changes.
            if(ack_sync[1]==request_toggle && source_config!=payload_hold) begin
                payload_hold<=source_config;request_toggle<=~request_toggle;
            end
        end
    end
    always @(posedge dst_clk or posedge dst_rst) begin
        if(dst_rst) begin
            payload_meta<=DEFAULT_CONFIG;payload_sync<=DEFAULT_CONFIG;
            request_sync<=0;ack_toggle<=0;
            pending_config<=DEFAULT_CONFIG;active_config<=DEFAULT_CONFIG;
        end else begin
            payload_meta<=payload_hold;payload_sync<=payload_meta;
            request_sync<={request_sync[1:0],request_toggle};
            if(new_request) begin
                pending_config<=payload_sync;ack_toggle<=request_sync[2];
            end
            if(frame_start) active_config<=new_request?payload_sync:pending_config;
        end
    end
endmodule
