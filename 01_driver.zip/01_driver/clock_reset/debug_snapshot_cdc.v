`timescale 1ns/1ps
// Coherent debug-only snapshot handshake. src_data can change every source clock.
// src_hold_data is frozen before acknowledgement and until the next request.
// Both resets must derive from the SAME board reset assertion, with release
// synchronized separately in their domains. Do not independently reset tokens
// on a PLL lock change or a functional-domain reset.
// If the source clock stops, busy stays asserted until that request completes.
// The caller must timeout its report wait WITHOUT resetting/cancelling this
// handshake, skip captures while busy, and accept the eventual late done.
module debug_snapshot_cdc #(
    parameter integer WIDTH = 32,
    parameter integer HOLD_OUTPUT = 1
)(
    input  wire                 src_clk,
    input  wire                 src_rst,
    input  wire [WIDTH-1:0]     src_data,
    input  wire                 dst_clk,
    input  wire                 dst_rst,
    input  wire                 capture,
    output reg                  busy,
    output reg                  done,
    output reg  [WIDTH-1:0]     data
);
    reg dst_req_toggle;
    reg src_ack_toggle;
    reg [WIDTH-1:0] src_hold_data;

    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg src_req_sync1;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg src_req_sync2;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_ack_sync1;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_ack_sync2;
    (* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg dst_ack_sync3;

    // Held payload capture, qualified by THREE ACK stages plus the consume edge.
    // src_hold_data is frozen; with its path bounded below one dst period,
    // dst_bus_sync1 has a complete settled tuple before the ACK qualifies it.
    (* KEEP = "TRUE" *) reg [WIDTH-1:0] dst_bus_sync1;


    always @(posedge src_clk or posedge src_rst) begin
        if (src_rst) begin
            src_req_sync1 <= 1'b0;
            src_req_sync2 <= 1'b0;
            src_ack_toggle <= 1'b0;
            src_hold_data <= {WIDTH{1'b0}};
        end else begin
            src_req_sync1 <= dst_req_toggle;
            src_req_sync2 <= src_req_sync1;
            if (src_req_sync2 != src_ack_toggle) begin
                src_hold_data <= src_data;
                src_ack_toggle <= src_req_sync2;
            end
        end
    end

    always @(posedge dst_clk or posedge dst_rst) begin
        if (dst_rst) begin
            dst_req_toggle <= 1'b0;
            dst_ack_sync1 <= 1'b0;
            dst_ack_sync2 <= 1'b0;
            dst_ack_sync3 <= 1'b0;
            dst_bus_sync1 <= {WIDTH{1'b0}};


            busy <= 1'b0;
            done <= 1'b0;
        end else begin
            dst_ack_sync1 <= src_ack_toggle;
            dst_ack_sync2 <= dst_ack_sync1;
            dst_ack_sync3 <= dst_ack_sync2;
            dst_bus_sync1 <= src_hold_data;

            done <= 1'b0;
            if (busy) begin
                if (dst_ack_sync3 == dst_req_toggle) begin

                    busy <= 1'b0;
                    done <= 1'b1;
                end
            end else if (capture) begin
                dst_req_toggle <= ~dst_req_toggle;
                busy <= 1'b1;
            end
        end
    end
    // HOLD_OUTPUT=0 is a qualified bundled-payload view in dst_clk.
    // It is valid after done and stable until the next accepted capture.
    // Consumers must mask timed-out/unrequested domains throughout use.
    generate if (HOLD_OUTPUT != 0) begin : g_held_output
        always @(posedge dst_clk or posedge dst_rst) begin
            if (dst_rst) data <= {WIDTH{1'b0}};
            else if (busy && dst_ack_sync3 == dst_req_toggle)
                data <= dst_bus_sync1;
        end
    end else begin : g_qualified_view
        always @* data = dst_bus_sync1;
    end endgenerate
endmodule
