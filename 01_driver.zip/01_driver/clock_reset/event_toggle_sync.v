`timescale 1ns/1ps
// Debounced human events are far slower than the four-cycle synchronizer.
// The source holds its toggle between presses; a shared asynchronous reset
// resets the source and this receiver together.
module event_toggle_sync (
    input wire dst_clk,
    input wire dst_rst,
    input wire src_toggle,
    output reg event_pulse
);
    reg toggle_sync1, toggle_sync2, toggle_sync3, toggle_seen;
    always @(posedge dst_clk or posedge dst_rst) begin
        if (dst_rst) begin
            toggle_sync1 <= 0;
            toggle_sync2 <= 0;
            toggle_sync3 <= 0;
            toggle_seen <= 0;
            event_pulse <= 0;
        end else begin
            toggle_sync1 <= src_toggle;
            toggle_sync2 <= toggle_sync1;
            toggle_sync3 <= toggle_sync2;
            toggle_seen <= toggle_sync3;
            event_pulse <= toggle_sync3 ^ toggle_seen;
        end
    end
endmodule

