module reset_sync (
    input  wire clk,
    input  wire async_reset,
    output wire reset_out
);

// Assert immediately, then release only after two edges of this domain's clock.
(* async_reg = "true" *) reg [1:0] reset_pipe;

always @(posedge clk or posedge async_reset) begin
    if (async_reset)
        reset_pipe <= 2'b11;
    else
        reset_pipe <= {reset_pipe[0], 1'b0};
end

assign reset_out = reset_pipe[1];

endmodule
