`timescale 1ns/1ps
// Acknowledged held mailbox: latest settings win while busy. A complete
// snapshot becomes visible only at a video blanking frame boundary.
module player_settings_cdc #(
    parameter integer WIDTH=17,
    parameter [WIDTH-1:0] RESET_VALUE=17'h00800
)(
    input src_clk,input src_rst,input [WIDTH-1:0] source_state,
    input dst_clk,input dst_rst,input frame_start,
    output reg [WIDTH-1:0] active_state
);
    reg [WIDTH-1:0] payload_hold,pending_state;
    reg request_toggle,ack_toggle;
    (* ASYNC_REG="TRUE",keep="true" *) reg [1:0] ack_sync;
    (* ASYNC_REG="TRUE",keep="true" *) reg [WIDTH-1:0] payload_meta,payload_sync;
    (* ASYNC_REG="TRUE",keep="true" *) reg [2:0] request_sync;
    wire new_request=request_sync[2]!=ack_toggle;
    always @(posedge src_clk or posedge src_rst) begin
        if(src_rst) begin
            payload_hold<=RESET_VALUE;request_toggle<=0;ack_sync<=0;
        end else begin
            ack_sync<={ack_sync[0],ack_toggle};
            if(ack_sync[1]==request_toggle && source_state!=payload_hold) begin
                payload_hold<=source_state;request_toggle<=~request_toggle;
            end
        end
    end
    always @(posedge dst_clk or posedge dst_rst) begin
        if(dst_rst) begin
            payload_meta<=RESET_VALUE;payload_sync<=RESET_VALUE;
            request_sync<=0;ack_toggle<=0;pending_state<=RESET_VALUE;
            active_state<=RESET_VALUE;
        end else begin
            payload_meta<=payload_hold;payload_sync<=payload_meta;
            request_sync<={request_sync[1:0],request_toggle};
            if(new_request) begin pending_state<=payload_sync;ack_toggle<=request_sync[2];end
            if(frame_start) active_state<=new_request ? payload_sync : pending_state;
        end
    end
endmodule

