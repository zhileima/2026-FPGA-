// One-way local controller. sys0/1/2 are unused vendor-default globals.
int sys0=0,sys1=0,sys2=0
int ended=0
int scene=0,sel=0,confirmed=0,started=0,correct=0,thumb=0,focus=0
int autoplay=0,period=5,effect=0,autoticks=0,autolimit=600
int vol=38,bri=100,con=50,zoom=0,sharp=0,sat=50
int sentv=0,sentz=0,sentb=0,sentc=0,sents=0,sentt=0
int editing=0,dirty=1,txarg=0,txchk=0
int queuev=0,queuez=0,queueb=0,queuec=0,queues=0,queuet=0
int txbusy=0,txcursor=0,txpick=-1
baud=115200
bkcmd=0
sendxy=0
recmod=0
page home
