from pathlib import Path
import json,re,hashlib
from PIL import Image,ImageDraw,ImageChops
from native_container import parse_container
from native_codec import parse_page,cstr
from native_font_render import ZiFont

B=Path(__file__).resolve().parents[2]
D=B
f=next(B.glob('*.HMI'));raw=f.read_bytes()
blobs={r.name:raw[r.offset:r.offset+r.length] for r in parse_container(raw)}
names=['0.zi','3.zi','6.zi']
fonts=[ZiFont.from_bytes(blobs[n],n) for n in names]
required=set((D/'source/font_characters.txt').read_text('utf-8'))-set('\r\n')
original=ZiFont(Path('D:\\FPGA_TD_CODE\\V1\\F1\\updata\\sim\\sound_detective_20261027\\hmi_native_20261028\\font_audit\\0.zi'))
reports=[]
for i,font in enumerate(fonts):
    height=font.character_height
    probe=ZiFont(Path('D:\\FPGA_TD_CODE\\V1\\F1\\updata\\sim\\sound_detective_20261027\\hmi_native_20261028\\font_audit')/f'probe{height}_fit.zi')
    missing=[];blank=[];crop=[];different=[];rawmax=0
    for ch in required:
        code=font._map_char_to_codepoint(ch)
        if code not in font.glyphs:missing.append(ch);continue
        mask=font._glyph_mask(code)
        if not mask.getbbox() and not ch.isspace():blank.append(ch)
        if code in probe.glyphs and mask.getbbox():
            big=probe._glyph_mask(code)
            top=big.getbbox()[1]-mask.getbbox()[1]
            expected=big.crop((0,top,mask.width,top+mask.height))
            if big.getbbox()[1]<top or big.getbbox()[3]>top+height:crop.append(ch)
            if expected.size!=mask.size or expected.tobytes()!=mask.tobytes():different.append(ch)
    reports.append({'font_id':i,'file':names[i],'height':height,'glyphs':len(font.glyphs),
        'sha256':hashlib.sha256(font.raw).hexdigest(),'required_characters':len(required),
        'index_order_matches_original':list(font.glyphs)==list(original.glyphs),
        'missing':sorted(missing),'blank_nonspace':sorted(blank),'clipped_vs_tall_probe':sorted(crop),
        'normalized_raster_difference':sorted(different)})

def rgb(v):return ((v>>11)*255//31,((v>>5)&63)*255//63,(v&31)*255//31)
out=B/'native_renders';out.mkdir(exist_ok=True)
checks=[];overflows=[]
for i in range(5):
    page=parse_page(blobs[f'{i}.pa'])
    items=[]
    for obj in page.objects:
        a={cstr(k).decode():v for k,v in obj.attrs}
        a={k:(v.decode('gbk') if k=='txt' else v.decode('ascii') if k=='objname' else int.from_bytes(v,'little')) for k,v in a.items()}
        items.append(a)
    image=Image.new('RGBA',(1024,600),rgb(items[0]['bco'])+(255,));draw=ImageDraw.Draw(image)
    controls={a['objname']:a for a in items}
    for a in items[1:]:
        if 'x' not in a or 'w' not in a:continue
        x,y,w,h=[a[k] for k in ('x','y','w','h')]
        draw.rectangle((x,y,x+w-1,y+h-1),fill=rgb(a.get('bco',items[0]['bco'])))
        if a['type']==1:
            kx=x+round((w-a['wid'])*a['val']/100)
            draw.rectangle((x,y,kx+a['wid']//2,y+h-1),fill=rgb(a['bco1']))
            draw.ellipse((kx,y,kx+a['wid']-1,y+h-1),fill=rgb(a['pco']))
        elif 'font' in a:
            text=a.get('txt',str(a.get('val','')));font=fonts[a['font']]
            tw,th=font.measure_text(text)
            tx=x if a.get('xcen',0)==0 else x+(w-tw)//2
            ty=y if a.get('ycen',0)==0 else y+(h-th)//2
            image.alpha_composite(font.render_text(text,rgb(a['pco'])),(tx,ty))
            if text and (tw>w or th>h):overflows.append([items[0]['objname'],a['objname'],text,[tw,th],[w,h]])
    for obj in page.objects:
        for slot,lines in obj.events:
            for line in lines:
                m=re.fullmatch(r'(\w+)\.txt="(.*)"',line.decode('gbk'))
                if m:
                    name,text=m.groups();a=controls[name];tw,th=fonts[a['font']].measure_text(text)
                    if tw>a['w'] or th>a['h']:overflows.append([items[0]['objname'],name,text,[tw,th],[a['w'],a['h']]])
                    checks.append([items[0]['objname'],name,text,tw])
    image.convert('RGB').save(out/f'{i:02d}_{page.objects[0].name}.png')
contact=Image.new('RGB',(1024,900))
for i,p in enumerate(sorted(out.glob('0*.png'))):contact.paste(Image.open(p).resize((512,300),Image.Resampling.LANCZOS),((i%2)*512,(i//2)*300))
contact.save(out/'五页字库回读总览.png')
result={'passed':not overflows and all(not f['missing'] and not f['blank_nonspace'] and not f['clipped_vs_tall_probe'] and not f['normalized_raster_difference'] and f['index_order_matches_original'] for f in reports),
 'fonts':reports,'dynamic_text_checks':len(checks),'overflow':overflows,
 'correction':'Old preview decoder mapped antialiased shade7 to252 but solid runs to255. Normalize 3-bit alpha with round(255*shade/7); tall-probe comparisons are now exact, without changing font binary.',
 'evidence':'Parsed actual saved HMI font payloads and page attributes; render is offline, not native editor/screen evidence.'}
(B/'font_and_render_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
assert result['passed']
