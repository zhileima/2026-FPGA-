"""Read-only native HMI CRC investigation; no vendor runtime loaded.

Algorithm reference: YXerer668/tjc-usart-hmi-toolchain (MIT),
usarthmi/{hmi_cfs,hmi_pagesafe,tft_hmisafe}.py. Reimplemented here in
standard Python to avoid executing downloaded package initializers.
"""
import json
import struct
from pathlib import Path

MASK = 0xffffffff
TABLE = []
for n in range(256):
    c = n << 24
    for _ in range(8):
        c = ((c << 1) ^ (0x04c11db7 if c & 0x80000000 else 0)) & MASK
    TABLE.append(c)

def crc_update(seed, data, kind=10):
    if kind == 11 and len(data) % 4:
        raise ValueError("type11 length must be a multiple of four")
    words = data if kind == 10 else (v[0] for v in struct.iter_unpack('<I', data))
    c = seed
    for v in words:
        c ^= v
        for _ in range(4):
            c = ((c << 8) ^ TABLE[(c >> 24) & 255]) & MASK
    return c

def page_crc(page):
    c = crc_update(MASK, page[4:])
    for extra in (page[4:8], page[12:16], page[20:21], page[21:22]):
        c = crc_update(c, extra)
    return c

def main_crc(blob):
    """Project manifest CRC, verified against this TJC1060X570 donor.

    Reference: eseverson/nextion-hmi findings/format-hmi.md H5.
    Offset 0x10 is Modelcrc, not a second checksum to be rewritten.
    """
    c = crc_update(MASK, blob[4:])
    for extra in (blob[16:20], blob[4:8], blob[10:11], blob[14:15]):
        c = crc_update(c, extra)
    return c

def cfs_crc(raw, offset):
    count = struct.unpack_from('<I', raw, offset)[0]
    size = 4 + count*28
    if count > 100000 or offset + size + 4 > len(raw):
        raise ValueError('invalid CFS table')
    return crc_update(crc_update(MASK, raw[offset:offset+size], 11), b'ADEC', 11)

def main():
    root = Path(__file__).parent
    original = Path('D:/FPGA_TD_CODE/V1/tjc串口屏资料/TJC1060X570.HMI')
    raw = original.read_bytes()
    report = {'algorithm_source':'https://github.com/YXerer668/tjc-usart-hmi-toolchain',
              'vendor_runtime_executed':False, 'donor':str(original), 'tables':[], 'pages':[]}
    for off in (0, 0x80000, 0x380000):
        count = struct.unpack_from('<I', raw, off)[0]
        item = {'offset':hex(off), 'count':count}
        if count != MASK and count < 100000:
            end = off+4+count*28
            stored = struct.unpack_from('<I', raw, end)[0]
            calc = cfs_crc(raw, off)
            item.update(stored=hex(stored), calculated=hex(calc), match=stored==calc)
        report['tables'].append(item)
    for path in sorted(root.glob('*.pa')):
        page = path.read_bytes()
        stored = struct.unpack_from('<I', page)[0]
        calc = page_crc(page)
        report['pages'].append({'name':path.name,'stored':hex(stored),'calculated':hex(calc),'match':stored==calc})
    count0, count1 = (struct.unpack_from('<I',raw,o)[0] for o in (0,0x80000))
    report['directory_mirror_bytes_equal'] = count0==count1 and raw[:4+count0*28+4] == raw[0x80000:0x80000+4+count1*28+4]
    report['all_page_crc_match']=all(x['match'] for x in report['pages'])
    manifest = (root/'main.HMI').read_bytes()
    stored = struct.unpack_from('<I',manifest)[0]
    calc = main_crc(manifest)
    report['main_crc']={'stored':hex(stored),'calculated':hex(calc),'match':stored==calc,
                        'source':'https://github.com/eseverson/nextion-hmi/blob/main/findings/format-hmi.md#open-structural-questions'}
    (root/'crc_review_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'tables':report['tables'],'all_page_crc_match':report['all_page_crc_match'],'pages':len(report['pages']),'mirror':report['directory_mirror_bytes_equal'],'main_crc':report['main_crc']}))

if __name__ == '__main__':
    main()
