"""Build this model-specific TJC HMI from saved layout/events and native fonts.

No USART HMI process, GUI, serial device or unofficial vendor runtime is used.
Binary/CRC validation is distinct from compilation in the official editor.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
from datetime import datetime
from native_codec import parse_page, parse_main, filtered_main, build_layout_page, cstr
from native_container import parse_container, compact_selected
from crc_review import page_crc, main_crc

DONOR_HASH = 'ebeb4c84ed10064836ed9772a64ab9d7ab17bbd33f4618f48b18645e9d9eb476'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def build(donor, delivery, fonts, output):
    raw = donor.read_bytes()
    assert sha(raw) == DONOR_HASH, 'Requires the inspected TJC1060X570 donor'
    source = delivery/'source'
    layout = json.loads((source/'layout.json').read_text(encoding='utf-8'))
    assert layout['size'] == [1024, 600]
    assert [p['name'] for p in layout['pages']] == ['home','chapters','task','settings','ending']
    records = parse_container(raw)
    live = {r.name: raw[r.offset:r.offset+r.length] for r in records if r.live}
    pages = {n:parse_page(b) for n,b in live.items() if n.endswith('.pa')}
    events = {str(p.relative_to(source)).replace('\\','/'):p.read_text(encoding='utf-8')
              for p in (source/'events').glob('*.txt')}
    bound_events = [path for page in layout['pages'] for obj in [page]+page['components']
                    for path in obj.get('events',{}).values()]
    assert len(bound_events) == len(set(bound_events)), 'Each event file must have exactly one binding'
    assert set(events) == set(bound_events), 'Unbound event source or missing bound script'
    expected_event_count = len(bound_events)
    pa_names = [f'{i}.pa' for i in range(len(layout['pages']))]
    font_names = ['0.zi', '3.zi', '6.zi']
    chosen = {}
    for name,font in zip(font_names,fonts):
        chosen[name] = font.read_bytes()
        assert len(chosen[name]) > 100000, 'Use full Chinese fonts, not sparse demo fonts'
    for name,page in zip(pa_names, layout['pages']):
        chosen[name] = build_layout_page(pages,page,event_text=events).encode()
    manifest = bytearray(filtered_main(live['main.HMI'],pa_names,font_names))
    struct.pack_into('<I',manifest,0,main_crc(manifest))
    chosen['main.HMI'] = bytes(manifest)
    chosen['Program.s'] = (source/'program.s').read_text(encoding='utf-8').replace('\r\n','\n').replace('\n','\r\n').encode('gbk')
    packed = compact_selected(raw, chosen)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(packed)
    actual = output.read_bytes()
    assert actual == packed
    saved_records = parse_container(actual)
    assert len(saved_records) == 10 and all(r.live for r in saved_records)
    readback = {r.name:actual[r.offset:r.offset+r.length] for r in saved_records}
    assert set(readback) == set(chosen)
    assert all(readback[n] == b for n,b in chosen.items())
    main = readback['main.HMI']
    header, refs = parse_main(main)
    old_header,_ = parse_main(live['main.HMI'])
    assert header[4:28] == old_header[4:28] and header[32:] == old_header[32:]
    assert struct.unpack_from('<I',main)[0] == main_crc(main)
    assert [cstr(r[8:]).decode() for r in refs] == font_names+pa_names
    page_reports = []
    event_count = 0
    reconstructed = output.parent/'extracted_source'
    (reconstructed/'events').mkdir(parents=True,exist_ok=True)
    for n in ('layout.json','scene_story_candidate.json','font_characters.txt'):
        (reconstructed/n).write_bytes((source/n).read_bytes())
    (reconstructed/'program.s').write_text(readback['Program.s'].decode('gbk'),encoding='utf-8')
    slots = {'touch_press':b'codesdown','touch_release':b'codesup','timer':b'codestimer',
             'postinitialize':b'codesloadend','preinitialize':b'codesload'}
    for name,p in zip(pa_names,layout['pages']):
        payload = readback[name]
        assert struct.unpack_from('<I',payload)[0] == page_crc(payload)
        decoded = parse_page(payload)
        assert decoded.encode() == payload
        assert decoded.objects[0].name == p['name']
        assert len(decoded.objects) == len(p['components'])+1
        count = 0
        for idx,(obj,spec) in enumerate(zip(decoded.objects,[p]+p['components'])):
            assert obj.name == spec['name']
            assert int.from_bytes(obj.attr('id'),'little') == idx
            attrs = {cstr(k).decode():v for k,v in obj.attrs}
            for key,value in spec.get('attributes',{}).items():
                expected = value.encode('gbk') if isinstance(value,str) else int(value).to_bytes(len(attrs[key]),'little')
                assert attrs[key] == expected,(p['name'],obj.name,key)
            if 'rect' in spec:
                x,y,w,h = spec['rect']
                assert 0<=x<x+w<=1024 and 0<=y<y+h<=600
                for key,num in zip(('x','y','w','h','endx','endy'),(x,y,w,h,x+w-1,y+h-1)):
                    assert int.from_bytes(attrs[key],'little') == num
            if 'font' in attrs:
                assert int.from_bytes(attrs['font'],'little') < 3
            if 'sendkey' in attrs:
                assert int.from_bytes(attrs['sendkey'],'little') == 0
            used = set()
            decoded_events = dict(obj.events)
            for slot,path in spec.get('events',{}).items():
                native_slot = slots[slot]
                text = '\n'.join(line.decode('gbk') for line in decoded_events[native_slot])
                assert text.splitlines() == events[path].splitlines(),path
                (reconstructed/path).write_text(text+'\n',encoding='utf-8')
                used.add(native_slot)
                count += 1
            assert all(not lines for slot,lines in obj.events if slot not in used)
        event_count += count
        page_reports.append({'page':p['name'],'objects':len(decoded.objects),'event_scripts':count,
                             'crc':f'{page_crc(payload):08x}','sha256':sha(payload)})
    assert event_count == expected_event_count
    assert sha(donor.read_bytes()) == DONOR_HASH
    report = {
        'generated_at':datetime.now().astimezone().isoformat(),
        'status':'NATIVE_HMI_BINARY_GENERATED_NOT_EDITOR_COMPILED',
        'file':str(output.resolve()),'bytes':len(actual),'sha256':sha(actual),
        'model':layout['model'],'canvas':layout['size'],'encoding':'GBK / CP936 (donor model setting)',
        'baud':115200,'data_bits':8,'parity':'none','stop_bits':1,
        'pages':page_reports,'event_scripts':event_count,'container_entries':len(saved_records),
        'main_references':[cstr(r[8:]).decode() for r in refs],
        'checks':{'both_directory_crcs':True,'directory_mirrors':True,'main_crc':True,
                  'page_crcs':True,'saved_readback':True,'all_events_match_saved_source':True,
                  'model_header_preserved':True,'exact_five_project_pages':True,'no_old_demo_resources':True,
                  'original_donor_unchanged':True},
        'resources':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in readback.items()},
        'donor':str(donor.resolve()),'donor_sha256':DONOR_HASH,
        'official_editor_open_tested':False,'official_editor_compile_tested':False,
        'tft_generated':False,'physical_screen_tested':False,
        'limitations':['Native binary/CRC/source validation does not prove USART HMI compiler acceptance.',
                       'No GUI or vendor runtime was used; there is no physical touch/UART evidence for this HMI.']
    }
    report_path = output.with_suffix('.validation.json')
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(output),'bytes':len(actual),'pages':len(layout['pages']),'events':event_count,
                      'sha256':report['sha256'],'native_compiled':False},ensure_ascii=False))
    return report

if __name__=='__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--donor',type=Path,required=True)
    ap.add_argument('--delivery',type=Path,required=True)
    ap.add_argument('--fonts',type=Path,nargs=3,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args = ap.parse_args()
    build(args.donor,args.delivery,args.fonts,args.output)
