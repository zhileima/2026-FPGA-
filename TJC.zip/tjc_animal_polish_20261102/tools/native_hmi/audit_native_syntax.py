"""Independent static review against the local official TJC wiki and donor.

Not a vendor compiler, emulator, GUI check, or assertion of native openability.
Reads saved delivery source and actual candidate native pages; writes stage evidence.
"""
from pathlib import Path
from html import unescape
from zipfile import ZipFile
import hashlib,json,re
from native_codec import parse_page,cstr

H=Path(__file__).resolve().parents[2]
V=next(p for p in H.parents if p.name=='V1')
S=H/'source'
Z=V/'tjc串口屏资料/tjcwiki.zip'
layout=json.loads((S/'layout.json').read_text(encoding='utf-8'))
program=(S/'program.s').read_text(encoding='utf-8')
pages={p['name']:p for p in layout['pages']}
globals_=[];after_decl=False
checks=[];references=[];strings=[];static_frames=[]

def require(v,detail):
    if not v:raise AssertionError(detail)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

for line in program.splitlines():
    line=line.split('//',1)[0].strip()
    if not line:continue
    if line.startswith('int '):
        require(not after_decl,'global declaration after executable statement')
        for item in line[4:].split(','):
            m=re.fullmatch(r'([a-zA-Z_][a-zA-Z_0-9]*)=(-?\d+)',item)
            require(m is not None,('declaration',line))
            require(m[1] not in globals_,('duplicate global',m[1]))
            globals_.append(m[1])
    else:after_decl=True
require(globals_[:3]==['sys0','sys1','sys2'],'native defaults exactly once')
require(all(x in program for x in ['baud=115200','bkcmd=0','sendxy=0','recmod=0','page home']),'native startup configuration')

event_keys={'touch_press':'codesdown','touch_release':'codesup','timer':'codestimer','postinitialize':'codesloadend'}
bindings=[]
for i,page in enumerate(layout['pages']):
    native=parse_page((H/'candidate_pages'/f'{i}.pa').read_bytes())
    controls={x['name']:x for x in page['components']}
    native_by_name={x.name:x for x in native.objects}
    require(native.objects[0].name==page['name'],'native page name mismatch')
    require(len(native_by_name)==len(native.objects),'duplicate object name')
    require([int.from_bytes(x.attr('id'),'little') for x in native.objects]==list(range(len(native.objects))),'native sequential IDs')
    timers=[x for x in controls.values()if x['type']=='Timer']
    require({t['name']:t['attributes'] for t in timers}=={'tm0':{'tim':100,'en':1},'tx0':{'tim':50,'en':1}},'timer configuration')
    for owner in [{'name':page['name'],'events':page['events']}]+page['components']:
        obj=native_by_name[owner['name']]
        for key,path in owner.get('events',{}).items():
            text=(S/path).read_text(encoding='utf-8')
            expected=text.splitlines()
            got=[s.decode('gbk')for n,lines in obj.events if n==event_keys[key].encode()for s in lines]
            require(got==expected,('native event differs',path))
            bindings.append({'file':path,'page':page['name'],'object':owner['name'],
                             'object_id':int.from_bytes(obj.attr('id'),'little'),'event':event_keys[key],
                             'line_count':len(expected)})
            balance=0
            for line_no,raw in enumerate(expected,1):
                line=raw.strip();loc=f'{path}:{line_no}'
                if not line or line.startswith('//'):continue
                require(not line.endswith(';'),('unsupported trailing semicolon',loc))
                for literal in re.findall(r'0x([0-9A-Fa-f]+)',line):require(len(literal)%2==0,('odd hex literal',loc))
                bare=re.sub(r'"[^"\r\n]*"','""',line)
                require(bare.count('"')==line.count('"'),('unbalanced quotes',loc))
                balance+=bare.count('{')-bare.count('}')
                require(balance>=0,('closing brace',loc))
                if bare in ('{','}','}else','else'):continue
                if line.startswith('page '):
                    require(line[5:] in pages,('unknown target',loc,line));continue
                if line.startswith('printh '):
                    require(re.fullmatch(r'printh [0-9A-Fa-f]{2}(?: [0-9A-Fa-f]{2})*',line) is not None,('printh grammar',loc))
                    data=bytes.fromhex(line[7:])
                    if len(data)==5:
                        require(data[0]==0xA5 and data[-1]==0x5A and data[3]==data[0]^data[1]^data[2],('5 byte checksum',loc))
                        static_frames.append({'file':path,'line':line_no,'hex':data.hex(' ')})
                    continue
                if line.startswith('prints '):
                    require(re.fullmatch(r'prints (txarg|txchk),1',line) is not None,('dynamic low byte print',loc))
                else:
                    require(not re.search(r'\s',bare),('extra space outside string',loc))
                for objname,prop in re.findall(r'([A-Za-z_]\w*)\.([A-Za-z_]\w*)',bare):
                    require(objname in controls,('unresolved local object',loc,objname))
                    require(prop in ('txt','bco','val','pco','pco2'),('unexpected runtime property',loc,prop))
                    require(any(cstr(n).decode()==prop for n,_ in native_by_name[objname].attrs),('missing native property',loc,prop))
                    references.append({'file':path,'line':line_no,'object':objname,'property':prop})
                scrub=re.sub(r'\b[A-Za-z_]\w*\.[A-Za-z_]\w*\b','',bare)
                scrub=re.sub(r'0x[0-9A-Fa-f]+','',scrub)
                for token in re.findall(r'\b[A-Za-z_]\w*\b',scrub):
                    require(token in globals_ or token in ('if','else','prints'),('unknown identifier',loc,token))
                require(re.match(r'sys[01](?:[+\-^&|]?=|\+\+|--)',bare) is None,('event overwrites FPGA status',loc))
                m=re.fullmatch(r'(\w+)\.txt="([^"\r\n]*)"',line)
                if m:
                    capacity=controls[m[1]]['attributes']['txt_maxl']
                    used=len(m[2].encode('gbk'))
                    require(used<=capacity,('text capacity',loc,used,capacity))
                    strings.append({'file':path,'line':line_no,'object':m[1],'gbk_bytes':used,'capacity':capacity})
            require(balance==0,('unbalanced braces',path))
    for control in controls.values():
        if 'txt' in control['attributes']:
            used=len(control['attributes']['txt'].encode('gbk'))
            require(used<=control['attributes']['txt_maxl'],('initial text capacity',page['name'],control['name']))
        if control['type']=='Slider':
            require((control['attributes']['minval'],control['attributes']['maxval'])==(0,4 if control['name']=='hzoom' else 100),'slider range')
            require(0<=control['attributes']['val']<=100,'slider initial value')
require(len(bindings)==71,'all authored events')
require(set(x['file']for x in bindings)==set(p.relative_to(S).as_posix()for p in (S/'events').glob('*.txt')),'unbound event file')
require(len(globals_)*4<1024,'global integer memory count')

official_paths=['grammar/arithmetic_operation','grammar/assignment_operation','grammar/global_variable',
                'variables/sys0-sys2','variables/baud','variables/bkcmd','variables/recmod',
                'widgets/Timer','widgets/Button','widgets/Text','widgets/Number','widgets/Slider',
                'commands/prints','commands/printh','commands/page']
evidence=[]
with ZipFile(Z) as z:
    for path in official_paths:
        name='tjcwiki/'+path+'.html'
        if name not in z.namelist():continue
        raw=z.read(name);html=raw.decode('utf-8')
        main=html[html.find('<div role="main"'):];main=main[:main.find('<footer>')]
        text=re.sub(r'\s+',' ',unescape(re.sub('<[^>]+>',' ',main))).strip()
        evidence.append({'zip_entry':name,'sha256':hashlib.sha256(raw).hexdigest(),'text':text})
(H/'syntax_official_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
result={'result':'PASS_STATIC_REVIEW','native_editor_opened':False,'native_compiled':False,
        'scope':'Saved Program.s plus 71 source events and five corresponding native candidate .pa files',
        'globals':globals_,'global_bytes':len(globals_)*4,'pages':5,'events':len(bindings),
        'runtime_property_references':len(references),'dynamic_text_assignments':len(strings),
        'max_dynamic_text_gbk_bytes':max(s['gbk_bytes']for s in strings),
        'bindings':bindings,'text_capacity_checks':strings,'static_frames':static_frames,
        'sys0_max':(9<<15)+(5<<12)+4095,'sys1_max':100+(100<<7)+(100<<14),
        'findings':[],
        'boundaries':['Static evidence is not vendor compilation or screen execution.',
                      'New ZI font validation and final container/main indices are reviewed separately.',
                      'Source changed for direct touch settings, thumbnail control, committed chapter synchronization and animal listening.'],
        'source_hashes':{str(p):sha(p)for p in [S/'program.s',S/'layout.json',*sorted((S/'events').glob('*.txt')),
            *sorted((H/'candidate_pages').glob('*.pa')),Z,H/'Program.s',Path(__file__)]}}
(H/'syntax_review_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'PASS static syntax/bindings: {len(globals_)} globals, 71 events, {len(references)} property refs, {len(strings)} strings; no native compile performed')
