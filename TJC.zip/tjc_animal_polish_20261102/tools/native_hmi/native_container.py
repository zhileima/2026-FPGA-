"""Conservative, append-only editor for verified TJC native CFS containers.

No vendor process, loader, GUI, serial port, or application API is used.
CRC algorithms were verified against both donor directories and 21 pages.
Does not claim native editor acceptance or infer unknown per-record bytes.
"""
from dataclasses import dataclass
import struct
from crc_review import cfs_crc

DIRECTORY_OFFSETS = (0, 0x80000)
DATA_START = 0x700000
RECORD_SIZE = 28

@dataclass(frozen=True)
class Record:
    index: int
    name: str
    offset: int
    length: int
    raw: bytes

    @property
    def live(self):
        return self.raw[24] == 0

def parse_container(raw):
    if len(raw) < DATA_START or raw[0x6ffff8:0x700000] != b'ver21234':
        raise ValueError('Not the verified native CFS container layout')
    if raw[0x380000:0x380004] != b'\xff'*4:
        raise ValueError('Nonempty secondary table is outside this writer contract')
    count = struct.unpack_from('<I', raw, 0)[0]
    table_len = 4 + count*RECORD_SIZE + 4
    if not 0 < count < 10000 or table_len > 0x80000:
        raise ValueError('Invalid native directory count')
    if raw[:table_len] != raw[0x80000:0x80000+table_len]:
        raise ValueError('Directory mirrors differ; do not guess active table')
    for off in DIRECTORY_OFFSETS:
        if struct.unpack_from('<I',raw,off+table_len-4)[0] != cfs_crc(raw,off):
            raise ValueError('Native directory CRC mismatch')
    result = []
    for index in range(count):
        r = bytes(raw[4+index*28:4+(index+1)*28])
        name = r[:16].split(b'\0')[0].decode('ascii')
        start,size = struct.unpack_from('<II',r,16)
        if start < DATA_START or start+size > len(raw):
            raise ValueError(f'Invalid payload bounds: {name}')
        result.append(Record(index,name,start,size,r))
    return result

def append_replace(raw, replacements, additions=()):
    """Return new bytes, retaining old payloads and all unrelated metadata.

    replacements: mapping existing LIVE entry name -> already serialized bytes.
    additions: optional iterable (new_name, payload, donor_record_raw).  The
    caller must supply a compatible record template; unknown final three
    bytes are preserved and the first flag byte is explicitly set to live=0.
    Page CRC and main resource table must be maintained by the caller.
    """
    records = parse_container(raw)
    out = bytearray(raw)
    new_records = [bytearray(r.raw) for r in records]
    used_names = {r.name for r in records}
    changes = []
    for name,payload in replacements.items():
        payload = bytes(payload)
        matches = [r for r in records if r.name == name and r.live]
        if len(matches) != 1:
            raise ValueError(f'Expected exactly one live entry named {name}')
        old = matches[0]
        if payload == raw[old.offset:old.offset+old.length]:
            continue
        start = len(out)
        out.extend(payload)
        struct.pack_into('<II',new_records[old.index],16,start,len(payload))
        changes.append(name)
    for name,payload,template in additions:
        encoded = name.encode('ascii')
        if name in used_names or not 0 < len(encoded) <= 16 or len(template) != RECORD_SIZE:
            raise ValueError(f'Invalid addition: {name}')
        rec = bytearray(template)
        rec[:16] = encoded.ljust(16,b'\0')
        payload = bytes(payload)
        struct.pack_into('<II',rec,16,len(out),len(payload))
        rec[24] = 0
        new_records.append(rec)
        out.extend(payload)
        used_names.add(name)
        changes.append(name)
    if not changes:
        return bytes(raw)
    table = struct.pack('<I',len(new_records)) + b''.join(new_records)
    if len(table)+4 > 0x80000:
        raise ValueError('Directory capacity exceeded')
    for off in DIRECTORY_OFFSETS:
        out[off:off+len(table)] = table
        struct.pack_into('<I',out,off+len(table),cfs_crc(out,off))
    verified = parse_container(out)
    for name,payload in replacements.items():
        entry = next(r for r in verified if r.name == name and r.live)
        if out[entry.offset:entry.offset+entry.length] != payload:
            raise AssertionError(f'Replacement readback mismatch: {name}')
    return bytes(out)

def compact_selected(raw, payloads):
    """Rebuild a compact native project from an ordered name->payload mapping.

    Every selected name must have exactly one live donor record so all opaque
    record bytes are retained. Keeps all non-directory reserved bytes below
    0x700000 unchanged, and discards old payloads and unused directory rows.
    Unlike append_replace, no stale demo resources remain in the output.
    Caller maintains the main.HMI resource list and every payload's own CRC.
    """
    old_records = parse_container(raw)
    if not payloads or not {'main.HMI','Program.s'} <= set(payloads):
        raise ValueError('A project requires main.HMI and Program.s')
    table_len = 4 + len(payloads)*RECORD_SIZE + 4
    if table_len > 0x80000:
        raise ValueError('Directory capacity exceeded')
    old_table_len = 4 + len(old_records)*RECORD_SIZE + 4
    out = bytearray(raw[:DATA_START])
    new_records = []
    for name,payload in payloads.items():
        matches = [r for r in old_records if r.name==name and r.live]
        if len(matches)!=1:
            raise ValueError(f'Expected exactly one live donor entry {name}')
        old = matches[0]
        rec = bytearray(old.raw)
        payload = bytes(payload)
        struct.pack_into('<II',rec,16,len(out),len(payload))
        new_records.append(rec)
        out.extend(payload)
    table = struct.pack('<I',len(new_records))+b''.join(new_records)
    for off in DIRECTORY_OFFSETS:
        span = max(old_table_len,table_len)
        out[off:off+span] = bytes(span)
        out[off:off+len(table)] = table
        struct.pack_into('<I',out,off+len(table),cfs_crc(out,off))
    rebuilt = parse_container(out)
    if [r.name for r in rebuilt] != list(payloads):
        raise AssertionError('Compact directory order mismatch')
    for r in rebuilt:
        if not r.live or out[r.offset:r.offset+r.length] != payloads[r.name]:
            raise AssertionError(f'Compact payload mismatch: {r.name}')
    return bytes(out)
