"""Lossless codec for the observed TJC1060X570 donor page/container records.

Pure byte processing only; no vendor executable, loader, GUI or .NET execution.
Unknown header fields are preserved. PageSafe CRC is recalculated with the
separate, donor-verified pure byte implementation. Main HMISafe CRC is also
recalculated. The caller must apply container checksum rules and validate the edited HMI in its native
editor before calling it usable. Public helper libraries are not imported.
"""
from dataclasses import dataclass
from copy import deepcopy
import struct
from crc_review import page_crc,main_crc

def u32(b,p=0):return struct.unpack_from('<I',b,p)[0]
def lp(b):return struct.pack('<I',len(b))+b
def cstr(b):return b.split(b'\0',1)[0]

@dataclass
class Component:
    attrs:list  # ordered [raw16-byte-name, raw-value]
    events:list # ordered [event-prefix bytes, list[raw-line bytes]]
    trailer:bytes=b'\0\0\0\0'

    def attr(self,name):
        key=name.encode('ascii')
        return next(v for n,v in self.attrs if cstr(n)==key)
    @property
    def name(self):return self.attr('objname').decode('ascii')
    @property
    def type(self):return int.from_bytes(self.attr('type'),'little')
    def set(self,name,value,encoding='gbk'):
        key=name.encode('ascii')
        for i,(n,old) in enumerate(self.attrs):
            if cstr(n)==key:
                raw=value.encode(encoding) if isinstance(value,str) else bytes(value) if isinstance(value,(bytes,bytearray)) else int(value).to_bytes(len(old),'little')
                self.attrs[i]=(n,raw);return self
        raise KeyError(f'No donor property {name}; refusing to invent property width')
    def set_event(self,name,lines,encoding='gbk'):
        key=name.encode('ascii')
        lines=lines.splitlines() if isinstance(lines,str) else lines
        raw=[s.encode(encoding) if isinstance(s,str) else bytes(s) for s in lines]
        for i,(n,_) in enumerate(self.events):
            if n==key:self.events[i]=(n,raw);return self
        raise KeyError(f'No donor event {name}')
    def clear_events(self):
        self.events=[(n,[])for n,_ in self.events];return self
    def clone(self):return deepcopy(self)
    def encode(self):
        out=lp(f'att-{len(self.attrs)}'.encode())
        for n,v in self.attrs:
            assert len(n)==16;out+=lp(n+v)
        for name,lines in self.events:
            out+=lp(name+b'-'+str(len(lines)).encode())
            out+=b''.join(lp(s)for s in lines)
        return out+self.trailer

def parse_component(blob):
    pos=0
    def take():
        nonlocal pos
        assert pos+4<=len(blob)
        n=u32(blob,pos);pos+=4
        assert pos+n<=len(blob)
        s=blob[pos:pos+n];pos+=n;return s
    marker=take();assert marker.startswith(b'att-')
    count=int(marker[4:]);attrs=[];events=[]
    for _ in range(count):
        raw=take();assert len(raw)>=16
        attrs.append((raw[:16],raw[16:]))
    while True:
        marker=take()
        if not marker:break
        name,count=marker.rsplit(b'-',1);assert name.startswith(b'codes')
        events.append((name,[take()for _ in range(int(count))]))
    assert pos==len(blob),(pos,len(blob))
    return Component(attrs,events)

@dataclass
class Page:
    header:bytes
    objects:list
    index_opaque:list
    def clone(self):return deepcopy(self)
    def encode(self):
        assert len(self.header)==56
        encoded=[o.encode()for o in self.objects]
        n=len(encoded);position=n*12;index=bytearray()
        for i,raw in enumerate(encoded):
            opaque=self.index_opaque[i] if i<len(self.index_opaque) else 0
            index.extend(struct.pack('<III',position,len(raw),opaque));position+=len(raw)
        head=bytearray(self.header)
        struct.pack_into('<I',head,4,56+position)
        struct.pack_into('<I',head,12,n)
        name=self.objects[0].attr('objname');assert len(name)<=16
        head[24:40]=name.ljust(16,b'\0')
        out=bytearray(bytes(head)+bytes(index)+b''.join(encoded))
        struct.pack_into('<I',out,0,page_crc(out))
        return bytes(out)

def parse_page(blob):
    assert u32(blob,4)==len(blob)
    header_len=u32(blob,8);assert header_len==56
    n=u32(blob,12);objects=[];opaque=[];expected=n*12
    for i in range(n):
        off,size,z=struct.unpack_from('<III',blob,56+i*12)
        assert off==expected and size>0 and off+size+56<=len(blob)
        objects.append(parse_component(blob[56+off:56+off+size]));opaque.append(z)
        expected+=size
    assert expected+56==len(blob)
    return Page(blob[:56],objects,opaque)

def parse_directory(blob):
    count=u32(blob);assert count<100000
    rows=[]
    for i in range(count):
        r=blob[4+i*28:32+i*28];assert len(r)==28
        off,size=struct.unpack_from('<II',r,16)
        assert off+size<=len(blob)
        rows.append(dict(index=i,name=cstr(r[:16]).decode('ascii'),offset=off,size=size,
                         deleted=r[24],opaque3=r[25:28],raw=r))
    return rows

def parse_main(blob):
    header_len=u32(blob,4);assert header_len==96
    records=[blob[i:i+16]for i in range(header_len,len(blob),16)]
    assert all(len(r)==16 for r in records) and len(records)==u32(blob,28)
    return blob[:96],records

def encode_main(header,records):
    assert len(header)==96 and all(len(r)==16 for r in records)
    head=bytearray(header);struct.pack_into('<I',head,28,len(records))
    out=bytearray(bytes(head)+b''.join(records))
    struct.pack_into('<I',out,0,main_crc(out))
    return bytes(out)

def filtered_main(original,pa_names,zi_names):
    """Keep model/header, choose ordered pages/fonts, recalculate HMISafe CRC."""
    header,records=parse_main(original)
    selected=[]
    for kind,names in ((b'zi',zi_names),(b'pa',pa_names)):
        for name in names:
            assert len(name.encode('ascii'))<=8
            donor=next(r for r in records if cstr(r[:8])==kind)
            selected.append(donor[:8]+name.encode('ascii').ljust(8,b'\0'))
    return encode_main(header,selected)

TYPE_DONORS={'Page':('0.pa',0),'Button':('0.pa',1),'Timer':('0.pa',11),
             'Text':('10.pa',7),'Number':('10.pa',4),'Slider':('14.pa',2)}

def donor_component(pages,kind):
    file,index=TYPE_DONORS[kind]
    obj=pages[file].objects[index]
    # Number index is discovered below, protecting against reordered donors.
    expected={'Page':0x79,'Button':0x62,'Timer':0x33,'Text':0x74,'Number':0x36,'Slider':1}[kind]
    if obj.type!=expected:obj=next(o for p in pages.values()for o in p.objects if o.type==expected)
    return obj.clone()

def build_layout_page(pages,layout,encoding='gbk',event_text=None):
    """Make one schema-valid candidate, preserving each donor property's width.
    event_text maps source/events filenames to decoded strings.
    Name/IDs/geometry/type/events are synchronized; Page.encode updates CRC.
    """
    page=pages['0.pa'].clone();page.objects=[];page.index_opaque=[]
    root=donor_component(pages,'Page').clear_events()
    root.set('objname',layout['name']).set('id',0).set('vscope',0)
    root.set('sta',1).set('bco',layout['background']).set('pic',65535)
    root.set('effect',0).set('left',255).set('right',255).set('up',255).set('down',255)
    root.set('drag',0).set('lockobj',0).set('sendkey',0)
    page.objects.append(root)
    event_keys={'touch_press':'codesdown','touch_release':'codesup','timer':'codestimer',
                'postinitialize':'codesloadend','preinitialize':'codesload'}
    if event_text:
        for name,file in layout.get('events',{}).items():root.set_event(event_keys[name],event_text[file],encoding)
    for index,control in enumerate(layout['components'],1):
        obj=donor_component(pages,control['type']).clear_events()
        obj.set('id',index).set('objname',control['name']).set('vscope',0)
        for raw_name,_ in list(obj.attrs):
            name=cstr(raw_name).decode('ascii')
            if name in ('drag','lockobj','sendkey','effect','movex','movey'):obj.set(name,0)
            if name.startswith('pic'):obj.set(name,65535)
        for prop,value in control['attributes'].items():obj.set(prop,value,encoding)
        if 'rect' in control:
            x,y,w,h=control['rect']
            for prop,value in zip(('x','y','w','h','endx','endy'),(x,y,w,h,x+w-1,y+h-1)):obj.set(prop,value)
            obj.set('sendkey',0).set('effect',0).set('lockobj',0)
        if event_text:
            for name,file in control.get('events',{}).items():obj.set_event(event_keys[name],event_text[file],encoding)
        page.objects.append(obj)
    return page
