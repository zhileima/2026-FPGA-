# HMI 后台封装来源与验证

本项目由同型号用户模板重建。原模板 SHA-256：
ebeb4c84ed10064836ed9772a64ab9d7ab17bbd33f4618f48b18645e9d9eb476。
原文件保持不变。

- `native_codec.py`：按实际模板实现长度前缀和属性宽度读写；原 21 页/297 个对象逐字节往返吻合。
- `crc_review.py`、`native_container.py`：原页面、main、两份目录 CRC 全部验证；主目录和镜像、保留区、模板型号字段按原格式写回。
- `native_font_render.py` 改编自 MIT 项目 YXerer668/tjc-usart-hmi-toolchain 的 zi_font.py；改用 Windows936 字符映射，并纠正 3-bit shade7 的255端点。许可证在同目录。
- 字体来自随包 Noto Sans CJK SC，遵循 assets/FONT_LICENSE.txt。完整字库由本地编译的公开 ZiLib 后台生成，未启动图形界面；源代码和命令保存在原工作区 hmi_native_20261028/font_audit。

格式与算法参考：
https://github.com/eseverson/nextion-hmi/blob/main/findings/format-hmi.md
https://github.com/eseverson/nextion-hmi/blob/main/findings/main-hmi-config.md
https://github.com/YXerer668/tjc-usart-hmi-toolchain
https://github.com/hagronnestad/nextion-font-editor

新字体曾在离线解码比较中出现255与252的差异；已定位为预览解码器端点量化问题。修正解码器后，全部286所需字符与高画布探针逐像素一致，没有修改字体二进制。旧失败报告保留在工作区。

所有检查均未调用厂商 GUI/编译器，未修改安装程序、许可证、功能开关或注册信息。项目的官方打开、编译与实际触摸屏联调仍需独立验证。
