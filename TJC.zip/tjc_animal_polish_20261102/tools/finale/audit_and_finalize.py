from pathlib import Path
import hashlib,json,sys,subprocess,shutil
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_animal_finale_20261102';S=D/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
sys.path.insert(0,str(D/'tools/native_hmi'));from native_container import parse_container
hmi=next(D.glob('*.HMI'));raw=hmi.read_bytes();digest=sha(hmi)
(D/'candidate_pages').mkdir(exist_ok=True)
for p in parse_container(raw):
    if p.live and p.name.endswith('.pa'):(D/'candidate_pages'/p.name).write_bytes(raw[p.offset:p.offset+p.length])
p=D/'tools/native_hmi/audit_native_syntax.py';t=p.read_text('utf-8')
t=t.replace('len(bindings)==65','len(bindings)==71').replace('65 source events and four','71 source events and five').replace("'pages':4","'pages':5").replace('65 events','71 events')
p.write_text(t,'utf-8')
subprocess.run([sys.executable,'-B',str(p)],check=True)
p=D/'tools/native_hmi/audit_font_and_render.py';t=p.read_text('utf-8')
t=t.replace('for i in range(4):','for i in range(5):').replace("contact=Image.new('RGB',(1024,600))","contact=Image.new('RGB',(1024,900))").replace('四页字库回读总览','五页字库回读总览')
p.write_text(t,'utf-8')
subprocess.run([sys.executable,'-B',str(p)],check=True)
font=json.loads((D/'font_and_render_validation.json').read_text('utf-8'));assert font['passed']
font['hmi_sha256']=digest;dump(D/'font_and_render_validation.json',font)
tests=json.loads((D/'validation/event_tests.json').read_text('utf-8'));assert tests['passed'] and tests['hmi_sha256']==digest
dump(S/'validation.json',{'passed':True,'hmi_sha256':digest,'native_events':71,'native_objects':tests['native_objects'],'event_tests':'../validation/event_tests.json','font_checks':'../font_and_render_validation.json','official_compiler':False,'physical_board':False})
dump(S/'source_manifest.json',{'version':'tjc_animal_finale_20261102','hmi_sha256':digest,'files':{str(p.relative_to(D)):sha(p)for p in sorted(S.rglob('*'))if p.is_file() and p.name!='source_manifest.json'}})
(D/'tools/finale').mkdir(exist_ok=True)
for name in ('build_finale.py','test_finale.py','audit_and_finalize.py'):shutil.copy2(R/name,D/'tools/finale'/name)
(D/'README.md').write_text('''# 声音侦探社：完整探案版

原生工程适用于 TJC1060X570 横屏 1024×600。五个页面为：首页、八章地图、探案、播放设置、探案终章。匹配本轮 FPGA 的 05 特殊页协议后使用；旧固件不支持新结尾命令。

首页“开始探案”明确进入第1章。八章仍可分别试听 A/B、重新试听与确认发现。第8章确认后保留结果，点击“完成探案”才进入结尾；结尾可重新探案、回顾八章或返回首页。

05/0返回启动首页待启动，05/1进入结尾，两者停止轮播并保留参数、媒体缓存和首次访问记录；重新探案04/0并不重新获得各章首次自动试听。只有播放设置中的复位2C才清访问记录并恢复默认值。设置页的返回操作不发送额外开始或试听指令。

屏端是单向控制器，不接收 FPGA 状态。板载按键与屏可独立驱动；板载按键更改后，屏端数字不会自动反映板端值。需要重新对齐时，从屏显式选择章节或设置所需数值。未增加 ACK、心跳或无限重试；本轮响应可靠性修正在配套 FPGA 的事件保存和忙碌时处理。

六项参数仍各自保存最终值，跨页继续发送；缩放100%～200%，其余0～100。屏端八章自动轮播保持循环，手动完成探案将停止轮播。

本目录已进行原生容器/CRC/事件回读、全部参数值及多次页面切换模型测试、三套字库与五页离线绘制检查。这些证据不代表官方编译或实体板卡通过；官方 USART HMI 编译由主代理完成，屏幕下载按用户指定自行操作。
''','utf-8')
dump(D/'validation/delivery.json',{'saved':True,'hmi':str(hmi),'sha256':digest,'bytes':len(raw),'pages':5,'events':71,'objects':tests['native_objects'],'native_event_model_passed':True,'font_render_passed':True,'official_compiled':False,'screen_downloaded':False,'physical_pass':False,'required_paired_protocol':'05/0 START waiting;05/1 END;04/0 firstchapter;2C realreset'})
print((D/'validation/delivery.json').read_text('utf-8'))
