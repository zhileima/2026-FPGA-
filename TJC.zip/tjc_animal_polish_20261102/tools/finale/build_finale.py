"""Saved-source, native-only ending-page candidate. No UI or hardware changes."""
from pathlib import Path
import copy,hashlib,json,re,shutil,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent
V=next(p for p in R.parents if p.name=='V1')
B=V/'tjc_interaction_polish_20261101'
D=V/'tjc_animal_finale_20261102'
S=D/'source'
NAME='声音侦探社_动物互动_完整探案版_TJC1060X570.HMI'
BASE_HASH='2a064e4be19a7db7286b5a7f3500b569f87de46c5932fa015e8b80490e2656b5'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')

def send(cmd,expr):
    return f'txarg={expr}\ntxchk=165^{cmd}\ntxchk^=txarg\nprinth A5 {cmd:02X}\nprints txarg,1\nprints txchk,1\nprinth 5A\n'

def chapter(expr='scene'):
    return f'scene={expr}\nended=0\nstarted=1\nsel=0\nconfirmed=0\ncorrect=0\nthumb=0\nfocus=scene\nautoticks=0\ndirty=1\n'+send(4,'scene')

def home():
    return 'started=0\nended=0\nautoplay=0\nthumb=0\nautoticks=0\ndirty=1\nprinth A5 05 00 A0 5A\npage home\n'

def end():
    return 'started=0\nended=1\nautoplay=0\nthumb=0\nautoticks=0\ndirty=1\nprinth A5 05 01 A1 5A\npage ending\n'

def main():
    R.mkdir(parents=True,exist_ok=True)
    assert sha(next(B.glob('*.HMI')))==BASE_HASH
    before={str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if not (R/'before').exists():
        (R/'before').mkdir()
        shutil.copytree(B/'source',R/'before/source')
        shutil.copy2(next(B.glob('*.HMI')),R/'before')
        dump(R/'before/manifest.json',{'hmi_sha256':BASE_HASH,'files':before})
    for folder in ('source','assets','tools'):
        shutil.copytree(B/folder,D/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    events={p.name:p.read_text('utf-8') for p in (S/'events').glob('*.txt')}
    # Existing actions stay wire-compatible; fixes live in the paired FPGA.
    # Local state is updated before each page jump because page terminates the event.
    for name,text in list(events.items()):
        if 'printh A5 04\n' in text:
            text=text.replace('started=1\n','ended=0\nstarted=1\n')
        text=text.replace('if(started==1&&autoplay==1&&thumb==0)','if(started==1&&autoplay==1&&thumb==0&&ended==0)')
        events[name]=text
    events['home__bstart__release.txt']=chapter('0')+'page task\n'
    events['chapters__btask__release.txt']=chapter()+'page task\n'
    events['chapters__bhome__release.txt']=home()
    events['settings__bback__release.txt']='editing=0\ndirty=1\nif(ended==1)\n{\npage ending\n}\nif(started==1)\n{\npage task\n}\npage home\n'
    # Reveal stays on-screen. The following deliberate button enters the finale.
    # Earlier chapters retain the established optional-skip behavior.
    events['task__bnext__release.txt']='if(scene==7)\n{\nif(confirmed==1)\n{\n'+end()+'}\nresult.txt="先确认发现，再完成本次探案。"\nresult.pco=65201\n}else\n{\n'+chapter('scene+1')+'page task\n}\n'
    for name,text in list(events.items()):
        if name.startswith('task__'):
            text=text.replace('bnext.txt="下一章"\n','bnext.txt="下一章"\nif(scene==7)\n{\nbnext.txt="完成探案"\n}\n')
            text=text.replace('bnext.txt="进入下一章"\n','bnext.txt="进入下一章"\nif(scene==7)\n{\nbnext.txt="完成探案"\n}\n')
        # No false implication that the home start button resumes an old chapter.
        text=text.replace('本地探案进行中，点击继续。','点击开始探案，从第一章出发。')
        text=text.replace('点击开始探索；单向发送控制。','点击开始探案，从第一章出发。')
        text=text.replace('点击开始探案；单向发送控制。','点击开始探案，从第一章出发。')
        if name=='settings__breset__release.txt':text='ended=0\n'+text
        if name=='settings__bthumb__release.txt':text=text.replace('thumb=1\n','ended=0\nthumb=1\n')
        events[name]=text
    layout=json.loads((S/'layout.json').read_text('utf-8'))
    ending=copy.deepcopy(layout['pages'][0])
    ending['name']='ending';ending['id']=4
    ending['events']={'postinitialize':'events/ending__postinitialize.txt'}
    labels={
        'pageid':'05 / 探案终章','eyebrow':'声音科学 / 今日发现',
        'tagline':'探案完成，听见新世界',
        'intro':'阿光与小猫，为每一种声音找到名字。',
        'hint':'把好奇带回生活，下一条线索就在身边。',
        'step0':'01  听见','step1':'02  分辨','step2':'03  发现',
        'catcaption':'小猫侦探：下次再见！',
        'bstart':'重新探案','bchap':'回顾八章','bset':'返回首页',
        'status':'八章线索已收录。保持好奇，继续发现声音的秘密。'}
    for c in ending['components']:
        if c['name'] in labels:c['attributes']['txt']=labels[c['name']]
        if c.get('events'):c['events']={slot:path.replace('home__','ending__') for slot,path in c['events'].items()}
    layout['pages'].append(ending)
    events['ending__postinitialize.txt']='editing=0\ndirty=0\n'
    events['ending__bstart__release.txt']=chapter('0')+'page task\n'
    events['ending__bchap__release.txt']='dirty=1\npage chapters\n'
    events['ending__bset__release.txt']=home()
    events['ending__tm0__timer.txt']='dirty=0\n'
    events['ending__tx0__timer.txt']=events['home__tx0__timer.txt']
    program=(S/'program.s').read_text('utf-8').replace('int scene=0,','int ended=0\nint scene=0,')
    (S/'program.s').write_text(program,'utf-8');(D/'Program.s').write_text(program,'utf-8')
    for name,text in events.items():
        assert 'printh A5 01 ' not in text,name
        assert not any(x in text for x in ('syncack','resetphase','printh A5 28'))
        (S/'events'/name).write_text(text,'utf-8')
    dump(S/'layout.json',layout)
    chars=set((S/'font_characters.txt').read_text('utf-8'))
    for text in events.values():
        for literal in re.findall(r'"([^"\n]*)"',text):chars.update(literal)
    for p in layout['pages']:
        for c in p['components']:chars.update(c.get('attributes',{}).get('txt',''))
    (S/'font_characters.txt').write_text(''.join(sorted(chars)),'utf-8')
    protocol=json.loads((S/'protocol.json').read_text('utf-8'))
    protocol['commands']['absolute_special_page']=5
    protocol['special_page']={'start':0,'end':1,'preserve_on_05':['parameters','media_cache','first_visit_mask'],
        'full_reset':'2C clears parameters and visited mask; 05 does not reset',
        'home_start':'04 ARG0 with local scene0, A, unconfirmed; no01 or implicit10',
        'last_chapter':'Confirm reveals the result. Completion button then sends05 ARG1; no scene8/9 indexing.',
        'settings_back':'local navigation only, preserving current screen chapter/choice/ending context',
        'ending_restart':'04 ARG0; does not promise first-visit autoplay again',
        'autoplay':'existing eight chapters loop; manual final completion ends the loop'}
    protocol['reliability']='No extra retry, ACK or heartbeat. Paired FPGA fixes event retention during renderer restart/menu and readiness.'
    dump(S/'protocol.json',protocol)
    dump(S/'control_event_map.json',{p['name']:{c['name']:c['events'] for c in [p]+p['components'] if c.get('events')} for p in layout['pages']})
    (S/'IMPORT_MANIFEST.md').write_text('# 完整探案版原生 HMI\n\n五页：home/chapters/task/settings/ending。05/0返回启动页，05/1进入结尾；04/0开始第一章。2C为真正复位，05保留参数和访问记录。单向发送，不新增ACK或重试。官方编译与实板仍需主代理独立验证。\n','utf-8')
    # Update only this candidate's builder, retaining native readback checks.
    p=D/'tools/native_hmi/build_native_hmi.py';t=p.read_text('utf-8')
    t=t.replace("== ['home','chapters','task','settings']","== ['home','chapters','task','settings','ending']")
    t=t.replace('range(4)','range(len(layout[\'pages\']))').replace('len(saved_records) == 9','len(saved_records) == 10')
    t=t.replace("'only_four_project_pages':True","'exact_five_project_pages':True")
    t=t.replace("'pages':4,","'pages':len(layout['pages']),")
    p.write_text(t,'utf-8')
    sys.path.insert(0,str(D/'tools/native_hmi'))
    from build_native_hmi import build
    native=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ('0.zi','3.zi','6.zi')],D/NAME)
    (D/'validation').mkdir(exist_ok=True)
    dump(D/'validation/build_result.json',{'passed':True,'hmi_sha256':native['sha256'],'events':len(events),'pages':5,'baseline_sha256':BASE_HASH,'official_compiled':False,'physical_pass':False})
    assert all(sha(B/name)==digest for name,digest in before.items())
    print(json.dumps({'saved':str(D/NAME),'sha256':native['sha256'],'events':len(events),'old_delivery_unchanged':True},ensure_ascii=False))

if __name__=='__main__':main()
