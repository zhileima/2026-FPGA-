"""Promote the validated saved native candidate into its new independent delivery."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent
V=next(p for p in R.parents if p.name=='V1')
C=R/'candidate';D=V/'tjc_oneway_control_20261101';B=V/'tjc_recovery_layers_20261101'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
assert not D.exists(),D
original=next(B.glob('*.HMI'))
historical='a6ab2329478b2229b7f246e893b9da17b514865e7b8f8996fe26c9f8959d5b9b'
try:
    original_now=sha(original);assert original_now==historical
except PermissionError:
    original_now=None # Official editor owns the old file; do not touch that file or UI.
base_source={str(p.relative_to(B)):sha(p) for p in (B/'source').rglob('*') if p.is_file()}
shutil.copytree(C,D,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
hmi=next(D.glob('*.HMI'));digest=sha(hmi)
assert digest=='36071431152370f0f0dc37192b8c58b7a28c669e20af4d3f4a16af33aeba23f9'
assert sha(hmi)==sha(C/hmi.name)
for p in C.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':assert sha(D/p.relative_to(C))==sha(p),p
receipt=next(D.glob('*.validation.json'));data=json.loads(receipt.read_text('utf-8'))
data['file']=str(hmi);data['promotion_from']=str(C/hmi.name);dump(receipt,data)
build=D/'validation/build_result.json';data=json.loads(build.read_text('utf-8'));data['hmi']=str(hmi);dump(build,data)
protocol=D/'source/protocol.json';data=json.loads(protocol.read_text('utf-8'))
data['autoplay']['fpga_requirement']='TJC29 or04 selects screen ownership and disables FPGA autonomous chapter advance; board KEY4 may independently select board ownership/automatic advance.29 and2A retain OSD style/speed. Without return communication the screen cannot detect board-key ownership changes.'
data['control_entry_rule']='Use one automatic-control entry at a time. Disable screen autoplay before using board-key autoplay; screen local values do not follow board keys.'
dump(protocol,data)
readme=D/'README.md'
readme.write_text('''# 单向主控版

屏端本地保存章节、A/B选择、确认结果和六项参数；点击立即更新屏并发送命令。显示的是本地设定，“已发送”不代表开发板已执行。无状态查询、ACK等待、心跳或无限重发。板上按键独立改变的状态不会回读到屏，实际值请看 HDMI。

开始发送01，保留先前设置。选章、下一章、轮播及缩略图确认发送04绝对章，随后10选择默认A并重开答题；重复选同章也一致。13重听保留A/B选择并清本地确认结果。八章答案和原资源不变。

屏每页100ms定时器共用一个全局计数，切页保留累计；仅已开始、轮播开启、非缩略图时推进。周期1/3/5/15/30/60秒。配套 FPGA 在 TJC29/04 后由屏接管自动推进，保留29/2A显示风格和速度；板 KEY4 可独立接管板端轮播。单向屏无法知道板键操作，轮播应只使用一种入口：使用板键轮播前先关闭屏端轮播。

复位立即本地恢复音量38、缩放100%、亮度100、对比度50、清晰度0、饱和度50；轮播关闭、周期60秒、淡入淡出、章节1、选择A未确认，发送2C并回首页。

未新增图片或字库，a6ab双向版本原文件保留。本目录实际 HMI 已完成原生容器读回、61事件比对、1973发送帧及字体/布局检查；这些不是官方编译或实板通过。官方 USART HMI 编译/保存与新版本用户实板反馈由主代理另记。

复现：F1/updata/sim/tjc_oneway_control_20261101/hmi/build_hmi.py 生成候选；同目录 test_hmi.py 后接本交付目录可执行保存原生事件回归。validation/parameter_events.json 为测试结果；font_and_render_validation.json 为离线原生字体渲染证据。
''','utf-8')
(D/'source/IMPORT_MANIFEST.md').write_text('# 单向主控原生屏工程\n\n四页、291对象、61原生事件。只发送用户动作和已开启轮播的绝对章命令，无query、ACK等待或接收依赖；04后固定10保证同章重选也重开默认A。单向控制/板键入口限制见README。官方编译和实板验收另记。\n','utf-8')
(D/'tools/oneway').mkdir()
for name in ['build_hmi.py','test_hmi.py','finalize_delivery.py']:shutil.copy2(R/name,D/'tools/oneway'/name)
subprocess.run([sys.executable,str(R/'test_hmi.py'),str(D)],check=True)
assets={str(p.relative_to(D)):sha(p) for p in (D/'assets').rglob('*') if p.is_file()}
for name,h in assets.items():assert sha(B/name)==h,name
dump(D/'validation/asset_inheritance.json',{'passed':True,'original_hmi':str(original),'original_hmi_historical_sha256':historical,'original_hmi_readback_sha256':original_now,'original_hmi_readback_status':'read and matched' if original_now else 'locked by editor; historical hash only; no modification attempted','new_hmi_sha256':digest,'all_original_and_new_assets_byte_equal':True,'assets':assets,'new_screenshot':False,'render_evidence':'native_renders are offline renders of the new native container, not screenshots from official simulator or physical display'})
font=D/'font_and_render_validation.json';data=json.loads(font.read_text('utf-8'));data['hmi_sha256']=digest;data['saved_delivery_copy_equals_tested_candidate']=True;dump(font,data)
dump(D/'source/validation.json',{'passed':True,'hmi_sha256':digest,'native_events':61,'native_objects':291,'event_tests':'../validation/parameter_events.json','fonts_and_layout':'../font_and_render_validation.json','official_compile':'pending main-agent vendor compilation','physical_board':'pending this new-version user feedback'})
dump(D/'source/source_manifest.json',{'version':'tjc_oneway_control_20261101','hmi_sha256':digest,'files':{str(p.relative_to(D)):sha(p) for p in sorted((D/'source').rglob('*')) if p.is_file() and p.name!='source_manifest.json'}})
assert all(sha(B/name)==h for name,h in base_source.items())
dump(R/'delivery_result.json',{'saved':True,'path':str(hmi),'sha256':sha(hmi),'bytes':hmi.stat().st_size,'source_manifest_files':len(json.loads((D/'source/source_manifest.json').read_text('utf-8'))['files']),'prior_source_assets_unchanged':True,'prior_a6ab_readback':original_now,'prior_a6ab_readback_limitation':None if original_now else 'old native HMI locked by official editor, historical hash retained without pretending current readback','native_model_passed':True,'font_render_passed':True,'official_compiled':False,'physical_pass':False})
print((R/'delivery_result.json').read_text('utf-8'))
