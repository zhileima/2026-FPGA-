"""Execute actual native one-way events with no FPGA-return injection at all."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R/'candidate'
old=V/'F1/updata/sim/tjc_reset_settings_20261101/hmi_audit/test_recovery_hmi.py'
sys.path.insert(0,str(old.parent));sys.argv=[str(old),str(D)]
ns={'__file__':str(old)};exec(compile(old.read_text('utf-8').split('checks=[]')[0],str(old),'exec'),ns)
for k in ['initial','event','enter','tick','run','frame','events','raw','objects','layout']:globals()[k]=ns[k]
PARAMS=[('v','vol','hvol','n0',37,100,38),('z','zoom','hzoom','nzoom',48,4,0),('b','bri','hbri','n1',38,100,100),('c','con','hcon','n2',39,100,50),('s','sharp','hsharp','nsharp',49,100,0),('t','sat','hsat','nsat',50,100,50)]
ANSWERS=[0,0,1,0,1,1,0,1];checks=[];seen=[]
def valid(data):
    assert len(data)%5==0,data.hex()
    for n in range(0,len(data),5):
        f=data[n:n+5];assert f[0]==165 and f[4]==90 and f[3]==f[0]^f[1]^f[2]
        assert f[1]!=40,'one-way must never query';seen.append(f.hex())
    return data
def act(v,name):return valid(event(v,name))
def step(v):return valid(tick(v))
def chapter_frame(index):return frame(4,index)+frame(16)
def local(page='home'):
    v=initial()
    if page!='home':assert enter(v,page)==b''
    return v
for name,text in events.items():
    assert not any(token in text for token in ['resetphase','syncack','synctag','reqtype','sys0','sys1','sys2','txneed','A5 28']),name
    assert '已应用"' not in text and '等待开发板' not in text and '未同步' not in text,name
assert [p['name'] for p in layout['pages']]==['home','chapters','task','settings']
for page in ['home','chapters','task','settings']:
    v=local(page)
    for _ in range(1000):assert step(v)==b''
checks.append('No incoming data supplied anywhere; 4 pages x1000 idle ticks have no query/heartbeat/retries')
v=local();assert act(v,'home__bstart__release.txt')==frame(1) and v['_page']=='task' and v['started']==1
for _ in range(50):assert step(v)==b''
checks.append('First Start immediately enters local task and emits01; no response or readiness fence')
cases=0
for short,actual,slider,num,cmd,maximum,default in PARAMS:
    for value in range(maximum+1):
        v=local('settings');act(v,'settings__'+slider+'__press.txt');v[slider+'.val']=value
        assert act(v,'settings__'+slider+'__release.txt')==frame(cmd,value)
        assert v[actual]==value and v[num+'.val']==(value*25+100 if short=='z' else value)
        assert v['sent'+short]==1 and '已发送' in v['pend'+short+'.txt']
        for direction,target in [('plus',min(maximum,value+(1 if short=='z' else 5))),('minus',max(0,value-(1 if short=='z' else 5)))]:
            v[actual]=value;v[slider+'.val']=value
            assert act(v,'settings__'+direction+short+'__release.txt')==frame(cmd,target)
            assert v[actual]==target
        cases+=1
checks.append(f'{cases} slider values and {cases*2} +/- frames update local values immediately and send exact absolute packets')
v=local('settings');values=[43,1,95,55,5,55]
for p,value in zip(PARAMS,values):
    previous={q[1]:v[q[1]] for q in PARAMS};v[p[2]+'.val']=value
    assert act(v,'settings__'+p[2]+'__release.txt')==frame(p[4],value)
    assert all(v[k]==x for k,x in previous.items() if k!=p[1])
assert v['started']==0
assert act(v,'settings__bback__release.txt')==frame(1)
assert [v[p[1]] for p in PARAMS]==values
for page in ['chapters','home','task','settings']:
    assert enter(v,page)==b''
    assert [v[p[1]] for p in PARAMS]==values
for _ in range(100):assert step(v)==b''
checks.append('Six independent pre-Start settings survive01 and all page-private control rebuilds; no resends')
for chapter in range(8):
    for selection in [0,1]:
        v=local('chapters')
        assert act(v,f'chapters__c{chapter+1}__release.txt')==chapter_frame(chapter)
        assert v['scene']==chapter and v['started']==1 and v['_page']=='task'
        assert act(v,'task__'+('bb' if selection else 'ba')+'__release.txt')==frame(16+selection)
        assert v['sel']==selection and v['confirmed']==0
        assert act(v,'task__bok__release.txt')==frame(18)
        assert v['confirmed']==1 and v['correct']==int(selection==ANSWERS[chapter]) and '本地判定' in v['result.txt']
        assert v['bnext.txt']=='进入下一章'
        enter(v,'settings');assert act(v,'settings__bback__release.txt')==frame(1)
        assert v['scene']==chapter and v['sel']==selection and v['confirmed']==1
        assert act(v,'task__breplay__release.txt')==frame(19)
        assert v['sel']==selection and v['confirmed']==0
        assert act(v,'task__bnext__release.txt')==chapter_frame((chapter+1)%8)
        assert v['scene']==(chapter+1)%8 and v['confirmed']==0 and v['sel']==0
checks.append('8 chapters x2 answers: local selection/result matches authored answer key; replay reopens same choice; next uses absolute04 and wraps')
for chapter in range(8):
    v=local('chapters');act(v,f'chapters__c{chapter+1}__release.txt')
    act(v,'task__bb__release.txt');act(v,'task__bok__release.txt');enter(v,'chapters')
    assert act(v,f'chapters__c{chapter+1}__release.txt')==chapter_frame(chapter)
    assert v['sel']==0 and v['confirmed']==0
checks.append('Same-chapter reselection after confirmed B emits04 then10 so FPGA resets local default A/reopens as screen does; all8 chapters')
for page in ['home','chapters','task','settings']:
    for period,limit in enumerate([10,30,50,150,300,600]):
        v=local('settings')
        # Only production button events configure period and automatic style.
        for i in range(period+1):assert act(v,'settings__bperiod__release.txt')==frame(42,i)
        assert v['period']==period and v['autolimit']==limit
        assert act(v,'settings__bauto__release.txt')==frame(41,1)
        for _ in range(limit+5):assert step(v)==b''
        assert v['scene']==0 and v['autoticks']==0 # autoplay does not start exploration
        assert act(v,'settings__bback__release.txt')==frame(1)
        enter(v,page)
        for n in range(1,limit):
            assert step(v)==b''
            if n==limit//2:
                count=v['autoticks'];enter(v,'settings' if page!='settings' else 'chapters');enter(v,page)
                assert v['autoticks']==count
        assert step(v)==chapter_frame(1)
        assert v['scene']==1 and v['autoticks']==0 and v['_page']==page
        for _ in range(limit-1):assert step(v)==b''
        assert step(v)==chapter_frame(2)
checks.append('4 pages x6 periods: sole screen100ms autoplay produces absolute04, preserves elapsed across pages, never starts before Start')
v=local('settings');act(v,'settings__bperiod__release.txt');act(v,'settings__bauto__release.txt');act(v,'settings__bback__release.txt')
for action in ['ba','bok','breplay']:
    for _ in range(5):assert step(v)==b''
    act(v,'task__'+action+'__release.txt');assert v['autoticks']==0
enter(v,'settings');act(v,'settings__bthumb__release.txt')
for _ in range(100):assert step(v)==b''
assert v['thumb']==1 and v['autoticks']==0
for _ in range(9):act(v,'settings__btnext__release.txt')
assert v['focus']==1
act(v,'settings__btprev__release.txt');assert v['focus']==0
act(v,'settings__btprev__release.txt');assert v['focus']==7
assert act(v,'settings__btpick__release.txt')==chapter_frame(7)
assert v['scene']==7 and v['thumb']==0 and v['autoticks']==0
checks.append('Manual A/B/confirm/replay restart local interval; thumbnail pauses it; local focus wraps and confirmation emits absolute04 then10 default A')
for i in range(1,11):assert act(v,'settings__beffect__release.txt')==frame(43,i%10)
act(v,'settings__breset__release.txt')
assert [v[p[1]] for p in PARAMS]==[38,0,100,50,0,50]
assert [v[k] for k in ['scene','sel','confirmed','started','thumb','autoplay','period','effect','autoticks','autolimit']]==[0,0,0,0,0,0,5,0,0,600]
assert v['_page']=='home' and all(v['sent'+p[0]]==0 for p in PARAMS)
for _ in range(1000):assert step(v)==b''
checks.append('Reset is immediate local defaults plus2C/home; all six defaults, period60/style0, mode/selection/count reset; no postreset queries')
report={'passed':True,'mode':'oneway_screen_master','hmi_sha256':hashlib.sha256(raw).hexdigest(),'native_events_equal_source':len(events),'native_objects':objects,'slider_values':cases,'plus_minus_cases':cases*2,'validated_tx_frames':len(seen),'checks':checks,'incoming_board_bytes_injected':0,'official_simulator':False,'physical_pass':False,'limits':'Native-event model uses documented arithmetic, terminating page and private-control recreation. Emitted commands and local UI do not certify FPGA execution; official compilation and user hardware observation remain independent.'}
(D/'validation/parameter_events.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
(R/'event_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
