"""Native one-way screen controller. No state query, ACK gate or board RX state."""
from pathlib import Path
import hashlib,json,re,shutil,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
BASE=V/'tjc_recovery_layers_20261101'
D=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R/'candidate';S=D/'source'
NAME='声音侦探社_动物互动_单向主控版_TJC1060X570.HMI'
PARAMS=[('v','vol','hvol','n0',37,100,38),('z','zoom','hzoom','nzoom',48,4,0),('b','bri','hbri','n1',38,100,100),('c','con','hcon','n2',39,100,50),('s','sharp','hsharp','nsharp',49,100,0),('t','sat','hsat','nsat',50,100,50)]
ANSWERS=[0,0,1,0,1,1,0,1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frame(cmd,arg=0):return f'printh A5 {cmd:02X} {arg:02X} {165^cmd^arg:02X} 5A\n'
def send(cmd,expr):return f'txarg={expr}\ntxchk=165^{cmd}\ntxchk^=txarg\nprinth A5 {cmd:02X}\nprints txarg,1\nprints txchk,1\nprinth 5A\n'
def block(text,marker):
    start=text.index(marker);opening=text.index('{',start);depth=1;end=opening+1
    while depth:
        if text[end]=='{':depth+=1
        if text[end]=='}':depth-=1
        end+=1
    return start,end+1
def remove(text,marker):
    while marker in text:
        a,b=block(text,marker);text=text[:a]+text[b:]
    return text
def reset_local():
    return 'scene=0\nsel=0\nconfirmed=0\nstarted=0\ncorrect=0\nthumb=0\nfocus=0\nautoplay=0\nperiod=5\neffect=0\nautoticks=0\nautolimit=600\nediting=0\ndirty=1\n'+''.join(f'{actual}={default}\nsent{short}=0\n' for short,actual,_,_,_,_,default in PARAMS)
def chapter(expr):
    return f'scene={expr}\nif(scene>7)\n{{\nscene=0\n}}\nstarted=1\nsel=0\nconfirmed=0\ncorrect=0\nthumb=0\nfocus=scene\nautoticks=0\ndirty=1\n'+send(4,'scene')+frame(16)
def auto_tick():
    return '''if(started==1&&autoplay==1&&thumb==0)
{
autoticks=autoticks+1
if(autoticks>=autolimit)
{
'''+chapter('scene+1')+'}\n}\n'
def settings_render():
    text=''
    for i,(short,actual,slider,num,cmd,maximum,default) in enumerate(PARAMS,1):
        text+=f'if(editing!={i})\n{{\nif({slider}.val!={actual})\n{{\n{slider}.val={actual}\n}}\n}}\ntxarg={actual}\n'
        if short=='z':text+='txarg=txarg*25+100\n'
        text+=f'if({num}.val!=txarg)\n{{\n{num}.val=txarg\n}}\n'
        text+=f'if(sent{short}==1)\n{{\npend{short}.txt="已发送，单向控制"\n}}else\n{{\npend{short}.txt="本地设定，单向控制"\n}}\n'
    text+='if(autoplay==0)\n{\nbauto.txt="轮播：关闭"\n}else\n{\nbauto.txt="轮播：开启"\n}\n'
    for i,n in enumerate([1,3,5,15,30,60]):text+=f'if(period=={i})\n{{\nbperiod.txt="周期：{n} 秒"\n}}\n'
    names=['淡入淡出','向右展开','向左展开','向下展开','向上展开','中心展开','百叶窗','棋盘格','菱形展开','3D 翻页']
    for i,n in enumerate(names):text+=f'if(effect=={i})\n{{\nbeffect.txt="转场：{n}"\n}}\n'
    text+='if(thumb==0)\n{\nbthumb.txt="进入缩略图"\n}else\n{\nbthumb.txt="退出缩略图"\n}\n'
    text+='hint.txt="本地设定；命令已发送不代表板端已应用。"\n'
    return text
def main():
    baseline={str(p.relative_to(BASE)):sha(p) for p in (BASE/'source').rglob('*') if p.is_file()}
    for name in ['source','assets','tools']:
        shutil.copytree(BASE/name,D/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','source_manifest.json','validation.json','current_recovery','recovery'))
    old={p.name:p.read_text('utf-8') for p in (S/'events').glob('*.txt')}
    # Retain the authored 8-chapter names/questions/answer descriptions only.
    task=old['task__tm0__timer.txt'].split('last2=sys2\n',1)[1]
    a,b=block(task,'if(dirty==1)\n');task=task[a:b]
    task=remove(task,'if(reqtype');task=remove(task,'if(ready==0)')
    task=task.replace('if(confirmed==1&&ready==1&&started==1&&thumb==0)','if(confirmed==1)')
    task=task.replace('等待开始，画面就绪后即可探案。','本地尚未开始探案。')
    task=task.replace('缩略图中；到播放设置移动焦点或确认。','本地缩略图模式；请看 HDMI。')
    # Correctness is the local answer key, explicitly not a board acknowledgement.
    task=re.sub(r'result.txt="([AB]是[^"\n]+)"',r'result.txt="本地判定：\1"',task)
    task+='dirty=0\n'
    chapters='if(dirty==1)\n{\n'
    for i in range(8):chapters+=f'if(scene=={i})\n{{\nc{i+1}.bco=8910\n}}else\n{{\nc{i+1}.bco=4328\n}}\n'
    chapters+='status.txt="高亮为本地所选章；点击发送选章。"\n}\ndirty=0\n'
    home='if(dirty==1)\n{\nif(started==1)\n{\nstatus.txt="本地探案进行中，点击继续。"\n}else\n{\nstatus.txt="点击开始探索；单向发送控制。"\n}\n}\ndirty=0\n'
    setting='if(dirty==1)\n{\n'+settings_render()+'}\ndirty=0\n'
    renders={'home':home,'chapters':chapters,'task':task,'settings':setting}
    e={}
    for page,render in renders.items():
        e[page+'__postinitialize.txt']='editing=0\ndirty=1\n'+render
        e[page+'__tm0__timer.txt']=auto_tick()+render
    # Local navigation has no serial traffic and never changes autoplay elapsed.
    for name,target in [('home__bchap__release.txt','chapters'),('home__bset__release.txt','settings'),('chapters__bhome__release.txt','home'),('task__bmap__release.txt','chapters'),('task__bset__release.txt','settings')]:e[name]='page '+target+'\n'
    for name in ['home__bstart__release.txt','chapters__btask__release.txt','settings__bback__release.txt']:
        e[name]='started=1\nautoticks=0\ndirty=1\n'+frame(1)+'page task\n'
    for i in range(8):e[f'chapters__c{i+1}__release.txt']=chapter(str(i))+'page task\n'
    e['task__bnext__release.txt']=chapter('scene+1')+'page task\n'
    for name,sel,cmd in [('ba',0,16),('bb',1,17)]:
        e['task__'+name+'__release.txt']=f'sel={sel}\nconfirmed=0\ncorrect=0\nautoticks=0\ndirty=1\n'+frame(cmd)+task
    correct='correct=0\n'+''.join(f'if(scene=={i}&&sel=={answer})\n{{\ncorrect=1\n}}\n' for i,answer in enumerate(ANSWERS))
    e['task__bok__release.txt']='confirmed=1\nautoticks=0\ndirty=1\n'+correct+frame(18)+task
    e['task__breplay__release.txt']='confirmed=0\ncorrect=0\nautoticks=0\ndirty=1\n'+frame(19)+task
    for i,(short,actual,slider,num,cmd,maximum,default) in enumerate(PARAMS,1):
        e[f'settings__{slider}__press.txt']=f'editing={i}\n'
        common=f'{actual}=txarg\nsent{short}=1\nediting=0\ndirty=1\n'+send(cmd,actual)+setting
        e[f'settings__{slider}__release.txt']=f'txarg={slider}.val\n'+common
        step=1 if short=='z' else 5
        for direction,op,edge,comparison in [('plus','+',maximum,'>'),('minus','-',0,'<')]:
            e[f'settings__{direction}{short}__release.txt']=f'txarg={actual}{op}{step}\nif(txarg{comparison}{edge})\n{{\ntxarg={edge}\n}}\n'+common
    e['settings__bauto__release.txt']='if(autoplay==0)\n{\nautoplay=1\n}else\n{\nautoplay=0\n}\nautoticks=0\ndirty=1\n'+send(41,'autoplay')+setting
    period='period=period+1\nif(period>5)\n{\nperiod=0\n}\n'
    for i,limit in enumerate([10,30,50,150,300,600]):period+=f'if(period=={i})\n{{\nautolimit={limit}\n}}\n'
    e['settings__bperiod__release.txt']=period+'autoticks=0\ndirty=1\n'+send(42,'period')+setting
    e['settings__beffect__release.txt']='effect=effect+1\nif(effect>9)\n{\neffect=0\n}\ndirty=1\n'+send(43,'effect')+setting
    e['settings__bthumb__release.txt']='if(thumb==0)\n{\nthumb=1\nstarted=1\nfocus=scene\n'+frame(45,1)+'}else\n{\nthumb=0\n'+frame(45,0)+'}\nautoticks=0\ndirty=1\n'+setting
    for name,op,check,edge,cmdarg in [('btnext','+','>7',0,3),('btprev','-','<0',7,4)]:
        e[f'settings__{name}__release.txt']='if(thumb==1)\n{\n'+f'focus=focus{op}1\nif(focus{check})\n{{\nfocus={edge}\n}}\n'+frame(45,cmdarg)+'}\n'
    e['settings__btpick__release.txt']='if(thumb==1)\n{\n'+chapter('focus')+'}\n'+setting
    e['settings__breset__release.txt']=reset_local()+frame(44)+'page home\n'
    assert set(e)==set(old),(set(e)-set(old),set(old)-set(e))
    banned=['resetphase','syncack','synctag','startintent','wantv','waitv','sys0','sys1','sys2','reqtype','txneed','ready==']
    for name,text in e.items():
        assert not any(x in text for x in banned),(name,[x for x in banned if x in text])
        assert 'A5 28' not in text and not any('&&' in line and '||' in line for line in text.splitlines())
        (S/'events'/name).write_text(text,'utf-8')
    program='''// One-way local controller. sys0/1/2 are unused vendor-default globals.
int sys0=0,sys1=0,sys2=0
int scene=0,sel=0,confirmed=0,started=0,correct=0,thumb=0,focus=0
int autoplay=0,period=5,effect=0,autoticks=0,autolimit=600
int vol=38,bri=100,con=50,zoom=0,sharp=0,sat=50
int sentv=0,sentz=0,sentb=0,sentc=0,sents=0,sentt=0
int editing=0,dirty=1,txarg=0,txchk=0
baud=115200
bkcmd=0
sendxy=0
recmod=0
page home
'''
    (S/'program.s').write_text(program,'utf-8');(D/'Program.s').write_text(program,'utf-8')
    layout=json.loads((S/'layout.json').read_text('utf-8'));setting_page=layout['pages'][3]
    setting_page['components']=[c for c in setting_page['components'] if c['name'] not in ['req'+p[0] for p in PARAMS]]
    for c in setting_page['components']:
        if c['name'] in ['unit'+p[0] for p in PARAMS]:c['attributes']['txt']='设定值'
        if c['name'].startswith('pend'):c['attributes']['txt']='本地设定，单向控制'
        if c['name']=='hint':c['attributes']['txt']='本地设定；命令已发送不代表板端已应用。'
    for p in layout['pages']:
        if p['name']=='home':
            for c in p['components']:
                if c['name']=='status':c['attributes']['txt']='点击开始探索；单向发送控制。'
    (S/'layout.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2),'utf-8')
    chars=set((S/'font_characters.txt').read_text('utf-8'))
    for text in e.values():
        for literal in re.findall(r'"([^"\n]*)"',text):chars.update(literal)
    for p in layout['pages']:
        for c in p['components']:chars.update(c.get('attributes',{}).get('txt',''))
    (S/'font_characters.txt').write_text(''.join(sorted(chars)),'utf-8')
    protocol={'mode':'oneway_screen_master','frame':'A5 CMD ARG (A5 XOR CMD XOR ARG) 5A','baud':115200,'format':'8N1','receive_dependency':False,'query_or_heartbeat':False,'screen_authority':['scene','selection','confirmed','six parameters','autoplay','period','effect','thumbnail mode/focus'],'commands':{'start':1,'absolute_chapter':4,'choice_a':16,'choice_b':17,'confirm':18,'replay':19,'volume':37,'brightness':38,'contrast':39,'autoplay_style':41,'period':42,'effect':43,'reset':44,'thumbnail':45,'zoom':48,'sharpness':49,'saturation':50},'parameter_ranges':{'volume':[0,100],'brightness':[0,100],'contrast':[0,100],'zoom_index':[0,4],'zoom_percent':[100,200],'sharpness':[0,100],'saturation':[0,100]},'defaults':{'volume':38,'brightness':100,'contrast':50,'zoom_index':0,'sharpness':0,'saturation':50,'autoplay':0,'period':5,'effect':0},'correct_choice_zero_based':ANSWERS,'autoplay':{'sole_timebase':'one active100ms page timer; counter is global and preserved across pages','period_seconds':[1,3,5,15,30,60],'advance':'only started1 and autoplay1 and thumb0; sends04 absolute index','manual_actions_reset_counter':['start','chapter','next','A/B','confirm','replay','period','auto toggle','thumbnail mode'],'fpga_requirement':'disable internal media auto-advance, preserve29 auto_play style and2A period for OSD speed'},'thumbnail_confirm':'send04 absolute local focus; FPGA existing04 cancels browser before absolute jump','board_keys':'remain independent; screen is not updated by board keys','ui_meaning':'local setting/sent, never actual board acknowledgement'}
    protocol['absolute_chapter_followup']='Every04 is followed by10 (choose A/reopen), including same chapter, autoplay and thumbnail confirmation. Existing FPGA FIFO waits for chapter/story readiness before10.'
    protocol['thumbnail_confirm']='send04 absolute local focus then10 default A; existing04 cancels browser before absolute jump'
    (S/'protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),'utf-8')
    (S/'control_event_map.json').write_text(json.dumps({p['name']:{c['name']:c['events'] for c in [p]+p['components'] if c.get('events')} for p in layout['pages']},ensure_ascii=False,indent=2),'utf-8')
    (S/'IMPORT_MANIFEST.md').write_text('# 单向主控原生屏工程\n\n仅发送用户操作与已启用轮播的绝对章节命令，无query、回执等待或接收依赖。显示本地设定/已发送，实体按键改变不会自动回读。官方编译及新实板验证由主代理继续。\n','utf-8')
    sys.path.insert(0,str(D/'tools/native_hmi'))
    from build_native_hmi import build
    result=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ['0.zi','3.zi','6.zi']],D/NAME)
    assert all(sha(BASE/p)==h for p,h in baseline.items())
    evidence={'passed':True,'hmi':str(D/NAME),'sha256':result['sha256'],'mode':'oneway_screen_master','native_events':len(e),'base_source_unchanged':True,'new_image_or_font_assets':False,'official_compile_tested':False,'physical_pass':False}
    (D/'validation').mkdir(exist_ok=True);(D/'validation/build_result.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),'utf-8')
    (D/'README.md').write_text('# 单向主控版\n\n屏端本地保存章节、A/B选择、确认结果和参数；点击立即更新屏并发送命令。所有画面数值是本地设定，“已发送”不代表开发板已经执行。没有状态查询、ACK门控、心跳或无限重发。板上实体键继续独立工作，其变化不自动反映到屏。\n\n开始发送01；选章、下一章、轮播发送04绝对章。屏每页100ms定时器共用一个全局轮播计数，跨页累计保持；仅已开始、轮播开启且不在缩略图时推进。FPGA配套必须关闭内部自动推进，保留29/2A供OSD显示风格和速度使用。\n\n六参数设定在开始前后、页面切换间保留。复位立即本地恢复38/100/50/100%/0/50，轮播关闭、周期60秒、淡入淡出，再发2C回首页。不新增图片和字库。旧a6ab工程保留。\n\n当前原生打包/回归结果见validation；官方USART HMI编译和本版本实板观察待主代理记录。\n','utf-8')
    print(json.dumps(evidence,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
