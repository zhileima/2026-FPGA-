from pathlib import Path
import hashlib,json,random,sys
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_interaction_polish_20261101'
old=V/'F1/updata/sim/tjc_reset_settings_20261101/hmi_audit/test_recovery_hmi.py'
sys.path.insert(0,str(old.parent));sys.argv=[str(old),str(D)]
ns={'__file__':str(old)};exec(compile(old.read_text('utf-8').split('checks=[]')[0],str(old),'exec'),ns)
for k in ('initial','event','enter','tick','run','frame','events','raw','objects','layout'):globals()[k]=ns[k]
PARAMS=[('v','vol','hvol','n0',37,100,38),('z','zoom','hzoom','nzoom',48,4,0),('b','bri','hbri','n1',38,100,100),('c','con','hcon','n2',39,100,50),('s','sharp','hsharp','nsharp',49,100,0),('t','sat','hsat','nsat',50,100,50)]
ANSWERS=[0,0,1,0,1,1,0,1];checks=[];frames=[];parameter_cmds={p[4] for p in PARAMS}
def valid(data):
    assert len(data)%5==0,data.hex()
    for n in range(0,len(data),5):
        f=data[n:n+5];assert f[0]==165 and f[4]==90 and f[3]==f[0]^f[1]^f[2] and f[1]!=40
        frames.append(f.hex())
    return data
def act(v,name):return valid(event(v,name))
def fast(v):
    data=act(v,v['_page']+'__tx0__timer.txt');assert len(data)<=5
    return data
def slow(v):return valid(tick(v))
def setup(page='settings'):
    v=initial()
    if page!='home':assert enter(v,page)==b''
    return v
def write(v,p,value):
    v[p[2]+'.val']=value
    data=act(v,'settings__'+p[2]+'__release.txt')
    assert v[p[1]]==value and v[p[3]+'.val']==(value*25+100 if p[0]=='z' else value)
    return data
def allframes(data):return [data[n:n+5] for n in range(0,len(data),5)]
for page in layout['pages']:
    timers={c['name']:c['attributes'] for c in page['components'] if c['type']=='Timer'}
    assert timers=={'tm0':{'tim':100,'en':1},'tx0':{'tim':50,'en':1}}
    v=setup(page['name'])
    for _ in range(1000):assert fast(v)==slow(v)==b''
checks.append('Four pages: separate50ms parameter and100ms autoplay timers;4000idle cycles no traffic/query/retries')
cases=0
for p in PARAMS:
    for value in range(p[5]+1):
        v=setup();assert write(v,p,value)==frame(p[4],value)
        assert v['sent'+p[0]]==1 and '已发送' in v['pend'+p[0]+'.txt']
        assert fast(v)==b''
        for direction,target in [('plus',min(p[5],value+(1 if p[0]=='z' else 5))),('minus',max(0,value-(1 if p[0]=='z' else 5)))]:
            v[p[1]]=value;v[p[2]+'.val']=value
            assert act(v,'settings__'+direction+p[0]+'__release.txt')==frame(p[4],target)
            assert v[p[1]]==target;assert fast(v)==b''
        cases+=1
checks.append(f'{cases}slider values and{2*cases}+/-: idle immediate exact frame, saturation and local number correct')
v=setup();targets=[43,1,95,55,5,55];emitted=b''
for p,x in zip(PARAMS,targets):emitted+=write(v,p,x)
assert emitted==frame(37,43)
assert all(v['queue'+p[0]]==1 for p in PARAMS[1:])
for page in ('home','task','chapters','settings','home'):
    enter(v,page);emitted+=fast(v)
assert all(v['queue'+p[0]]==0 for p in PARAMS)
assert emitted==b''.join(frame(p[4],x) for p,x in zip(PARAMS,targets))
enter(v,'settings');assert [v[p[1]] for p in PARAMS]==targets
assert act(v,'settings__bback__release.txt')==frame(1)
assert [v[p[1]] for p in PARAMS]==targets
checks.append('Six simultaneous parameters: first immediate, five pending survive five page changes and emit final independent values; Start preserves them')
v=setup();write(v,PARAMS[0],10)
for x in range(11,101):assert write(v,PARAMS[0],x)==b''
assert fast(v)==frame(37,100)
for _ in range(20):assert fast(v)==b''
checks.append('90 same-parameter changes coalesce to only latest100; no queued obsolete values or retransmission after drain')
v=setup();write(v,PARAMS[0],20)
for p in PARAMS[1:]:write(v,p,p[5])
got=[]
for x in range(5):
    assert write(v,PARAMS[0],21+x)==b''
    got+=allframes(fast(v))
assert [f[1] for f in got]==[p[4] for p in PARAMS[1:]],got
assert fast(v)==frame(37,25)
checks.append('Continuously changing volume cannot starve the other five pending parameters')
rng=random.Random(20261101);fuzz=0
for trial in range(100):
    v=setup();latest={p[4]:p[6] for p in PARAMS};wire={};sent_count=0
    for step in range(100):
        enter(v,'settings');p=rng.choice(PARAMS);value=rng.randrange(p[5]+1);latest[p[4]]=value
        out=write(v,p,value)
        for f in allframes(out):wire[f[1]]=f[2]
        if rng.randrange(3)==0:
            enter(v,rng.choice(['home','chapters','task','settings']))
            for f in allframes(fast(v)):wire[f[1]]=f[2]
        fuzz+=1
    for _ in range(6):
        for f in allframes(fast(v)):wire[f[1]]=f[2]
    assert wire==latest,(trial,wire,latest)
    assert all(v['queue'+p[0]]==0 for p in PARAMS)
checks.append(f'{fuzz}random interleaved edits/page changes: after6dispatch ticks wire values equal all latest local values')
v=setup();write(v,PARAMS[0],75)
for p in PARAMS:write(v,p,p[5])
assert any(v['queue'+p[0]] for p in PARAMS)
assert act(v,'settings__breset__release.txt')==frame(44)
assert v['_page']=='home' and [v[p[1]] for p in PARAMS]==[38,0,100,50,0,50]
for _ in range(100):assert fast(v)==slow(v)==b''
checks.append('Reset clears queued old settings before2C; no old parameter returns after local/home reset')
for chapter in range(8):
    v=setup('chapters')
    for visit in range(2):
        enter(v,'chapters');assert act(v,f'chapters__c{chapter+1}__release.txt')==frame(4,chapter)
        assert v['sel']==0 and v['confirmed']==0 and v['_page']=='task'
        assert act(v,'task__ba__release.txt')==frame(16)
        assert act(v,'task__bb__release.txt')==frame(17)
        assert act(v,'task__breplay__release.txt')==frame(19)
        assert act(v,'task__bok__release.txt')==frame(18)
        assert v['correct']==int(ANSWERS[chapter]==1)
    assert act(v,'task__bnext__release.txt')==frame(4,(chapter+1)%8)
checks.append('8chapters first/repeated selection and Next send04ONLY; no implicitA; explicitA/B/replay remain16/17/19 and local answer keys unchanged')
for chapter,label in ((2,'小鸟'),(7,'布谷鸟')):
    v=setup('chapters');act(v,f'chapters__c{chapter+1}__release.txt')
    assert v['question.txt']==f'哪段是{label}叫声？'
    act(v,'task__bb__release.txt');act(v,'task__bok__release.txt')
    assert v['correct']==1 and v['result.txt']==f'本地判定：B是{label}，找到了！'
    act(v,'task__breplay__release.txt');assert v['question.txt']==f'哪段是{label}叫声？'
checks.append('Chapter3B remains小鸟; approved Chapter8B=布谷鸟 question/reveal/replay match, native text and original frame protocol unchanged')
for page in ('home','chapters','task','settings'):
    for period,limit in enumerate((10,30,50,150,300,600)):
        v=setup()
        for i in range(period+1):assert act(v,'settings__bperiod__release.txt')==frame(42,i)
        assert act(v,'settings__bauto__release.txt')==frame(41,1)
        assert act(v,'settings__bback__release.txt')==frame(1);enter(v,page)
        for n in range(1,limit):
            assert fast(v)==fast(v)==b'' and slow(v)==b''
            if n==limit//2:
                count=v['autoticks'];enter(v,'settings');enter(v,page);assert v['autoticks']==count
        assert fast(v)==fast(v)==b'' and slow(v)==frame(4,1)
checks.append('4pages x6 periods:50ms dispatch does not accelerate100ms autoplay; no post04 A frame; cross-page timing preserved')
v=setup();assert act(v,'settings__bthumb__release.txt')==frame(45,1)
for _ in range(7):assert act(v,'settings__btnext__release.txt')==frame(45,3)
assert act(v,'settings__btpick__release.txt')==frame(4,7)
checks.append('Thumbnail confirmation sends only absolute04, not implicit10')
result={'passed':True,'hmi_sha256':hashlib.sha256(raw).hexdigest(),'native_objects':objects,'native_events_equal_source':len(events),'validated_frames':len(frames),'all_slider_values':cases,'random_edits':fuzz,'incoming_data_injected':0,'checks':checks,'official_compiler':False,'physical_pass':False,'timing_limit':'Timer ticks are logical events, not measured wall-clock or HDMI latency; official wiki warns real timers depend on CPU/event load.'}
(D/'validation/parameter_events.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
