"""Synchronize external source metadata; no touch/event/serial behavior change."""
from pathlib import Path
import sys,json,hashlib,shutil
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_interaction_polish_20261101';S=D/'source'
src=V/'media_assets/animal_interaction_polish_20261101/scene_story.json';dst=S/'scene_story_candidate.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads(dst.read_text('utf-8'));new=json.loads(src.read_text('utf-8'))
assert len(new['scenes'])==8 and new['correct_choice_zero_based']==old['correct_choice_zero_based']
for a,b in zip(old['scenes'],new['scenes']):
 assert a['id']==b['id'] and a['title']==b['title']
 assert a['interaction']['question']==b['interaction']['question']
 assert a['interaction']['results']==b['interaction']['results']
 assert a['animal_pair']['a']==b['animal_pair']['a'] and a['animal_pair']['b']==b['animal_pair']['b']
before=R/'before_media_metadata';before.mkdir(exist_ok=True)
if not (before/dst.name).exists():shutil.copy2(dst,before/dst.name)
hmi=next(D.glob('*.HMI'));before_hash=sha(hmi)
event_hashes={p.name:sha(p) for p in (S/'events').glob('*.txt')}
shutil.copyfile(src,dst)
sys.path.insert(0,str(D/'tools/native_hmi'))
from build_native_hmi import build
from native_container import parse_container
record=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ('0.zi','3.zi','6.zi')],hmi)
assert sha(hmi)==before_hash
assert event_hashes=={p.name:sha(p) for p in (S/'events').glob('*.txt')}
assert not any(p.name.endswith('.json') for p in parse_container(hmi.read_bytes()))
assert sha(D/'extracted_source/scene_story_candidate.json')==sha(src)==sha(dst)
result={'passed':True,'hmi_sha256':sha(hmi),'hmi_binary_unchanged':True,'native_container_has_no_embedded_scene_json':True,'all65_event_sources_unchanged':True,'source_scene_sha256':sha(src),'source_scene_path':str(src),'external_source_and_extracted_copy_match':True,'official_compiled':False}
(D/'validation/media_metadata_update.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
