from pathlib import Path
import hashlib,json,sys,shutil,subprocess
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_interaction_polish_20261101';S=D/'source'
sys.path.insert(0,str(D/'tools/native_hmi'));from native_container import parse_container
hmi=next(D.glob('*.HMI'));raw=hmi.read_bytes();digest=hashlib.sha256(raw).hexdigest()
(D/'candidate_pages').mkdir(exist_ok=True)
for p in parse_container(raw):
    if p.live and p.name.endswith('.pa'):(D/'candidate_pages'/p.name).write_bytes(raw[p.offset:p.offset+p.length])
p=D/'tools/native_hmi/audit_native_syntax.py';s=p.read_text('utf-8')
s=s.replace("require(len(timers)==1 and timers[0]['attributes']=={'tim':100,'en':1},'timer configuration')", "require({t['name']:t['attributes'] for t in timers}=={'tm0':{'tim':100,'en':1},'tx0':{'tim':50,'en':1}},'timer configuration')")
s=s.replace("==(0,100),'slider range'", "==(0,4 if control['name']=='hzoom' else 100),'slider range'")
s=s.replace('len(bindings)==43','len(bindings)==65').replace('43 source events','65 source events').replace('43 events','65 events')
p.write_text(s,'utf-8')
subprocess.run([sys.executable,'-B',str(p)],check=True)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
assert json.loads((D/'validation/parameter_events.json').read_text('utf-8'))['hmi_sha256']==digest
assert json.loads((D/'font_and_render_validation.json').read_text('utf-8'))['passed']
font=json.loads((D/'font_and_render_validation.json').read_text('utf-8'));font['hmi_sha256']=digest;dump(D/'font_and_render_validation.json',font)
dump(S/'validation.json',{'passed':True,'hmi_sha256':digest,'native_events':65,'native_objects':295,'event_tests':'../validation/parameter_events.json','fonts_and_layout':'../font_and_render_validation.json','official_compile':'pending new-version official compilation by main agent','physical_board':'pending new-version independent observation'})
dump(S/'source_manifest.json',{'version':'tjc_interaction_polish_20261101','hmi_sha256':digest,'files':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(S.rglob('*')) if p.is_file() and p.name!='source_manifest.json'}})
(D/'tools/interaction_polish').mkdir(exist_ok=True)
for name in ('build_polished.py','test_polished.py','finalize_hmi.py','update_cuckoo.py','update_media_metadata.py'):shutil.copy2(R/name,D/'tools/interaction_polish'/name)
dump(D/'validation/delivery.json',{'saved':True,'hmi':str(hmi),'sha256':digest,'bytes':len(raw),'events':65,'objects':295,'source_manifest_count':len(json.loads((S/'source_manifest.json').read_text('utf-8'))['files']),'native_event_model_passed':True,'font_render_passed':True,'official_syntax_reference':'../syntax_official_evidence.json','official_compiled':False,'screen_downloaded':False,'physical_pass':False})
print((D/'validation/delivery.json').read_text('utf-8'))
