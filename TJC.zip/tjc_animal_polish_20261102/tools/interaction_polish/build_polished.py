"""Build a new native HMI; no UI/device access and no edits to the old project."""
from pathlib import Path
import copy, hashlib, json, re, shutil, sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
B=V/'tjc_oneway_control_20261101';D=V/'tjc_interaction_polish_20261101';S=D/'source'
NAME='声音侦探社_动物互动_响应优化版_TJC1060X570.HMI'
PARAMS=[('v','vol','hvol','n0',37,100),('z','zoom','hzoom','nzoom',48,4),('b','bri','hbri','n1',38,100),('c','con','hcon','n2',39,100),('s','sharp','hsharp','nsharp',49,100),('t','sat','hsat','nsat',50,100)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
def send(cmd,expr):return f'txarg={expr}\ntxchk=165^{cmd}\ntxchk^=txarg\nprinth A5 {cmd:02X}\nprints txarg,1\nprints txchk,1\nprinth 5A\n'
def dispatch():
    s='if(txbusy==0)\n{\ntxpick=-1\n'
    for start in range(6):
        s+=f'if(txcursor=={start})\n{{\n'
        for j in range(6):
            i=(start+j)%6;short=PARAMS[i][0]
            s+=f'if(txpick<0&&pend{short}==1)\n{{\ntxpick={i}\n}}\n'
        s+='}\n'
    for i,(short,actual,_,_,cmd,_) in enumerate(PARAMS):
        s+=f'if(txpick=={i})\n{{\n'+send(cmd,actual)+f'pend{short}=0\nsent{short}=1\ntxcursor={(i+1)%6}\ntxbusy=1\ndirty=1\n}}\n'
    return s+'}\n'

def main():
    R.mkdir(parents=True,exist_ok=True)
    if not (R/'before').exists():
        (R/'before').mkdir()
        shutil.copytree(B/'source',R/'before/source')
        try:
            hmi=next(B.glob('*.HMI'));shutil.copy2(hmi,R/'before'/hmi.name)
            hmi_status={'current_readback':sha(hmi),'copied':True}
        except PermissionError:
            hmi_status={'current_readback':None,'copied':False,'reason':'Official editor exclusive file lock; old source and known build evidence preserved, old HMI not modified'}
        dump(R/'before/manifest.json',{'old_hmi':hmi_status,'files':{str(p.relative_to(B)):sha(p) for p in (B/'source').rglob('*') if p.is_file()}})
    before=json.loads((R/'before/manifest.json').read_text('utf-8'))['files']
    for folder in ('source','assets','tools'):
        shutil.copytree(B/folder,D/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    events={p.name:p.read_text('utf-8') for p in (S/'events').glob('*.txt')}
    # 04 now has first-visit playback semantics on the FPGA. Never follow it by10.
    follow='printh 5A\nprinth A5 10 00 B5 5A\n'
    removed=0
    for name,text in list(events.items()):
        count=text.count(follow)
        if count:
            assert 'printh A5 04\n' in text,name
            events[name]=text.replace(follow,'printh 5A\n');removed+=count
    assert removed==14,removed # 8 cards, next, thumbnail confirm and 4 autoplay timers
    # Six independent pending values. The existing globals always contain latest local settings.
    setting=events['settings__postinitialize.txt'].split('editing=0\ndirty=1\n',1)[1]
    for short,actual,slider,num,cmd,maximum in PARAMS:
        old=f'if(sent{short}==1)\n{{\npend{short}.txt="已发送，单向控制"\n}}else\n{{\npend{short}.txt="本地设定，单向控制"\n}}\n'
        new=f'if(pend{short}==1)\n{{\npend{short}.txt="待发送，单向控制"\n}}else\n{{\n'+old+'}\n'
        assert old in setting;setting=setting.replace(old,new)
    # Preserve all existing texts and layout; render local changes immediately.
    for name,text in list(events.items()):
        if name.startswith('settings__'):
            for short,actual,slider,num,cmd,maximum in PARAMS:
                old=f'if(sent{short}==1)\n{{\npend{short}.txt="已发送，单向控制"\n}}else\n{{\npend{short}.txt="本地设定，单向控制"\n}}\n'
                new=f'if(pend{short}==1)\n{{\npend{short}.txt="待发送，单向控制"\n}}else\n{{\n'+old+'}\n'
                text=text.replace(old,new)
            events[name]=text
    for short,actual,slider,num,cmd,maximum in PARAMS:
        common=f'{actual}=txarg\npend{short}=1\nsent{short}=0\nediting=0\ndirty=1\n'+dispatch()+setting
        events[f'settings__{slider}__release.txt']=f'txarg={slider}.val\n'+common
        step=1 if short=='z' else 5
        for direction,op,edge,compare in [('plus','+',maximum,'>'),('minus','-',0,'<')]:
            events[f'settings__{direction}{short}__release.txt']=f'txarg={actual}{op}{step}\nif(txarg{compare}{edge})\n{{\ntxarg={edge}\n}}\n'+common
    clear=''.join(f'pend{p[0]}=0\n' for p in PARAMS)+'txbusy=0\ntxcursor=0\ntxpick=-1\n'
    events['settings__breset__release.txt']=clear+events['settings__breset__release.txt']
    layout=json.loads((S/'layout.json').read_text('utf-8'))
    for page in layout['pages']:
        page['components'].append({'name':'tx0','type':'Timer','attributes':{'tim':50,'en':1},'events':{'timer':f'events/{page["name"]}__tx0__timer.txt'}})
        for i,c in enumerate(page['components'],1):c['planned_id']=i
        events[page['name']+'__tx0__timer.txt']='txbusy=0\n'+dispatch()
    for name,text in events.items():
        assert not any(x in text for x in ('syncack','resetphase','sys0','sys1','sys2','A5 28'))
        assert not any('&&' in line and '||' in line for line in text.splitlines())
        (S/'events'/name).write_text(text,'utf-8')
    program=(S/'program.s').read_text('utf-8')
    program=program.replace('baud=115200\n','int pendv=0,pendz=0,pendb=0,pendc=0,pends=0,pendt=0\nint txbusy=0,txcursor=0,txpick=-1\nbaud=115200\n')
    # Component names must not collide with globals: pendv etc are existing text controls.
    for p in PARAMS:
        program=program.replace('pend'+p[0]+'=','queue'+p[0]+'=')
    for name,text in events.items():
        for p in PARAMS:text=re.sub(r'\bpend'+p[0]+r'(?=[=!])','queue'+p[0],text)
        (S/'events'/name).write_text(text,'utf-8');events[name]=text
    (S/'program.s').write_text(program,'utf-8');(D/'Program.s').write_text(program,'utf-8')
    dump(S/'layout.json',layout)
    chars=set((S/'font_characters.txt').read_text('utf-8'))
    for text in events.values():
        for literal in re.findall(r'"([^"\n]*)"',text):chars.update(literal)
    (S/'font_characters.txt').write_text(''.join(sorted(chars)),'utf-8')
    protocol=json.loads((S/'protocol.json').read_text('utf-8'))
    protocol['absolute_chapter_followup']='04 only; no implicit10. FPGA automatically plays A once on first chapter visit since reset; later visits silent. Only explicit10/11/13 restart one-shot playback.'
    protocol['thumbnail_confirm']='send04 absolute focus only; default local A/unconfirmed, first-visit audio handled by FPGA'
    protocol['parameter_dispatch']={'period_ms':50,'idle_first_action':'immediate','coalesce':'independent latest values for six parameters','fairness':'round-robin, one packet per active timer window','across_pages':True,'reset':'clears all queued values before2C','repeat_or_ack':False,'nominal_burst_bound_ms':300,'wall_time_guarantee':False}
    protocol['autoplay']['fpga_requirement']='29/04 select external scheduler ownership; KEY4 can independently reclaim internal autoplay; same as prior paired FPGA.'
    dump(S/'protocol.json',protocol)
    dump(S/'control_event_map.json',{p['name']:{c['name']:c['events'] for c in [p]+p['components'] if c.get('events')} for p in layout['pages']})
    (S/'IMPORT_MANIFEST.md').write_text('# 响应优化原生HMI\n\n04选章不再隐式试听。首次访问自动播放由FPGA控制。六参数50ms窗口独立保留最终值，跨页继续发送，复位清空；无ACK/查询/无限重试。官方编译及实体响应仍待主代理验证。\n','utf-8')
    sys.path.insert(0,str(D/'tools/native_hmi'));from build_native_hmi import build
    native=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ('0.zi','3.zi','6.zi')],D/NAME)
    (D/'validation').mkdir(exist_ok=True)
    dump(D/'validation/build_result.json',{'passed':True,'hmi_sha256':native['sha256'],'native_events':len(events),'removed_implicit_A_commands':removed,'old_sources_unchanged':all(sha(B/name)==h for name,h in before.items()),'official_compiled':False,'physical_pass':False})
    (D/'README.md').write_text('''# 动物互动响应优化版

配套本轮FPGA，串口屏只发送、立即更新本地页面，不等待回传。选章04不再自动追加试听10；每次FPGA复位后，每章首次进入自动播放A一次，再进入静音，点击试听A/B或重新试听才再次播放。屏复位同时清本地状态与排队参数。

六项参数保留各自最新设定。空闲时首次操作立即发送；连续调节按50ms窗口轮流发送，重复修改同一项合并到最终值，跨页不丢待发送项；没有无限重试。50ms为屏端定时器设定值，实际延迟取决于实体屏负载，不能当作端到端保证。设置数值仍是本地设定，板键修改不回传。

原100ms轮播定时器与新增参数发送定时器分离，1/3/5/15/30/60秒周期不变。板键KEY1切图、KEY2对比度、KEY3亮度、KEY4轮播/信息卡保持独立。使用板键自动轮播前应先关闭屏自动轮播，避免两端反复接管。

本轮没有更换动物声音或TF素材。文件、事件、字库检查不替代官方编译或实体屏/FPGA观察；主代理继续官方编译，屏下载由用户自行执行。
''','utf-8')
    assert all(sha(B/name)==h for name,h in before.items())
    print(json.dumps({'saved':str(D/NAME),'sha256':native['sha256'],'native_events':len(events),'removed_implicit10':removed},ensure_ascii=False))
if __name__=='__main__':main()
