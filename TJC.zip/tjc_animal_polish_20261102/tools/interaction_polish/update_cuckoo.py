"""Approved chapter8B=布谷鸟; preserve chapter3B=小鸟 and all control events."""
from pathlib import Path
import sys,json,re,hashlib,shutil
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_interaction_polish_20261101';S=D/'source';B=R/'before_cuckoo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf-8')
hmi=next(D.glob('*.HMI'))
if not B.exists():
 B.mkdir();shutil.copy2(hmi,B/hmi.name);shutil.copytree(S,B/'source')
 dump(B/'manifest.json',{'hmi_sha256':sha(hmi),'source_files':{str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}})
changed=[]
for p in (S/'events').glob('*.txt'):
 old=p.read_text('utf-8');lines=old.splitlines(True);out=[];i=0;hits=0
 while i<len(lines):
  if lines[i].strip()=='if(scene==7)':
   j=i+1;assert lines[j].strip()=='{';depth=1;j+=1
   while depth:
    depth+=lines[j].strip().count('{')-lines[j].strip().count('}');j+=1
   block=''.join(lines[i:j]);hits+=block.count('小鸟');out.append(block.replace('小鸟','布谷鸟'));i=j
  else:out.append(lines[i]);i+=1
 new=''.join(out)
 if hits:
  assert hits==2,(p,hits)
  p.write_text(new,'utf-8');changed.append(p.name)
  # Identical commands and branches: only human-facing quoted strings differ.
  literals=lambda s:re.sub(r'"[^"\n]*"','"TEXT"',s)
  assert literals(old)==literals(new)
assert len(changed) in (0,6),changed
changed=[p.name for p in (S/'events').glob('*.txt') if p.read_bytes()!=(B/'source/events'/p.name).read_bytes()]
assert len(changed)==6
story_path=S/'scene_story_candidate.json';story=json.loads(story_path.read_text('utf-8'))
chapters=story['scenes'];assert len(chapters)==8
third=json.dumps(chapters[2],ensure_ascii=False,sort_keys=True)
def change(v):
 if isinstance(v,str):return v.replace('小鸟','布谷鸟')
 if isinstance(v,list):return [change(x) for x in v]
 if isinstance(v,dict):return {k:change(x) for k,x in v.items()}
 return v
chapters[7]=change(chapters[7]);assert third==json.dumps(chapters[2],ensure_ascii=False,sort_keys=True)
chapters[7]['animal_pair']['b']='布谷鸟';chapters[7]['animal_pair']['target']='布谷鸟'
chapters[7]['animal_pair']['source_b']='approved_cuckoo_PCM16'
dump(story_path,story)
chars=set((S/'font_characters.txt').read_text('utf-8'));chars.update('布谷鸟')
(S/'font_characters.txt').write_text(''.join(sorted(chars)),'utf-8')
sys.path.insert(0,str(D/'tools/native_hmi'))
from native_font_render import ZiFont
fonts=[]
for n in ('0.zi','3.zi','6.zi'):
 font=ZiFont(D/'assets/native_fonts'/n)
 for ch in '布谷鸟':
  code=font._map_char_to_codepoint(ch);assert code in font.glyphs and font._glyph_mask(code).getbbox(),(n,ch)
 fonts.append({'font':n,'height':font.character_height,'glyphs_present':['布','谷','鸟'],'sha256':sha(D/'assets/native_fonts'/n)})
from build_native_hmi import build
native=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ('0.zi','3.zi','6.zi')],hmi)
dump(D/'validation/cuckoo_update.json',{'passed':True,'hmi_sha256':sha(hmi),'chapter':8,'branch':'B','name':'布谷鸟','tf_file':'PCM16.PCM','third_chapter_B_unchanged':'小鸟','event_files':changed,'wire_commands_unchanged':True,'fonts':fonts,'official_compiled':False})
build_result=json.loads((D/'validation/build_result.json').read_text('utf-8'));build_result['hmi_sha256']=sha(hmi);build_result['chapter8_B']='布谷鸟';dump(D/'validation/build_result.json',build_result)
readme=(D/'README.md').read_text('utf-8').replace('本轮没有更换动物声音或TF素材。','用户已选定本轮动物素材；第8章B改为布谷鸟（PCM16.PCM），第3章B继续小鸟。TF卡更新由主代理单独执行。')
(D/'README.md').write_text(readme,'utf-8')
print(json.dumps({'hmi_sha256':sha(hmi),'event_files_changed':changed,'third_chapter_preserved':True,'fonts_complete':True},ensure_ascii=False))
