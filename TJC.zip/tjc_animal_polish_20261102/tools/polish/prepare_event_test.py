from pathlib import Path
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
src=V/'F1/updata/sim/animal_finale_20261102/hmi/test_finale.py'
t=src.read_text('utf-8').replace("D=V/'tjc_animal_finale_20261102'","D=V/'tjc_animal_polish_20261102'")
extra='''
titles=['雨巷来信','池塘回声','森林夜哨','农场晨曲','牧场合唱','谷仓足迹','旷野呼唤','布谷寻声']
for chap,title in enumerate(titles):
    v=setup('chapters')
    assert act(v,f'chapters__c{chap+1}__release.txt')==frame(4,chap)
    assert v['title.txt']==f'{chap+1:02}  {title}'
    assert v['scene']==chap and v['ended']==0
checks.append('All eight native chapter-card actions render distinct saved titles matching the new OSD title list')
end_visits=0;end_restarts=0
for page in ('home','chapters','task','settings','ending'):
    for period,limit in enumerate((10,30,50,150,300,600)):
        v=setup(page);v['period']=period;v['autolimit']=limit
        v['scene']=7;v['started']=1;v['ended']=0;v['autoplay']=1;v['autoticks']=limit-2
        v['vol']=73;v['bri']=85;v['con']=45
        assert slow(v)==b'' and v['autoticks']==limit-1
        assert slow(v)==frame(5,1)
        assert v['_page']=='ending' and (v['ended'],v['started'],v['autoplay'],v['autoticks'])==(1,0,1,0)
        end_visits+=1
        for k in range(1,limit):
            assert slow(v)==b'' and v['autoticks']==k
        assert slow(v)==frame(41,1)+frame(4,0)
        assert v['_page']=='task' and (v['ended'],v['started'],v['autoplay'],v['scene'],v['sel'],v['confirmed'])==(0,1,1,0,0,0)
        assert (v['vol'],v['bri'],v['con'])==(73,85,45)
        end_restarts+=1
checks.append('5 pages x 6 periods: final chapter emits05/1 once, END lasts exactly one screen timer period,29/1+04/0 restart is ordered and preserves settings')
for page in ('home','chapters','task','settings','ending'):
    v=setup(page);v['ended']=1;v['started']=0;v['autoplay']=1;v['scene']=7;v['autolimit']=10;v['autoticks']=9
    assert slow(v)==frame(41,1)+frame(4,0)
    assert v['_page']=='task' and v['title.txt']=='01  雨巷来信'
checks.append('Auto END dwell survives local page browsing; only one tm0 belonging to current page schedules, no duplicate chapter or restart frame')
for button,target in [('ending__bstart__release.txt',0),('chapters__btask__release.txt',7)]+[(f'chapters__c{n+1}__release.txt',n) for n in range(8)]:
    v=setup(button.split('__')[0]);v['ended']=1;v['started']=0;v['autoplay']=1;v['scene']=7;v['autoticks']=3
    assert act(v,button)==frame(41,1)+frame(4,target)
    assert v['_page']=='task' and v['autoplay']==1 and v['ended']==0 and v['scene']==target and v['autoticks']==0
checks.append('Early user exit from automatic END via restart or any map card restores29/1 before04; autoplay rate cannot silently remain disabled on FPGA')
v=setup('task');v['started']=1;v['autoplay']=1;v['scene']=0;v['autolimit']=10
seq=[]
for step in range(27):
    v['autoticks']=9;seq.append(slow(v))
assert seq==([frame(4,n)for n in range(1,8)]+[frame(5,1),frame(41,1)+frame(4,0)])*3
assert v['autoplay']==1 and v['scene']==0 and v['_page']=='task'
checks.append('Three consecutive complete autoplay cycles: chapters1..8 ->END ->chapter1; START is never inserted, no unbounded repeat/ACK introduced')
'''
t=t.replace('result={',extra+'\nresult={',1)
t=t.replace("'pages':5,'native_objects'","'auto_end_visits':end_visits,'auto_end_restarts':end_restarts,'pages':5,'native_objects'",1)
(R/'test_polish.py').write_text(t,encoding='utf-8')
print('saved test_polish.py')
