from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_animal_polish_20261102';S=D/'source';B=V/'tjc_animal_finale_20261102'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
hmi=next(D.glob('*.HMI'));digest=sha(hmi)
tests=json.loads((D/'validation/event_tests.json').read_text('utf-8'))
stat=json.loads((D/'validation/native_static.json').read_text('utf-8'))
assert tests['passed'] and stat['passed'] and tests['hmi_sha256']==stat['hmi_sha256']==digest
# Metadata only: this is not embedded into the native page/font payload.
scene=R.parent/'osd/scene_story.json';shutil.copy2(scene,S/'scene_story_candidate.json')
protocol=json.loads((S/'protocol.json').read_text('utf-8'))
protocol['autoplay']['advance']='Single current-page100ms scheduler; active chapters send04; after chapter8 send05/1 and showEND one period; return sends29/1 then04/0. Early map/restart exits from autoEND restore29/1 before04.'
dump(S/'protocol.json',protocol)
(S/'IMPORT_MANIFEST.md').write_text('# 终章轮播版原生HMI\n\n五页：home/chapters/task/settings/ending。自动轮播顺序1..8→END一周期→1，END返回时先29/1后04/0；提前从自动END选择章节也恢复29/1。手动完成探案停END；05/0首页和2C复位语义不变。单向发送，不新增ACK、状态等待或重试。八章主标题与本轮OSD元数据一致。官方编译和本次实板由主代理继续。\n',encoding='utf-8')
(D/'README.md').write_text('''# 声音侦探社：终章轮播版

适配 TJC1060X570 横屏1024×600，原生HMI五页：首页、八章地图、探案任务、播放设置、结束页。

本轮八章主标题统一为：雨巷来信、池塘回声、森林夜哨、农场晨曲、牧场合唱、谷仓足迹、旷野呼唤、布谷寻声。动物A/B映射、正确选项和首次进入自动试听规则不变。

屏端自动轮播从第1章至第8章后显示结束页，停留当前轮播周期，再返回第1章。自动END发送05/1，屏端保留自有autoplay计时；返回时按顺序发送29/1、04/0，恢复板端叙事节奏。自动END期间提前点重新探案或选择地图章节，也先恢复29/1。只有当前页的100ms定时器调度，不新增ACK或循环重发，不与FPGA本地调度同时推进。

手动探索在第8章确认发现后，点击完成探案，停留END；返回首页05/0也停止轮播。重新探案04/0保留设置及首次访问记录，播放设置的复位2C才清访问记录并恢复默认值。

板载按键与屏端单向控制相互独立，板键更改不会自动反映屏端本地数值；自动播放请一次使用一种操作入口。六参数仍各自保留最终绝对值，跨页50ms队列发送，缩放100%～200%五档，其余0～100。

已完成保存后的原生容器CRC、71事件回读、逻辑事件模型、510滑块值、1020加减边界、10000次随机参数编辑、5页×6周期END进入/恢复、3个完整轮播循环和三套字库检查。原生HMI编译及实板观察是独立环节，本目录不宣称已执行。
''',encoding='utf-8')
dump(S/'validation.json',{'passed':True,'hmi_sha256':digest,'native_events':71,'native_objects':tests['native_objects'],'event_tests':'../validation/event_tests.json','font_checks':'../font_and_render_validation.json','official_compiler':False,'physical_board':False})
dump(S/'source_manifest.json',{'version':'tjc_animal_polish_20261102','hmi_sha256':digest,'scene_metadata_source':str(scene),'files':{str(p.relative_to(D)):sha(p)for p in sorted(S.rglob('*'))if p.is_file() and p.name!='source_manifest.json'}})
(D/'tools/polish').mkdir(exist_ok=True)
for name in ('build_polish.py','prepare_event_test.py','test_polish.py','audit_polish.py','finalize_polish.py'):shutil.copy2(R/name,D/'tools/polish'/name)
before=json.loads((R/'before/manifest.json').read_text('utf-8'))
assert all(sha(B/n)==v for n,v in before['files'].items())
assert sha(hmi)==digest
dump(D/'validation/delivery.json',{'saved':True,'hmi':str(hmi),'sha256':digest,'bytes':hmi.stat().st_size,'pages':5,'events':71,'objects':tests['native_objects'],'event_model_passed':True,'font_native_readback_passed':True,'syntax_passed':True,'native_old_delivery_unchanged':True,'official_compiled':False,'screen_downloaded':False,'physical_pass':False,'paired_commands':'05/1 END always stops boardauto;29/1 then04/0 resumes screen-owned autoplay;05/0 START waiting;2C fullreset','source_titles':protocol['chapter_titles']})
print((D/'validation/delivery.json').read_text('utf-8'))
