from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_animal_polish_20261102';S=D/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sys.path.insert(0,str(D/'tools/native_hmi'));from native_container import parse_container
hmi=next(D.glob('*.HMI'));raw=hmi.read_bytes();digest=sha(hmi)
(D/'candidate_pages').mkdir(exist_ok=True)
for p in parse_container(raw):
 if p.live and p.name.endswith('.pa'):(D/'candidate_pages'/p.name).write_bytes(raw[p.offset:p.offset+p.length])
for script in ['audit_native_syntax.py','audit_font_and_render.py']:
 subprocess.run([sys.executable,'-B','-X','utf8',str(D/'tools/native_hmi'/script)],check=True)
font=json.loads((D/'font_and_render_validation.json').read_text('utf-8'));assert font['passed'];font['hmi_sha256']=digest;dump(D/'font_and_render_validation.json',font)
dump(D/'validation/native_static.json',{'passed':True,'hmi_sha256':digest,'native_events':71,'pages':5,'font_checks':'../font_and_render_validation.json','official_compiled':False,'physical_board':False})
print(json.dumps({'native_static_passed':True,'sha256':digest},ensure_ascii=False))
