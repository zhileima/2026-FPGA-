"""Independent saved native HMI candidate. No UI, UART hardware, or card writes."""
from pathlib import Path
import copy,hashlib,json,re,shutil,sys
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
B=V/'tjc_animal_finale_20261102';D=V/'tjc_animal_polish_20261102';S=D/'source'
NAME='声音侦探社_动物互动_终章轮播版_TJC1060X570.HMI'
BASE_HASH='9ab45c9936a2e5e808fb1097514336d5c6cdd87d8bfc095e49640f70cba31c2a'
OLD=['侦探事务所','雨夜车站','森林邮局','钟表工坊','乐器剧场','回声隧道','声音档案室','城市音乐节']
NEW=['雨巷来信','池塘回声','森林夜哨','农场晨曲','牧场合唱','谷仓足迹','旷野呼唤','布谷寻声']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def send(cmd,expr):return f'txarg={expr}\ntxchk=165^{cmd}\ntxchk^=txarg\nprinth A5 {cmd:02X}\nprints txarg,1\nprints txchk,1\nprinth 5A\n'
def chapter(expr='scene'):
 return f'scene={expr}\nended=0\nstarted=1\nsel=0\nconfirmed=0\ncorrect=0\nthumb=0\nfocus=scene\nautoticks=0\ndirty=1\n'+send(4,'scene')
def auto_end():
 return 'started=0\nended=1\nthumb=0\nautoticks=0\ndirty=1\nprinth A5 05 01 A1 5A\npage ending\n'
def scheduler():
 return ('if(autoplay==1&&thumb==0)\n{\nif(ended==1)\n{\nautoticks=autoticks+1\nif(autoticks>=autolimit)\n{\n'
  +send(41,'1')+chapter('0')+'page task\n}\n}else\n{\nif(started==1)\n{\nautoticks=autoticks+1\nif(autoticks>=autolimit)\n{\nif(scene==7)\n{\n'
  +auto_end()+'}else\n{\n'+chapter('scene+1')+'}\n}\n}\n}\n}\n')
def renamed(s):
 for a,b in zip(OLD,NEW):s=s.replace(a,b)
 return s
def main():
 R.mkdir(parents=True,exist_ok=True);hmi=next(B.glob('*.HMI'));assert sha(hmi)==BASE_HASH
 before={str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file() and '__pycache__'not in p.parts}
 if not (R/'before').exists():
  (R/'before').mkdir();shutil.copytree(B/'source',R/'before/source');shutil.copy2(hmi,R/'before');dump(R/'before/manifest.json',{'hmi_sha256':BASE_HASH,'files':before})
 for folder in ('source','assets','tools'):shutil.copytree(B/folder,D/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 events={p.name:renamed(p.read_text('utf-8')) for p in (S/'events').glob('*.txt')}
 oldtimer='if(started==1&&autoplay==1&&thumb==0&&ended==0)'
 for name,t in list(events.items()):
  if name.endswith('__tm0__timer.txt'):
   if name.startswith('ending__'):t=scheduler()+'dirty=0\n'
   else:
    assert t.startswith(oldtimer),name
    rest=t[t.index('if(dirty==1)'):]
    t=scheduler()+rest
  elif 'printh A5 04\n' in t:
   # A user may leave the automatic END dwell early using restart or the map.
   # 05/1 stopped board auto_status, while the screen kept its scheduler active.
   t='if(ended==1&&autoplay==1)\n{\n'+send(41,'1')+'}\n'+t
  events[name]=t
 for name,t in events.items():(S/'events'/name).write_text(t,encoding='utf-8')
 layout=json.loads(renamed((S/'layout.json').read_text('utf-8')))
 dump(S/'layout.json',layout)
 scene_source=R.parent/'osd/scene_story.json'
 scene=json.loads(scene_source.read_text('utf-8'))
 for i,sc in enumerate(scene['scenes']):sc['title']=NEW[i]
 scene['status']='animal_polish_20261102_pending_official_compile_and_board'
 dump(S/'scene_story_candidate.json',scene)
 protocol=json.loads((S/'protocol.json').read_text('utf-8'))
 protocol['special_page']['autoplay']='Screen-local scheduler: chapters1..8 ->05/1 END one current period ->29/1 then04/0 chapter1. No START in automatic cycle. Manual completion sets autoplay0 and stays END.'
 protocol['special_page']['board_independence']='Board KEY controls remain independent; no status feedback or forced screen update from keys.'
 protocol['chapter_titles']=NEW
 protocol['autoplay']['advance']='Single current-page100ms scheduler; active chapters send04; after chapter8 send05/1 and showEND one period; return sends29/1 then04/0. Early map/restart exits from autoEND restore29/1 before04.'
 dump(S/'protocol.json',protocol)
 chars=set((S/'font_characters.txt').read_text('utf-8'))
 for t in events.values():
  for s in re.findall(r'"([^"\n]*)"',t):chars.update(s)
 for page in layout['pages']:
  for c in page['components']:chars.update(c.get('attributes',{}).get('txt',''))
 (S/'font_characters.txt').write_text(''.join(sorted(chars)),encoding='utf-8')
 shutil.copy2(S/'program.s',D/'Program.s')
 dump(S/'control_event_map.json',{p['name']:{c['name']:c['events'] for c in [p]+p['components'] if c.get('events')} for p in layout['pages']})
 sys.path.insert(0,str(D/'tools/native_hmi'));from build_native_hmi import build
 result=build(V/'tjc串口屏资料/TJC1060X570.HMI',D,[D/'assets/native_fonts'/n for n in ('0.zi','3.zi','6.zi')],D/NAME)
 (D/'validation').mkdir(exist_ok=True)
 changed=[n for n in events if events[n]!=(B/'source/events'/n).read_text('utf-8')]
 dump(D/'validation/build_result.json',{'saved':True,'passed':True,'hmi_sha256':result['sha256'],'baseline_sha256':BASE_HASH,'event_files_changed':changed,'pages':5,'events':len(events),'titles':NEW,'official_compiled':False,'hardware_downloaded':False})
 assert all(sha(B/n)==v for n,v in before.items()),'Old delivery changed'
 print(json.dumps({'hmi':str(D/NAME),'sha256':result['sha256'],'changed_events':len(changed),'old_delivery_unchanged':True},ensure_ascii=False))
if __name__=='__main__':main()
