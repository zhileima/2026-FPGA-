"""Run saved native HMI events in the documented integer/page semantic model."""
from pathlib import Path
import hashlib,json,random,sys
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent;V=next(p for p in R.parents if p.name=='V1')
D=V/'tjc_animal_polish_20261102'
old=V/'F1/updata/sim/tjc_reset_settings_20261101/hmi_audit/test_recovery_hmi.py'
sys.path.insert(0,str(old.parent));sys.argv=[str(old),str(D)]
ns={'__file__':str(old)};exec(compile(old.read_text('utf-8').split('checks=[]')[0],str(old),'exec'),ns)
for k in ('initial','event','enter','tick','run','frame','events','raw','objects','layout'):globals()[k]=ns[k]
PARAMS=[('v','vol','hvol','n0',37,100,38),('z','zoom','hzoom','nzoom',48,4,0),('b','bri','hbri','n1',38,100,100),('c','con','hcon','n2',39,100,50),('s','sharp','hsharp','nsharp',49,100,0),('t','sat','hsat','nsat',50,100,50)]
ANSWERS=[0,0,1,0,1,1,0,1];checks=[];frames=[]
def valid(data):
    assert len(data)%5==0,data.hex()
    for n in range(0,len(data),5):
        f=data[n:n+5];assert f[0]==165 and f[4]==90 and f[3]==f[0]^f[1]^f[2]
        assert f[1] in {4,5,16,17,18,19,37,38,39,41,42,43,44,45,48,49,50}
        frames.append(f.hex())
    return data
def act(v,name):return valid(event(v,name))
def fast(v):
    data=act(v,v['_page']+'__tx0__timer.txt');assert len(data)<=5;return data
def slow(v):return valid(tick(v))
def setup(page='settings'):
    v=initial()
    if page!='home':assert enter(v,page)==b''
    return v
def write(v,p,value):
    v[p[2]+'.val']=value;data=act(v,'settings__'+p[2]+'__release.txt')
    assert v[p[1]]==value and v[p[3]+'.val']==(value*25+100 if p[0]=='z' else value)
    return data
def split(data):return [data[n:n+5]for n in range(0,len(data),5)]
assert [p['name']for p in layout['pages']]==['home','chapters','task','settings','ending']
for page in layout['pages']:
    assert {c['name']:c['attributes']for c in page['components']if c['type']=='Timer'}=={'tm0':{'tim':100,'en':1},'tx0':{'tim':50,'en':1}}
    v=setup(page['name'])
    for _ in range(500):assert fast(v)==slow(v)==b''
checks.append('Five pages with independent100ms/50ms timers;2500idle paired cycles emit no traffic')
cases=0
for p in PARAMS:
    for value in range(p[5]+1):
        v=setup();assert write(v,p,value)==frame(p[4],value);assert fast(v)==b''
        for direction,target in [('plus',min(p[5],value+(1 if p[0]=='z'else 5))),('minus',max(0,value-(1 if p[0]=='z'else 5)))]:
            v[p[1]]=value;v[p[2]+'.val']=value
            assert act(v,'settings__'+direction+p[0]+'__release.txt')==frame(p[4],target)
            assert v[p[1]]==target and fast(v)==b''
        cases+=1
checks.append(f'{cases}slider values + {cases*2}plus/minus cases: exact frame, clamping, local persistence')
v=setup();targets=[43,1,95,55,5,55];sent=b''
for p,x in zip(PARAMS,targets):sent+=write(v,p,x)
assert sent==frame(37,43)
for page in ('home','ending','task','chapters','settings'):
    enter(v,page);sent+=fast(v)
assert sent==b''.join(frame(p[4],x)for p,x in zip(PARAMS,targets))
assert [v[p[1]]for p in PARAMS]==targets
checks.append('Six pending final settings survive all five pages including ending, without overwrites')
rng=random.Random(20261102);fuzz=0
for trial in range(100):
    v=setup();latest={p[4]:p[6]for p in PARAMS};wire={}
    for step in range(100):
        enter(v,'settings');p=rng.choice(PARAMS);value=rng.randrange(p[5]+1);latest[p[4]]=value
        for f in split(write(v,p,value)):wire[f[1]]=f[2]
        if rng.randrange(3)==0:
            enter(v,rng.choice(['home','chapters','task','settings','ending']))
            for f in split(fast(v)):wire[f[1]]=f[2]
        fuzz+=1
    for _ in range(6):
        for f in split(fast(v)):wire[f[1]]=f[2]
    assert wire==latest and all(v['queue'+p[0]]==0 for p in PARAMS)
checks.append('10000 random parameter edits/page transitions preserve six final values with bounded drain')
for chap in range(8):
    v=setup('chapters');assert act(v,f'chapters__c{chap+1}__release.txt')==frame(4,chap)
    assert v['_page']=='task' and v['scene']==chap and v['ended']==0 and v['sel']==0 and not v['confirmed']
    assert act(v,'task__ba__release.txt')==frame(16)
    assert act(v,'task__bb__release.txt')==frame(17)
    assert act(v,'task__breplay__release.txt')==frame(19)
    if chap==7:
        assert act(v,'task__bnext__release.txt')==b'' and v['_page']=='task'
        assert '先确认' in v['result.txt']
    assert act(v,'task__bok__release.txt')==frame(18)
    assert v['correct']==int(ANSWERS[chap]==1) and v['_page']=='task'
    if chap<7:
        assert act(v,'task__bnext__release.txt')==frame(4,chap+1) and v['_page']=='task'
    else:
        assert v['bnext.txt']=='完成探案'
        v['autoplay']=1;v['vol']=63;v['bri']=85
        assert act(v,'task__bnext__release.txt')==frame(5,1)
        assert v['_page']=='ending' and v['ended']==1 and v['started']==v['autoplay']==v['thumb']==0
        assert v['scene']==7 and v['vol']==63 and v['bri']==85
        for _ in range(1000):assert fast(v)==slow(v)==b''
checks.append('Eight chapters A/B/confirm/replay preserve legacy frames; final reveal remains until explicit05/1 completion, END stops autoplay and preserves settings')
v=setup('home');v['scene']=7;v['sel']=1;v['confirmed']=1;v['vol']=73
assert act(v,'home__bstart__release.txt')==frame(4,0)
assert v['_page']=='task' and v['scene']==v['sel']==v['confirmed']==v['ended']==0 and v['vol']==73
checks.append('Home start explicitly selects chapter1/A/unconfirmed, sends04only and preserves parameters')
for started,ended,want in ((0,0,'home'),(1,0,'task'),(0,1,'ending')):
    v=setup();v['started']=started;v['ended']=ended;v['scene']=5;v['sel']=1;v['confirmed']=1
    assert act(v,'settings__bback__release.txt')==b'' and v['_page']==want
    assert (v['scene'],v['sel'],v['confirmed'])==(5,1,1)
checks.append('Settings return emits no start/replay/navigation packet and preserves task or END context')
for button in ('chapters__bhome__release.txt','ending__bset__release.txt'):
    v=setup(button.split('__')[0]);v['scene']=7;v['ended']=1;v['autoplay']=1;v['started']=1;v['vol']=75
    assert act(v,button)==frame(5,0) and v['_page']=='home'
    assert v['vol']==75 and v['ended']==v['started']==v['autoplay']==0
    assert act(v,'home__bstart__release.txt')==frame(4,0)
v=setup('ending');v['ended']=1;v['scene']=7
assert act(v,'ending__bstart__release.txt')==frame(4,0) and v['_page']=='task' and not v['ended']
checks.append('Return home05/0 does not reset parameters; explicit restart04/0 does not impersonate a full2C reset')
for page in ('home','chapters','task','settings'):
    for period,limit in enumerate((10,30,50,150,300,600)):
        v=setup()
        for i in range(period+1):assert act(v,'settings__bperiod__release.txt')==frame(42,i)
        assert act(v,'settings__bauto__release.txt')==frame(41,1)
        v['started']=1;enter(v,page)
        for n in range(1,limit):assert fast(v)==fast(v)==slow(v)==b''
        assert fast(v)==fast(v)==b'' and slow(v)==frame(4,1)
checks.append('Four active pages x six autoplay periods preserve100ms timing and no implicit A; manual END separately terminates autoplay')
v=setup();write(v,PARAMS[0],75)
for p in PARAMS:write(v,p,p[5])
v['ended']=1
assert act(v,'settings__breset__release.txt')==frame(44) and v['_page']=='home' and v['ended']==0
assert [v[p[1]]for p in PARAMS]==[38,0,100,50,0,50]
for _ in range(100):assert fast(v)==slow(v)==b''
checks.append('Full2C reset clears pending previous parameters and ended state; no stale queue resurrects values')

titles=['雨巷来信','池塘回声','森林夜哨','农场晨曲','牧场合唱','谷仓足迹','旷野呼唤','布谷寻声']
for chap,title in enumerate(titles):
    v=setup('chapters')
    assert act(v,f'chapters__c{chap+1}__release.txt')==frame(4,chap)
    assert v['title.txt']==f'{chap+1:02}  {title}'
    assert v['scene']==chap and v['ended']==0
checks.append('All eight native chapter-card actions render distinct saved titles matching the new OSD title list')
end_visits=0;end_restarts=0
for page in ('home','chapters','task','settings','ending'):
    for period,limit in enumerate((10,30,50,150,300,600)):
        v=setup(page);v['period']=period;v['autolimit']=limit
        v['scene']=7;v['started']=1;v['ended']=0;v['autoplay']=1;v['autoticks']=limit-2
        v['vol']=73;v['bri']=85;v['con']=45
        assert slow(v)==b'' and v['autoticks']==limit-1
        assert slow(v)==frame(5,1)
        assert v['_page']=='ending' and (v['ended'],v['started'],v['autoplay'],v['autoticks'])==(1,0,1,0)
        end_visits+=1
        for k in range(1,limit):
            assert slow(v)==b'' and v['autoticks']==k
        assert slow(v)==frame(41,1)+frame(4,0)
        assert v['_page']=='task' and (v['ended'],v['started'],v['autoplay'],v['scene'],v['sel'],v['confirmed'])==(0,1,1,0,0,0)
        assert (v['vol'],v['bri'],v['con'])==(73,85,45)
        end_restarts+=1
checks.append('5 pages x 6 periods: final chapter emits05/1 once, END lasts exactly one screen timer period,29/1+04/0 restart is ordered and preserves settings')
for page in ('home','chapters','task','settings','ending'):
    v=setup(page);v['ended']=1;v['started']=0;v['autoplay']=1;v['scene']=7;v['autolimit']=10;v['autoticks']=9
    assert slow(v)==frame(41,1)+frame(4,0)
    assert v['_page']=='task' and v['title.txt']=='01  雨巷来信'
checks.append('Auto END dwell survives local page browsing; only one tm0 belonging to current page schedules, no duplicate chapter or restart frame')
for button,target in [('ending__bstart__release.txt',0),('chapters__btask__release.txt',7)]+[(f'chapters__c{n+1}__release.txt',n) for n in range(8)]:
    v=setup(button.split('__')[0]);v['ended']=1;v['started']=0;v['autoplay']=1;v['scene']=7;v['autoticks']=3
    assert act(v,button)==frame(41,1)+frame(4,target)
    assert v['_page']=='task' and v['autoplay']==1 and v['ended']==0 and v['scene']==target and v['autoticks']==0
checks.append('Early user exit from automatic END via restart or any map card restores29/1 before04; autoplay rate cannot silently remain disabled on FPGA')
v=setup('task');v['started']=1;v['autoplay']=1;v['scene']=0;v['autolimit']=10
seq=[]
for step in range(27):
    v['autoticks']=9;seq.append(slow(v))
assert seq==([frame(4,n)for n in range(1,8)]+[frame(5,1),frame(41,1)+frame(4,0)])*3
assert v['autoplay']==1 and v['scene']==0 and v['_page']=='task'
checks.append('Three consecutive complete autoplay cycles: chapters1..8 ->END ->chapter1; START is never inserted, no unbounded repeat/ACK introduced')

result={'passed':True,'hmi_sha256':hashlib.sha256(raw).hexdigest(),'auto_end_visits':end_visits,'auto_end_restarts':end_restarts,'pages':5,'native_objects':objects,'native_events_equal_source':len(events),'validated_frames':len(frames),'slider_values':cases,'random_edits':fuzz,'checks':checks,'incoming_status_or_ack':0,'official_compiler':False,'physical_pass':False,'limits':'Logical event model/readback only; paired FPGA timing and physical latency are separate evidence.'}
(D/'validation/event_tests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
