`timescale 1ns/1ps
// Eight native 128x96 thumbnails in one 4x2 SDRAM atlas. No duplicate framebuffer.
// One-clock video latency, including bypass. view_page is a retained legacy port.
module dental_thumbnail_renderer (
    input wire clk,rst_n,frame_start,
    input wire hs_in,vs_in,de_in,
    input wire [11:0] pixel_x,pixel_y,
    input wire [23:0] rgb_in,
    input wire view_mode,view_page,
    input wire [2:0] focus,
    input wire [7:0] valid_mask,present_mask,failed_mask,
    input wire scan_complete,animation_active,
    input wire [4:0] animation_step, input wire [1:0] animation_kind,
    output reg hs_out,vs_out,de_out,
    output reg [11:0] pixel_x_out,pixel_y_out,
    output reg [23:0] rgb_out, output wire focus_cache_ready
);
    wire [1:0] column=(pixel_x>=464)?2'd3:(pixel_x>=320)?2'd2:(pixel_x>=176)?2'd1:2'd0;
    wire bottom_row=pixel_y>=240;
    wire [2:0] tile={bottom_row,column};
    wire [11:0] left=(column==3)?12'd472:(column==2)?12'd328:(column==1)?12'd184:12'd40;
    wire [11:0] top=bottom_row?12'd256:12'd112;
    wire inside_tile=pixel_x>=left && pixel_x<left+128 && pixel_y>=top && pixel_y<top+96;
    wire border=pixel_x>=left-3 && pixel_x<left+131 && pixel_y>=top-3 && pixel_y<top+99 && !inside_tile;
    assign focus_cache_ready=view_mode && valid_mask[focus] && !failed_mask[focus];
    wire [3:0] number={1'b0,tile}+1'b1;
    wire [11:0] label_x=pixel_x-(left+59);
    wire [11:0] label_y=pixel_y-(top+104);
    function [34:0] digit;
        input [3:0] n;
        begin case(n)
            1:digit=35'b00100_01100_00100_00100_00100_00100_01110;
            2:digit=35'b01110_10001_00001_00010_00100_01000_11111;
            3:digit=35'b11110_00001_00001_01110_00001_00001_11110;
            4:digit=35'b00010_00110_01010_10010_11111_00010_00010;
            5:digit=35'b11111_10000_10000_11110_00001_00001_11110;
            6:digit=35'b01110_10000_10000_11110_10001_10001_01110;
            7:digit=35'b11111_00001_00010_00100_01000_01000_01000;
            8:digit=35'b01110_10001_10001_01110_10001_10001_01110;
            default:digit=0;
        endcase end
    endfunction
    wire [34:0] number_bitmap=digit(number);
    wire label=label_x<10 && label_y<14 && number_bitmap[34-(label_y[3:1]*5+label_x[3:1])];
    wire [23:0] tile_color=failed_mask[tile]?24'he78080:(!valid_mask[tile]?24'h566b70:rgb_in);
    reg [23:0] composed;
    always @* begin
        composed=24'h173f40;
        if(inside_tile) composed=tile_color;
        else if(border) composed=(tile==focus)?24'hefbc5a:24'h50958c;
        else if(label) composed=(tile==focus)?24'hefbc5a:24'hfff8e7;
        if(animation_active) begin
            if(animation_step>=16) composed=0;
            else if(animation_step>=8) composed={2'b0,composed[23:18],2'b0,composed[15:10],2'b0,composed[7:2]};
            else if(animation_step>=4) composed={1'b0,composed[23:17],1'b0,composed[15:9],1'b0,composed[7:1]};
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin hs_out<=1;vs_out<=1;de_out<=0;pixel_x_out<=0;pixel_y_out<=0;rgb_out<=0;end
        else begin
            hs_out<=hs_in;vs_out<=vs_in;de_out<=de_in;pixel_x_out<=pixel_x;pixel_y_out<=pixel_y;
            rgb_out<=!de_in?24'd0:(view_mode?composed:rgb_in);
        end
    end
endmodule
