`timescale 1ns/1ps

// Beijing wall clock after an external HH:MM:SS time-set command.
// The caller converts its trusted time source to UTC+08:00. This module has
// no RTC or network connection: reset leaves it invalid until a fresh set.
// Clocking uses exact pixel-clock cycles, independently of video frame rate.
// All time-set signals are synchronous to pix_clk; cross domains upstream.
// Rendering is combinational (zero additional video-pipeline cycles).
module timestamp_osd #(
    parameter integer PIXEL_CLK_HZ = 25_000_000,
    parameter integer OSD_X = 8,
    parameter integer OSD_Y = 8,
    parameter [23:0] TEXT_COLOR = 24'hFFFFFF
) (
    input  wire        pix_clk,
    input  wire        pix_rst_n,
    input  wire        enable,
    input  wire        frame_start,
    input  wire        de,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    input  wire [23:0] rgb_in,
    input  wire        time_set_valid,
    input  wire [23:0] time_set_bcd,
    input  wire [24:0] time_set_subsecond,
    output wire [23:0] rgb_out,
    output wire        ts_active,
    output reg         time_valid,
    output reg  [23:0] time_bcd,
    output wire [24:0] time_subsecond,
    output reg  [23:0] display_time_bcd,
    output reg         time_set_accept,
    output reg         time_set_reject
);
    localparam integer TICK_BITS = (PIXEL_CLK_HZ > 1) ? $clog2(PIXEL_CLK_HZ) : 1;
    localparam [TICK_BITS-1:0] SECOND_LAST = PIXEL_CLK_HZ - 1;
    localparam integer PANEL_W = 136;
    localparam integer PANEL_H = 32;

    reg [TICK_BITS-1:0] tick_count;
    reg [TICK_BITS-1:0] next_tick_count;
    reg [23:0] next_time_bcd;
    reg next_time_valid;
    reg next_accept;
    reg next_reject;
    reg display_time_valid;

    function valid_bcd_time;
        input [23:0] value;
        begin
            valid_bcd_time = (value[23:20] <= 4'd2) &&
                             (value[19:16] <= 4'd9) &&
                             ((value[23:20] != 4'd2) ||
                              (value[19:16] <= 4'd3)) &&
                             (value[15:12] <= 4'd5) &&
                             (value[11:8] <= 4'd9) &&
                             (value[7:4] <= 4'd5) &&
                             (value[3:0] <= 4'd9);
        end
    endfunction

    function [23:0] add_second;
        input [23:0] value;
        reg [23:0] result;
        begin
            result = value;
            if (value[3:0] != 4'd9)
                result[3:0] = value[3:0] + 1'b1;
            else begin
                result[3:0] = 4'd0;
                if (value[7:4] != 4'd5)
                    result[7:4] = value[7:4] + 1'b1;
                else begin
                    result[7:4] = 4'd0;
                    if (value[11:8] != 4'd9)
                        result[11:8] = value[11:8] + 1'b1;
                    else begin
                        result[11:8] = 4'd0;
                        if (value[15:12] != 4'd5)
                            result[15:12] = value[15:12] + 1'b1;
                        else begin
                            result[15:12] = 4'd0;
                            if (value[23:16] == 8'h23)
                                result[23:16] = 8'h00;
                            else if (value[19:16] == 4'd9) begin
                                result[19:16] = 4'd0;
                                result[23:20] = value[23:20] + 1'b1;
                            end else
                                result[19:16] = value[19:16] + 1'b1;
                        end
                    end
                end
            end
            add_second = result;
        end
    endfunction

    always @* begin
        next_tick_count = tick_count;
        next_time_bcd = time_bcd;
        next_time_valid = time_valid;
        next_accept = 1'b0;
        next_reject = 1'b0;
        if (time_valid) begin
            if (tick_count == SECOND_LAST) begin
                next_tick_count = {TICK_BITS{1'b0}};
                next_time_bcd = add_second(time_bcd);
            end else
                next_tick_count = tick_count + 1'b1;
        end
        if (time_set_valid) begin
            if (valid_bcd_time(time_set_bcd) && (time_set_subsecond < PIXEL_CLK_HZ)) begin
                next_time_bcd = time_set_bcd;
                next_time_valid = 1'b1;
                next_tick_count = time_set_subsecond[TICK_BITS-1:0];
                next_accept = 1'b1;
            end else
                next_reject = 1'b1;
        end
    end

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            tick_count <= {TICK_BITS{1'b0}};
            time_bcd <= 24'd0;
            time_valid <= 1'b0;
            display_time_bcd <= 24'd0;
            display_time_valid <= 1'b0;
            time_set_accept <= 1'b0;
            time_set_reject <= 1'b0;
        end else begin
            tick_count <= next_tick_count;
            time_bcd <= next_time_bcd;
            time_valid <= next_time_valid;
            time_set_accept <= next_accept;
            time_set_reject <= next_reject;
            // Freeze all six digits together for the complete next frame.
            // Use next state so a simultaneous set/tick is displayed atomically.
            if (frame_start) begin
                display_time_bcd <= next_time_bcd;
                display_time_valid <= next_time_valid;
            end
        end
    end

    assign time_subsecond = tick_count;

    // A 5x7 font, enlarged 2x within each 16x24 character cell.
    // A, B denote colon and dash; eight cells spell HH:MM:SS.
    function [4:0] font_row;
        input [3:0] glyph;
        input [2:0] row;
        reg [34:0] bitmap;
        begin
            case (glyph)
                4'd0: bitmap = {5'b01110,5'b10001,5'b10011,5'b10101,5'b11001,5'b10001,5'b01110};
                4'd1: bitmap = {5'b00100,5'b01100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};
                4'd2: bitmap = {5'b01110,5'b10001,5'b00001,5'b00010,5'b00100,5'b01000,5'b11111};
                4'd3: bitmap = {5'b11110,5'b00001,5'b00001,5'b01110,5'b00001,5'b00001,5'b11110};
                4'd4: bitmap = {5'b00010,5'b00110,5'b01010,5'b10010,5'b11111,5'b00010,5'b00010};
                4'd5: bitmap = {5'b11111,5'b10000,5'b10000,5'b11110,5'b00001,5'b00001,5'b11110};
                4'd6: bitmap = {5'b01110,5'b10000,5'b10000,5'b11110,5'b10001,5'b10001,5'b01110};
                4'd7: bitmap = {5'b11111,5'b00001,5'b00010,5'b00100,5'b01000,5'b01000,5'b01000};
                4'd8: bitmap = {5'b01110,5'b10001,5'b10001,5'b01110,5'b10001,5'b10001,5'b01110};
                4'd9: bitmap = {5'b01110,5'b10001,5'b10001,5'b01111,5'b00001,5'b00001,5'b01110};
                4'hA: bitmap = {5'b00000,5'b00100,5'b00100,5'b00000,5'b00100,5'b00100,5'b00000};
                4'hB: bitmap = {5'b00000,5'b00000,5'b00000,5'b01110,5'b00000,5'b00000,5'b00000};
                default: bitmap = 35'd0;
            endcase
            case (row)
                3'd0: font_row = bitmap[34:30];
                3'd1: font_row = bitmap[29:25];
                3'd2: font_row = bitmap[24:20];
                3'd3: font_row = bitmap[19:15];
                3'd4: font_row = bitmap[14:10];
                3'd5: font_row = bitmap[9:5];
                3'd6: font_row = bitmap[4:0];
                default: font_row = 5'd0;
            endcase
        end
    endfunction

    wire in_panel = enable && de && pix_rst_n &&
                    (pixel_x >= OSD_X) && (pixel_x < OSD_X + PANEL_W) &&
                    (pixel_y >= OSD_Y) && (pixel_y < OSD_Y + PANEL_H);
    wire [11:0] text_x = pixel_x - (OSD_X + 4);
    wire [11:0] text_y = pixel_y - (OSD_Y + 4);
    wire in_cells = in_panel &&
                    (pixel_x >= OSD_X + 4) && (text_x < 12'd128) &&
                    (pixel_y >= OSD_Y + 4) && (text_y < 12'd24);
    wire [3:0] cell_x = text_x[3:0];
    wire [4:0] cell_y = text_y[4:0];
    wire [3:0] glyph_x = (cell_x - 4'd3) >> 1;
    wire [4:0] glyph_y = (cell_y - 5'd5) >> 1;
    reg [3:0] selected_glyph;
    reg [4:0] selected_row;
    reg text_pixel;
    always @* begin
        case (text_x[6:4])
            3'd0: selected_glyph = display_time_bcd[23:20];
            3'd1: selected_glyph = display_time_bcd[19:16];
            3'd2: selected_glyph = 4'hA;
            3'd3: selected_glyph = display_time_bcd[15:12];
            3'd4: selected_glyph = display_time_bcd[11:8];
            3'd5: selected_glyph = 4'hA;
            3'd6: selected_glyph = display_time_bcd[7:4];
            default: selected_glyph = display_time_bcd[3:0];
        endcase
        if (!display_time_valid && (selected_glyph != 4'hA))
            selected_glyph = 4'hB;
        selected_row = font_row(selected_glyph, glyph_y[2:0]);
        text_pixel = 1'b0;
        if (in_cells && (cell_x >= 4'd3) && (cell_x < 4'd13) &&
            (cell_y >= 5'd5) && (cell_y < 5'd19))
            text_pixel = selected_row[4 - glyph_x];
    end

    // 50% black alpha blend; independent channels never carry into neighbors.
    wire [23:0] dim_rgb = {1'b0,rgb_in[23:17],1'b0,rgb_in[15:9],1'b0,rgb_in[7:1]};
    assign ts_active = in_panel;
    assign rgb_out = !in_panel ? rgb_in : (text_pixel ? TEXT_COLOR : dim_rgb);
endmodule
