`timescale 1ns/1ps

// Frame-stable numeric gain display. INPUT_IS_PERCENT=1 accepts 0..100 directly.
// Mapping is owned by the controller; this module never rescales the gain.
// Serial BCD conversion runs off the pixel clock; rendering adds no video stage.
module audio_volume_osd #(
    parameter integer TEXT_X = 16,
    parameter integer TEXT_Y = 16,
    parameter integer INPUT_IS_PERCENT = 0
) (
    input wire clk,
    input wire rst_n,
    input wire vsync,
    input wire de,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire enable,
    input wire [7:0] volume,
    input wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire overlay_active
);
    localparam [12:0] TEXT_LEFT = TEXT_X;
    localparam [12:0] TEXT_RIGHT = TEXT_X + (INPUT_IS_PERCENT ? 128 : 112);
    localparam [12:0] TEXT_TOP = TEXT_Y;
    localparam [12:0] TEXT_BOTTOM = TEXT_Y + 16;
    initial begin
        if (TEXT_X < 0 || TEXT_Y < 0 || TEXT_X + (INPUT_IS_PERCENT ? 128 : 112) > 4096 || TEXT_Y + 16 > 4096) begin
            $display("F1_VOLUME_OSD_CONFIG_ERROR: invalid text region");
            $finish;
        end
    end

    reg vs_q;
    wire frame_start = vs_q && !vsync;
    reg converting;
    reg converted_valid;
    reg display_valid;
    reg [7:0] conversion_value;
    reg [7:0] binary_shift;
    reg [2:0] bit_count;
    reg [11:0] bcd_work;
    reg [11:0] converted_bcd;
    reg [11:0] displayed_bcd;
    reg [11:0] adjusted_bcd;
    wire [11:0] next_bcd = {adjusted_bcd[10:0],binary_shift[7]};
    always @* begin
        adjusted_bcd = bcd_work;
        if (bcd_work[3:0] >= 5) adjusted_bcd[3:0] = bcd_work[3:0] + 4'd3;
        if (bcd_work[7:4] >= 5) adjusted_bcd[7:4] = bcd_work[7:4] + 4'd3;
        if (bcd_work[11:8] >= 5) adjusted_bcd[11:8] = bcd_work[11:8] + 4'd3;
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_q <= 1'b1;
            converting <= 1'b0;
            converted_valid <= 1'b0;
            display_valid <= 1'b0;
            conversion_value <= 8'd0;
            binary_shift <= 8'd0;
            bit_count <= 3'd0;
            bcd_work <= 12'd0;
            converted_bcd <= 12'd0;
            displayed_bcd <= 12'd0;
        end else begin
            vs_q <= vsync;
            if (!converting) begin
                if (!converted_valid || volume != conversion_value) begin
                    conversion_value <= volume;
                    binary_shift <= volume;
                    bcd_work <= 12'd0;
                    bit_count <= 3'd0;
                    converting <= 1'b1;
                end
            end else begin
                bcd_work <= next_bcd;
                binary_shift <= {binary_shift[6:0],1'b0};
                if (bit_count == 3'd7) begin
                    converted_bcd <= next_bcd;
                    converted_valid <= 1'b1;
                    converting <= 1'b0;
                end else bit_count <= bit_count + 1'b1;
            end
            // All three digits become visible together only in vertical blank.
            if (frame_start && converted_valid) begin
                displayed_bcd <= converted_bcd;
                display_valid <= 1'b1;
            end
        end
    end

    function [34:0] glyph_bits;
        input [3:0] character;
        begin
            case (character)
                0: glyph_bits = 35'b01110_10001_10011_10101_11001_10001_01110;
                1: glyph_bits = 35'b00100_01100_00100_00100_00100_00100_01110;
                2: glyph_bits = 35'b01110_10001_00001_00010_00100_01000_11111;
                3: glyph_bits = 35'b11110_00001_00001_01110_00001_00001_11110;
                4: glyph_bits = 35'b00010_00110_01010_10010_11111_00010_00010;
                5: glyph_bits = 35'b11111_10000_10000_11110_00001_00001_11110;
                6: glyph_bits = 35'b01110_10000_10000_11110_10001_10001_01110;
                7: glyph_bits = 35'b11111_00001_00010_00100_01000_01000_01000;
                8: glyph_bits = 35'b01110_10001_10001_01110_10001_10001_01110;
                9: glyph_bits = 35'b01110_10001_10001_01111_00001_00001_01110;
                10: glyph_bits = 35'b10001_10001_10001_10001_10001_01010_00100; // V
                11: glyph_bits = 35'b01110_10001_10001_10001_10001_10001_01110; // O
                12: glyph_bits = 35'b10000_10000_10000_10000_10000_10000_11111; // L
                13: glyph_bits = 35'b11001_11010_00100_01000_10110_00110_00000; // %
                default: glyph_bits = 35'd0;
            endcase
        end
    endfunction
    wire [12:0] x = {1'b0,pixel_x};
    wire [12:0] y = {1'b0,pixel_y};
    wire [11:0] local_x = pixel_x - TEXT_LEFT[11:0];
    wire [11:0] local_y = pixel_y - TEXT_TOP[11:0];
    wire text_enabled = enable && de && display_valid;
    wire in_text = x >= TEXT_LEFT && x < TEXT_RIGHT && y >= TEXT_TOP && y < TEXT_BOTTOM;
    reg [3:0] character;
    reg [34:0] glyph;
    reg text_pixel;
    always @* begin
        character = 4'd15;
        case (local_x[6:4])
            0: character = 4'd10;
            1: character = 4'd11;
            2: character = 4'd12;
            4: character = displayed_bcd[11:8];
            5: character = displayed_bcd[7:4];
            6: character = displayed_bcd[3:0];
            7: character = INPUT_IS_PERCENT ? 4'd13 : 4'd15;
            default: character = 4'd15;
        endcase
        glyph = glyph_bits(character);
        text_pixel = 1'b0;
        if (text_enabled && in_text && local_x[3:1] < 5 && local_y[3:1] < 7)
            text_pixel = glyph[34 - (local_y[3:1] * 5 + local_x[3:1])];
    end
    // Only the white glyphs cover the image; spacing and margins stay transparent.
    assign overlay_active = text_pixel;
    assign rgb_out = text_pixel ? 24'hffffff : rgb_in;
endmodule
