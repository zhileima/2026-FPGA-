`timescale 1ns/1ps
// Same source coordinates as media_frame_reader RGB565 word-pair zoom.
// No added pixel latency. Sample scene_x/y with the input pixel at clk edge.
// zoom_level must be the reader's committed tag, delayed with that pixel.
module scene_zoom_coordinates (
    input wire clk, input wire rst_n, input wire de,
    input wire [9:0] pixel_x, input wire [9:0] pixel_y,
    input wire [2:0] zoom_level,
    output wire [9:0] scene_x, output wire [9:0] scene_y
);
    reg [18:0] x_start, y_start;
    reg [10:0] step;
    reg [18:0] x_phase, y_phase;
    wire zoom_valid=(zoom_level>=3'd1 && zoom_level<=3'd4);
    always @* begin
        x_start=0; y_start=0; step=11'd1024;
        case(zoom_level)
            1:begin x_start=19'd32768;y_start=19'd49152;step=11'd819;end
            2:begin x_start=19'd54613;y_start=19'd81920;step=11'd683;end
            3:begin x_start=19'd70217;y_start=19'd105326;step=11'd585;end
            4:begin x_start=19'd81920;y_start=19'd122880;step=11'd512;end
            default:begin end
        endcase
    end
    // x=0 and y=0 use configuration directly: NBA state reset must not
    // delay the first visible pixel of a row/frame by one clock.
    wire [18:0] current_x=(pixel_x==0)?x_start:x_phase;
    wire [18:0] current_y=(pixel_y==0)?y_start:y_phase;
    assign scene_x=(rst_n && de && zoom_valid)?{current_x[18:10],pixel_x[0]}:pixel_x;
    assign scene_y=(rst_n && de && zoom_valid)?{1'b0,current_y[18:10]}:pixel_y;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin x_phase<=0;y_phase<=0;end
        else if(de)begin
            if(pixel_x==0)x_phase<=x_start;
            else if(pixel_x[0])x_phase<=x_phase+step;
            if(pixel_y==0)y_phase<=y_start;
            // Last-pixel increment takes priority over row0 initialization.
            if(pixel_x==10'd639)y_phase<=current_y+step;
        end
    end
endmodule
