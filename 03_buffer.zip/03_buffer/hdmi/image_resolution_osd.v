`timescale 1ns/1ps

// Original-image dimensions: navy 5x7 glyphs at 2x scale with a one-pixel
// pale outline. All other pixels retain the exact incoming background.
// Inputs must already be synchronous to clk.  Width and height are captured as
// one pair, converted without division, and published only in vertical blank.
// A bank changed beside the VS falling edge can therefore appear in this frame:
// allow at least 36 pixel clocks before its first active pixel (the worst case
// includes finishing a conversion of the previous pair).
module image_resolution_osd #(
    parameter integer SCREEN_WIDTH = 640,
    parameter integer RIGHT_MARGIN = 16,
    parameter integer TEXT_Y = 16
) (
    input wire clk,
    input wire rst_n,
    input wire vsync,
    input wire de,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire enable,
    input wire [15:0] image_width,
    input wire [15:0] image_height,
    input wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire overlay_active
);
    localparam [12:0] TEXT_RIGHT = SCREEN_WIDTH - RIGHT_MARGIN;
    localparam [12:0] TEXT_TOP = TEXT_Y;
    localparam [12:0] TEXT_BOTTOM = TEXT_Y + 14;
    initial begin
        if (SCREEN_WIDTH > 4096 || RIGHT_MARGIN < 0 ||
            SCREEN_WIDTH - RIGHT_MARGIN < 170 || TEXT_Y < 0 ||
            TEXT_Y + 14 > 4096) begin
            $display("F1_RESOLUTION_OSD_CONFIG_ERROR: invalid text region");
            $finish;
        end
    end

    reg vs_q;
    wire frame_start = vs_q && !vsync;
    reg publish_window;
    reg converting;
    reg converted_valid;
    reg display_valid;
    reg [15:0] conversion_width, conversion_height;
    reg [15:0] width_shift, height_shift;
    reg [3:0] bit_count;
    reg [19:0] width_work, height_work;
    reg [19:0] displayed_width, displayed_height;
    reg [15:0] displayed_binary_width, displayed_binary_height;
    reg [19:0] adjusted_width, adjusted_height;
    wire [19:0] next_width = {adjusted_width[18:0],width_shift[15]};
    wire [19:0] next_height = {adjusted_height[18:0],height_shift[15]};
    wire conversion_current = conversion_width == image_width &&
                              conversion_height == image_height;

    always @* begin
        adjusted_width = width_work;
        adjusted_height = height_work;
        if (width_work[3:0] >= 5) adjusted_width[3:0] = width_work[3:0] + 4'd3;
        if (width_work[7:4] >= 5) adjusted_width[7:4] = width_work[7:4] + 4'd3;
        if (width_work[11:8] >= 5) adjusted_width[11:8] = width_work[11:8] + 4'd3;
        if (width_work[15:12] >= 5) adjusted_width[15:12] = width_work[15:12] + 4'd3;
        if (height_work[3:0] >= 5) adjusted_height[3:0] = height_work[3:0] + 4'd3;
        if (height_work[7:4] >= 5) adjusted_height[7:4] = height_work[7:4] + 4'd3;
        if (height_work[11:8] >= 5) adjusted_height[11:8] = height_work[11:8] + 4'd3;
        if (height_work[15:12] >= 5) adjusted_height[15:12] = height_work[15:12] + 4'd3;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_q <= 1'b1;
            publish_window <= 1'b0;
            converting <= 1'b0;
            converted_valid <= 1'b0;
            display_valid <= 1'b0;
            conversion_width <= 16'd0;
            conversion_height <= 16'd0;
            width_shift <= 16'd0;
            height_shift <= 16'd0;
            bit_count <= 4'd0;
            width_work <= 20'd0;
            height_work <= 20'd0;
            displayed_width <= 20'd0;
            displayed_height <= 20'd0;
            displayed_binary_width <= 16'd0;
            displayed_binary_height <= 16'd0;
        end else begin
            vs_q <= vsync;
            if (frame_start) publish_window <= 1'b1;
            else if (de) publish_window <= 1'b0;

            if (!converting) begin
                if (!converted_valid || !conversion_current) begin
                    conversion_width <= image_width;
                    conversion_height <= image_height;
                    width_shift <= image_width;
                    height_shift <= image_height;
                    width_work <= 20'd0;
                    height_work <= 20'd0;
                    bit_count <= 4'd0;
                    converting <= 1'b1;
                    // Old BCD must not be associated with this new input pair.
                    converted_valid <= 1'b0;
                end
            end else begin
                width_work <= next_width;
                height_work <= next_height;
                width_shift <= {width_shift[14:0],1'b0};
                height_shift <= {height_shift[14:0],1'b0};
                if (bit_count == 4'd15) begin
                    converted_valid <= 1'b1;
                    converting <= 1'b0;
                end else bit_count <= bit_count + 1'b1;
            end

            // No publication during active video or its horizontal blanks.
            // Both dimensions become visible on the same clock edge.
            if ((frame_start || publish_window) && !de &&
                converted_valid && conversion_current) begin
                // The last conversion step already placed the final BCD in
                // the work registers. They hold it until the next pair starts.
                displayed_width <= width_work;
                displayed_height <= height_work;
                displayed_binary_width <= conversion_width;
                displayed_binary_height <= conversion_height;
                display_valid <= conversion_width != 0 && conversion_height != 0;
            end
        end
    end

    function [2:0] decimal_digits;
        input [19:0] bcd;
        begin
            if (bcd[19:16] != 0) decimal_digits = 3'd5;
            else if (bcd[15:12] != 0) decimal_digits = 3'd4;
            else if (bcd[11:8] != 0) decimal_digits = 3'd3;
            else if (bcd[7:4] != 0) decimal_digits = 3'd2;
            else decimal_digits = 3'd1;
        end
    endfunction
    function [3:0] decimal_digit;
        input [19:0] bcd;
        input [3:0] units_index;
        begin
            case (units_index)
                0: decimal_digit = bcd[3:0];
                1: decimal_digit = bcd[7:4];
                2: decimal_digit = bcd[11:8];
                3: decimal_digit = bcd[15:12];
                4: decimal_digit = bcd[19:16];
                default: decimal_digit = 4'd15;
            endcase
        end
    endfunction
    // One shared combinational row-pair table: previous/native next row.
    // Padded 2x cells require only two adjacent source rows for an exact
    // one-screen-pixel 8-neighbour outline. No extra RAM, FF or video latency.
    function [9:0] glyph_rows;
        input [3:0] character;
        input [2:0] pair_row;
        begin
            case ({character,pair_row})
                7'd80, 7'd81: glyph_rows = 10'b0000000000;
                7'd32: glyph_rows = 10'b0000000010;
                7'd8: glyph_rows = 10'b0000000100;
                7'd0, 7'd16, 7'd48, 7'd64, 7'd72: glyph_rows = 10'b0000001110;
                7'd82: glyph_rows = 10'b0000010001;
                7'd24: glyph_rows = 10'b0000011110;
                7'd40, 7'd56: glyph_rows = 10'b0000011111;
                7'd26, 7'd29, 7'd45, 7'd77: glyph_rows = 10'b0000100001;
                7'd19, 7'd58: glyph_rows = 10'b0000100010;
                7'd27, 7'd78: glyph_rows = 10'b0000101110;
                7'd30, 7'd46: glyph_rows = 10'b0000111110;
                7'd39: glyph_rows = 10'b0001000000;
                7'd38: glyph_rows = 10'b0001000010;
                7'd20, 7'd59: glyph_rows = 10'b0001000100;
                7'd33: glyph_rows = 10'b0001000110;
                7'd11, 7'd12, 7'd13: glyph_rows = 10'b0010000100;
                7'd21, 7'd60: glyph_rows = 10'b0010001000;
                7'd85: glyph_rows = 10'b0010001010;
                7'd9: glyph_rows = 10'b0010001100;
                7'd14: glyph_rows = 10'b0010001110;
                7'd34: glyph_rows = 10'b0011001010;
                7'd63: glyph_rows = 10'b0100000000;
                7'd61, 7'd62: glyph_rows = 10'b0100001000;
                7'd22: glyph_rows = 10'b0100011111;
                7'd84: glyph_rows = 10'b0101000100;
                7'd86: glyph_rows = 10'b0101010001;
                7'd35: glyph_rows = 10'b0101010010;
                7'd10: glyph_rows = 10'b0110000100;
                7'd7, 7'd15, 7'd55, 7'd71, 7'd79: glyph_rows = 10'b0111000000;
                7'd28: glyph_rows = 10'b0111000001;
                7'd49: glyph_rows = 10'b0111010000;
                7'd1, 7'd17, 7'd65, 7'd68, 7'd73: glyph_rows = 10'b0111010001;
                7'd76: glyph_rows = 10'b0111100001;
                7'd42, 7'd50: glyph_rows = 10'b1000010000;
                7'd43, 7'd51: glyph_rows = 10'b1000011110;
                7'd87: glyph_rows = 10'b1000100000;
                7'd18: glyph_rows = 10'b1000100001;
                7'd83: glyph_rows = 10'b1000101010;
                7'd6, 7'd54, 7'd67, 7'd70: glyph_rows = 10'b1000101110;
                7'd75: glyph_rows = 10'b1000101111;
                7'd53, 7'd66, 7'd69, 7'd74: glyph_rows = 10'b1000110001;
                7'd2: glyph_rows = 10'b1000110011;
                7'd36: glyph_rows = 10'b1001011111;
                7'd3: glyph_rows = 10'b1001110101;
                7'd4: glyph_rows = 10'b1010111001;
                7'd5: glyph_rows = 10'b1100110001;
                7'd31, 7'd47: glyph_rows = 10'b1111000000;
                7'd25, 7'd44: glyph_rows = 10'b1111000001;
                7'd52: glyph_rows = 10'b1111010001;
                7'd23: glyph_rows = 10'b1111100000;
                7'd57: glyph_rows = 10'b1111100001;
                7'd37: glyph_rows = 10'b1111100010;
                7'd41: glyph_rows = 10'b1111110000;
                default: glyph_rows = 10'd0;
            endcase
        end
    endfunction

    wire [2:0] width_digits = decimal_digits(displayed_width);
    wire [2:0] height_digits = decimal_digits(displayed_height);
    wire [3:0] character_count = {1'b0,width_digits} + {1'b0,height_digits} + 4'd1;
    // Digits occupy fixed 16-pixel cells measured from the right edge.
    // right_distance[7:4] is the units-first cell index, and its inverted
    // low nibble is the original local x within that cell.
    wire [12:0] x = {1'b0,pixel_x};
    wire [12:0] y = {1'b0,pixel_y};
    wire [12:0] right_distance = TEXT_RIGHT + 13'd4 - x;
    wire [3:0] right_index = right_distance[7:4];
    wire [3:0] local_x = ~right_distance[3:0];
    wire [12:0] local_y = y - TEXT_TOP + 13'd1;
    // At most eleven cells (five digits for each operand and the x).
    // The extra checked pixel on the left belongs to the outline.
    wire in_text = x + 13'd171 >= TEXT_RIGHT && x <= TEXT_RIGHT &&
                   right_index < character_count &&
                   y + 13'd1 >= TEXT_TOP && y < TEXT_BOTTOM + 13'd1;
    // A late reader-bank commit may miss this blank's conversion budget. Hide
    // the previous size immediately; the next vertical blank publishes the new
    // complete pair. Never label a new picture with the previous picture's size.
    wire displayed_pair_current = displayed_binary_width == image_width &&
                                  displayed_binary_height == image_height;
    reg [3:0] character;
    reg [9:0] row_pair;
    reg [4:0] ink_row, near_rows;
    reg [5:0] ink_columns, outline_columns;
    reg text_pixel, outline_pixel;
    always @* begin
        character = 4'd15;
        if (right_index < {1'b0,height_digits})
            character = decimal_digit(displayed_height,right_index);
        else if (right_index == {1'b0,height_digits})
            character = 4'd10;
        else
            character = decimal_digit(displayed_width,right_index - {1'b0,height_digits} - 4'd1);
        row_pair = glyph_rows(character,local_y[3:1]);
        ink_row = local_y[0] ? row_pair[4:0] : row_pair[9:5];
        near_rows = row_pair[9:5] | row_pair[4:0];
        ink_columns = local_x[0] ? {ink_row,1'b0} : {1'b0,ink_row};
        outline_columns = {near_rows,1'b0} | {1'b0,near_rows};
        text_pixel = 1'b0;
        outline_pixel = 1'b0;
        if (enable && de && display_valid && displayed_pair_current && in_text &&
            local_x[3:1] < 6) begin
            text_pixel = ink_columns[3'd5-local_x[3:1]];
            outline_pixel = outline_columns[3'd5-local_x[3:1]] && !text_pixel;
        end
    end
    assign overlay_active = text_pixel || outline_pixel;
    assign rgb_out = text_pixel ? 24'h10243B : outline_pixel ? 24'hF3EBD8 : rgb_in;
endmodule
