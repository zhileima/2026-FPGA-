`timescale 1ns/1ps
// Read-only 640x480 parameter card. All timing/RGB/coordinates: TWO clocks,
// exactly like player_settings_osd. No command or scene-control outputs.
// Inputs are VIDEO-CLOCK synchronous. All five controls are percentages
// 0..100 (sharpness defaults to0, saturation to50). Capture after VS fall.
module player_info_osd (
    input wire clk, input wire rst,
    input wire hs_in, input wire vs_in, input wire de_in,
    input wire [11:0] pixel_x, input wire [11:0] pixel_y,
    input wire [23:0] rgb_in, input wire view_visible,
    input wire [7:0] volume, input wire [7:0] brightness,
    input wire [7:0] contrast, input wire [2:0] zoom_index,
    input wire [7:0] sharpness, input wire [7:0] saturation,
    input wire [15:0] image_width, input wire [15:0] image_height,
    input wire source_resolution_valid,
    output reg hs_out, output reg vs_out, output reg de_out,
    output reg [11:0] pixel_x_out, output reg [11:0] pixel_y_out,
    output reg [23:0] rgb_out
);
    // A shared double-dabble engine converts one 16-bit field in 16 clocks.
    // Eight fields take <150 clocks (<6us at 25MHz). No divider,
    // multiplier, pixel-clock decimal chain, or additional frame latency.
    reg vs_q, capture_pending, publish_window, ready_to_publish;
    reg [15:0] snapshot [0:7];
    reg snapshot_valid, display_resolution_valid;
    // The six scalar inputs are at most255 (zoom at most200), so their
    // completed decimal representations need only three BCD digits.
    // Keep the original20-bit read interface by zero-extension; dimensions
    // and the shared16-cycle conversion engine retain all five digits.
    reg [11:0] converted_small [0:5];
    reg [11:0] displayed_small [0:5];
    reg [19:0] converted_dimensions [0:1];
    reg [19:0] displayed_dimensions [0:1];
    wire [19:0] converted [0:7];
    wire [19:0] displayed [0:7];
    genvar field;
    generate for(field=0;field<8;field=field+1)begin:g_bcd_read
        if(field<6)begin
            assign converted[field]={8'd0,converted_small[field]};
            assign displayed[field]={8'd0,displayed_small[field]};
        end else begin
            assign converted[field]=converted_dimensions[field-6];
            assign displayed[field]=displayed_dimensions[field-6];
        end
    end endgenerate
    reg [2:0] channel;
    reg [1:0] conversion_state;
    reg [4:0] bit_count;
    reg [15:0] binary_work;
    reg [19:0] bcd_work, bcd_adjusted;
    wire [19:0] bcd_next={bcd_adjusted[18:0],binary_work[15]};
    integer n;
    always @* begin
        bcd_adjusted=bcd_work;
        if(bcd_work[3:0]>=5)bcd_adjusted[3:0]=bcd_work[3:0]+4'd3;
        if(bcd_work[7:4]>=5)bcd_adjusted[7:4]=bcd_work[7:4]+4'd3;
        if(bcd_work[11:8]>=5)bcd_adjusted[11:8]=bcd_work[11:8]+4'd3;
        if(bcd_work[15:12]>=5)bcd_adjusted[15:12]=bcd_work[15:12]+4'd3;
        if(bcd_work[19:16]>=5)bcd_adjusted[19:16]=bcd_work[19:16]+4'd3;
    end
    always @(posedge clk or posedge rst) begin
        if(rst)begin
            vs_q<=1;capture_pending<=0;publish_window<=0;ready_to_publish<=0;
            snapshot_valid<=0;display_resolution_valid<=0;
            channel<=0;conversion_state<=0;bit_count<=0;binary_work<=0;bcd_work<=0;
            for(n=0;n<8;n=n+1)snapshot[n]<=0;
            for(n=0;n<6;n=n+1)begin converted_small[n]<=0;displayed_small[n]<=0;end
            for(n=0;n<2;n=n+1)begin converted_dimensions[n]<=0;displayed_dimensions[n]<=0;end
        end else begin
            vs_q<=vs_in;
            if(de_in)publish_window<=0;
            if(vs_q && !vs_in)begin
                capture_pending<=1;publish_window<=1;
            end
            if(capture_pending)begin
                capture_pending<=0;ready_to_publish<=0;
                snapshot[0]<={8'd0,volume};snapshot[2]<={8'd0,brightness};
                snapshot[3]<={8'd0,contrast};snapshot[4]<={8'd0,sharpness};
                snapshot[5]<={8'd0,saturation};snapshot[6]<=image_width;snapshot[7]<=image_height;
                snapshot_valid<=source_resolution_valid;
                case(zoom_index)
                    0:snapshot[1]<=100;1:snapshot[1]<=125;2:snapshot[1]<=150;
                    3:snapshot[1]<=175;default:snapshot[1]<=200;
                endcase
                channel<=0;conversion_state<=1;
            end else case(conversion_state)
                1:begin
                    bcd_work<=0;bit_count<=0;
                    binary_work<=snapshot[channel];conversion_state<=3;
                end
                3:begin
                    binary_work<={binary_work[14:0],1'b0};bcd_work<=bcd_next;
                    if(bit_count==15)begin
                        if(channel<6)converted_small[channel]<=bcd_next[11:0];
                        else converted_dimensions[channel[0]]<=bcd_next;
                        if(channel==7)begin ready_to_publish<=1;conversion_state<=0;end
                        else begin channel<=channel+1'b1;conversion_state<=1;end
                    end else bit_count<=bit_count+1'b1;
                end
                default:conversion_state<=0;
            endcase
            if(ready_to_publish && publish_window && !de_in && !capture_pending)begin
                for(n=0;n<6;n=n+1)displayed_small[n]<=converted_small[n];
                for(n=0;n<2;n=n+1)displayed_dimensions[n]<=converted_dimensions[n];
                display_resolution_valid<=snapshot_valid;ready_to_publish<=0;
            end
        end
    end

    // Native24px raster in32x32 storage cells, mapped1:1: no scaling.
    // Only the card is opaque. Everything outside passes through unchanged.
    wire card_on=view_visible && de_in && pixel_x>=112 && pixel_x<528 && pixel_y>=72 && pixel_y<408;
    wire border=(pixel_x==112 || pixel_x==527 || pixel_y==72 || pixel_y==407);
    reg [2:0] row_index;
    reg [8:0] row_top;
    always @* begin
        if(pixel_y>=352)begin row_index=6;row_top=352;end
        else if(pixel_y>=308)begin row_index=5;row_top=308;end
        else if(pixel_y>=264)begin row_index=4;row_top=264;end
        else if(pixel_y>=220)begin row_index=3;row_top=220;end
        else if(pixel_y>=176)begin row_index=2;row_top=176;end
        else if(pixel_y>=132)begin row_index=1;row_top=132;end
        else begin row_index=0;row_top=88;end
    end
    wire [8:0] relative_y=pixel_y[8:0]-row_top;
    wire [9:0] label_x=pixel_x[9:0]-10'd136;
    wire [9:0] value_x=pixel_x[9:0]-10'd408;
    wire [9:0] resolution_x=pixel_x[9:0]-10'd304;
    wire [3:0] label_slot=label_x[8:5];
    wire [3:0] value_slot=value_x[7:4];
    wire [3:0] resolution_slot=resolution_x[7:4];
    wire divider=(relative_y==37 && row_index<6 && pixel_x>=132 && pixel_x<508);
    reg [4:0] font_y,font_x;
    reg [5:0] glyph_code;
    reg glyph_valid, glyph_is_value;
    reg [19:0] value_bcd, dimension_bcd;
    reg [3:0] dimension_slot;
    function [5:0] digit_code;
        input [19:0] bcd;
        input [3:0] slot;
        begin
            case(slot)
                0:digit_code=(bcd[19:16]==0)?0:6'd1+{2'd0,bcd[19:16]};
                1:digit_code=(bcd[19:12]==0)?0:6'd1+{2'd0,bcd[15:12]};
                2:digit_code=(bcd[19:8]==0)?0:6'd1+{2'd0,bcd[11:8]};
                3:digit_code=(bcd[19:4]==0)?0:6'd1+{2'd0,bcd[7:4]};
                default:digit_code=6'd1+{2'd0,bcd[3:0]};
            endcase
        end
    endfunction
    function [5:0] label_code;
input [2:0] row;input [3:0] slot;
begin
case({row,slot})
7'd0:label_code=6'd14; // 音
7'd1:label_code=6'd15; // 量
7'd16:label_code=6'd16; // 缩
7'd17:label_code=6'd17; // 放
7'd32:label_code=6'd18; // 亮
7'd33:label_code=6'd19; // 度
7'd48:label_code=6'd20; // 对
7'd49:label_code=6'd21; // 比
7'd50:label_code=6'd19; // 度
7'd64:label_code=6'd22; // 清
7'd65:label_code=6'd23; // 晰
7'd66:label_code=6'd19; // 度
7'd80:label_code=6'd24; // 饱
7'd81:label_code=6'd25; // 和
7'd82:label_code=6'd19; // 度
7'd96:label_code=6'd30; // 分
7'd97:label_code=6'd31; // 辨
7'd98:label_code=6'd32; // 率
default:label_code=0;
endcase
end
endfunction
    always @* begin
        value_bcd=displayed[row_index];
        dimension_bcd=resolution_slot<5 ? displayed[6] : displayed[7];
        dimension_slot=resolution_slot<5 ? resolution_slot : resolution_slot-6;
        glyph_code=0;glyph_valid=0;glyph_is_value=0;
        font_y=relative_y[4:0];font_x=label_x[4:0];
        if(card_on && pixel_y>=88 && relative_y<32)begin
            if(pixel_x>=136 && pixel_x<232)begin
                glyph_code=label_code(row_index,label_slot);glyph_valid=1;
            end else if(row_index<6 && pixel_x>=408 && pixel_x<480)begin
                glyph_is_value=1;glyph_valid=1;
                font_x=value_slot>=3 ? value_x-10'd48 : {1'b0,value_x[3:0]};
                glyph_code=value_slot>=3 ? 6'd11 : digit_code(value_bcd,value_slot+2);
            end else if(row_index==6 && pixel_x>=304 && pixel_x<480)begin
                glyph_is_value=1;glyph_valid=1;font_x={1'b0,resolution_x[3:0]};
                if(resolution_slot==5)glyph_code=12;
                else if(!display_resolution_valid)
                    glyph_code=(resolution_slot==4 || resolution_slot==10) ? 0 : 13;
                else glyph_code=digit_code(dimension_bcd,dimension_slot);
            end
        end
    end
    wire [31:0] font_row;
    player_info_font_rom font_rom(.clk(clk),.address({glyph_code,font_y}),.row_bits(font_row));
    reg hs_pipe,vs_pipe,de_pipe,card_pipe,border_pipe,divider_pipe,glyph_valid_pipe,value_pipe;
    reg [11:0] x_pipe,y_pipe;
    reg [23:0] rgb_pipe;
    reg [4:0] column_pipe;
    wire ink=glyph_valid_pipe && font_row[5'd31-column_pipe];
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            hs_pipe<=0;vs_pipe<=0;de_pipe<=0;card_pipe<=0;border_pipe<=0;divider_pipe<=0;glyph_valid_pipe<=0;value_pipe<=0;
            x_pipe<=0;y_pipe<=0;rgb_pipe<=0;column_pipe<=0;
            hs_out<=0;vs_out<=0;de_out<=0;pixel_x_out<=0;pixel_y_out<=0;rgb_out<=0;
        end else begin
            hs_pipe<=hs_in;vs_pipe<=vs_in;de_pipe<=de_in;x_pipe<=pixel_x;y_pipe<=pixel_y;rgb_pipe<=rgb_in;
            card_pipe<=card_on;border_pipe<=border;divider_pipe<=divider;glyph_valid_pipe<=glyph_valid;value_pipe<=glyph_is_value;column_pipe<=font_x;
            hs_out<=hs_pipe;vs_out<=vs_pipe;de_out<=de_pipe;pixel_x_out<=x_pipe;pixel_y_out<=y_pipe;
            if(!card_pipe)rgb_out<=rgb_pipe;
            else if(ink)rgb_out<=value_pipe ? 24'h087c8e : 24'h16324b;
            else if(border_pipe)rgb_out<=24'h8bb8c7;
            else if(divider_pipe)rgb_out<=24'hdce8ee;
            else rgb_out<=24'hf5f9fc;
        end
    end
endmodule

// One32K primitive, no DSP or divider. Both16bit ports form one32bit row.
// code32 occupies slot0; code0 is synchronously blanked without extra ROM.
module player_info_font_rom(input wire clk,input wire [10:0] address,output wire [31:0] row_bits);
reg valid_q;always @(posedge clk)valid_q<=(address[10:5]!=0 && address[10:5]<=32);
wire [31:0] row_data;
assign row_bits=valid_q ? row_data : 32'd0;
`ifdef DENTAL_OSD_BEHAVIORAL_RAM
reg [31:0] font [0:1023];initial begin
font[0]=32'h00000000;
font[1]=32'h00000000;
font[2]=32'h00000000;
font[3]=32'h00000000;
font[4]=32'h003c0000;
font[5]=32'h003c0000;
font[6]=32'h7ffffe00;
font[7]=32'h7ffffe00;
font[8]=32'h7ffffe00;
font[9]=32'h10730800;
font[10]=32'h38f39c00;
font[11]=32'h3de77c00;
font[12]=32'h09fe7800;
font[13]=32'h01fc3000;
font[14]=32'h043f7000;
font[15]=32'h1e7f7800;
font[16]=32'h3ff7bc00;
font[17]=32'h7bff9e00;
font[18]=32'h71ffce00;
font[19]=32'h21c1c400;
font[20]=32'h00008000;
font[21]=32'h003c0000;
font[22]=32'hffffff00;
font[23]=32'hffffff00;
font[24]=32'hffffff00;
font[25]=32'h003c0000;
font[26]=32'h003c0000;
font[27]=32'h00000000;
font[28]=32'h00000000;
font[29]=32'h00000000;
font[30]=32'h00000000;
font[31]=32'h00000000;
font[32]=32'h00000000;
font[33]=32'h00000000;
font[34]=32'h00000000;
font[35]=32'h00000000;
font[36]=32'h00000000;
font[37]=32'h00000000;
font[38]=32'h07c00000;
font[39]=32'h0ff00000;
font[40]=32'h1ff80000;
font[41]=32'h3c780000;
font[42]=32'h3c7c0000;
font[43]=32'h783c0000;
font[44]=32'h783c0000;
font[45]=32'h783c0000;
font[46]=32'h783c0000;
font[47]=32'h783c0000;
font[48]=32'h783c0000;
font[49]=32'h783c0000;
font[50]=32'h783c0000;
font[51]=32'h7c780000;
font[52]=32'h3c780000;
font[53]=32'h3ff00000;
font[54]=32'h1ff00000;
font[55]=32'h07c00000;
font[56]=32'h00000000;
font[57]=32'h00000000;
font[58]=32'h00000000;
font[59]=32'h00000000;
font[60]=32'h00000000;
font[61]=32'h00000000;
font[62]=32'h00000000;
font[63]=32'h00000000;
font[64]=32'h00000000;
font[65]=32'h00000000;
font[66]=32'h00000000;
font[67]=32'h00000000;
font[68]=32'h00000000;
font[69]=32'h00000000;
font[70]=32'h01c00000;
font[71]=32'h07c00000;
font[72]=32'h1fc00000;
font[73]=32'h3fc00000;
font[74]=32'h3fc00000;
font[75]=32'h33c00000;
font[76]=32'h03c00000;
font[77]=32'h03c00000;
font[78]=32'h03c00000;
font[79]=32'h03c00000;
font[80]=32'h03c00000;
font[81]=32'h03c00000;
font[82]=32'h03c00000;
font[83]=32'h03c00000;
font[84]=32'h03c00000;
font[85]=32'h03c00000;
font[86]=32'h03c00000;
font[87]=32'h03c00000;
font[88]=32'h00000000;
font[89]=32'h00000000;
font[90]=32'h00000000;
font[91]=32'h00000000;
font[92]=32'h00000000;
font[93]=32'h00000000;
font[94]=32'h00000000;
font[95]=32'h00000000;
font[96]=32'h00000000;
font[97]=32'h00000000;
font[98]=32'h00000000;
font[99]=32'h00000000;
font[100]=32'h00000000;
font[101]=32'h00000000;
font[102]=32'h0fc00000;
font[103]=32'h3ff00000;
font[104]=32'h3ff00000;
font[105]=32'h30f80000;
font[106]=32'h20780000;
font[107]=32'h00780000;
font[108]=32'h00780000;
font[109]=32'h00f80000;
font[110]=32'h01f00000;
font[111]=32'h03e00000;
font[112]=32'h07c00000;
font[113]=32'h1f800000;
font[114]=32'h1e000000;
font[115]=32'h3c000000;
font[116]=32'h7c000000;
font[117]=32'h7ff80000;
font[118]=32'h7ff80000;
font[119]=32'h7ff80000;
font[120]=32'h00000000;
font[121]=32'h00000000;
font[122]=32'h00000000;
font[123]=32'h00000000;
font[124]=32'h00000000;
font[125]=32'h00000000;
font[126]=32'h00000000;
font[127]=32'h00000000;
font[128]=32'h00000000;
font[129]=32'h00000000;
font[130]=32'h00000000;
font[131]=32'h00000000;
font[132]=32'h00000000;
font[133]=32'h00000000;
font[134]=32'h0fc00000;
font[135]=32'h1ff00000;
font[136]=32'h1ff80000;
font[137]=32'h10f80000;
font[138]=32'h00780000;
font[139]=32'h00780000;
font[140]=32'h00f00000;
font[141]=32'h0fe00000;
font[142]=32'h0fc00000;
font[143]=32'h0ff00000;
font[144]=32'h00f80000;
font[145]=32'h003c0000;
font[146]=32'h003c0000;
font[147]=32'h003c0000;
font[148]=32'h207c0000;
font[149]=32'h3ff80000;
font[150]=32'h3ff00000;
font[151]=32'h1fc00000;
font[152]=32'h00000000;
font[153]=32'h00000000;
font[154]=32'h00000000;
font[155]=32'h00000000;
font[156]=32'h00000000;
font[157]=32'h00000000;
font[158]=32'h00000000;
font[159]=32'h00000000;
font[160]=32'h00000000;
font[161]=32'h00000000;
font[162]=32'h00000000;
font[163]=32'h00000000;
font[164]=32'h00000000;
font[165]=32'h00000000;
font[166]=32'h00f00000;
font[167]=32'h01f00000;
font[168]=32'h03f00000;
font[169]=32'h03f00000;
font[170]=32'h07f00000;
font[171]=32'h0ff00000;
font[172]=32'h0ef00000;
font[173]=32'h1cf00000;
font[174]=32'h38f00000;
font[175]=32'h78f00000;
font[176]=32'hf0f00000;
font[177]=32'hfffe0000;
font[178]=32'hfffe0000;
font[179]=32'hfffe0000;
font[180]=32'h00f00000;
font[181]=32'h00f00000;
font[182]=32'h00f00000;
font[183]=32'h00f00000;
font[184]=32'h00000000;
font[185]=32'h00000000;
font[186]=32'h00000000;
font[187]=32'h00000000;
font[188]=32'h00000000;
font[189]=32'h00000000;
font[190]=32'h00000000;
font[191]=32'h00000000;
font[192]=32'h00000000;
font[193]=32'h00000000;
font[194]=32'h00000000;
font[195]=32'h00000000;
font[196]=32'h00000000;
font[197]=32'h00000000;
font[198]=32'h1ff00000;
font[199]=32'h3ff00000;
font[200]=32'h3ff00000;
font[201]=32'h38000000;
font[202]=32'h38000000;
font[203]=32'h38000000;
font[204]=32'h38000000;
font[205]=32'h3fc00000;
font[206]=32'h3ff00000;
font[207]=32'h3ff00000;
font[208]=32'h00f80000;
font[209]=32'h00780000;
font[210]=32'h00780000;
font[211]=32'h00780000;
font[212]=32'h20f80000;
font[213]=32'h3ff00000;
font[214]=32'h3fe00000;
font[215]=32'h1f800000;
font[216]=32'h00000000;
font[217]=32'h00000000;
font[218]=32'h00000000;
font[219]=32'h00000000;
font[220]=32'h00000000;
font[221]=32'h00000000;
font[222]=32'h00000000;
font[223]=32'h00000000;
font[224]=32'h00000000;
font[225]=32'h00000000;
font[226]=32'h00000000;
font[227]=32'h00000000;
font[228]=32'h00000000;
font[229]=32'h00000000;
font[230]=32'h03f80000;
font[231]=32'h07f80000;
font[232]=32'h1ff80000;
font[233]=32'h1e080000;
font[234]=32'h3c000000;
font[235]=32'h38000000;
font[236]=32'h79e00000;
font[237]=32'h7ff80000;
font[238]=32'h7ff80000;
font[239]=32'h7c7c0000;
font[240]=32'h783c0000;
font[241]=32'h783c0000;
font[242]=32'h783c0000;
font[243]=32'h783c0000;
font[244]=32'h3c780000;
font[245]=32'h3ff80000;
font[246]=32'h1ff00000;
font[247]=32'h07c00000;
font[248]=32'h00000000;
font[249]=32'h00000000;
font[250]=32'h00000000;
font[251]=32'h00000000;
font[252]=32'h00000000;
font[253]=32'h00000000;
font[254]=32'h00000000;
font[255]=32'h00000000;
font[256]=32'h00000000;
font[257]=32'h00000000;
font[258]=32'h00000000;
font[259]=32'h00000000;
font[260]=32'h00000000;
font[261]=32'h00000000;
font[262]=32'h7ffc0000;
font[263]=32'h7ffc0000;
font[264]=32'h7ffc0000;
font[265]=32'h00380000;
font[266]=32'h00780000;
font[267]=32'h00f00000;
font[268]=32'h00f00000;
font[269]=32'h01e00000;
font[270]=32'h01e00000;
font[271]=32'h03c00000;
font[272]=32'h03c00000;
font[273]=32'h03800000;
font[274]=32'h07800000;
font[275]=32'h07800000;
font[276]=32'h07800000;
font[277]=32'h0f000000;
font[278]=32'h0f000000;
font[279]=32'h0f000000;
font[280]=32'h00000000;
font[281]=32'h00000000;
font[282]=32'h00000000;
font[283]=32'h00000000;
font[284]=32'h00000000;
font[285]=32'h00000000;
font[286]=32'h00000000;
font[287]=32'h00000000;
font[288]=32'h00000000;
font[289]=32'h00000000;
font[290]=32'h00000000;
font[291]=32'h00000000;
font[292]=32'h00000000;
font[293]=32'h00000000;
font[294]=32'h07c00000;
font[295]=32'h1ff00000;
font[296]=32'h1ff00000;
font[297]=32'h3c780000;
font[298]=32'h3c780000;
font[299]=32'h3c780000;
font[300]=32'h3c700000;
font[301]=32'h1ff00000;
font[302]=32'h0fe00000;
font[303]=32'h1ff00000;
font[304]=32'h3c780000;
font[305]=32'h783c0000;
font[306]=32'h783c0000;
font[307]=32'h783c0000;
font[308]=32'h7c7c0000;
font[309]=32'h3ff80000;
font[310]=32'h1ff00000;
font[311]=32'h0fe00000;
font[312]=32'h00000000;
font[313]=32'h00000000;
font[314]=32'h00000000;
font[315]=32'h00000000;
font[316]=32'h00000000;
font[317]=32'h00000000;
font[318]=32'h00000000;
font[319]=32'h00000000;
font[320]=32'h00000000;
font[321]=32'h00000000;
font[322]=32'h00000000;
font[323]=32'h00000000;
font[324]=32'h00000000;
font[325]=32'h00000000;
font[326]=32'h07c00000;
font[327]=32'h1ff00000;
font[328]=32'h3ff80000;
font[329]=32'h3c780000;
font[330]=32'h783c0000;
font[331]=32'h783c0000;
font[332]=32'h783c0000;
font[333]=32'h783c0000;
font[334]=32'h7c7c0000;
font[335]=32'h3ffc0000;
font[336]=32'h1ffc0000;
font[337]=32'h0f3c0000;
font[338]=32'h00380000;
font[339]=32'h00780000;
font[340]=32'h20f80000;
font[341]=32'h3ff00000;
font[342]=32'h3fe00000;
font[343]=32'h3f800000;
font[344]=32'h00000000;
font[345]=32'h00000000;
font[346]=32'h00000000;
font[347]=32'h00000000;
font[348]=32'h00000000;
font[349]=32'h00000000;
font[350]=32'h00000000;
font[351]=32'h00000000;
font[352]=32'h00000000;
font[353]=32'h00000000;
font[354]=32'h00000000;
font[355]=32'h00000000;
font[356]=32'h00000000;
font[357]=32'h00000000;
font[358]=32'h1f01c000;
font[359]=32'h3f838000;
font[360]=32'h7bc38000;
font[361]=32'h71c70000;
font[362]=32'h71ce0000;
font[363]=32'h71ce0000;
font[364]=32'h7bdc0000;
font[365]=32'h3fbc0000;
font[366]=32'h1f380000;
font[367]=32'h0073e000;
font[368]=32'h00f7f000;
font[369]=32'h00ef7800;
font[370]=32'h01ce3800;
font[371]=32'h01ce3800;
font[372]=32'h038e3800;
font[373]=32'h070f7800;
font[374]=32'h0707f000;
font[375]=32'h0e03e000;
font[376]=32'h00000000;
font[377]=32'h00000000;
font[378]=32'h00000000;
font[379]=32'h00000000;
font[380]=32'h00000000;
font[381]=32'h00000000;
font[382]=32'h00000000;
font[383]=32'h00000000;
font[384]=32'h00000000;
font[385]=32'h00000000;
font[386]=32'h00000000;
font[387]=32'h00000000;
font[388]=32'h00000000;
font[389]=32'h00000000;
font[390]=32'h00000000;
font[391]=32'h00000000;
font[392]=32'h00000000;
font[393]=32'h00000000;
font[394]=32'h08040000;
font[395]=32'h1c0e0000;
font[396]=32'h0e1c0000;
font[397]=32'h07380000;
font[398]=32'h03f00000;
font[399]=32'h01e00000;
font[400]=32'h01e00000;
font[401]=32'h03f80000;
font[402]=32'h073c0000;
font[403]=32'h0e1e0000;
font[404]=32'h1c0e0000;
font[405]=32'h08040000;
font[406]=32'h00000000;
font[407]=32'h00000000;
font[408]=32'h00000000;
font[409]=32'h00000000;
font[410]=32'h00000000;
font[411]=32'h00000000;
font[412]=32'h00000000;
font[413]=32'h00000000;
font[414]=32'h00000000;
font[415]=32'h00000000;
font[416]=32'h00000000;
font[417]=32'h00000000;
font[418]=32'h00000000;
font[419]=32'h00000000;
font[420]=32'h00000000;
font[421]=32'h00000000;
font[422]=32'h00000000;
font[423]=32'h00000000;
font[424]=32'h00000000;
font[425]=32'h00000000;
font[426]=32'h00000000;
font[427]=32'h00000000;
font[428]=32'h00000000;
font[429]=32'h00000000;
font[430]=32'h00000000;
font[431]=32'h00000000;
font[432]=32'h3f000000;
font[433]=32'h3f000000;
font[434]=32'h3f000000;
font[435]=32'h00000000;
font[436]=32'h00000000;
font[437]=32'h00000000;
font[438]=32'h00000000;
font[439]=32'h00000000;
font[440]=32'h00000000;
font[441]=32'h00000000;
font[442]=32'h00000000;
font[443]=32'h00000000;
font[444]=32'h00000000;
font[445]=32'h00000000;
font[446]=32'h00000000;
font[447]=32'h00000000;
font[448]=32'h00000000;
font[449]=32'h00000000;
font[450]=32'h00000000;
font[451]=32'h00000000;
font[452]=32'h00380000;
font[453]=32'h003c0000;
font[454]=32'h7ffffe00;
font[455]=32'h7ffffe00;
font[456]=32'h3ffffe00;
font[457]=32'h0381e000;
font[458]=32'h03c3c000;
font[459]=32'hffffff00;
font[460]=32'hffffff00;
font[461]=32'h7ffffe00;
font[462]=32'h00000000;
font[463]=32'h1ffff800;
font[464]=32'h1ffff800;
font[465]=32'h1ffff800;
font[466]=32'h1c003800;
font[467]=32'h1ffff800;
font[468]=32'h1ffff800;
font[469]=32'h1e007800;
font[470]=32'h1c003800;
font[471]=32'h1c003800;
font[472]=32'h1ffff800;
font[473]=32'h1ffff800;
font[474]=32'h1ffff800;
font[475]=32'h1c003800;
font[476]=32'h00000000;
font[477]=32'h00000000;
font[478]=32'h00000000;
font[479]=32'h00000000;
font[480]=32'h00000000;
font[481]=32'h00000000;
font[482]=32'h00000000;
font[483]=32'h00000000;
font[484]=32'h00000000;
font[485]=32'h1ffff800;
font[486]=32'h1ffff800;
font[487]=32'h1c003800;
font[488]=32'h1ffff800;
font[489]=32'h1c003800;
font[490]=32'h1ffff800;
font[491]=32'h1ffff800;
font[492]=32'h00000000;
font[493]=32'hffffff00;
font[494]=32'h7ffffe00;
font[495]=32'h00000000;
font[496]=32'h1ffff800;
font[497]=32'h1c3c3800;
font[498]=32'h1ffff800;
font[499]=32'h1ffff800;
font[500]=32'h1ffff800;
font[501]=32'h003c0000;
font[502]=32'h3ffffc00;
font[503]=32'h3ffffc00;
font[504]=32'h003c0000;
font[505]=32'hffffff00;
font[506]=32'h7fffff00;
font[507]=32'h00000000;
font[508]=32'h00000000;
font[509]=32'h00000000;
font[510]=32'h00000000;
font[511]=32'h00000000;
font[512]=32'h00000000;
font[513]=32'h00000000;
font[514]=32'h00000000;
font[515]=32'h00000000;
font[516]=32'h0c038000;
font[517]=32'h1e078000;
font[518]=32'h1c038000;
font[519]=32'h1cfffe00;
font[520]=32'h38fffe00;
font[521]=32'h38fffe00;
font[522]=32'h76f00e00;
font[523]=32'h7f780000;
font[524]=32'hff7fff00;
font[525]=32'h7e7fff00;
font[526]=32'h7ef7fe00;
font[527]=32'h1cf0e000;
font[528]=32'h39f7fe00;
font[529]=32'h79f7fe00;
font[530]=32'h7ff7fe00;
font[531]=32'h7ff70e00;
font[532]=32'h7f77fe00;
font[533]=32'h0077fe00;
font[534]=32'h00770e00;
font[535]=32'h1f770e00;
font[536]=32'h7f77fe00;
font[537]=32'h7e77fe00;
font[538]=32'h7077fe00;
font[539]=32'h00770e00;
font[540]=32'h00000000;
font[541]=32'h00000000;
font[542]=32'h00000000;
font[543]=32'h00000000;
font[544]=32'h00000000;
font[545]=32'h00000000;
font[546]=32'h00000000;
font[547]=32'h00000000;
font[548]=32'h06038000;
font[549]=32'h0f03c000;
font[550]=32'h0f038000;
font[551]=32'h07038000;
font[552]=32'h7ff7ff00;
font[553]=32'h7ff7ff00;
font[554]=32'h7fffff00;
font[555]=32'h3c0f1c00;
font[556]=32'h1c0e1c00;
font[557]=32'h1c1f1c00;
font[558]=32'h3fff1c00;
font[559]=32'h3fff3c00;
font[560]=32'h3fef3800;
font[561]=32'h3ce3b800;
font[562]=32'h38e3f800;
font[563]=32'h38e3f000;
font[564]=32'h38e1f000;
font[565]=32'h38e1e000;
font[566]=32'h78e3f000;
font[567]=32'h79e7f800;
font[568]=32'hf1effe00;
font[569]=32'h7fff3e00;
font[570]=32'h67de0e00;
font[571]=32'h27880400;
font[572]=32'h00000000;
font[573]=32'h00000000;
font[574]=32'h00000000;
font[575]=32'h00000000;
font[576]=32'h00000000;
font[577]=32'h00000000;
font[578]=32'h00000000;
font[579]=32'h00000000;
font[580]=32'h00380000;
font[581]=32'h003c0000;
font[582]=32'h7ffffe00;
font[583]=32'h7ffffe00;
font[584]=32'h00000000;
font[585]=32'h0ffff000;
font[586]=32'h0ffff000;
font[587]=32'h0e007000;
font[588]=32'h0e007000;
font[589]=32'h0ffff000;
font[590]=32'h0ffff000;
font[591]=32'h00000000;
font[592]=32'h7ffffe00;
font[593]=32'h7ffffe00;
font[594]=32'h78001e00;
font[595]=32'h73ff8e00;
font[596]=32'h03ff8000;
font[597]=32'h03c38000;
font[598]=32'h03838400;
font[599]=32'h07838700;
font[600]=32'h0f83cf00;
font[601]=32'h7f03fe00;
font[602]=32'h7c03fe00;
font[603]=32'h3000f800;
font[604]=32'h00000000;
font[605]=32'h00000000;
font[606]=32'h00000000;
font[607]=32'h00000000;
font[608]=32'h00000000;
font[609]=32'h00000000;
font[610]=32'h00000000;
font[611]=32'h00000000;
font[612]=32'h001e0000;
font[613]=32'h001e0000;
font[614]=32'h3fffff00;
font[615]=32'h3fffff00;
font[616]=32'h3ffffe00;
font[617]=32'h38e07000;
font[618]=32'h38e07000;
font[619]=32'h3ffffe00;
font[620]=32'h3ffffe00;
font[621]=32'h3bfffe00;
font[622]=32'h38e07000;
font[623]=32'h38fff000;
font[624]=32'h38fff000;
font[625]=32'h38000000;
font[626]=32'h38000000;
font[627]=32'h3bfff800;
font[628]=32'h3bfff800;
font[629]=32'h7bfff800;
font[630]=32'h70f0f000;
font[631]=32'h707fe000;
font[632]=32'h703ffe00;
font[633]=32'hfffffe00;
font[634]=32'h67f9fe00;
font[635]=32'h22000000;
font[636]=32'h00000000;
font[637]=32'h00000000;
font[638]=32'h00000000;
font[639]=32'h00000000;
font[640]=32'h00000000;
font[641]=32'h00000000;
font[642]=32'h00000000;
font[643]=32'h00000000;
font[644]=32'h00003c00;
font[645]=32'h00003c00;
font[646]=32'h7fe03c00;
font[647]=32'h7fe03c00;
font[648]=32'h7fffff00;
font[649]=32'h01ffff00;
font[650]=32'h31ffff00;
font[651]=32'h71c03c00;
font[652]=32'h79c03c00;
font[653]=32'h3dc83c00;
font[654]=32'h3fdc3c00;
font[655]=32'h1f9e3c00;
font[656]=32'h0f8f3c00;
font[657]=32'h0f87bc00;
font[658]=32'h0787bc00;
font[659]=32'h0fc23c00;
font[660]=32'h1fc03c00;
font[661]=32'h1fe03c00;
font[662]=32'h3df03c00;
font[663]=32'h78e03c00;
font[664]=32'h7047f800;
font[665]=32'h7007f800;
font[666]=32'h2007f000;
font[667]=32'h00000000;
font[668]=32'h00000000;
font[669]=32'h00000000;
font[670]=32'h00000000;
font[671]=32'h00000000;
font[672]=32'h00000000;
font[673]=32'h00000000;
font[674]=32'h00000000;
font[675]=32'h00000000;
font[676]=32'h380f0000;
font[677]=32'h380f0000;
font[678]=32'h380f0000;
font[679]=32'h380f0000;
font[680]=32'h380f0800;
font[681]=32'h380f1e00;
font[682]=32'h380f3e00;
font[683]=32'h3fef7c00;
font[684]=32'h3feff800;
font[685]=32'h3feff000;
font[686]=32'h3c0fe000;
font[687]=32'h380fc000;
font[688]=32'h380f0000;
font[689]=32'h380f0000;
font[690]=32'h380f0000;
font[691]=32'h380f0000;
font[692]=32'h380f0c00;
font[693]=32'h38ef0f00;
font[694]=32'h3fef0e00;
font[695]=32'h3fef0e00;
font[696]=32'h3fcf1e00;
font[697]=32'h7f0ffe00;
font[698]=32'h3c0ffc00;
font[699]=32'h3007fc00;
font[700]=32'h00000000;
font[701]=32'h00000000;
font[702]=32'h00000000;
font[703]=32'h00000000;
font[704]=32'h00000000;
font[705]=32'h00000000;
font[706]=32'h00000000;
font[707]=32'h00000000;
font[708]=32'h30078000;
font[709]=32'h78078000;
font[710]=32'h3dfffe00;
font[711]=32'h1dfffe00;
font[712]=32'h08078000;
font[713]=32'h01fffe00;
font[714]=32'h01fffe00;
font[715]=32'h20078000;
font[716]=32'h73ffff00;
font[717]=32'h7bffff00;
font[718]=32'h3c000000;
font[719]=32'h18fffc00;
font[720]=32'h00fffc00;
font[721]=32'h00e01c00;
font[722]=32'h18fffc00;
font[723]=32'h1cfffc00;
font[724]=32'h1ce01c00;
font[725]=32'h3ce01c00;
font[726]=32'h38fffc00;
font[727]=32'h38fffc00;
font[728]=32'h38e01c00;
font[729]=32'h78e01c00;
font[730]=32'h70e3fc00;
font[731]=32'h30e1f800;
font[732]=32'h00000000;
font[733]=32'h00000000;
font[734]=32'h00000000;
font[735]=32'h00000000;
font[736]=32'h00000000;
font[737]=32'h00000000;
font[738]=32'h00000000;
font[739]=32'h00000000;
font[740]=32'h00380000;
font[741]=32'h00380600;
font[742]=32'h00383e00;
font[743]=32'h0039fe00;
font[744]=32'h7f39fc00;
font[745]=32'h7f39c000;
font[746]=32'h7fffc000;
font[747]=32'h77ffc000;
font[748]=32'h77fdc000;
font[749]=32'h7739ff00;
font[750]=32'h7779ff00;
font[751]=32'h7f7dff00;
font[752]=32'h7f7fdc00;
font[753]=32'h7fffdc00;
font[754]=32'h77fddc00;
font[755]=32'h77f9dc00;
font[756]=32'h77b9dc00;
font[757]=32'h77bb9c00;
font[758]=32'h773b9c00;
font[759]=32'h7f3b9c00;
font[760]=32'h7f3f9c00;
font[761]=32'h7f3f1c00;
font[762]=32'h773f1c00;
font[763]=32'h003a1c00;
font[764]=32'h00000000;
font[765]=32'h00000000;
font[766]=32'h00000000;
font[767]=32'h00000000;
font[768]=32'h00000000;
font[769]=32'h00000000;
font[770]=32'h00000000;
font[771]=32'h00000000;
font[772]=32'h1c1c0000;
font[773]=32'h1c3c0000;
font[774]=32'h3c3ffc00;
font[775]=32'h3fbffc00;
font[776]=32'h3fbffc00;
font[777]=32'h7ff01c00;
font[778]=32'h73f01c00;
font[779]=32'hf7ffdc00;
font[780]=32'h67ffdc00;
font[781]=32'h7e7fdc00;
font[782]=32'h5c71dc00;
font[783]=32'h1c71dc00;
font[784]=32'h1c71dc00;
font[785]=32'h1c7fdc00;
font[786]=32'h1c7ffc00;
font[787]=32'h1c7ff800;
font[788]=32'h1c71fc00;
font[789]=32'h1d700700;
font[790]=32'h1ff00f00;
font[791]=32'h1ff80e00;
font[792]=32'h3f7ffe00;
font[793]=32'h1c3ffc00;
font[794]=32'h081ff800;
font[795]=32'h00000000;
font[796]=32'h00000000;
font[797]=32'h00000000;
font[798]=32'h00000000;
font[799]=32'h00000000;
font[800]=32'h00000000;
font[801]=32'h00000000;
font[802]=32'h00000000;
font[803]=32'h00000000;
font[804]=32'h00e00000;
font[805]=32'h1fe00000;
font[806]=32'h7feffe00;
font[807]=32'h7f8ffe00;
font[808]=32'h7f0ffe00;
font[809]=32'h070e1e00;
font[810]=32'h070e1e00;
font[811]=32'hffee1e00;
font[812]=32'hffee1e00;
font[813]=32'hffee1e00;
font[814]=32'h0f0e1e00;
font[815]=32'h0f0e1e00;
font[816]=32'h1f8e1e00;
font[817]=32'h1fce1e00;
font[818]=32'h3fee1e00;
font[819]=32'h3ffe1e00;
font[820]=32'h7f6e1e00;
font[821]=32'hf70e1e00;
font[822]=32'h670ffe00;
font[823]=32'h670ffe00;
font[824]=32'h070ffe00;
font[825]=32'h070e1e00;
font[826]=32'h070e1e00;
font[827]=32'h07000000;
font[828]=32'h00000000;
font[829]=32'h00000000;
font[830]=32'h00000000;
font[831]=32'h00000000;
font[832]=32'h00000000;
font[833]=32'h00000000;
font[834]=32'h00000000;
font[835]=32'h00000000;
font[836]=32'h00000000;
font[837]=32'h00000000;
font[838]=32'h00000000;
font[839]=32'h00000000;
font[840]=32'h00000000;
font[841]=32'h00000000;
font[842]=32'h00000000;
font[843]=32'h00000000;
font[844]=32'h00000000;
font[845]=32'h00000000;
font[846]=32'h00000000;
font[847]=32'h00000000;
font[848]=32'h00000000;
font[849]=32'h00000000;
font[850]=32'h00000000;
font[851]=32'h00000000;
font[852]=32'h00000000;
font[853]=32'h00000000;
font[854]=32'h00000000;
font[855]=32'h00000000;
font[856]=32'h00000000;
font[857]=32'h00000000;
font[858]=32'h00000000;
font[859]=32'h00000000;
font[860]=32'h00000000;
font[861]=32'h00000000;
font[862]=32'h00000000;
font[863]=32'h00000000;
font[864]=32'h00000000;
font[865]=32'h00000000;
font[866]=32'h00000000;
font[867]=32'h00000000;
font[868]=32'h00000000;
font[869]=32'h00000000;
font[870]=32'h00000000;
font[871]=32'h00000000;
font[872]=32'h00000000;
font[873]=32'h00000000;
font[874]=32'h00000000;
font[875]=32'h00000000;
font[876]=32'h00000000;
font[877]=32'h00000000;
font[878]=32'h00000000;
font[879]=32'h00000000;
font[880]=32'h00000000;
font[881]=32'h00000000;
font[882]=32'h00000000;
font[883]=32'h00000000;
font[884]=32'h00000000;
font[885]=32'h00000000;
font[886]=32'h00000000;
font[887]=32'h00000000;
font[888]=32'h00000000;
font[889]=32'h00000000;
font[890]=32'h00000000;
font[891]=32'h00000000;
font[892]=32'h00000000;
font[893]=32'h00000000;
font[894]=32'h00000000;
font[895]=32'h00000000;
font[896]=32'h00000000;
font[897]=32'h00000000;
font[898]=32'h00000000;
font[899]=32'h00000000;
font[900]=32'h00000000;
font[901]=32'h00000000;
font[902]=32'h00000000;
font[903]=32'h00000000;
font[904]=32'h00000000;
font[905]=32'h00000000;
font[906]=32'h00000000;
font[907]=32'h00000000;
font[908]=32'h00000000;
font[909]=32'h00000000;
font[910]=32'h00000000;
font[911]=32'h00000000;
font[912]=32'h00000000;
font[913]=32'h00000000;
font[914]=32'h00000000;
font[915]=32'h00000000;
font[916]=32'h00000000;
font[917]=32'h00000000;
font[918]=32'h00000000;
font[919]=32'h00000000;
font[920]=32'h00000000;
font[921]=32'h00000000;
font[922]=32'h00000000;
font[923]=32'h00000000;
font[924]=32'h00000000;
font[925]=32'h00000000;
font[926]=32'h00000000;
font[927]=32'h00000000;
font[928]=32'h00000000;
font[929]=32'h00000000;
font[930]=32'h00000000;
font[931]=32'h00000000;
font[932]=32'h00000000;
font[933]=32'h00000000;
font[934]=32'h00000000;
font[935]=32'h00000000;
font[936]=32'h00000000;
font[937]=32'h00000000;
font[938]=32'h00000000;
font[939]=32'h00000000;
font[940]=32'h00000000;
font[941]=32'h00000000;
font[942]=32'h00000000;
font[943]=32'h00000000;
font[944]=32'h00000000;
font[945]=32'h00000000;
font[946]=32'h00000000;
font[947]=32'h00000000;
font[948]=32'h00000000;
font[949]=32'h00000000;
font[950]=32'h00000000;
font[951]=32'h00000000;
font[952]=32'h00000000;
font[953]=32'h00000000;
font[954]=32'h00000000;
font[955]=32'h00000000;
font[956]=32'h00000000;
font[957]=32'h00000000;
font[958]=32'h00000000;
font[959]=32'h00000000;
font[960]=32'h00000000;
font[961]=32'h00000000;
font[962]=32'h00000000;
font[963]=32'h00000000;
font[964]=32'h00c10000;
font[965]=32'h01e78000;
font[966]=32'h01e3c000;
font[967]=32'h03c3e000;
font[968]=32'h0781e000;
font[969]=32'h0f80f000;
font[970]=32'h1f00fc00;
font[971]=32'h3e007e00;
font[972]=32'hfc003f00;
font[973]=32'h7ffffe00;
font[974]=32'h3ffff400;
font[975]=32'h1ffff000;
font[976]=32'h01e0f000;
font[977]=32'h01c0f000;
font[978]=32'h01c0f000;
font[979]=32'h03c0f000;
font[980]=32'h03c0f000;
font[981]=32'h07c0f000;
font[982]=32'h0780f000;
font[983]=32'h0f80e000;
font[984]=32'h3f3fe000;
font[985]=32'h7e1fe000;
font[986]=32'h3c1fc000;
font[987]=32'h10180000;
font[988]=32'h00000000;
font[989]=32'h00000000;
font[990]=32'h00000000;
font[991]=32'h00000000;
font[992]=32'h00000000;
font[993]=32'h00000000;
font[994]=32'h00000000;
font[995]=32'h00000000;
font[996]=32'h1c0c3000;
font[997]=32'h1c0c7000;
font[998]=32'h1c0c7800;
font[999]=32'h7f8dfe00;
font[1000]=32'h7f8dfe00;
font[1001]=32'h737dcc00;
font[1002]=32'h73fdce00;
font[1003]=32'h736dce00;
font[1004]=32'h376ccc00;
font[1005]=32'h376cdc00;
font[1006]=32'hffefff00;
font[1007]=32'hffefff00;
font[1008]=32'h7fefff00;
font[1009]=32'h1c6c7800;
font[1010]=32'h1c1c7800;
font[1011]=32'h7f9dfe00;
font[1012]=32'h7f9dfe00;
font[1013]=32'h7f9dfe00;
font[1014]=32'h1c3c7800;
font[1015]=32'h3c387800;
font[1016]=32'h38787800;
font[1017]=32'h78f07800;
font[1018]=32'h70f07800;
font[1019]=32'h30607800;
font[1020]=32'h00000000;
font[1021]=32'h00000000;
font[1022]=32'h00000000;
font[1023]=32'h00000000;
end
reg [31:0] row_q;always @(posedge clk)row_q<=font[address[9:0]];
assign row_data=row_q;
`else
wire [15:0] upper_bits,lower_bits;
assign row_data={upper_bits,lower_bits};
EG_PHY_BRAM32K #(
.MODE("DP16K"),.DATA_WIDTH_A("16"),.DATA_WIDTH_B("16"),
.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
.WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.SRMODE("SYNC"),
.CSAMUX("SIG"),.CSBMUX("SIG"),.OCEAMUX("SIG"),.OCEBMUX("SIG"),
.RSTAMUX("SIG"),.RSTBMUX("SIG"),.CLKAMUX("SIG"),.CLKBMUX("SIG"),
.WEAMUX("SIG"),.WEBMUX("SIG"),.READBACK("OFF"),.INIT_FILE(""),
.INIT_00(256'hfe007ffffe007fff0000003c0000003c00000000000000000000000000000000),
.INIT_01(256'h78001e7f7000043f300001fc780009fe7c003de79c0038f308001073fe007fff),
.INIT_02(256'hff00ffffff00ffff0000003c80000000c40021c1ce0071ff9e007bffbc003ff7),
.INIT_03(256'h00000000000000000000000000000000000000000000003c0000003cff00ffff),
.INIT_04(256'h00000ff0000007c0000000000000000000000000000000000000000000000000),
.INIT_05(256'h0000783c0000783c0000783c0000783c0000783c00003c7c00003c7800001ff8),
.INIT_06(256'h000007c000001ff000003ff000003c7800007c780000783c0000783c0000783c),
.INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_08(256'h000007c0000001c0000000000000000000000000000000000000000000000000),
.INIT_09(256'h000003c0000003c0000003c0000003c0000033c000003fc000003fc000001fc0),
.INIT_0A(256'h000003c0000003c0000003c0000003c0000003c0000003c0000003c0000003c0),
.INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_0C(256'h00003ff000000fc0000000000000000000000000000000000000000000000000),
.INIT_0D(256'h000003e0000001f0000000f8000000780000007800002078000030f800003ff0),
.INIT_0E(256'h00007ff800007ff800007ff800007c0000003c0000001e0000001f80000007c0),
.INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_10(256'h00001ff000000fc0000000000000000000000000000000000000000000000000),
.INIT_11(256'h00000ff000000fc000000fe0000000f00000007800000078000010f800001ff8),
.INIT_12(256'h00001fc000003ff000003ff80000207c0000003c0000003c0000003c000000f8),
.INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_14(256'h000001f0000000f0000000000000000000000000000000000000000000000000),
.INIT_15(256'h000078f0000038f000001cf000000ef000000ff0000007f0000003f0000003f0),
.INIT_16(256'h000000f0000000f0000000f0000000f00000fffe0000fffe0000fffe0000f0f0),
.INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_18(256'h00003ff000001ff0000000000000000000000000000000000000000000000000),
.INIT_19(256'h00003ff000003ff000003fc00000380000003800000038000000380000003ff0),
.INIT_1A(256'h00001f8000003fe000003ff0000020f8000000780000007800000078000000f8),
.INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_1C(256'h000007f8000003f8000000000000000000000000000000000000000000000000),
.INIT_1D(256'h00007c7c00007ff800007ff8000079e00000380000003c0000001e0800001ff8),
.INIT_1E(256'h000007c000001ff000003ff800003c780000783c0000783c0000783c0000783c),
.INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_20(256'h00007ffc00007ffc000000000000000000000000000000000000000000000000),
.INIT_21(256'h000003c0000001e0000001e0000000f0000000f0000000780000003800007ffc),
.INIT_22(256'h00000f0000000f0000000f0000000780000007800000078000000380000003c0),
.INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_24(256'h00001ff0000007c0000000000000000000000000000000000000000000000000),
.INIT_25(256'h00001ff000000fe000001ff000003c7000003c7800003c7800003c7800001ff0),
.INIT_26(256'h00000fe000001ff000003ff800007c7c0000783c0000783c0000783c00003c78),
.INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_28(256'h00001ff0000007c0000000000000000000000000000000000000000000000000),
.INIT_29(256'h00003ffc00007c7c0000783c0000783c0000783c0000783c00003c7800003ff8),
.INIT_2A(256'h00003f8000003fe000003ff0000020f8000000780000003800000f3c00001ffc),
.INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_2C(256'h80003f83c0001f01000000000000000000000000000000000000000000000000),
.INIT_2D(256'he000007300001f3800003fbc00007bdc000071ce000071ce000071c780007bc3),
.INIT_2E(256'he0000e03f00007077800070f3800038e380001ce380001ce780000eff00000f7),
.INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_31(256'h000001e0000003f00000073800000e1c00001c0e000008040000000000000000),
.INIT_32(256'h00000000000000000000080400001c0e00000e1e0000073c000003f8000001e0),
.INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_36(256'h000000000000000000000000000000000000000000003f0000003f0000003f00),
.INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_38(256'hfe007ffffe007fff0000003c0000003800000000000000000000000000000000),
.INIT_39(256'hf8001fff00000000fe007fffff00ffffff00ffffc00003c3e0000381fe003fff),
.INIT_3A(256'h38001c0038001c0078001e00f8001ffff8001fff38001c00f8001ffff8001fff),
.INIT_3B(256'h0000000000000000000000000000000038001c00f8001ffff8001ffff8001fff),
.INIT_3C(256'h38001c00f8001ffff8001fff0000000000000000000000000000000000000000),
.INIT_3D(256'h00000000fe007fffff00ffff00000000f8001ffff8001fff38001c00f8001fff),
.INIT_3E(256'hfc003ffffc003fff0000003cf8001ffff8001ffff8001fff38001c3cf8001fff),
.INIT_3F(256'h0000000000000000000000000000000000000000ff007fffff00ffff0000003c),
.INIT_40(256'hfe001cff80001c0380001e0780000c0300000000000000000000000000000000),
.INIT_41(256'he0001cf0fe007ef7ff007e7fff00ff7f00007f780e0076f0fe0038fffe0038ff),
.INIT_42(256'h0e001f770e000077fe000077fe007f770e007ff7fe007ff7fe0079f7fe0039f7),
.INIT_43(256'h000000000000000000000000000000000e000077fe007077fe007e77fe007f77),
.INIT_44(256'h8000070380000f03c0000f038000060300000000000000000000000000000000),
.INIT_45(256'h3c003fff1c003fff1c001c1f1c001c0e1c003c0fff007fffff007ff7ff007ff7),
.INIT_46(256'hf80079e7f00078e3e00038e1f00038e1f00038e3f80038e3b8003ce338003fef),
.INIT_47(256'h00000000000000000000000000000000040027880e0067de3e007ffffe00f1ef),
.INIT_48(256'hfe007ffffe007fff0000003c0000003800000000000000000000000000000000),
.INIT_49(256'h00000000f0000ffff0000fff70000e0070000e00f0000ffff0000fff00000000),
.INIT_4A(256'h8700078384000383800003c3800003ff8e0073ff1e007800fe007ffffe007fff),
.INIT_4B(256'h00000000000000000000000000000000f8003000fe007c03fe007f03cf000f83),
.INIT_4C(256'hff003fffff003fff0000001e0000001e00000000000000000000000000000000),
.INIT_4D(256'hf00038ff700038e0fe003bfffe003ffffe003fff700038e0700038e0fe003fff),
.INIT_4E(256'he000707ff00070f0f8007bfff8003bfff8003bff0000380000003800f00038ff),
.INIT_4F(256'h0000000000000000000000000000000000002200fe0067f9fe00fffffe00703f),
.INIT_50(256'h3c007fe03c007fe03c0000003c00000000000000000000000000000000000000),
.INIT_51(256'h3c001f9e3c003fdc3c003dc83c0079c03c0071c0ff0031ffff0001ffff007fff),
.INIT_52(256'h3c0078e03c003df03c001fe03c001fc03c000fc2bc000787bc000f873c000f8f),
.INIT_53(256'h0000000000000000000000000000000000000000f0002007f8007007f8007047),
.INIT_54(256'h0000380f0000380f0000380f0000380f00000000000000000000000000000000),
.INIT_55(256'hc000380fe0003c0ff0003feff8003fef7c003fef3e00380f1e00380f0800380f),
.INIT_56(256'h0e003fef0e003fef0f0038ef0c00380f0000380f0000380f0000380f0000380f),
.INIT_57(256'h00000000000000000000000000000000fc003007fc003c0ffe007f0f1e003fcf),
.INIT_58(256'hfe001dfffe003dff800078078000300700000000000000000000000000000000),
.INIT_59(256'hfc0018ff00003c00ff007bffff0073ff80002007fe0001fffe0001ff80000807),
.INIT_5A(256'hfc0038fffc0038ff1c003ce01c001ce0fc001cfffc0018ff1c0000e0fc0000ff),
.INIT_5B(256'h00000000000000000000000000000000f80030e1fc0070e31c0078e01c0038e0),
.INIT_5C(256'hfe0000393e000038060000380000003800000000000000000000000000000000),
.INIT_5D(256'hff007f7dff007779ff007739c00077fdc00077ffc0007fffc0007f39fc007f39),
.INIT_5E(256'h9c007f3b9c00773b9c0077bbdc0077b9dc0077f9dc0077fddc007fffdc007f7f),
.INIT_5F(256'h000000000000000000000000000000001c00003a1c00773f1c007f3f9c007f3f),
.INIT_60(256'hfc003fbffc003c3f00001c3c00001c1c00000000000000000000000000000000),
.INIT_61(256'hdc001c71dc005c71dc007e7fdc0067ffdc00f7ff1c0073f01c007ff0fc003fbf),
.INIT_62(256'h0e001ff80f001ff007001d70fc001c71f8001c7ffc001c7fdc001c7fdc001c71),
.INIT_63(256'h0000000000000000000000000000000000000000f800081ffc001c3ffe003f7f),
.INIT_64(256'hfe007f8ffe007fef00001fe0000000e000000000000000000000000000000000),
.INIT_65(256'h1e000f0e1e000f0e1e00ffee1e00ffee1e00ffee1e00070e1e00070efe007f0f),
.INIT_66(256'hfe00670ffe00670f1e00f70e1e007f6e1e003ffe1e003fee1e001fce1e001f8e),
.INIT_67(256'h00000000000000000000000000000000000007001e00070e1e00070efe00070f),
.INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
.INIT_78(256'he00003c3c00001e3800001e7000000c100000000000000000000000000000000),
.INIT_79(256'hf0001ffff4003ffffe007fff3f00fc007e003e00fc001f00f0000f80e0000781),
.INIT_7A(256'he0000f80f0000780f00007c0f00003c0f00003c0f00001c0f00001c0f00001e0),
.INIT_7B(256'h0000000000000000000000000000000000001018c0003c1fe0007e1fe0003f3f),
.INIT_7C(256'hfe007f8d78001c0c70001c0c30001c0c00000000000000000000000000000000),
.INIT_7D(256'hff00ffefff00ffefdc00376ccc00376cce00736dce0073fdcc00737dfe007f8d),
.INIT_7E(256'h78003c3878001c3cfe007f9dfe007f9dfe007f9d78001c1c78001c6cff007fef),
.INIT_7F(256'h0000000000000000000000000000000078003060780070f0780078f078003878)
) u_font32k(
.doa(upper_bits),.dob(lower_bits),.dia(16'd0),.dib(16'd0),
.addra({address[9:0],1'b0}),.addrb({address[9:0],1'b1}),
.bytea(1'b0),.bytewea(1'b0),.byteb(1'b0),.byteweb(1'b0),
.csa(1'b1),.csb(1'b1),.wea(1'b0),.web(1'b0),
.clka(clk),.clkb(clk),.rsta(1'b0),.rstb(1'b0),.ocea(1'b1),.oceb(1'b1));
`endif
endmodule
