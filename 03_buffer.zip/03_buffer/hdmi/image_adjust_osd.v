`timescale 1ns/1ps

// Transparent 2x 5x7 text below VOL: BRI nnn, CON nnn, MODE xxx STEP nnn.
// INPUT_IS_PERCENT=1 expects controller-mapped 0..100 values and adds %.
// Inputs are one frame-committed pixel-domain tuple; no rescaling hardware. Serial decimal conversion
// is published atomically during vertical blank, before this frame's first DE.
// Rendering is combinational and adds no video latency.
module image_adjust_osd #(
    parameter integer TEXT_X = 16,
    parameter integer TEXT_Y = 40,
    parameter integer INPUT_IS_PERCENT = 0
) (
    input wire clk,
    input wire rst_n,
    input wire vsync,
    input wire de,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire enable,
    input wire [7:0] brightness,
    input wire [7:0] contrast,
    input wire [1:0] mode,
    input wire [5:0] step,
    input wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire overlay_active
);
    reg vs_q, publish_window, converting, converted_valid, display_valid;
    wire frame_start = vs_q && !vsync;
    wire [23:0] input_tuple = {brightness,contrast,mode,step};
    reg [23:0] conversion_tuple, displayed_tuple;
    reg [7:0] b_shift, c_shift, s_shift;
    reg [2:0] bit_count;
    reg [11:0] b_work, c_work, s_work;
    reg [11:0] b_converted, c_converted, s_converted;
    reg [11:0] b_displayed, c_displayed, s_displayed;

    function [11:0] bcd_step;
        input [11:0] work;
        input next_bit;
        reg [11:0] adjusted;
        begin
            adjusted = work;
            if (work[3:0] >= 5) adjusted[3:0] = work[3:0] + 4'd3;
            if (work[7:4] >= 5) adjusted[7:4] = work[7:4] + 4'd3;
            if (work[11:8] >= 5) adjusted[11:8] = work[11:8] + 4'd3;
            bcd_step = {adjusted[10:0],next_bit};
        end
    endfunction
    wire [11:0] b_next = bcd_step(b_work,b_shift[7]);
    wire [11:0] c_next = bcd_step(c_work,c_shift[7]);
    wire [11:0] s_next = bcd_step(s_work,s_shift[7]);
    wire conversion_current = conversion_tuple == input_tuple;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_q <= 1'b1;
            publish_window <= 1'b0;
            converting <= 1'b0;
            converted_valid <= 1'b0;
            display_valid <= 1'b0;
            conversion_tuple <= 0;
            displayed_tuple <= 0;
            b_shift <= 0; c_shift <= 0; s_shift <= 0;
            bit_count <= 0;
            b_work <= 0; c_work <= 0; s_work <= 0;
            b_converted <= 0; c_converted <= 0; s_converted <= 0;
            b_displayed <= 0; c_displayed <= 0; s_displayed <= 0;
        end else begin
            vs_q <= vsync;
            if (frame_start) publish_window <= 1'b1;
            else if (de) publish_window <= 1'b0;
            if (!converting) begin
                if (!converted_valid || !conversion_current) begin
                    conversion_tuple <= input_tuple;
                    b_shift <= brightness;
                    c_shift <= contrast;
                    s_shift <= {2'd0,step};
                    b_work <= 0; c_work <= 0; s_work <= 0;
                    bit_count <= 0;
                    converting <= 1'b1;
                    converted_valid <= 1'b0;
                end
            end else begin
                b_work <= b_next; c_work <= c_next; s_work <= s_next;
                b_shift <= {b_shift[6:0],1'b0};
                c_shift <= {c_shift[6:0],1'b0};
                s_shift <= {s_shift[6:0],1'b0};
                if (bit_count == 3'd7) begin
                    b_converted <= b_next;
                    c_converted <= c_next;
                    s_converted <= s_next;
                    converted_valid <= 1'b1;
                    converting <= 1'b0;
                end else bit_count <= bit_count + 1'b1;
            end
            if ((frame_start || publish_window) && !de &&
                converted_valid && conversion_current) begin
                b_displayed <= b_converted;
                c_displayed <= c_converted;
                s_displayed <= s_converted;
                displayed_tuple <= conversion_tuple;
                display_valid <= 1'b1;
            end
        end
    end

    function [34:0] glyph_bits;
        input [7:0] character;
        begin
            case (character)
                "0": glyph_bits = 35'b01110_10001_10011_10101_11001_10001_01110;
                "1": glyph_bits = 35'b00100_01100_00100_00100_00100_00100_01110;
                "2": glyph_bits = 35'b01110_10001_00001_00010_00100_01000_11111;
                "3": glyph_bits = 35'b11110_00001_00001_01110_00001_00001_11110;
                "4": glyph_bits = 35'b00010_00110_01010_10010_11111_00010_00010;
                "5": glyph_bits = 35'b11111_10000_10000_11110_00001_00001_11110;
                "6": glyph_bits = 35'b01110_10000_10000_11110_10001_10001_01110;
                "7": glyph_bits = 35'b11111_00001_00010_00100_01000_01000_01000;
                "8": glyph_bits = 35'b01110_10001_10001_01110_10001_10001_01110;
                "9": glyph_bits = 35'b01110_10001_10001_01111_00001_00001_01110;
                "B": glyph_bits = 35'b11110_10001_10001_11110_10001_10001_11110;
                "R": glyph_bits = 35'b11110_10001_10001_11110_10100_10010_10001;
                "I": glyph_bits = 35'b01110_00100_00100_00100_00100_00100_01110;
                "C": glyph_bits = 35'b01110_10001_10000_10000_10000_10001_01110;
                "O": glyph_bits = 35'b01110_10001_10001_10001_10001_10001_01110;
                "N": glyph_bits = 35'b10001_11001_10101_10011_10001_10001_10001;
                "M": glyph_bits = 35'b10001_11011_10101_10101_10001_10001_10001;
                "D": glyph_bits = 35'b11110_10001_10001_10001_10001_10001_11110;
                "E": glyph_bits = 35'b11111_10000_10000_11110_10000_10000_11111;
                "V": glyph_bits = 35'b10001_10001_10001_10001_10001_01010_00100;
                "L": glyph_bits = 35'b10000_10000_10000_10000_10000_10000_11111;
                "S": glyph_bits = 35'b01111_10000_10000_01110_00001_00001_11110;
                "T": glyph_bits = 35'b11111_00100_00100_00100_00100_00100_00100;
                "P": glyph_bits = 35'b11110_10001_10001_11110_10000_10000_10000;
                "%": glyph_bits = 35'b11001_11010_00100_01000_10110_00110_00000;
                default: glyph_bits = 35'd0;
            endcase
        end
    endfunction
    wire [12:0] x = {1'b0,pixel_x};
    wire [12:0] y = {1'b0,pixel_y};
    wire [11:0] local_x = pixel_x - TEXT_X;
    wire [11:0] local_y = pixel_y - TEXT_Y;
    wire [4:0] character_index = local_x[8:4];
    reg [7:0] character;
    reg [34:0] glyph;
    reg [1:0] line_index;
    reg [11:0] line_y;
    reg in_text, text_pixel;
    always @* begin
        line_index = 2'd3;
        line_y = local_y;
        if (local_y < 14) line_index = 0;
        else if (local_y >= 20 && local_y < 34) begin
            line_index = 1; line_y = local_y - 12'd20;
        end else if (local_y >= 40 && local_y < 54) begin
            line_index = 2; line_y = local_y - 12'd40;
        end
        in_text = x >= TEXT_X && x < TEXT_X+272 &&
                  y >= TEXT_Y && y < TEXT_Y+54 && line_index != 3;
        character = " ";
        case (line_index)
            0: case (character_index)
                0: character = "B";
                1: character = "R";
                2: character = "I";
                4: character = "0" + b_displayed[11:8];
                5: character = "0" + b_displayed[7:4];
                6: character = "0" + b_displayed[3:0];
                7: character = INPUT_IS_PERCENT ? "%" : " ";
                default: character = " ";
            endcase
            1: case (character_index)
                0: character = "C";
                1: character = "O";
                2: character = "N";
                4: character = "0" + c_displayed[11:8];
                5: character = "0" + c_displayed[7:4];
                6: character = "0" + c_displayed[3:0];
                7: character = INPUT_IS_PERCENT ? "%" : " ";
                default: character = " ";
            endcase
            2: case (character_index)
                0: character = "M";
                1: character = "O";
                2: character = "D";
                3: character = "E";
                5: case (displayed_tuple[7:6])
                    0: character = "V";
                    1: character = "B";
                    2: character = "C";
                    3: character = "R";
                endcase
                6: case (displayed_tuple[7:6])
                    0,2: character = "O";
                    1: character = "R";
                    3: character = "S";
                endcase
                7: case (displayed_tuple[7:6])
                    0: character = "L";
                    1: character = "I";
                    2: character = "N";
                    3: character = "T";
                endcase
                9: character = "S";
                10: character = "T";
                11: character = "E";
                12: character = "P";
                14: character = "0" + s_displayed[11:8];
                15: character = "0" + s_displayed[7:4];
                16: character = "0" + s_displayed[3:0];
                default: character = " ";
            endcase
            default: character = " ";
        endcase
        glyph = glyph_bits(character);
        text_pixel = 1'b0;
        if (enable && de && display_valid && displayed_tuple == input_tuple &&
            in_text && local_x[3:1] < 5 && line_y[3:1] < 7)
            text_pixel = glyph[34-(line_y[3:1]*5+local_x[3:1])];
    end
    assign overlay_active = text_pixel;
    assign rgb_out = text_pixel ? 24'hffffff : rgb_in;
endmodule
