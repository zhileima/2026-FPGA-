`timescale 1ns/1ps

// Pixel-clock waveform of the PCM accepted by the HDMI packetizer. RGB,
// coordinates and sync belong to the same input pixel; this transparent
// overlay adds no register or video latency and never backpressures audio.
module promax_audio_waveform #(
    parameter integer WAVE_X = 64,
    parameter integer WAVE_Y = 352,
    parameter integer WAVE_WIDTH = 512,
    parameter integer WAVE_HEIGHT = 64,
    parameter integer DECIMATE = 12,
    parameter integer REFRESH_FRAMES = 6,
    parameter integer FILTER_SHIFT = 2,
    parameter integer TRIGGER_TIMEOUT = 128,
    parameter integer FRAME_SMOOTH_SHIFT = 2
) (
    input wire clk,
    input wire rst_n,
    input wire vsync,
    input wire de,
    input wire [23:0] rgb_in,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire enable,
    input wire pcm_tap_valid,
    input wire signed [15:0] pcm_tap_left,
    output wire [23:0] rgb_out,
    output wire waveform_active
);
    localparam integer SAMPLE_COUNT = 32;
    // Defensive elaboration values keep invalid parameters from introducing
    // zero divisors/widths before the configuration check can report them.
    localparam integer SAMPLE_SPACING = WAVE_WIDTH >= SAMPLE_COUNT ?
                                       WAVE_WIDTH / SAMPLE_COUNT : 1;
    localparam integer HEIGHT_BITS = WAVE_HEIGHT >= 2 ?
                                    $clog2(WAVE_HEIGHT + 1) : 2;
    localparam integer SCALE_BITS = 8 + HEIGHT_BITS;
    localparam integer FRACTION_BITS = SAMPLE_SPACING > 1 ?
                                      $clog2(SAMPLE_SPACING) : 1;
    localparam integer INTERPOLATE_BITS = HEIGHT_BITS + FRACTION_BITS;
    localparam [HEIGHT_BITS-1:0] HEIGHT_VALUE = WAVE_HEIGHT;
    localparam [HEIGHT_BITS-1:0] CENTER_LEVEL = WAVE_HEIGHT / 2;
    localparam [11:0] SPACING_VALUE = SAMPLE_SPACING;
    localparam [FRACTION_BITS:0] SPACING_DIVISOR = SAMPLE_SPACING;
    localparam [12:0] LEFT_X = WAVE_X;
    localparam [12:0] RIGHT_X = WAVE_X + WAVE_WIDTH;
    localparam [12:0] TOP_Y = WAVE_Y;
    localparam [12:0] BOTTOM_Y = WAVE_Y + WAVE_HEIGHT;
    localparam [12:0] CENTER_Y = WAVE_Y + WAVE_HEIGHT/2;
    localparam [12:0] PEAK_LEFT_X = WAVE_X + WAVE_WIDTH + 8;
    localparam [12:0] PEAK_RIGHT_X = WAVE_X + WAVE_WIDTH + 16;

    initial begin
        if (WAVE_X < 0 || WAVE_Y < 0 || WAVE_WIDTH < SAMPLE_COUNT ||
            WAVE_WIDTH % SAMPLE_COUNT != 0 || WAVE_HEIGHT < 2 ||
            WAVE_X + WAVE_WIDTH + 16 > 4096 ||
            WAVE_Y + WAVE_HEIGHT > 4096 ||
            DECIMATE < 1 || DECIMATE > 65536 ||
            REFRESH_FRAMES < 1 || REFRESH_FRAMES > 65536 ||
            FILTER_SHIFT < 0 || FILTER_SHIFT > 7 ||
            TRIGGER_TIMEOUT < 1 || TRIGGER_TIMEOUT > 65536 ||
            FRAME_SMOOTH_SHIFT < 0 || FRAME_SMOOTH_SHIFT > 7) begin
            $display("F1_WAVEFORM_CONFIG_ERROR: invalid region/spacing/filter/refresh");
            $finish;
        end
    end

    reg vs_q;
    wire frame_start = vs_q && !vsync;
    // Separate complete target and visible arrays. The target stays frozen
    // throughout its frame-by-frame display interpolation. A single shared
    // adder updates one display point per blanking clock instead of placing
    // 32 smoothing adders on the video rendering path.
    reg signed [7:0] sample_bank0 [0:SAMPLE_COUNT-1]; // acquisition target
    reg signed [7:0] sample_bank1 [0:SAMPLE_COUNT-1]; // visible waveform
    reg display_valid;
    reg [5:0] capture_count;
    reg [15:0] decimate_count;
    reg signed [15:0] filter_state;
    reg await_trigger;
    reg [15:0] trigger_count;
    reg blend_busy;
    reg blend_copy;
    reg [4:0] blend_index;
    reg [15:0] refresh_sweeps;
    reg [7:0] interval_peak;
    reg [7:0] display_peak;

    // Take the absolute value before quantizing: -1 maps to zero, and the
    // signed minimum -32768 remains representable as unsigned 32768.
    wire [15:0] pcm_magnitude = pcm_tap_left[15] ?
                               (~pcm_tap_left + 16'd1) : pcm_tap_left;
    wire [7:0] sample_abs = pcm_magnitude[15:8];
    wire signed [16:0] filter_delta =
        $signed({pcm_tap_left[15],pcm_tap_left}) -
        $signed({filter_state[15],filter_state});
    wire signed [16:0] filter_next_wide =
        $signed({filter_state[15],filter_state}) +
        (filter_delta >>> FILTER_SHIFT);
    wire signed [15:0] filter_next = filter_next_wide[15:0];
    wire positive_crossing = filter_state[15] && !filter_next[15];

    // Ceil the magnitude of the step so even a one-LSB difference converges.
    // Input and display filtering affect the visualization only. The PCM
    // accepted by the HDMI packetizer is never altered or delayed here.
    function signed [7:0] smooth_sample;
        input signed [7:0] shown;
        input signed [7:0] target;
        reg signed [8:0] delta;
        reg [8:0] magnitude;
        reg [8:0] step;
        reg signed [9:0] moved;
        begin
            delta = $signed({target[7],target}) -
                    $signed({shown[7],shown});
            magnitude = delta[8] ? (~delta + 9'd1) : delta;
            step = (magnitude + ((9'd1 << FRAME_SMOOTH_SHIFT) - 1'b1))
                   >> FRAME_SMOOTH_SHIFT;
            moved = delta[8] ? $signed({{2{shown[7]}},shown}) -
                                  $signed({1'b0,step}) :
                              $signed({{2{shown[7]}},shown}) +
                                  $signed({1'b0,step});
            smooth_sample = moved[7:0];
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_q <= 1'b1;
            display_valid <= 1'b0;
            capture_count <= 6'd0;
            decimate_count <= 16'd0;
            filter_state <= 16'sd0;
            await_trigger <= 1'b1;
            trigger_count <= 16'd0;
            blend_busy <= 1'b0;
            blend_copy <= 1'b0;
            blend_index <= 5'd0;
            refresh_sweeps <= 16'd0;
            interval_peak <= 8'd0;
            display_peak <= 8'd0;
        end else begin
            vs_q <= vsync;
            // A vertical-sync boundary owns this cycle. Samples accepted on
            // that exact cycle are excluded; no display point is updated.
            if (frame_start) begin
                display_peak <= interval_peak;
                interval_peak <= 8'd0;
                if (capture_count == SAMPLE_COUNT && !blend_busy) begin
                    blend_busy <= 1'b1;
                    blend_copy <= !display_valid;
                    blend_index <= 5'd0;
                end
            end else begin
                // Thirty-two blanking clocks fit comfortably in vertical
                // sync. If DE is asserted unexpectedly, pause the update and
                // bypass the overlay until the complete array is consistent.
                if (blend_busy && !de) begin
                    sample_bank1[blend_index] <= blend_copy ?
                        sample_bank0[blend_index] :
                        smooth_sample(sample_bank1[blend_index],
                                      sample_bank0[blend_index]);
                    if (blend_index == SAMPLE_COUNT-1) begin
                        blend_busy <= 1'b0;
                        display_valid <= 1'b1;
                        if (refresh_sweeps == REFRESH_FRAMES-1) begin
                            refresh_sweeps <= 16'd0;
                            capture_count <= 6'd0;
                            decimate_count <= 16'd0;
                            await_trigger <= 1'b1;
                            trigger_count <= 16'd0;
                        end else begin
                            refresh_sweeps <= refresh_sweeps + 1'b1;
                        end
                    end else begin
                        blend_index <= blend_index + 1'b1;
                    end
                end
                if (pcm_tap_valid) begin
                    filter_state <= filter_next;
                    // Peak uses the raw accepted PCM and the whole video
                    // interval, independently of triggered/decimated capture.
                    if (sample_abs > interval_peak) interval_peak <= sample_abs;
                    if (capture_count < SAMPLE_COUNT && !blend_busy) begin
                        if (await_trigger) begin
                            if (positive_crossing ||
                                trigger_count == TRIGGER_TIMEOUT-1) begin
                                sample_bank0[0] <= filter_next[15:8];
                                capture_count <= 6'd1;
                                decimate_count <= DECIMATE-1;
                                await_trigger <= 1'b0;
                            end else begin
                                trigger_count <= trigger_count + 1'b1;
                            end
                        end else if (decimate_count == 0) begin
                            sample_bank0[capture_count[4:0]] <= filter_next[15:8];
                            capture_count <= capture_count + 1'b1;
                            decimate_count <= DECIMATE-1;
                        end else begin
                            decimate_count <= decimate_count - 1'b1;
                        end
                    end
                end
            end
        end
    end

    wire [12:0] x_position = {1'b0,pixel_x};
    wire [12:0] y_position = {1'b0,pixel_y};
    wire in_wave = x_position >= LEFT_X && x_position < RIGHT_X &&
                   y_position >= TOP_Y && y_position < BOTTOM_Y;
    wire [11:0] local_x = pixel_x - LEFT_X[11:0];
    wire [11:0] sample_slot = local_x / SPACING_VALUE;
    wire [FRACTION_BITS-1:0] sample_fraction = local_x % SPACING_VALUE;
    reg signed [7:0] selected_sample;
    reg signed [7:0] next_sample;
    reg [4:0] next_slot;
    reg [HEIGHT_BITS-1:0] first_level;
    reg [HEIGHT_BITS-1:0] next_level;
    reg [HEIGHT_BITS-1:0] level_delta;
    reg [INTERPOLATE_BITS-1:0] interpolate_product;
    reg [HEIGHT_BITS-1:0] interpolate_distance;
    reg [HEIGHT_BITS-1:0] interpolate_level;
    reg [12:0] sample_y;
    wire [SCALE_BITS-1:0] peak_scale = display_peak * HEIGHT_VALUE;
    wire [12:0] peak_height = peak_scale >> 7;
    reg wave_pixel;
    reg axis_pixel;
    reg peak_pixel;

    // Map each endpoint exactly as before, but relative to the waveform's
    // top edge. The interpolation multiplier therefore uses only the height
    // bits, independent of the absolute screen coordinate.
    function [HEIGHT_BITS-1:0] sample_level;
        input signed [7:0] value;
        reg [7:0] magnitude;
        reg [SCALE_BITS-1:0] scale;
        reg [HEIGHT_BITS-1:0] offset;
        reg [HEIGHT_BITS:0] level;
        begin
            magnitude = value[7] ? (~value + 8'd1) : value;
            scale = magnitude * HEIGHT_VALUE;
            offset = scale >> 8;
            level = value[7] ? {1'b0,CENTER_LEVEL} + offset :
                               {1'b0,CENTER_LEVEL} - offset;
            if (level >= HEIGHT_VALUE) level = HEIGHT_VALUE - 1'b1;
            sample_level = level[HEIGHT_BITS-1:0];
        end
    endfunction

    always @* begin
        selected_sample = 8'sd0;
        next_sample = 8'sd0;
        next_slot = 5'd31;
        first_level = CENTER_LEVEL;
        next_level = CENTER_LEVEL;
        level_delta = 0;
        interpolate_product = 0;
        interpolate_distance = 0;
        interpolate_level = CENTER_LEVEL;
        sample_y = CENTER_Y;
        wave_pixel = 1'b0;
        axis_pixel = 1'b0;
        peak_pixel = 1'b0;
        // RAM contents intentionally have no reset mux. display_valid remains
        // false until every address in the published bank has been written.
        if (enable && de && display_valid && !blend_busy) begin
            if (in_wave) begin
                axis_pixel = y_position == CENTER_Y;
                if (sample_slot < SAMPLE_COUNT) begin
                    selected_sample = sample_bank1[sample_slot[4:0]];
                    if (sample_slot < SAMPLE_COUNT-1)
                        next_slot = sample_slot[4:0] + 1'b1;
                    next_sample = sample_bank1[next_slot];
                    first_level = sample_level(selected_sample);
                    next_level = sample_level(next_sample);
                    // Connect adjacent endpoints across every pixel column.
                    // Unsigned distance division rounds toward the first
                    // endpoint; the last 16-pixel span holds point 31.
                    // Default spacing 16 reduces division/remainder to shifts.
                    level_delta = next_level >= first_level ?
                                  next_level - first_level : first_level - next_level;
                    interpolate_product = level_delta * sample_fraction;
                    interpolate_distance = interpolate_product / SPACING_DIVISOR;
                    interpolate_level = next_level >= first_level ?
                                        first_level + interpolate_distance :
                                        first_level - interpolate_distance;
                    sample_y = TOP_Y + interpolate_level;
                    // Difference comparisons avoid unsigned y +/- 1 wrapping
                    // at the top/bottom of the coordinate range.
                    wave_pixel = y_position >= sample_y ?
                                 y_position - sample_y <= 13'd1 :
                                 sample_y - y_position <= 13'd1;
                end
            end
            if (x_position >= PEAK_LEFT_X && x_position < PEAK_RIGHT_X &&
                y_position >= BOTTOM_Y - peak_height && y_position < BOTTOM_Y)
                peak_pixel = 1'b1;
        end
    end

    assign waveform_active = wave_pixel || axis_pixel || peak_pixel;
    assign rgb_out = wave_pixel ? 24'h20ff90 :
                     peak_pixel ? 24'hffb020 :
                     axis_pixel ? 24'h406060 : rgb_in;
endmodule
