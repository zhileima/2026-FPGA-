`timescale 1ns/1ps

// One-in-flight bundled-data mailbox. Source payload stays fixed until the
// destination has sampled both data stages and acknowledged the request.
// Both domain resets must assert for a system reset; deassertions may differ.
// A producer that ignores busy is diagnosed and cannot overwrite live data.
module clock_set_cdc (
    input wire src_clk,
    input wire src_rst_n,
    input wire src_valid,
    input wire [23:0] src_bcd,
    input wire [24:0] src_ticks,
    output wire src_busy,
    output reg src_dropped,
    output reg [15:0] src_drop_count,
    input wire dst_clk,
    input wire dst_rst_n,
    output reg dst_valid,
    output reg [23:0] dst_bcd,
    output reg [24:0] dst_ticks
);
    reg [23:0] payload_bcd_hold;
    reg [24:0] payload_ticks_hold;
    reg request_toggle, acknowledge_toggle;
    (* ASYNC_REG = "TRUE" *) reg acknowledge_sync1, acknowledge_sync2;
    (* ASYNC_REG = "TRUE" *) reg request_sync1, request_sync2, request_sync3;
    reg [23:0] bcd_sync1, bcd_sync2;
    reg [24:0] ticks_sync1, ticks_sync2;
    reg request_seen;
    assign src_busy = request_toggle != acknowledge_sync2;

    always @(posedge src_clk or negedge src_rst_n) begin
        if (!src_rst_n) begin
            payload_bcd_hold <= 0; payload_ticks_hold <= 0;
            request_toggle <= 0; acknowledge_sync1 <= 0; acknowledge_sync2 <= 0;
            src_dropped <= 0; src_drop_count <= 0;
        end else begin
            acknowledge_sync1 <= acknowledge_toggle;
            acknowledge_sync2 <= acknowledge_sync1;
            if (src_valid) begin
                if (!src_busy) begin
                    payload_bcd_hold <= src_bcd;
                    payload_ticks_hold <= src_ticks;
                    request_toggle <= ~request_toggle;
                end else begin
                    src_dropped <= 1;
                    if (src_drop_count != 16'hffff) src_drop_count <= src_drop_count+1'b1;
                end
            end
        end
    end

    always @(posedge dst_clk or negedge dst_rst_n) begin
        if (!dst_rst_n) begin
            request_sync1 <= 0; request_sync2 <= 0; request_sync3 <= 0;
            bcd_sync1 <= 0; bcd_sync2 <= 0; ticks_sync1 <= 0; ticks_sync2 <= 0;
            request_seen <= 0; acknowledge_toggle <= 0;
            dst_valid <= 0; dst_bcd <= 0; dst_ticks <= 0;
        end else begin
            request_sync1 <= request_toggle;
            request_sync2 <= request_sync1;
            request_sync3 <= request_sync2;
            bcd_sync1 <= payload_bcd_hold; bcd_sync2 <= bcd_sync1;
            ticks_sync1 <= payload_ticks_hold; ticks_sync2 <= ticks_sync1;
            dst_valid <= 0;
            if (request_sync3 != request_seen) begin
                dst_bcd <= bcd_sync2; dst_ticks <= ticks_sync2; dst_valid <= 1;
                request_seen <= request_sync3;
                acknowledge_toggle <= request_sync3;
            end
        end
    end
endmodule
