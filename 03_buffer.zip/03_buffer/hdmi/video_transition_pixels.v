`timescale 1ns/1ps
// Single SDRAM read stream. Every mode traverses the same scanline memory.
// Kind 9 is an orthographically projected 3D page turning about its vertical
// centre axis: x' = 320 + (x-320)*cos(theta). It resamples the whole image;
// this is not a wipe mask or a curled-sheet / two-frame alpha compositor.
// Angle-dependent face lighting and a one-pixel page rim reveal the edge.
// Fixed sampling-edge latency: output at input edge + 803 clocks for all modes.
// 640x480 uses 800 clocks per raster line. RGB ping-pong holds two complete
// lines; the 800-clock timing/control/context delay uses distinct RAM addresses.
module video_transition_pixels #(parameter integer META_BITS=3) (
    input wire clk, input wire rst_n,
    input wire hs_in, input wire vs_in, input wire de_in,
    input wire [11:0] pixel_x, input wire [11:0] pixel_y,
    input wire [23:0] rgb_in, input wire [7:0] alpha,
    input wire wipe_active, input wire [9:0] wipe_boundary,
    input wire [3:0] transition_kind,
    input wire flip_active, input wire [4:0] flip_phase,
    input wire flip_reveal, input wire [META_BITS-1:0] meta_in,
    output reg hs_out, output reg vs_out, output reg de_out,
    output reg [11:0] pixel_x_out, output reg [11:0] pixel_y_out,
    output reg [23:0] rgb_out, output reg [META_BITS-1:0] meta_out
);
    reg [9:0] page_left, page_last;
    reg [20:0] sample_step;
    reg [7:0] page_shade;
    // 17 angle poses, 0..90 degrees. Reciprocal is compile-time constant;
    // sampling uses one fixed-point addition per pixel, with no divider or DSP.
    always @* begin
        page_left=0;page_last=639;sample_step=65536;page_shade=255;
        case(flip_phase)
            5'd0: begin page_left=10'd0; page_last=10'd639; sample_step=21'd65536; page_shade=8'd255; end
            5'd1: begin page_left=10'd1; page_last=10'd637; sample_step=21'd65845; page_shade=8'd254; end
            5'd2: begin page_left=10'd6; page_last=10'd633; sample_step=21'd66788; page_shade=8'd252; end
            5'd3: begin page_left=10'd14; page_last=10'd625; sample_step=21'd68534; page_shade=8'd248; end
            5'd4: begin page_left=10'd24; page_last=10'd614; sample_step=21'd70970; page_shade=8'd243; end
            5'd5: begin page_left=10'd38; page_last=10'd601; sample_step=21'd74367; page_shade=8'd236; end
            5'd6: begin page_left=10'd54; page_last=10'd585; sample_step=21'd78840; page_shade=8'd228; end
            5'd7: begin page_left=10'd72; page_last=10'd566; sample_step=21'd84733; page_shade=8'd219; end
            5'd8: begin page_left=10'd93; page_last=10'd545; sample_step=21'd92589; page_shade=8'd208; end
            5'd9: begin page_left=10'd117; page_last=10'd522; sample_step=21'd103308; page_shade=8'd197; end
            5'd10: begin page_left=10'd142; page_last=10'd497; sample_step=21'd117818; page_shade=8'd184; end
            5'd11: begin page_left=10'd169; page_last=10'd470; sample_step=21'd138884; page_shade=8'd171; end
            5'd12: begin page_left=10'd197; page_last=10'd441; sample_step=21'd171196; page_shade=8'd157; end
            5'd13: begin page_left=10'd227; page_last=10'd412; sample_step=21'd225500; page_shade=8'd142; end
            5'd14: begin page_left=10'd257; page_last=10'd381; sample_step=21'd335544; page_shade=8'd127; end
            5'd15: begin page_left=10'd288; page_last=10'd350; sample_step=21'd665763; page_shade=8'd112; end
            5'd16: begin page_left=10'd320; page_last=10'd319; sample_step=21'd0; page_shade=8'd96; end
            default: begin page_left=320;page_last=319;sample_step=0;page_shade=96; end
        endcase
    end
    wire face_pixel=pixel_x>={2'b0,page_left} && pixel_x<={2'b0,page_last};
    reg [25:0] source_acc;
    wire [25:0] first_sample={6'd0,sample_step[20:1]};
    wire [25:0] source_position=(pixel_x=={2'b0,page_left}) ? first_sample : source_acc;
    wire [9:0] projected_source=source_position[25:16]>639 ? 10'd639 : source_position[25:16];
    wire [9:0] source_x=flip_active ? projected_source : pixel_x[9:0];
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) source_acc<=0;
        else if(de_in && flip_active && face_pixel)
            source_acc<=source_position+{5'd0,sample_step};
        else source_acc<=0;
    end
    // All thresholds are derived from the same frame-held progress. Opposite
    // directions are exact complements in spatial order. Center distances use
    // the two center pixels symmetrically, avoiding an off-by-one center seam.
    wire [9:0] vertical_edge = (wipe_boundary >> 1) + (wipe_boundary >> 2);
    wire [11:0] offset_x = pixel_x-12'd320;
    wire [11:0] dx = pixel_x >= 12'd320 ? offset_x : ~offset_x;
    wire [11:0] offset_y = pixel_y-12'd240;
    wire [11:0] dy = pixel_y >= 12'd240 ? offset_y : ~offset_y;
    wire [12:0] diamond_distance = {1'b0,dx}+{1'b0,dy};
    wire [9:0] diamond_edge = (wipe_boundary >> 1)+(wipe_boundary >> 2)+(wipe_boundary >> 3);
    // Ten 64-pixel vertical blinds: compare (local_x * 10) with progress.
    wire [9:0] blind_position = {1'b0,pixel_x[5:0],3'b000}+{3'b000,pixel_x[5:0],1'b0};
    // Alternating 64x64 checker cells fill from left to right, even cells
    // during the first half and odd cells during the second half.
    wire [8:0] cell_position = {1'b0,pixel_x[5:0],2'b00}+{3'b000,pixel_x[5:0]};
    wire [9:0] checker_position = {1'b0,cell_position}+
        ((pixel_x[6]^pixel_y[6]) ? 10'd320 : 10'd0);
    reg reveal_pixel;
    always @* begin
        if (wipe_boundary == 0) reveal_pixel=1'b0;
        else if (wipe_boundary >= 10'd640) reveal_pixel=1'b1;
        else case (transition_kind)
            4'd1: reveal_pixel = pixel_x < {2'b00,wipe_boundary};
            4'd2: reveal_pixel = pixel_x >= 12'd640-{2'b00,wipe_boundary};
            4'd3: reveal_pixel = pixel_y < {2'b00,vertical_edge};
            4'd4: reveal_pixel = pixel_y >= 12'd480-{2'b00,vertical_edge};
            4'd5: reveal_pixel = dx < {3'b000,wipe_boundary[9:1]} &&
                                 dy < {3'b000,vertical_edge[9:1]};
            4'd6: reveal_pixel = blind_position < wipe_boundary;
            4'd7: reveal_pixel = checker_position < wipe_boundary;
            4'd8: reveal_pixel = diamond_distance < {3'b000,diamond_edge};
            default: reveal_pixel = pixel_x < {2'b00,wipe_boundary};
        endcase
    end
    wire [7:0] mask_alpha = wipe_active ?
        (reveal_pixel ? 8'd255 : 8'd0) : alpha;


    // With a projected page, alpha remains independent of its width. The
    // controller exposes zero-width while the old/new bank handshake completes.
    wire [7:0] selected_alpha=flip_active ? (face_pixel ? page_shade : 8'd0) : mask_alpha;
    wire rim=flip_active && flip_phase>0 && flip_phase<16 && face_pixel &&
        (flip_reveal ? (pixel_x=={2'b0,page_left}) : (pixel_x=={2'b0,page_last}));

    // Decisions are evaluated with the original pixel before their FIFO.
    // This commutes the unchanged coordinate transform across its delay and
    // removes 11 bits of context without adding a pixel clock of latency.
    // Context memory holds RGB-independent controls with each original pixel.
    // Packing: HS VS DE X Y source_x selected_alpha rim meta.
    (* ram_style = "block" *) reg [45+META_BITS:0] context_ram [0:1023];
    (* ram_style = "block" *) reg [23:0] line_pixels [0:2047];
    reg [9:0] wr_address;
    reg [9:0] fill_count;
    wire [9:0] delay_address = wr_address - 10'd800;
    reg [45+META_BITS:0] context_q;
    reg context_valid;
    // RAM contents need no reset; their valid fence excludes pre-reset pixels.
    always @(posedge clk) begin
        if (rst_n) begin
            context_ram[wr_address] <= {hs_in,vs_in,de_in,pixel_x,pixel_y,
                source_x,selected_alpha,rim,meta_in};
            context_q <= context_ram[delay_address];
            if(de_in && pixel_x<640 && pixel_y<480) begin
                line_pixels[{pixel_y[0],pixel_x[9:0]}] <= rgb_in;
            end
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin wr_address<=0;fill_count<=0;context_valid<=0; end
        else begin
            wr_address<=wr_address+1'b1;
            if(fill_count<800) fill_count<=fill_count+1'b1;
            context_valid<=fill_count>=800;
        end
    end
    wire scan_hs,scan_vs,raw_de,scan_rim;
    wire [11:0] scan_x,scan_y;
    wire [9:0] scan_source_x;
    wire [7:0] scan_alpha;
    wire [META_BITS-1:0] scan_meta;
    assign {scan_hs,scan_vs,raw_de,scan_x,scan_y,scan_source_x,
        scan_alpha,scan_rim,scan_meta}=context_q;
    wire scan_de=raw_de && context_valid;
    reg [23:0] rgb_q;
    reg [7:0] alpha_q;
    reg hs_read,vs_read,de_read;
    reg [11:0] x_read,y_read;
    reg [META_BITS-1:0] meta_read;
    reg rim_read;
    // One synchronous-read dual-port memory; row parity is an address bit.
    reg [23:0] sampled_rgb;
    always @(posedge clk) begin
        sampled_rgb<=line_pixels[{scan_y[0],scan_source_x}];
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            alpha_q<=0;hs_read<=1;vs_read<=1;de_read<=0;
            x_read<=0;y_read<=0;meta_read<=0;rim_read<=0;
        end else begin
            alpha_q<=context_valid ? scan_alpha : 8'd0;
            hs_read<=context_valid ? scan_hs : 1'b1;
            vs_read<=context_valid ? scan_vs : 1'b1;
            de_read<=scan_de;
            x_read<=context_valid ? scan_x : 12'd0;
            y_read<=context_valid ? scan_y : 12'd0;
            meta_read<=context_valid ? scan_meta : 3'd0;
            rim_read<=scan_rim && scan_de;
        end
    end
    (* use_dsp = "yes" *) reg [15:0] product_r,product_g,product_b;
    reg hs_q,vs_q,de_q;
    reg [11:0] x_q,y_q;
    reg [META_BITS-1:0] meta_q;
    wire [23:0] lit_source=rim_read ? 24'hdce8f0 : sampled_rgb;
    wire [16:0] quotient_r={1'b0,product_r}+17'd1+{9'd0,product_r[15:8]};
    wire [16:0] quotient_g={1'b0,product_g}+17'd1+{9'd0,product_g[15:8]};
    wire [16:0] quotient_b={1'b0,product_b}+17'd1+{9'd0,product_b[15:8]};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            product_r<=0;product_g<=0;product_b<=0;
            hs_q<=1;vs_q<=1;de_q<=0;x_q<=0;y_q<=0;meta_q<=0;
            hs_out<=1;vs_out<=1;de_out<=0;pixel_x_out<=0;pixel_y_out<=0;rgb_out<=0;meta_out<=0;
        end else begin
            product_r <= (de_read ? lit_source[23:16] : 8'd0) * alpha_q;
            product_g <= (de_read ? lit_source[15:8] : 8'd0) * alpha_q;
            product_b <= (de_read ? lit_source[7:0] : 8'd0) * alpha_q;
            hs_q<=hs_read;vs_q<=vs_read;de_q<=de_read;
            x_q<=x_read;y_q<=y_read;meta_q<=meta_read;
            hs_out<=hs_q;vs_out<=vs_q;de_out<=de_q;
            pixel_x_out<=x_q;pixel_y_out<=y_q;meta_out<=meta_q;
            rgb_out<={quotient_r[15:8],quotient_g[15:8],quotient_b[15:8]};
        end
    end
endmodule
