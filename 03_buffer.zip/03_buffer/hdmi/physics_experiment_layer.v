`timescale 1ns/1ps
// Sound Detective animal reveal. Actual production path is combinational
// prepare -> existing OSD recipe1 register + synchronous decor RAM -> finish.
// It adds NO video pipeline stage. The legacy stateless wrapper remains a
// neutral listening illustration because it has no asset-memory clock port.
module physics_experiment_layer(
 input wire[2:0]scene_index,story_beat,input wire choice_valid,choice_index,
 input wire[3:0]experiment_event,input wire[7:0]highlight_mask,
 input wire[12:0]beat_time_ms,input wire[13:0]visual_ms,
 input wire[9:0]pixel_x,pixel_y,output wire draw,output wire[23:0]colour
);
 wire[15:0]recipe;
 physics_experiment_prepare u_prepare(.scene_index(scene_index),.story_beat(story_beat),
 .choice_valid(choice_valid),.choice_index(choice_index),.confirmed(1'b0),.animation_phase(visual_ms[7:0]),
 .experiment_event(experiment_event),.highlight_mask(highlight_mask),.beat_time_ms(beat_time_ms),.visual_ms(visual_ms),
 .pixel_x(pixel_x),.pixel_y(pixel_y),.recipe(recipe));
 physics_experiment_finish u_finish(.recipe(recipe),.decor_palette(4'd0),.draw(draw),.colour(colour));
endmodule

module physics_experiment_prepare(
 input wire[2:0]scene_index,story_beat,input wire choice_valid,choice_index,
 input wire confirmed,input wire[7:0]animation_phase,
 input wire[3:0]experiment_event,input wire[7:0]highlight_mask,
 input wire[12:0]beat_time_ms,input wire[13:0]visual_ms,
 input wire[9:0]pixel_x,pixel_y,output reg[15:0]recipe
);
 wire visible=choice_valid && pixel_x>=164 && pixel_x<292 && pixel_y>=96 && pixel_y<224;
 wire[7:0]x=pixel_x-10'd164,y=pixel_y-10'd96;
 wire[6:0]dx=x>=64?x-8'd64:8'd64-x;
 wire[6:0]dy=y>=64?y-8'd64:8'd64-y;
 wire[7:0]radius=(dx>dy)?{1'b0,dx}+{2'b0,dy[6:1]}:{1'b0,dy}+{2'b0,dx[6:1]};
 wire[6:0]wavefront=7'd40+{3'd0,animation_phase[4:2],1'b0};
 wire[1:0]sway=animation_phase[5]?~animation_phase[4:3]:animation_phase[4:3];
 wire[8:0]sprite_y={1'b0,y}+{6'd0,sway};
 wire blink=animation_phase[6:2]==5'b11111;
 reg[3:0]face_ink;
 always @*case({scene_index,choice_index})
  0,12,14:face_ink=4;1,4,7,11:face_ink=5;2:face_ink=11;3:face_ink=13;
  5,15:face_ink=12;6,8:face_ink=2;9:face_ink=3;10:face_ink=9;13:face_ink=7;
  default:face_ink=2;
 endcase
 // Unrevealed animal is a large80x112 question mark, identical in all
 // chapters and both choices. Reveal still uses the existing animal atlas.
 wire[7:0]question_x=x-8'd24,question_y=y-8'd8;
 reg[4:0]question_row;
 always @*begin
  case(question_y[6:4])
   0:question_row=5'b01110;
   1:question_row=5'b10001;
   2:question_row=5'b00001;
   3:question_row=5'b00010;
   4:question_row=5'b00100;
   5:question_row=5'b00000;
   6:question_row=5'b00100;
   default:question_row=0;
  endcase
 end
 wire question_hit=x>=24 && x<104 && y>=8 && y<120 && question_row[4-question_x[6:4]];
 reg hit;reg[3:0]ink;
 always @*begin
  hit=question_hit;ink=4'd13;
  // recipe[15]=box valid,[14]=atlas,[13]=blink,[12:9]=direct ink,
  // [8]=direct hit,[7:4]=eye backing colour,[3:1]=pixel subrow.
  if(confirmed)recipe={visible,1'b1,blink,4'd0,1'b0,face_ink,sprite_y[2:0],1'b0};
  else recipe={visible,1'b0,1'b0,ink,hit,4'd0,3'd0,1'b0};
 end
endmodule

module physics_experiment_finish(input wire[15:0]recipe,input wire[3:0]decor_palette,
 output wire draw,output reg[23:0]colour);
 wire[3:0]eye_ink=(recipe[3:1]>=6)?4'd1:recipe[7:4];
 wire[3:0]atlas_ink=(recipe[13]&&decor_palette==15)?eye_ink:decor_palette;
 wire[3:0]ink=recipe[14]?atlas_ink:recipe[12:9];
 assign draw=recipe[15] && (recipe[14] ? decor_palette!=0 : recipe[8]);
 always @*case(ink)
  1:colour=24'h20283F;2:colour=24'hF2F6F4;3:colour=24'hFFE8B9;4:colour=24'hF7A94A;
  5:colour=24'hC7996B;6:colour=24'h8A513A;7:colour=24'h9EAEBD;8:colour=24'h526173;
  9:colour=24'hF4A2B8;10:colour=24'h69DBE5;11:colour=24'h8ACB74;12:colour=24'h6B9DE5;
  13:colour=24'hFFE08A;14:colour=24'hEA6C75;15:colour=24'h151B2E;default:colour=24'h000000;
 endcase
endmodule

module physics_experiment_decor(
 input wire clk,load_clk,load_we,input wire[10:0]load_addr,input wire[7:0]load_data,
 input wire[2:0]scene_index,story_beat,input wire[3:0]experiment_event,
 input wire choice_valid,choice_index,confirmed,input wire[7:0]animation_phase,
 input wire[9:0]pixel_x,pixel_y,output wire[3:0]decor_palette
);
 wire[1:0]sway=animation_phase[5]?~animation_phase[4:3]:animation_phase[4:3];
 wire[8:0]x=pixel_x-10'd164+9'd3-{7'd0,sway};
 wire[8:0]y=pixel_y-10'd96+{7'd0,sway};
 wire valid=choice_valid && confirmed && pixel_x>=164 && pixel_x<292 &&
            pixel_y>=96 && pixel_y<224 && x<128 && y<128;
 wire[10:0]read_addr={scene_index,choice_index,y[6:3],x[6:4]};
 wire[7:0]bank_data[0:1];
 reg bank_q,nibble_q,valid_q;
 always @(posedge clk)begin bank_q<=read_addr[10];nibble_q<=x[3];valid_q<=valid;end
 wire[7:0]read_byte=bank_data[bank_q];
 assign decor_palette=valid_q?(nibble_q?read_byte[3:0]:read_byte[7:4]):4'd0;
 genvar b;
 generate for(b=0;b<2;b=b+1)begin:g_animal_bank
  wire we=load_we && load_addr[10]==b;
`ifdef DENTAL_OSD_BEHAVIORAL_RAM
  reg[7:0]memory[0:1023];reg[7:0]data_q;
  always @(posedge load_clk)if(we)memory[load_addr[9:0]]<=load_data;
  always @(posedge clk)data_q<=memory[read_addr[9:0]];
  assign bank_data[b]=data_q;
`else
  EG_LOGIC_BRAM #(
   .DATA_WIDTH_A(8),.DATA_WIDTH_B(8),.ADDR_WIDTH_A(10),.ADDR_WIDTH_B(10),
   .DATA_DEPTH_A(1024),.DATA_DEPTH_B(1024),.BYTE_ENABLE(0),.BYTE_A(1),.BYTE_B(1),.MODE("DP"),
   .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),.WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.RESETMODE("SYNC"),
   .DEBUGGABLE("NO"),.PACKABLE("NO"),.FORCE_KEEP("OFF"),.INIT_FILE("NONE"),.FILL_ALL("NONE"),.IMPLEMENT("9K")
  ) u_animal_ram(.doa(),.dob(bank_data[b]),.dia(load_data),.dib(8'd0),
   .cea(we),.ocea(1'b1),.clka(load_clk),.wea(we),.rsta(1'b0),.ceb(1'b1),.oceb(1'b1),.clkb(clk),.web(1'b0),.rstb(1'b0),
   .bea(1'b1),.beb(1'b1),.addra(load_addr[9:0]),.addrb(read_addr[9:0]));
`endif
 end endgenerate
endmodule
