`timescale 1ns/1ps
// PHYOSD03+SNF2 renderer: native 16x16 two-bit ink/outline in 72-byte card slots. Artwork, glyphs, strings, panel colours and animation
// sequences are loaded from OSD.BIN. PHYOSD03 uses a fixed 640x480 layout
// profile (matching all eight packaged scenes). No external initialization files.
// Video latency is exactly THREE clk rising edges, including bypass.
module dental_scene_osd #(
    parameter integer PIXEL_HZ=25000000,
    parameter integer LAYER_ZOOM_ENABLE=0,
    parameter integer SPECIAL_AUDIO_ENABLE=0
)(
    input wire load_clk, input wire load_rst_n,
    input wire load_start, input wire load_valid,
    input wire [15:0] load_addr, input wire [7:0] load_data,
    input wire load_done, input wire load_error,
    output reg asset_ready_load, output reg asset_error_load,
    input wire clk, input wire rst_n, input wire frame_start,
    input wire [2:0] active_index, input wire enable,
    // Already frame-latched in the existing settings CDC; no new clock domain.
    input wire auto_play, input wire [2:0] period_sel,
    input wire adventure_started,choice_cursor,choice_confirm_toggle,choice_open_toggle,
    input wire menu_visible,thumbnail_active,
    output wire choice_requested,output wire [2:0] story_chapter,
    output wire choice_confirmed,choice_correct,scene_ready_status,
    input wire hs_in, input wire vs_in, input wire de_in,
    input wire [11:0] pixel_x, input wire [11:0] pixel_y,
    input wire [2:0] layer_zoom,
    input wire [23:0] rgb_in,
    input wire [7:0] volume_level,
    input wire audio_valid, input wire signed [15:0] audio_sample,
    input wire special_audio_page,audio_source_change,
    output reg hs_out, output reg vs_out, output reg de_out,
    output reg [11:0] pixel_x_out, output reg [11:0] pixel_y_out,
    output reg [23:0] rgb_out, output reg overlay_active,
    output reg [3:0] scene_music_track,
    output reg scene_changed_toggle,
    output reg cue_toggle, output reg [2:0] cue_id
);
    localparam integer MS_DIV=(PIXEL_HZ/1000<1)?1:PIXEL_HZ/1000;
    localparam integer MS_W=(MS_DIV<2)?1:$clog2(MS_DIV);
    reg [15:0] load_count; reg loading; reg [7:0] glyph_low;
    reg [2:0] scene_write_bank; reg [9:0] scene_write_word;
    // SNF2 keeps 384 x 72 card bytes. Bytes3..66 hold64 packed bytes;
    // bytes0..2 and67..71 must be zero and are rejected otherwise.
    reg [8:0] font_write_glyph;
    reg [6:0] font_source_byte;
    wire in_font=load_addr>=16'd17408 && load_addr<16'd45056;
    wire font_write_keep=font_source_byte>=7'd3 && font_source_byte<7'd67;
    function [31:0] abi_word;
        input [5:0] n;
        begin case(n)
            0:abi_word=32'h4F594850;
            1:abi_word=32'h33304453;
            2:abi_word=32'h03000003;
            3:abi_word=32'h0000FC00;
            4:abi_word=32'h01E00280;
            5:abi_word=32'h06000008;
            6:abi_word=32'h00480180;
            7:abi_word=32'h00400008;
            8:abi_word=32'h00040040;
            9:abi_word=32'h00080010;
            10:abi_word=32'h00000003;
            11:abi_word=32'h00010009;
            12:abi_word=32'h00180018;
            13:abi_word=32'h1D4C0008;
            14:abi_word=32'h00000000;
            15:abi_word=32'h00000000;
            16:abi_word=32'h00000001;
            17:abi_word=32'h00000200;
            18:abi_word=32'h00000030;
            19:abi_word=32'h00000003;
            20:abi_word=32'h00000002;
            21:abi_word=32'h00000400;
            22:abi_word=32'h00004000;
            23:abi_word=32'h00000800;
            24:abi_word=32'h00000003;
            25:abi_word=32'h00004400;
            26:abi_word=32'h00006C00;
            27:abi_word=32'h00000048;
            28:abi_word=32'h00000004;
            29:abi_word=32'h0000B000;
            30:abi_word=32'h00000000;
            31:abi_word=32'h00000000;
            32:abi_word=32'h00000005;
            33:abi_word=32'h0000B000;
            34:abi_word=32'h00003000;
            35:abi_word=32'h00000600;
            36:abi_word=32'h00000006;
            37:abi_word=32'h0000E000;
            38:abi_word=32'h00000200;
            39:abi_word=32'h00000200;
            40:abi_word=32'h00000007;
            41:abi_word=32'h0000E200;
            42:abi_word=32'h00001198;
            43:abi_word=32'h00000001;
            44:abi_word=32'h00000008;
            45:abi_word=32'h0000F400;
            46:abi_word=32'h00000800;
            47:abi_word=32'h00000200;
            48:abi_word=32'h32464E53; // SNF2, 16x16 two-bit ink/outline glyphs
            default:abi_word=0;
        endcase end
    endfunction
    wire [7:0] header_prefetch_addr=load_start?8'd0:
        (load_valid && loading)?load_count[7:0]+8'd1:load_count[7:0];
    (* ram_style="block" *) reg [7:0] header_rom[0:255];
    reg [7:0] header_byte; integer header_init;
    initial begin
        for(header_init=0;header_init<256;header_init=header_init+1)
            header_rom[header_init]=abi_word(header_init>>2)>>((header_init%4)*8);
    end
    always @(posedge load_clk)header_byte<=header_rom[header_prefetch_addr];
    wire in_scene=load_addr>=16'd45056 && load_addr<16'd57344;
    wire [8:0] scene_write_data={load_data[0],glyph_low};
    wire scene_meta=(scene_write_word<128) ||
                   (scene_write_word>=256 && scene_write_word[5:0]<8);
    reg bad_scene_word;
    always @*begin
        bad_scene_word=(load_data[7:1]!=0);
        if(!scene_meta)begin
            if(scene_write_data>=384 && scene_write_data!=511)bad_scene_word=1;
        end else if(scene_write_word<128)begin
            case(scene_write_word)
                0:if(scene_write_data<1 || scene_write_data>8)bad_scene_word=1;
                // Scene metadata identifies its A clip; B is the adjacent slot.
                // 4-bit one-based metadata admits odd 1..15, never wraps 16.
                1:if(scene_write_data<1 || scene_write_data>15 || !scene_write_data[0])bad_scene_word=1;
                2:if(scene_write_data>8)bad_scene_word=1;
                3:if(scene_write_data>12)bad_scene_word=1;
                4:if(scene_write_data>24)bad_scene_word=1;
                5:if(scene_write_data>32)bad_scene_word=1;
                6:if(scene_write_data>4)bad_scene_word=1;
                7:if(scene_write_data>5)bad_scene_word=1;
                8:begin end
                9:if(scene_write_data>6)bad_scene_word=1;
                10:if(scene_write_data>7)bad_scene_word=1;
                11:if(scene_write_data<60 || scene_write_data>200)bad_scene_word=1;
                12:if(scene_write_data>1)bad_scene_word=1;
                default:if(scene_write_data!=0)bad_scene_word=1;
            endcase
        end else begin
            case(scene_write_word[5:0])
                0,1:if(scene_write_data>16)bad_scene_word=1;
                2:if(scene_write_data>6)bad_scene_word=1;
                3,4:if(scene_write_data>7)bad_scene_word=1;
                5:if(scene_write_data>127)bad_scene_word=1;
                6:if(scene_write_data>3)bad_scene_word=1;
                7:if(scene_write_data>5)bad_scene_word=1;
            endcase
        end
    end
    always @(posedge load_clk or negedge load_rst_n)begin
        if(!load_rst_n)begin
            asset_ready_load<=0;asset_error_load<=0;loading<=0;load_count<=0;
            glyph_low<=0;scene_write_bank<=0;scene_write_word<=0;
            font_write_glyph<=0;font_source_byte<=0;
        end else if(load_start)begin
            asset_ready_load<=0;asset_error_load<=0;loading<=1;load_count<=0;
            glyph_low<=0;scene_write_bank<=0;scene_write_word<=0;
            font_write_glyph<=0;font_source_byte<=0;
        end else begin
            if(load_error)begin asset_error_load<=1;asset_ready_load<=0;loading<=0;end
            if(load_valid && loading)begin
                load_count<=load_count+1'b1;
                if(load_addr!=load_count || load_addr>=64512)asset_error_load<=1;
                if(load_addr<196 && load_data!=header_byte)asset_error_load<=1;
                if(in_font)begin
                    if(!font_write_keep && load_data!=0)asset_error_load<=1;
                    if(font_write_keep && ((load_data[7:6]==2'b11) ||
                        (load_data[5:4]==2'b11) || (load_data[3:2]==2'b11) ||
                        (load_data[1:0]==2'b11)))asset_error_load<=1;
                    if(font_source_byte==7'd71)begin
                        font_source_byte<=0;font_write_glyph<=font_write_glyph+1'b1;
                    end else font_source_byte<=font_source_byte+1'b1;
                end
                if(in_scene)begin
                    if(!load_addr[0])glyph_low<=load_data;
                    else begin
                        if(bad_scene_word)asset_error_load<=1;
                        if(scene_write_word==767)begin
                            scene_write_word<=0;scene_write_bank<=scene_write_bank+1'b1;
                        end else scene_write_word<=scene_write_word+1'b1;
                    end
                end
            end
            if(load_done)begin
                loading<=0;
                if(loading && load_count==64512 && !asset_error_load && !load_error)asset_ready_load<=1;
                else begin asset_ready_load<=0;asset_error_load<=1;end
            end
        end
    end
    wire wr=loading && load_valid && !asset_error_load;
    wire [13:0] sprite_wr_addr=load_addr-16'd1024;
    // Each glyph uses all64 bytes of its already allocated aligned slot.
    // Six banks x 4096 bytes replace seven banks without an asset change.
    wire [5:0] font_write_slot=font_source_byte[5:0]-6'd3;
    wire [14:0] font_wr_addr={font_write_glyph,font_write_slot};
    reg [23:0] palette[0:15];
    reg [1:0] palette_byte;
    reg [3:0] palette_index;
    always @(posedge load_clk or negedge load_rst_n) begin
        if(!load_rst_n) begin palette_byte<=0;palette_index<=0;end
        else if(load_start) begin palette_byte<=0;palette_index<=0;end
        else if(wr && load_addr>=512 && load_addr<560) begin
            case(palette_byte)
                0:palette[palette_index][23:16]<=load_data;
                1:palette[palette_index][15:8]<=load_data;
                2:palette[palette_index][7:0]<=load_data;
            endcase
            if(palette_byte==2) begin palette_byte<=0;palette_index<=palette_index+1'b1;end
            else palette_byte<=palette_byte+1'b1;
        end
    end
    reg [13:0] sprite_rd_addr;
    reg [14:0] font_rd_addr;
    wire [7:0] sprite_bytes[0:3]; wire [7:0] font_bytes[0:5];
    reg [1:0] sprite_bank_q; reg [2:0] font_bank_q;
    wire [7:0] sprite_q=sprite_bytes[sprite_bank_q];
    reg font_row_q;
    wire [7:0] font_q=font_row_q?font_bytes[font_bank_q]:8'd0;
    genvar bank;
    generate for(bank=0;bank<4;bank=bank+1)begin:g_ram
        dental_osd_ram #(.AW(12)) u_sprite(
            .wclk(load_clk),.we(wr && load_addr>=1024 && load_addr<17408 && sprite_wr_addr[13:12]==bank),
            .wa(sprite_wr_addr[11:0]),.wd(load_data),.rclk(clk),.ra(sprite_rd_addr[11:0]),.rd(sprite_bytes[bank]));
        dental_osd_ram #(.AW(12)) u_font(
            .wclk(load_clk),.we(wr && in_font && font_write_keep && font_wr_addr[14:12]==bank),
            .wa(font_wr_addr[11:0]),.wd(load_data),.rclk(clk),.ra(font_rd_addr[11:0]),.rd(font_bytes[bank]));
    end
    for(bank=4;bank<6;bank=bank+1)begin:g_font_extra
        dental_osd_ram #(.AW(12)) u_font(
            .wclk(load_clk),.we(wr && in_font && font_write_keep && font_wr_addr[14:12]==bank),
            .wa(font_wr_addr[11:0]),.wd(load_data),.rclk(clk),.ra(font_rd_addr[11:0]),.rd(font_bytes[bank]));
    end endgenerate
    reg [12:0] scene_rd_addr; wire [8:0] scene_q;
    dental_story_ram u_scene(
        .wclk(load_clk),.we(wr && in_scene && load_addr[0]),
        .wa({scene_write_bank,scene_write_word}),.wd(scene_write_data),
        .rclk(clk),.ra(scene_rd_addr),.rd(scene_q));
    wire [7:0] action_q; wire [8:0] action_rd_addr;
    dental_osd_ram #(.AW(9)) u_action(
        .wclk(load_clk),.we(wr && load_addr>=57344 && load_addr<57856),
        .wa(load_addr[8:0]),.wd(load_data),.rclk(clk),.ra(action_rd_addr),.rd(action_q));
    // Only the scene/beat address mux shares the glyph RAM. Configuration
    // starts at VS falling and finishes in blank, never during active video.
    (* ASYNC_REG="TRUE" *) reg [1:0] ready_sync;
    reg [2:0] scene_index,beat_index;
    reg choice_pending,choice_decided,choice_selected;
    reg confirm_seen,open_seen;
    reg correct_choice;
    reg scene_ready,actions_ready,frame_blank;
    assign choice_requested=choice_pending && adventure_started;
    assign choice_confirmed=choice_decided;
    assign choice_correct=choice_decided && choice_selected==correct_choice;
    assign scene_ready_status=scene_ready;
    assign story_chapter=scene_index;
    reg cfg_running,cfg_valid_d,cfg_finish,cfg_initial;
    reg [1:0] cfg_kind,cfg_kind_d;
    reg [5:0] cfg_count,cfg_count_d;
    reg [2:0] cfg_target_beat;
    reg next_valid;
    reg [8:0] next_meta[0:7],beat_meta[0:7];
    reg [5:0] title_length,era_length,summary_length,ticker_length,name_length,brand_length;
    reg [8:0] layer_mask;
    reg [3:0] particle_count;
    reg [7:0] type_ms;
    reg [23:0] colours[0:7];
    integer ci;
    wire [9:0] cfg_scene_word=(cfg_kind==1)?{4'd0,cfg_count}:
        (10'd256+{1'b0,cfg_target_beat,6'd0}+{4'd0,cfg_count});
    wire [8:0] cfg_data=(cfg_kind_d==0)?{1'b0,action_q}:scene_q;
    wire cfg_busy=cfg_running||cfg_valid_d||cfg_finish;
    assign action_rd_addr={3'd0,cfg_count};

    reg [2:0] timing_profile;
    reg timing_auto;
    wire [2:0] requested_profile=(period_sel<6)?period_sel:3'd5;
    wire timing_restart=frame_start &&
        (requested_profile!=timing_profile || timing_auto!=auto_play);
    wire compact_summary=1'b0; // Every period uses the full authored text.
    wire [5:0] story_step=(timing_profile==0)?6'd60:
        (timing_profile==1)?6'd20:(timing_profile==2)?6'd12:
        (timing_profile==3)?6'd4:(timing_profile==4)?6'd2:6'd1;
    reg [MS_W-1:0] ms_div;
    wire ms_tick=ms_div==MS_DIV-1;
    reg [15:0] elapsed_ms;
    reg [12:0] beat_ms;
    reg [2:0] logical_beat;
    reg story_done;
    wire [16:0] elapsed_next={1'b0,elapsed_ms}+{11'd0,story_step};
    wire [13:0] beat_next={1'b0,beat_ms}+{8'd0,story_step};
    wire beat_commit=frame_start && scene_ready && next_valid && logical_beat!=beat_index;

    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            ready_sync<=0;scene_index<=0;beat_index<=0;scene_ready<=0;actions_ready<=0;frame_blank<=1;
            cfg_running<=0;cfg_valid_d<=0;cfg_finish<=0;cfg_initial<=0;
            cfg_kind<=0;cfg_kind_d<=0;cfg_count<=0;cfg_count_d<=0;cfg_target_beat<=0;next_valid<=0;
            scene_music_track<=1;scene_changed_toggle<=0;
        end else begin
            ready_sync<={ready_sync[0],asset_ready_load};
            if(frame_start)frame_blank<=1;else if(de_in)frame_blank<=0;
            cfg_valid_d<=cfg_running;cfg_count_d<=cfg_count;cfg_kind_d<=cfg_kind;
            if(!ready_sync[1])begin
                scene_ready<=0;actions_ready<=0;cfg_running<=0;cfg_valid_d<=0;cfg_finish<=0;next_valid<=0;
            end else if((active_index!=scene_index || timing_restart) &&
                        !de_in && (frame_blank||frame_start))begin
                // Cancel any stale next-beat transaction; the new scene owns
                // both the address and pending state before writes can apply.
                scene_index<=active_index;scene_ready<=0;beat_index<=0;next_valid<=0;
                cfg_running<=1;cfg_valid_d<=0;cfg_finish<=0;cfg_initial<=1;
                cfg_kind<=actions_ready?1:0;cfg_count<=0;cfg_target_beat<=0;
            end else begin
                if(!scene_ready && !cfg_busy && !de_in && (frame_blank||frame_start))begin
                    scene_index<=active_index;beat_index<=0;next_valid<=0;
                    cfg_running<=1;cfg_initial<=1;cfg_kind<=actions_ready?1:0;cfg_count<=0;cfg_target_beat<=0;
                end else if(scene_ready && frame_start && !cfg_busy && !next_valid && beat_index<7)begin
                    cfg_running<=1;cfg_initial<=0;cfg_kind<=2;cfg_count<=0;cfg_target_beat<=beat_index+1'b1;
                end
                if(cfg_running)begin
                    if((cfg_kind==0 && cfg_count==63)||(cfg_kind==1 && cfg_count==12)||
                       (cfg_kind==2 && cfg_count==7))begin cfg_running<=0;cfg_finish<=1;end
                    else cfg_count<=cfg_count+1'b1;
                end
                if(cfg_valid_d && cfg_kind_d==1 && cfg_count_d==1)
                    scene_music_track<=cfg_data[3:0];
                if(cfg_finish && !cfg_valid_d)begin
                    cfg_finish<=0;cfg_count<=0;
                    if(cfg_kind==0)begin actions_ready<=1;cfg_kind<=1;cfg_running<=1;end
                    else if(cfg_kind==1)begin cfg_kind<=2;cfg_running<=1;cfg_target_beat<=0;end
                    else if(cfg_initial)begin
                        scene_ready<=1;beat_index<=0;next_valid<=0;cfg_initial<=0;
                        scene_changed_toggle<=~scene_changed_toggle;
                    end else next_valid<=1;
                end
                if(beat_commit)begin
                    beat_index<=logical_beat;next_valid<=0;
                end
            end
        end
    end

    // Pure card-configured payload has no reset value. The independently
    // reset ready/transaction controls below prevent a read before its full
    // action -> scene -> initial-beat transaction finishes. Preserve exactly
    // the same cancellation priority as the control process above; do not
    // turn asynchronous reset into a per-payload-bit reset enable.
    wire config_payload_window=ready_sync[1] &&
        !((active_index!=scene_index || timing_restart) &&
          !de_in && (frame_blank||frame_start));
    always @(posedge clk)begin
        if(config_payload_window)begin
                if(cfg_valid_d)begin
                    if(cfg_kind_d==0 && cfg_count_d>=32)begin
                        case(cfg_count_d[1:0])
                            0:colours[cfg_count_d[4:2]][7:0]<=cfg_data[7:0];
                            1:colours[cfg_count_d[4:2]][15:8]<=cfg_data[7:0];
                            2:colours[cfg_count_d[4:2]][23:16]<=cfg_data[7:0];
                        endcase
                    end
                    if(cfg_kind_d==1)begin
                        case(cfg_count_d)
                            2:title_length<={2'd0,cfg_data[3:0]};3:era_length<={2'd0,cfg_data[3:0]};
                            4:summary_length<={1'd0,cfg_data[4:0]};5:ticker_length<=cfg_data[5:0];
                            6:name_length<={3'd0,cfg_data[2:0]};7:brand_length<={3'd0,cfg_data[2:0]};
                            8:layer_mask<=cfg_data;9:particle_count<={1'b0,cfg_data[2:0]};11:type_ms<=cfg_data[7:0];
                            12:correct_choice<=cfg_data[0];
                        endcase
                    end
                    // The loader has already rejected values outside these limits.
                    // Constant word destinations expose zero high bits to
                    // synthesis; one shared 9-bit indexed write hides them.
                    if(cfg_kind_d==2)begin
                        case(cfg_count_d[2:0])
                            0:next_meta[0]<={4'd0,cfg_data[4:0]};
                            1:next_meta[1]<={4'd0,cfg_data[4:0]};
                            2:next_meta[2]<={6'd0,cfg_data[2:0]};
                            3:next_meta[3]<={6'd0,cfg_data[2:0]};
                            4:next_meta[4]<={6'd0,cfg_data[2:0]};
                            5:next_meta[5]<={2'd0,cfg_data[6:0]};
                            6:next_meta[6]<={7'd0,cfg_data[1:0]};
                            7:next_meta[7]<={6'd0,cfg_data[2:0]};
                        endcase
                    end
                end
            if((cfg_finish && !cfg_valid_d && cfg_kind[1] && cfg_initial) || beat_commit)
                for(ci=0;ci<8;ci=ci+1)beat_meta[ci]<=next_meta[ci];
        end
    end

    // Visible on entry, not hidden behind fifteen seconds of narration.
    // Frame-boundary choice commits prevent mixed answer/panel frames.
    // Automatic tours still show the task, but never wait for an answer.
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            choice_pending<=0;choice_decided<=0;choice_selected<=0;confirm_seen<=0;open_seen<=0;
        end else if(active_index!=scene_index || !adventure_started)begin
            // A real page boundary discards the previous chapter's interaction.
            choice_pending<=0;choice_decided<=0;choice_selected<=0;
            confirm_seen<=choice_confirm_toggle;open_seen<=choice_open_toggle;
        end else if(frame_start && scene_ready && !timing_restart && !menu_visible && !thumbnail_active)begin
            // A rate reload or temporarily covered scene is not an ACK. Keep
            // tokens pending until the result can actually commit to a frame.
            confirm_seen<=choice_confirm_toggle;open_seen<=choice_open_toggle;
            if(choice_confirm_toggle!=confirm_seen &&
               (!choice_decided || choice_open_toggle!=open_seen))begin
                choice_pending<=0;choice_decided<=1;choice_selected<=choice_cursor;
            end else if(choice_open_toggle!=open_seen)begin
                choice_pending<=1;choice_decided<=0;
            end else if(!choice_decided)choice_pending<=1;
        end
    end

    wire story_hold=!adventure_started || menu_visible || thumbnail_active ||
        (!auto_play && logical_beat>=2 && !choice_decided);
    reg [4:0] typed1,typed2;
    reg [12:0] next_type;
    reg [15:0] scroll_acc;
    reg [10:0] scroll_pixels;
    wire [10:0] ticker_text_width={1'b0,ticker_length,4'd0}; // Native 16px cells.
    wire [10:0] scroll_distance=ticker_text_width+11'd460;
    // One complete ticker transit per selected period. All products are
    // constant shifts/adds; max 972*60=58320 fits 16 bits and one pixel/ms.
    wire [15:0] distance_ext={5'd0,scroll_distance};
    wire [15:0] scroll_increment=(timing_profile==0)?((distance_ext<<6)-(distance_ext<<2)):
        (timing_profile==1)?((distance_ext<<4)+(distance_ext<<2)):
        (timing_profile==2)?((distance_ext<<3)+(distance_ext<<2)):
        (timing_profile==3)?(distance_ext<<2):(timing_profile==4)?(distance_ext<<1):distance_ext;
    wire [16:0] scroll_sum={1'b0,scroll_acc}+scroll_increment;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            timing_profile<=5;timing_auto<=0;ms_div<=0;elapsed_ms<=0;beat_ms<=0;logical_beat<=0;story_done<=0;
            typed1<=0;typed2<=0;next_type<=200;scroll_acc<=0;scroll_pixels<=0;cue_toggle<=0;cue_id<=0;
        end else begin
            if(ms_tick)ms_div<=0;else ms_div<=ms_div+1'b1;
            if(frame_start)begin timing_profile<=requested_profile;timing_auto<=auto_play;end
            if(!scene_ready || timing_restart)begin
                elapsed_ms<=0;beat_ms<=0;logical_beat<=0;story_done<=0;
                typed1<=0;typed2<=0;next_type<=200;scroll_acc<=0;scroll_pixels<=0;
            end else begin
                if(beat_commit)begin
                    typed1<=0;typed2<=0;next_type<=200;
                    if(!compact_summary && next_meta[7]!=0)begin cue_toggle<=~cue_toggle;cue_id<=next_meta[7][2:0];end
                end
                // Pausing at the task must not leave its narrative bubble
                // blank after the new beat reset. Reveal the short question.
                if(!auto_play && choice_pending && logical_beat>=2 &&
                   logical_beat==beat_index && !beat_commit)begin
                    typed1<=beat_meta[0][4:0];typed2<=beat_meta[1][4:0];
                end
                // Scrolling remains alive while an unanswered task holds
                // its dialogue. Menu/thumbnail contexts pause it explicitly.
                if(ms_tick && adventure_started && !menu_visible && !thumbnail_active)begin
                    if(scroll_sum>=60000)begin
                        scroll_acc<=scroll_sum-17'd60000;
                        scroll_pixels<=(scroll_pixels+1'b1>=scroll_distance)?11'd0:scroll_pixels+1'b1;
                    end else scroll_acc<=scroll_sum[15:0];
                end
                if(ms_tick && !story_done && !story_hold)begin
                    if(elapsed_next>=60000)begin elapsed_ms<=59999;beat_ms<=7499;logical_beat<=7;story_done<=1;end
                    else begin
                        elapsed_ms<=elapsed_next[15:0];
                        if(beat_next>=7500)begin beat_ms<=beat_next-14'd7500;logical_beat<=logical_beat+1'b1;end
                        else beat_ms<=beat_next[12:0];
                    end
                    if(!compact_summary && logical_beat==beat_index && !beat_commit && beat_ms>=next_type)begin
                        if(typed1<beat_meta[0])begin
                            typed1<=typed1+1'b1;
                            next_type<=next_type+((typed1+1'b1==beat_meta[0])?13'd300:{5'd0,type_ms});
                        end else if(typed2<beat_meta[1])begin typed2<=typed2+1'b1;next_type<=next_type+{5'd0,type_ms};end
                    end

                end
            end
        end
    end
    reg [13:0] visual_ms;
    reg [12:0] visual_beat_ms;
    reg [4:0] visual_typed1,visual_typed2;
    reg [10:0] visual_scroll;
    reg [7:0] frame_count;
    wire [2:0] motion_step=(timing_profile==0)?3'd4:(timing_profile==1)?3'd3:(timing_profile==2)?3'd2:3'd1;
    reg [5:0] effect_age;
    reg effect_choice_seen,effect_result_seen,effect_open_seen;
    wire [6:0] effect_next={1'b0,effect_age}+motion_step;
    wire interaction_event=effect_choice_seen!=choice_cursor || effect_result_seen!=choice_decided || effect_open_seen!=choice_open_toggle;
    wire [5:0] display_effect_age=interaction_event?6'd0:effect_age;
    wire [4:0] result_letters=(display_effect_age>=20)?5'd12:({1'b0,display_effect_age[5:1]}+5'd2);
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            effect_age<=0;effect_choice_seen<=0;effect_result_seen<=0;effect_open_seen<=0;
        end else if(!scene_ready || timing_restart || active_index!=scene_index)begin
            effect_age<=0;effect_choice_seen<=choice_cursor;effect_result_seen<=choice_decided;effect_open_seen<=choice_open_toggle;
        end else if(frame_start)begin
            effect_choice_seen<=choice_cursor;effect_result_seen<=choice_decided;effect_open_seen<=choice_open_toggle;
            if(interaction_event)
                effect_age<=0;
            else if(!menu_visible && !thumbnail_active)
                effect_age<=effect_next[6]?6'd63:effect_next[5:0];
        end
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin visual_ms<=0;visual_beat_ms<=0;visual_typed1<=0;visual_typed2<=0;visual_scroll<=0;frame_count<=0;end
        else if(!scene_ready || timing_restart)begin
            visual_ms<=0;visual_beat_ms<=0;visual_typed1<=0;visual_typed2<=0;visual_scroll<=0;frame_count<=0;
        end else if(frame_start)begin
            visual_ms<=elapsed_ms[15:2];visual_beat_ms<=beat_ms;visual_scroll<=scroll_pixels;
            visual_typed1<=beat_commit?0:typed1;visual_typed2<=beat_commit?0:typed2;
            if(!menu_visible && !thumbnail_active)frame_count<=frame_count+(!adventure_started?3'd1:motion_step);
        end
    end
    wire [9:0] beat_base=10'd256+{1'b0,beat_index,6'd0};
    wire [2:0] sprite_frame=!adventure_started?(frame_count[4]?3'd2:3'd1):(display_effect_age<16)?(display_effect_age[2]?3'd2:3'd1):(beat_meta[3]==1 || beat_meta[3]==2)?
        (frame_count[4]?3'd2:3'd1):
        ((beat_meta[6]==3 && visual_beat_ms<720)?(visual_beat_ms[8]?3'd2:3'd1):beat_meta[3][2:0]);
    wire [5:0] text_length[0:8];
    assign text_length[0]=title_length;assign text_length[1]=era_length;
    assign text_length[2]=beat_meta[0][5:0];assign text_length[3]=beat_meta[1][5:0];
    assign text_length[4]=ticker_length;assign text_length[5]=beat_meta[2][5:0];
    assign text_length[6]=0;assign text_length[7]=brand_length;assign text_length[8]=name_length;
    wire [9:0] cat_x=10'd20,cat_y=10'd304;
    wire [9:0] bubble_x=10'd160,bubble_y=10'd340,bubble_w=10'd460,bubble_h=10'd80;
    wire [9:0] title_x=10'd20,title_y=10'd20;
    wire [9:0] event_x=bubble_x,event_y=bubble_y,event_w=bubble_w,event_h=bubble_h;
    wire [9:0] ticker_x=10'd160,ticker_y=10'd310,ticker_w=10'd460,ticker_h=10'd20;
    wire [9:0] audio_x=10'd20,audio_y=10'd434,audio_w=10'd280,audio_h=10'd40;
    wire [7:0] cat_scale=8'd2,bob_amplitude=8'd1;
    // Transform only scene sampling; physical XY/timing remain unchanged.
    // This tag comes from the same committed reader frame as rgb_in.
    wire [9:0] px,py;
    generate if(LAYER_ZOOM_ENABLE!=0)begin:g_scene_zoom
        scene_zoom_coordinates u_coordinates(.clk(clk),.rst_n(rst_n),.de(de_in),
            .pixel_x(pixel_x[9:0]),.pixel_y(pixel_y[9:0]),.zoom_level(layer_zoom),
            .scene_x(px),.scene_y(py));
    end else begin:g_scene_unscaled
        assign px=pixel_x[9:0];assign py=pixel_y[9:0];
    end endgenerate
    // One signed local-coordinate subtractor per layer. Reusing these deltas
    // avoids separate add/compare networks for every rectangle edge and row.
    wire signed [10:0] tx=$signed({1'b0,px})-$signed({1'b0,title_x});
    wire signed [10:0] ty=$signed({1'b0,py})-$signed({1'b0,title_y});
    wire signed [10:0] bx=$signed({1'b0,px})-$signed({1'b0,bubble_x});
    wire signed [10:0] by=$signed({1'b0,py})-$signed({1'b0,bubble_y});
    wire signed [10:0] ex=$signed({1'b0,px})-$signed({1'b0,event_x});
    wire signed [10:0] ey=$signed({1'b0,py})-$signed({1'b0,event_y});
    wire signed [10:0] kx=$signed({1'b0,px})-$signed({1'b0,ticker_x});
    wire signed [10:0] ky=$signed({1'b0,py})-$signed({1'b0,ticker_y});
    wire signed [10:0] ax=$signed({1'b0,px})-$signed({1'b0,audio_x});
    // The special-page plot occupies the bottom strip below the START prompt
    // and mascot. Chapter coordinates continue to use the committed scene zoom.
    wire special_plot=(SPECIAL_AUDIO_ENABLE!=0) && special_audio_page;
    wire [9:0] plot_y=special_plot ? 10'd444 : audio_y;
    wire signed [10:0] ay=$signed({1'b0,py})-$signed({1'b0,plot_y});
    wire signed [10:0] scope_x=$signed({1'b0,px})-11'sd340;
    wire [9:0] bubble_inner_w=bubble_w-10'd12;
    wire [9:0] event_inner_w=event_w-10'd8;
    wire [9:0] ticker_inner_w=ticker_w-10'd6;
    wire signed [10:0] star_row=$signed({1'b0,py})-11'sd98-$signed({6'd0,frame_count[7:3]});
    // Geometric layers. Only one text glyph lookup is needed per pixel.
    reg [3:0] field_id;
    reg signed [11:0] text_dx;
    reg signed [5:0] text_dy;
    reg [9:0] slot_base;
    reg [5:0] text_limit;
    // Text roles are fixed RGB accents; panel/sprite colours still come from
    // OSD.BIN. Encode correctness here, before the existing glyph pipeline:
    // a later choice update cannot recolour an in-flight text pixel.
    localparam [2:0] TEXT_BODY=3'd0, TEXT_TITLE=3'd1, TEXT_HINT=3'd2,
                     TEXT_CORRECT=3'd3, TEXT_RETRY=3'd4,
                     TEXT_START_TITLE=3'd5, TEXT_START_HINT=3'd6;
    localparam [23:0] INK_BODY=24'hE8EEF9, INK_TITLE=24'h8FE9F6,
                      INK_HINT=24'hFFD68A, INK_CORRECT=24'h82E6BA,
                      INK_RETRY=24'hFF8C8C;
    reg [2:0] text_colour;
    reg text_candidate;
    reg ui_text,large_text;
    reg [9:0] text_origin_x;reg [5:0] text_origin_y;
    reg [4:0] text_char;
    reg [1:0] text_mod3;
    reg [4:0] text_col,text_row;
    reg text_on;
    reg [2:0] panel_kind;
    reg sparkle_on,sprite_on,sprite_odd;
    reg speech_on,shadow_on,choice_marker_on;
    reg [9:0] cat_draw_y;
    wire [9:0] startup_sx=px-10'd60,startup_sy=py-10'd320;
    reg startup_word_on,startup_arrow_on;
    reg startup_word1,startup_word2,startup_arrow1;
    wire [4:0] startup_ascii_row;
    startup_press_start_rom u_startup_ascii(.clk(clk),
        .address({text_char[3:0],text_row[4:2]}),.row_bits(startup_ascii_row));
    reg [9:0] sx,sy;
    reg [6:0] pxs,pys;
    reg [9:0] spark_x,spark_y;
    integer sp;
    wire display_on=enable && scene_ready && ready_sync[1] && de_in;
    wire event_visible=1'b0;
    wire [2:0] bounce_phase=frame_count[3:1];
    wire [7:0] bounce=(bounce_phase<4)?bounce_phase:(7-bounce_phase);
    wire [15:0] experiment_recipe;
    wire [3:0] decor_palette;
    reg [15:0] experiment_recipe1;
    wire experiment_draw;
    wire [23:0] experiment_colour;
    physics_experiment_prepare u_experiment(
        .scene_index(scene_index),.visual_ms(choice_pending?{6'd0,frame_count}:visual_ms),.pixel_x(px),.pixel_y(py),
        .choice_valid(adventure_started),.choice_index(choice_decided?choice_selected:choice_cursor),
        .confirmed(choice_decided),.animation_phase(frame_count),
        .story_beat(beat_index),.experiment_event(beat_meta[4][3:0]),
        .highlight_mask(beat_meta[5][7:0]),.beat_time_ms(visual_beat_ms),
        .recipe(experiment_recipe));
    physics_experiment_decor u_decor(
        .clk(clk),.load_clk(load_clk),.load_we(wr && load_addr>=62464 && load_addr<64512),
        .load_addr(load_addr[10:0]-11'd1024),.load_data(load_data),
        .scene_index(scene_index),.story_beat(beat_index),.experiment_event(beat_meta[4][3:0]),
        .choice_valid(adventure_started),.choice_index(choice_decided?choice_selected:choice_cursor),
        .confirmed(choice_decided),.animation_phase(frame_count),.pixel_x(px),.pixel_y(py),
        .decor_palette(decor_palette));
    physics_experiment_finish u_experiment_finish(.recipe(experiment_recipe1),.decor_palette(decor_palette),
        .draw(experiment_draw),.colour(experiment_colour));
    wire wave_on,scope_wave_on,scope_level_on,scope_volume_on;
    wire plot_visible=(display_on && adventure_started && layer_mask[8]) ||
        (special_plot && de_in && ready_sync[1] && !thumbnail_active);
    wire change_sound=(SPECIAL_AUDIO_ENABLE!=0) && audio_source_change;
    physics_fft_spectrum512 u_spectrum(
        .clk(clk),.rst_n(rst_n),.frame_start(frame_start),
        .sample_valid(audio_valid),.sample(audio_sample),
        .source_change(change_sound),.region_enable(plot_visible),
        // Duplicate each spectrum column horizontally. FFT math, bins and
        // sample cadence are untouched; 128 plot pixels become 256 pixels.
        .local_x(ax >>> 1),.local_y(ay),.region_width(10'd140),.region_height(audio_h),
        .pixel_on(wave_on));
    physics_pcm_scope256 u_scope(
        .clk(clk),.rst_n(rst_n),.frame_start(frame_start),
        .sample_valid(audio_valid),.sample(audio_sample),
        .source_change(change_sound),.region_enable(plot_visible),
        .local_x(scope_x),.local_y(ay),.region_width(10'd280),.region_height(audio_h),
        .volume_level(volume_level),.pixel_on(),.wave_on(scope_wave_on),.level_on(scope_level_on),.volume_on(scope_volume_on));
    always @*begin
        startup_word_on=0;startup_arrow_on=0;field_id=0;text_dx=0;text_dy=0;slot_base=128;text_limit=0;text_colour=TEXT_BODY;text_candidate=0;ui_text=0;large_text=0;text_origin_x=0;text_origin_y=0;
        panel_kind=0;sparkle_on=0;sprite_on=0;sprite_odd=0;speech_on=0;shadow_on=0;choice_marker_on=0;
        spark_x=0;spark_y=0;
        text_char=0;text_mod3=0;text_col=0;text_row=0;text_on=0;
        cat_draw_y=cat_y;
        if(adventure_started && display_effect_age<8)cat_draw_y=cat_y+10'd8-{4'd0,display_effect_age};
        else if(!adventure_started && visual_ms<75)cat_draw_y=cat_y+8;
        else if(frame_count[5])cat_draw_y=cat_y-({10'd0,bob_amplitude[1:0]});
        sx=px-cat_x;sy=py-cat_draw_y;
        pxs=cat_scale==1?sx[6:0]:sx[7:1];pys=cat_scale==1?sy[6:0]:sy[7:1];
        sprite_rd_addr={sprite_frame,11'd0}+{pys[5:0],5'd0}+{9'd0,pxs[5:1]};
        sprite_odd=pxs[0];
        if(!adventure_started)begin
            sprite_rd_addr={sprite_frame,11'd0}+{startup_sy[6:1],5'd0}+{9'd0,startup_sx[6:2]};
            sprite_odd=startup_sx[1];
        end
        if(display_on && adventure_started)begin
            // Transparent scene labels, choices, ticker and audio plots. Only
            // A-Guang dialogue and its attached speaker tab retain a panel.
            // Independent sprite shadow, speech tail and animated typing
            // marks. All geometry lies above the ticker/FFT reserved strip.
            if(layer_mask[2] && px>=42 && px<126 && py>=421 && py<426 &&
               (py>=423 || (px>=52 && px<116)))shadow_on=1;
            if(layer_mask[3] && px>=148 && px<160 && py>=350 && py<374 &&
               ((px>=154) || (py>=356 && py<368)))speech_on=1;
            if(layer_mask[5] && !compact_summary && !choice_pending && !choice_decided &&
               (visual_typed1<text_length[2] || visual_typed2<text_length[3]) &&
               py>=395 && py<400 && px>=560 && px<597 &&
               px[3:0]<5 && ((px<565) || (px<581 && frame_count[3:2]!=0) || frame_count[3]))speech_on=1;

            if(layer_mask[2] && px>=cat_x && py>=cat_draw_y &&
              sx<(cat_scale==1?64:128) && sy<(cat_scale==1?64:128) && sprite_frame<8)sprite_on=1;
            if(layer_mask[3] && !bx[10] && bx[9:0]<bubble_w &&
               !by[10] && by[9:0]<bubble_h &&
               ((bx>=11'sd4 && bx[9:0]<bubble_w-10'd4) ||
                (by>=11'sd4 && by[9:0]<bubble_h-10'd4)))begin
                // Four-pixel stepped corners, a fine two-pixel rim and a
                // dark glass interior. Geometry only: no new framebuffer.
                panel_kind=(bx<11'sd2 || bx[9:0]>=bubble_w-10'd2 ||
                            by<11'sd2 || by[9:0]>=bubble_h-10'd2 ||
                            ((by<11'sd5 || by[9:0]>=bubble_h-10'd5) &&
                             (bx<11'sd6 || bx[9:0]>=bubble_w-10'd6))) ? 2 : 4;
            end
            // A small independent speaker tab bridges the dialogue frame.
            if(layer_mask[2] && px>=172 && px<252 && py>=332 && py<352)
                panel_kind=(px<174 || px>=250 || py<334 || py>=350) ? 2 : 4;



            if(layer_mask[1])begin
                for(sp=0;sp<6;sp=sp+1)begin
                    spark_x=48+sp*103;
                    // For six stars, (sp*37)%144 ranges 0..111; adding
                    // phase 0..31 never wraps. Modulo is therefore constant.
                    spark_y=(sp*37)%144;
                    if(sp<particle_count && ((px==spark_x && star_row>=$signed({1'b0,spark_y})-11'sd3 && star_row<=$signed({1'b0,spark_y})+11'sd3)||
                       (star_row==$signed({1'b0,spark_y}) && px>=spark_x-3 && px<=spark_x+3)))sparkle_on=1;
                end
            end
            // Text priorities are disjoint rectangles: title, slogan, bubble,
            // event, ticker, mascot name and brand. Positions use the fixed ABI profile.
            if(layer_mask[4] && px>=20 && px<276 && py>=20 && py<52)begin
                field_id=0;text_origin_x=10;text_origin_y=20;text_colour=TEXT_TITLE;text_candidate=1;large_text=1;
            end
            if(layer_mask[4] && px>=20 && px<276 && py>=60 && py<76)begin
                field_id=1;text_origin_x=20;text_origin_y=60;text_colour=TEXT_BODY;text_candidate=1;
            end
            if(layer_mask[5] && !event_visible && bx>=11'sd16 && bx[9:0]<bubble_inner_w &&
               by>=11'sd17 && by<11'sd33)begin
                field_id=2;text_origin_x=176;text_origin_y=37;text_colour=TEXT_BODY;text_candidate=1;
            end
            if(layer_mask[5] && !event_visible && bx>=11'sd16 && bx[9:0]<bubble_inner_w &&
               by>=11'sd41 && by<11'sd57)begin
                field_id=3;text_origin_x=176;text_origin_y=61;text_colour=TEXT_BODY;text_candidate=1;
            end

            if(layer_mask[6] && px>=420 && px<612 && py>=54 && py<70)begin
                field_id=5;text_origin_x=420;text_origin_y=54;text_colour=TEXT_HINT;text_candidate=1;
            end
            // Interaction advances on confirmation; no elapsed-story progress bar.
            if(layer_mask[7] && 1'b1 && kx>=11'sd6 && kx[9:0]<ticker_inner_w &&
               ky>=11'sd2 && ky<11'sd18)begin
                // Fast overview uses the short, complete experiment caption
                // from the same asset; long ticker text remains in slower modes.
                field_id=4;
                text_origin_x=compact_summary?10'd166:10'd620;
                text_origin_y=56;text_colour=TEXT_HINT;text_candidate=1;
            end
            if(layer_mask[2] && px>=180 && px<244 && py>=334 && py<350)begin
                field_id=8;text_origin_x=180;text_origin_y=14;text_colour=TEXT_TITLE;text_candidate=1;
            end
            if(layer_mask[4] && px>=460 && px<620 && py>=12 && py<44)begin
                field_id=7;text_origin_x=230;text_origin_y=12;text_colour=TEXT_TITLE;text_candidate=1;large_text=1;
            end
        end
        // One final selection per text field; avoid a dynamic array read
        // followed by three separate overriding multiplexers.
        case(field_id)
            0:begin slot_base=128;text_limit=title_length;end
            1:begin slot_base=136;text_limit=era_length;end
            2:begin
                // Authored narration is an independent typewriter layer.
                // Selection remains visible in the separate A/B card/badge.
                // Only confirmation replaces narration with the branch result.
                if(choice_decided)begin
                    slot_base=choice_selected?430:366;text_limit={1'b0,result_letters};
                    text_colour=choice_correct ? TEXT_CORRECT : TEXT_RETRY;
                end else begin
                    slot_base=compact_summary?148:(beat_base+10'd8);
                    text_limit=compact_summary?((summary_length>12)?12:summary_length):visual_typed1;
                end
            end
            3:begin
                // Separate result action hint from the neutral listening hint.
                // Six existing glyphs occupy formerly blank UI slots 631..636.
                if(choice_decided)begin slot_base=631;text_limit=6;text_colour=TEXT_HINT;end
                else begin
                    slot_base=compact_summary?160:(beat_base+10'd24);
                    text_limit=compact_summary?((summary_length>12)?summary_length-12:0):visual_typed2;
                end
            end
            4:begin
                slot_base=compact_summary?148:172;
                text_limit=compact_summary?((summary_length>18)?18:summary_length):ticker_length;
            end
            5:begin
                if(choice_pending)begin slot_base=choice_cursor?233:225;text_limit=8;ui_text=1;end
                else begin slot_base=beat_base+10'd40;text_limit=beat_meta[2][5:0];end
            end
            7:begin slot_base=204;text_limit=brand_length;end
            8:begin slot_base=209;text_limit=name_length;end
            default:begin slot_base=128;text_limit=0;end
        endcase
        if(display_on)begin
            if(!adventure_started)begin
                // START.BMP is scenery only. Authored title/subtitle remain
                // independent OSD layers from the existing card glyph bank.
                panel_kind=0;sparkle_on=0;speech_on=0;shadow_on=0;choice_marker_on=0;
                text_candidate=0;ui_text=1;text_limit=0;
                sprite_on=(px>=60 && px<188 && py>=320 && py<448);

                // Words 244..248 are the five visible letters after three
                // leading blanks. A 4x cell is 64 pixels; five cells at x160
                // center the title without changing the subtitle or START prompt.
                if(px>=160 && px<480 && py>=112 && py<176)begin
                    slot_base=244;text_limit=5;text_origin_x=40;text_origin_y=48;
                    text_candidate=1;large_text=1;text_colour=TEXT_START_TITLE;
                end

                if(px>=192 && px<448 && py>=202 && py<218)begin
                    slot_base=494;text_limit=16;text_origin_x=192;text_origin_y=10;
                    text_candidate=1;text_colour=TEXT_START_HINT;
                end
                if(px>=278 && px<542 && py>=416 && py<444)begin
                    text_origin_x=10'd278;text_origin_y=6'd32;
                    text_candidate=1;startup_word_on=1;
                end
                // The triangular yellow cursor flashes slowly, once per
                // 128 video frames. It does not change prompt brightness.
                if(frame_count[6] && px>=252 && px<268 && py>=420 && py<440 &&
                   ((px<258 && py>=420 && py<440) ||
                    (px<263 && py>=424 && py<436) || (py>=428 && py<432)))
                    startup_arrow_on=1;
            end else begin
                // A static formula stays separate from animated apparatus,
                // the scrolling caption and the two-line narrative bubble.

                if(px>=176 && px<608 && py>=286 && py<302)begin
                    ui_text=1;slot_base=302;text_limit=16;text_origin_x=9'd176;text_origin_y=6'd30;
                    text_colour=TEXT_HINT;text_candidate=1;
                end
                if(choice_decided)begin

                    if(px>=420 && px<612 && py>=54 && py<70)begin
                        ui_text=1;slot_base=choice_selected?430:366;text_limit=12;
                        text_origin_x=9'd420;text_origin_y=6'd54;text_colour=choice_correct ? TEXT_CORRECT : TEXT_RETRY;text_candidate=1;
                    end
                end
                if(choice_requested)begin


                    if(px>=392 && px<600 && py>=112 && py<128)begin
                        ui_text=1;slot_base=213;text_limit=12;text_origin_x=10'd392;text_origin_y=6'd48;
                        text_colour=TEXT_HINT;text_candidate=1;
                    end
                    if(px>=416 && px<584 && ((py>=152 && py<168)||(py>=192 && py<208)))begin
                        ui_text=1;slot_base=(py<180) ? 225 : 233;text_limit=8;
                        text_origin_x=10'd416;text_origin_y=(py<180) ? 6'd24 : 6'd0;
                        text_colour=((py<180)==!choice_cursor) ? TEXT_TITLE : TEXT_BODY;text_candidate=1;
                    end
                    if(px>=396 && px<402 && ((py>=155 && py<165 && !choice_cursor)||
                                             (py>=195 && py<205 && choice_cursor)))choice_marker_on=1;
                    // TJC owns the labelled listen/confirm/replay controls.
                    // The bubble uses the current option plus a neutral hint;
                    // confirmation replaces them with that option's result.
                end
            end
        end
        // The UI regions are disjoint and at most 432 pixels wide. Their
        // coordinates share one 9-bit modular subtractor; the 576-pixel title
        // halves its X coordinate first. Bounds above make every drawn delta
        // nonnegative, so modulo truncation cannot change a visible glyph.
        if(text_candidate)begin
            // All text uses one origin mux followed by shared subtraction.
            // The moving ticker alone adds its logical scroll displacement.
            text_dx=$signed(large_text ? (adventure_started ? {3'd0,px[9:1]} : {4'd0,px[9:2]}) : {2'd0,px})-$signed({2'd0,text_origin_x});
            if(!ui_text && field_id==4 && !compact_summary)
                text_dx=text_dx+$signed({1'b0,visual_scroll});
            text_dy=large_text ? (adventure_started ? ((py[5:0]-text_origin_y)>>1) :
                ((py[5:0]-text_origin_y)>>2)) : (py[5:0]-text_origin_y);
        end
        // Native 16px cells are direct bit slices, not sampled 24px glyphs.
        // The ASCII PRESS START ROM alone retains its independent 24px pitch.
        if(startup_word_on)begin
            if(text_dx>=0 && text_dx<13'sd768)begin
                text_char=text_dx[9:3]/7'd3;
                text_mod3=text_dx[9:3]%7'd3;
                text_col={text_mod3,text_dx[2:0]};
            end
        end else if(text_dx>=0 && text_dx<13'sd512)begin
            text_char=text_dx[8:4];text_col={1'b0,text_dx[3:0]};
        end
        if(!ui_text && field_id==5 && beat_meta[6]!=0 && visual_beat_ms<1200)begin
            text_dy=text_dy+$signed({3'd0,bounce});
            text_colour=TEXT_HINT;
        end
        // Native16 assets put row zero in ABI row one; the loader remains unchanged.
        text_row=startup_word_on ? text_dy[4:0] : text_dy[4:0]+5'd1;
        text_on=text_candidate && !startup_word_on && text_dx>=0 && text_dx<13'sd512 && text_char<text_limit && text_dy>=0 && text_dy<16;
        // Startup title/subtitle use the same pipelined font read as chapters.
        scene_rd_addr={scene_index,(slot_base+{5'd0,text_char})};
        if(cfg_running && cfg_kind!=0)scene_rd_addr={scene_index,cfg_scene_word};
    end

    reg hs1,vs1,de1,hs2,vs2,de2;
    reg [11:0] x1,y1,x2,y2;
    reg [23:0] rgb1,rgb2;
    // Three role bits (two additional FFs total) track the font pixel through
    // both pipeline stages. No late read of live answer/cursor state.
    reg [2:0] text_colour1,text_colour2;
    reg [2:0] panel1,panel2;
    reg [2:0] bit2;
    wire [1:0] font_pixel=font_q[bit2 +: 2];
    reg [23:0] text_rgb2;
    // Transparent scene text uses ink-dark accents. Dialogue keeps its
    // existing pale glyphs on the dark panel; START remains pale on night sky.
    wire dark_text2=(panel2==0) && (text_colour2<3'd5);
    always @* begin
        case(text_colour2)
            TEXT_TITLE:   text_rgb2=INK_TITLE;
            TEXT_HINT:    text_rgb2=INK_HINT;
            TEXT_CORRECT: text_rgb2=INK_CORRECT;
            TEXT_RETRY:   text_rgb2=INK_RETRY;
            TEXT_START_TITLE: text_rgb2=INK_TITLE;
            TEXT_START_HINT: text_rgb2=INK_HINT;
            default:      text_rgb2=INK_BODY;
        endcase
        if(dark_text2)begin
            case(text_colour2)
                TEXT_TITLE: text_rgb2=24'h10243B;
                TEXT_HINT: text_rgb2=24'h243B58;
                TEXT_CORRECT: text_rgb2=24'h124735;
                TEXT_RETRY: text_rgb2=24'h682C36;
                default: text_rgb2=24'h182B46;
            endcase
        end
        if(font_pixel[1])text_rgb2=dark_text2?24'hF3EBD8:24'h091321;
    end
    reg text1,text2;
    // Complete one-source-pixel outline is authored in the same glyph read.
    // No line buffer, extra RAM or video stage; scene zoom scales both codes.
    reg [4:0] row1,col1;
    reg spr1_on,spr1_odd,spr2_on;
    reg [23:0] spr2_rgb;
    reg spark1,spark2,audio2,scope2,level2,experiment1,experiment2;
    reg speech1,speech2,shadow1,shadow2,choice_marker1,choice_marker2,volume2;
    reg [23:0] experiment_rgb2;
    wire [3:0] sprite_palette=spr1_odd?sprite_q[3:0]:sprite_q[7:4];
    wire font_row_present=row1>=5'd1 && row1<=5'd16;
    wire [4:0] font_row_index=row1-5'd1;
    always @*begin
        // Four two-bit pixels per byte, four bytes per row, sixteen rows.
        // Concatenation addresses exactly0..63, with no multiply or divide.
        font_rd_addr={scene_q,font_row_index[3:0],col1[3:2]};
    end
    function [23:0] blend_half;
        input [23:0] a,b;
        begin blend_half={1'b0,a[23:17]}+{1'b0,b[23:17]};
            blend_half[23:16]={1'b0,a[23:17]}+{1'b0,b[23:17]};
            blend_half[15:8]={1'b0,a[15:9]}+{1'b0,b[15:9]};
            blend_half[7:0]={1'b0,a[7:1]}+{1'b0,b[7:1]};end
    endfunction
    reg [23:0] composed,compose_base,compose_half;
    // Resolve overlay priority once in one-bit control, then select RGB.
    // This preserves every overlap while avoiding repeated wide RGB muxes.
    wire [14:0] rgb_request={startup_word2,text2 && (|font_pixel),volume2,level2,scope2,
        audio2,choice_marker2,speech2,(spr2_on && !adventure_started),
        (panel2==5),(panel2==4),(panel2==3),(panel2==2),
        ((panel2==1)||(shadow2 && !spr2_on)),1'b1};
    wire [14:0] rgb_select;
    assign rgb_select[14]=rgb_request[14];
    genvar rs;
    generate for(rs=0;rs<14;rs=rs+1)begin:g_rgb_select
        assign rgb_select[rs]=rgb_request[rs] && !(|rgb_request[14:rs+1]);
    end endgenerate
    always @*begin
        compose_base=rgb2;
        if(experiment2)compose_base=experiment_rgb2;
        if(spark2)compose_base=colours[6];
        if(spr2_on)compose_base=spr2_rgb;
        // Shadow x42..125/y421..425 never intersects a panel. Share the
        // first half-blend with panels 1/4; an opaque sprite still covers
        // its shadow. No geometry or registered video stage is changed.
        compose_half=blend_half(compose_base,colours[1]);
        composed=({24{rgb_select[0]}} & compose_base) |
                 ({24{rgb_select[1]}} & compose_half) |
                 ({24{rgb_select[2]|rgb_select[7]}} & colours[2]) |
                 ({24{rgb_select[3]}} & colours[4]) |
                 ({24{rgb_select[4]}} & blend_half(compose_half,colours[1])) |
                 ({24{rgb_select[5]}} & 24'h424E91) |
                 ({24{rgb_select[6]}} & spr2_rgb) |
                 ({24{rgb_select[8]}} & colours[3]) |
                 ({24{rgb_select[9]}} & colours[6]) |
                 ({24{rgb_select[10]}} & 24'hC4ECFF) |
                 ({24{rgb_select[11]}} & 24'hFFF1AA) |
                 ({24{rgb_select[12]}} & 24'hF7B955) |
                 ({24{rgb_select[13]}} & text_rgb2) | {24{rgb_select[14]}};
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            hs1<=0;vs1<=0;de1<=0;hs2<=0;vs2<=0;de2<=0;hs_out<=0;vs_out<=0;de_out<=0;
            x1<=0;y1<=0;x2<=0;y2<=0;pixel_x_out<=0;pixel_y_out<=0;rgb1<=0;rgb2<=0;rgb_out<=0;
            text1<=0;text2<=0;text_colour1<=0;text_colour2<=0;row1<=0;col1<=0;bit2<=0;
            startup_word1<=0;startup_word2<=0;startup_arrow1<=0;panel1<=0;panel2<=0;spr1_on<=0;spr1_odd<=0;spr2_on<=0;spr2_rgb<=0;
            speech1<=0;speech2<=0;shadow1<=0;shadow2<=0;choice_marker1<=0;choice_marker2<=0;volume2<=0;
            spark1<=0;spark2<=0;audio2<=0;scope2<=0;level2<=0;experiment1<=0;experiment2<=0;experiment_recipe1<=0;experiment_rgb2<=0;
            sprite_bank_q<=0;font_bank_q<=0;font_row_q<=0;overlay_active<=0;
        end else begin
            sprite_bank_q<=sprite_rd_addr[13:12];font_bank_q<=font_rd_addr[14:12];font_row_q<=font_row_present;
            hs1<=hs_in;vs1<=vs_in;de1<=de_in;x1<=pixel_x;y1<=pixel_y;rgb1<=rgb_in;
            text1<=text_on;text_colour1<=text_colour;row1<=text_row;col1<=text_col;
            startup_word1<=startup_word_on;startup_arrow1<=startup_arrow_on;
            panel1<=panel_kind;spr1_on<=sprite_on;spr1_odd<=sprite_odd;spark1<=sparkle_on;
            speech1<=speech_on;shadow1<=shadow_on;choice_marker1<=choice_marker_on;
            experiment1<=display_on && adventure_started;experiment_recipe1<=experiment_recipe;
            hs2<=hs1;vs2<=vs1;de2<=de1;x2<=x1;y2<=y1;rgb2<=rgb1;
            text2<=text1 && scene_q<384;text_colour2<=text_colour1;bit2<=3'd6-{col1[1:0],1'b0};
            startup_word2<=startup_word1 && col1<20 && startup_ascii_row[3'd4-col1[4:2]];
            panel2<=panel1;spr2_on<=spr1_on && sprite_palette!=0;spr2_rgb<=palette[sprite_palette];spark2<=spark1;audio2<=wave_on;scope2<=scope_wave_on;level2<=scope_level_on || startup_arrow1;
            speech2<=speech1;shadow2<=shadow1;choice_marker2<=choice_marker1;volume2<=scope_volume_on;
            experiment2<=experiment1&&experiment_draw;experiment_rgb2<=experiment_colour;
            hs_out<=hs2;vs_out<=vs2;de_out<=de2;pixel_x_out<=x2;pixel_y_out<=y2;
            rgb_out<=composed;overlay_active<=de2 && (startup_word2 || text2&&(|font_pixel) || spr2_on || panel2!=0 || spark2 || audio2 || scope2 || level2 || experiment2 || speech2 || shadow2 || choice_marker2 || volume2);
        end
    end
endmodule

// Vendor-independent simple dual-port block RAM template. Writes occur only
// during startup/reload; asset_ready synchronizes the completed stable bank.
module dental_osd_ram #(parameter integer AW=12)(
    input wire wclk,we,input wire [AW-1:0]wa,input wire [7:0]wd,
    input wire rclk,input wire [AW-1:0]ra,output wire [7:0]rd
);
`ifdef DENTAL_OSD_BEHAVIORAL_RAM
    (* ram_style="block" *) reg [7:0] mem[0:(1<<AW)-1];
    reg [7:0] rd_sim;
    assign rd=rd_sim;
    always @(posedge wclk)if(we)mem[wa]<=wd;
    always @(posedge rclk)rd_sim<=mem[ra];
`else
    EG_LOGIC_BRAM #(
        .DATA_WIDTH_A(8),.DATA_WIDTH_B(8),.ADDR_WIDTH_A(AW),.ADDR_WIDTH_B(AW),
        .DATA_DEPTH_A(1<<AW),.DATA_DEPTH_B(1<<AW),
        .BYTE_ENABLE(0),.BYTE_A(1),.BYTE_B(1),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.RESETMODE("SYNC"),
        .DEBUGGABLE("NO"),.PACKABLE("NO"),.FORCE_KEEP("OFF"),
        .INIT_FILE("NONE"),.FILL_ALL("NONE"),.IMPLEMENT(AW==12?"32K":"9K")
    ) u_ram(
        .doa(),.dob(rd),.dia(wd),.dib(8'd0),.cea(we),.ocea(1'b1),.clka(wclk),.wea(we),.rsta(1'b0),
        .ceb(1'b1),.oceb(1'b1),.clkb(rclk),.web(1'b0),.rstb(1'b0),
        .bea(1'b1),.beb(1'b1),.addra(wa),.addrb(ra)
    );
`endif
endmodule

// Vendor-independent simple dual-port block RAM template. Writes occur only
// during startup/reload; asset_ready synchronizes the completed stable bank.
module dental_story_ram #(parameter integer AW=13)(
    input wire wclk,we,input wire [AW-1:0]wa,input wire [8:0]wd,
    input wire rclk,input wire [AW-1:0]ra,output wire [8:0]rd
);
    // Keep the public {scene,word} address. Only word pages 0..2 are
    // populated by PHYOSD03; page 3 was a 256-word hole in each scene.
    // A tiny truth table replaces a wide 3*scene+word arithmetic path.
    function [4:0] packed_page;
        input [4:0] source_page;
        begin case(source_page)
            5'd0:packed_page=5'd0;
            5'd1:packed_page=5'd1;
            5'd2:packed_page=5'd2;
            5'd4:packed_page=5'd3;
            5'd5:packed_page=5'd4;
            5'd6:packed_page=5'd5;
            5'd8:packed_page=5'd6;
            5'd9:packed_page=5'd7;
            5'd10:packed_page=5'd8;
            5'd12:packed_page=5'd9;
            5'd13:packed_page=5'd10;
            5'd14:packed_page=5'd11;
            5'd16:packed_page=5'd12;
            5'd17:packed_page=5'd13;
            5'd18:packed_page=5'd14;
            5'd20:packed_page=5'd15;
            5'd21:packed_page=5'd16;
            5'd22:packed_page=5'd17;
            5'd24:packed_page=5'd18;
            5'd25:packed_page=5'd19;
            5'd26:packed_page=5'd20;
            5'd28:packed_page=5'd21;
            5'd29:packed_page=5'd22;
            5'd30:packed_page=5'd23;
            default:packed_page=0;
        endcase end
    endfunction
    wire [4:0] write_page=packed_page(wa[12:8]);
    wire [4:0] read_page=packed_page(ra[12:8]);
    wire valid_write=we && wa[9:8]!=2'b11;
    wire [12:0] compact_wa={write_page,wa[7:0]};
    wire [12:0] compact_ra={read_page,ra[7:0]};
`ifdef DENTAL_OSD_BEHAVIORAL_RAM
    // This is the compact physical capacity, not the original 8192 words.
    reg [8:0] mem[0:6143];
    reg [8:0] rd_sim;
    assign rd=rd_sim;
    always @(posedge wclk)if(valid_write)mem[compact_wa]<=wd;
    always @(posedge rclk)rd_sim<=mem[compact_ra];
`else
    wire [8:0] bank_data[0:5];
    reg [2:0] read_bank_q;
    always @(posedge rclk)read_bank_q<=read_page[4:2];
    assign rd=bank_data[read_bank_q];
    genvar b;
    generate for(b=0;b<6;b=b+1)begin:g_compact_bank
        wire bank_we=valid_write && write_page[4:2]==b;
        EG_LOGIC_BRAM #(
            .DATA_WIDTH_A(9),.DATA_WIDTH_B(9),.ADDR_WIDTH_A(10),.ADDR_WIDTH_B(10),
            .DATA_DEPTH_A(1024),.DATA_DEPTH_B(1024),
            .BYTE_ENABLE(0),.BYTE_A(1),.BYTE_B(1),.MODE("DP"),
            .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
            .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.RESETMODE("SYNC"),
            .DEBUGGABLE("NO"),.PACKABLE("NO"),.FORCE_KEEP("OFF"),
            .INIT_FILE("NONE"),.FILL_ALL("NONE"),.IMPLEMENT("9K")
        ) u_ram(
            .doa(),.dob(bank_data[b]),.dia(wd),.dib(9'd0),
            .cea(bank_we),.ocea(1'b1),.clka(wclk),.wea(bank_we),.rsta(1'b0),
            .ceb(1'b1),.oceb(1'b1),.clkb(rclk),.web(1'b0),.rstb(1'b0),
            .bea(1'b1),.beb(1'b1),.addra(compact_wa[9:0]),.addrb(compact_ra[9:0])
        );
    end endgenerate
`endif
endmodule

// Self-contained 5x7 ASCII prompt. One synchronous read fits the existing
// first video stage; transparent gaps preserve START.BMP. No TF ABI change.
module startup_press_start_rom(input wire clk,input wire [6:0] address,
    output reg [4:0] row_bits);
    (* ram_style="block" *) reg [4:0] pixels [0:127];
    integer k;
    initial begin
        for(k=0;k<128;k=k+1)pixels[k]=0;
        pixels[0]=5'b11110;
        pixels[1]=5'b10001;
        pixels[2]=5'b10001;
        pixels[3]=5'b11110;
        pixels[4]=5'b10000;
        pixels[5]=5'b10000;
        pixels[6]=5'b10000;
        pixels[8]=5'b11110;
        pixels[9]=5'b10001;
        pixels[10]=5'b10001;
        pixels[11]=5'b11110;
        pixels[12]=5'b10100;
        pixels[13]=5'b10010;
        pixels[14]=5'b10001;
        pixels[16]=5'b11111;
        pixels[17]=5'b10000;
        pixels[18]=5'b10000;
        pixels[19]=5'b11110;
        pixels[20]=5'b10000;
        pixels[21]=5'b10000;
        pixels[22]=5'b11111;
        pixels[24]=5'b01111;
        pixels[25]=5'b10000;
        pixels[26]=5'b10000;
        pixels[27]=5'b01110;
        pixels[28]=5'b00001;
        pixels[29]=5'b00001;
        pixels[30]=5'b11110;
        pixels[32]=5'b01111;
        pixels[33]=5'b10000;
        pixels[34]=5'b10000;
        pixels[35]=5'b01110;
        pixels[36]=5'b00001;
        pixels[37]=5'b00001;
        pixels[38]=5'b11110;
        pixels[48]=5'b01111;
        pixels[49]=5'b10000;
        pixels[50]=5'b10000;
        pixels[51]=5'b01110;
        pixels[52]=5'b00001;
        pixels[53]=5'b00001;
        pixels[54]=5'b11110;
        pixels[56]=5'b11111;
        pixels[57]=5'b00100;
        pixels[58]=5'b00100;
        pixels[59]=5'b00100;
        pixels[60]=5'b00100;
        pixels[61]=5'b00100;
        pixels[62]=5'b00100;
        pixels[64]=5'b01110;
        pixels[65]=5'b10001;
        pixels[66]=5'b10001;
        pixels[67]=5'b11111;
        pixels[68]=5'b10001;
        pixels[69]=5'b10001;
        pixels[70]=5'b10001;
        pixels[72]=5'b11110;
        pixels[73]=5'b10001;
        pixels[74]=5'b10001;
        pixels[75]=5'b11110;
        pixels[76]=5'b10100;
        pixels[77]=5'b10010;
        pixels[78]=5'b10001;
        pixels[80]=5'b11111;
        pixels[81]=5'b00100;
        pixels[82]=5'b00100;
        pixels[83]=5'b00100;
        pixels[84]=5'b00100;
        pixels[85]=5'b00100;
        pixels[86]=5'b00100;
    end
    always @(posedge clk)row_bits<=pixels[address];
endmodule
