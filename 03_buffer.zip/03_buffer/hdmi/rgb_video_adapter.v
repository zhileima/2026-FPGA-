`timescale 1ns/1ps
// Register the timing, coordinates and prefetched RGB together. Missing data
// produces a black active pixel; it never changes the HDMI DE/audio schedule.
module rgb_video_adapter #(
    parameter HS_IN_ACTIVE_LOW=1, parameter VS_IN_ACTIVE_LOW=1,
    parameter HS_OUT_ACTIVE_LOW=1, parameter VS_OUT_ACTIVE_LOW=1
)(
    input wire pclk, input wire rst_n,
    input wire hs_in, input wire vs_in, input wire de_in,
    input wire [11:0] x_in, input wire [11:0] y_in,
    input wire [23:0] rgb_in, input wire pixel_valid, input wire display_enable,
    output wire video_clk, output reg video_hs, output reg video_vs,
    output reg video_de, output reg [23:0] video_rgb,
    output reg [11:0] video_x, output reg [11:0] video_y
);
    wire hs_active=HS_IN_ACTIVE_LOW ? ~hs_in : hs_in;
    wire vs_active=VS_IN_ACTIVE_LOW ? ~vs_in : vs_in;
    assign video_clk=pclk;
    always @(posedge pclk or negedge rst_n) begin
        if (!rst_n) begin
            video_hs<=HS_OUT_ACTIVE_LOW ? 1'b1 : 1'b0;
            video_vs<=VS_OUT_ACTIVE_LOW ? 1'b1 : 1'b0;
            video_de<=0; video_rgb<=0; video_x<=0; video_y<=0;
        end else begin
            video_hs<=HS_OUT_ACTIVE_LOW ? ~hs_active : hs_active;
            video_vs<=VS_OUT_ACTIVE_LOW ? ~vs_active : vs_active;
            video_de<=de_in; video_x<=x_in; video_y<=y_in;
            video_rgb<=(de_in && pixel_valid && display_enable) ? rgb_in : 24'd0;
        end
    end
endmodule
