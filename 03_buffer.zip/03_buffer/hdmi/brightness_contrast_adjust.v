`timescale 1ns/1ps

// Four registered stages, one pixel per clock. All timing/coordinates travel
// with RGB. Parameters belong to the input pixel, including a mid-stream change.
// B=255 and C=128 preserve every input bit. No approximation by /256 is used.
module brightness_contrast_adjust (
    input wire clk,
    input wire rst_n,
    input wire hs_in,
    input wire vs_in,
    input wire de_in,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire [23:0] rgb_in,
    input wire [7:0] brightness,
    input wire [7:0] contrast,
    output wire hs_out,
    output wire vs_out,
    output wire de_out,
    output wire [11:0] pixel_x_out,
    output wire [11:0] pixel_y_out,
    output reg [23:0] rgb_out
);
    reg [15:0] mul_r, mul_g, mul_b;
    reg signed [8:0] center_r, center_g, center_b;
    reg signed [17:0] contrast_r, contrast_g, contrast_b;
    reg [7:0] contrast_s1, contrast_s2;
    reg [3:0] hs_pipe, vs_pipe, de_pipe;
    reg [11:0] x_pipe [0:3];
    reg [11:0] y_pipe [0:3];
    integer i;

    // For 0 <= p <= 255*255, this identity is exactly floor(p/255).
    // The intermediate maximum is 65280, so 16 bits are sufficient.
    function [7:0] divide_255;
        input [15:0] p;
        reg [15:0] corrected;
        begin
            corrected = p + 16'd1 + {8'd0,p[15:8]};
            divide_255 = corrected[15:8];
        end
    endfunction

    function [7:0] saturate_contrast;
        input signed [17:0] product;
        reg signed [17:0] adjusted;
        begin
            // Arithmetic shift implements floor for negative products too.
            adjusted = (product >>> 7) + 18'sd128;
            if (adjusted < 18'sd0) saturate_contrast = 8'd0;
            else if (adjusted > 18'sd255) saturate_contrast = 8'd255;
            else saturate_contrast = adjusted[7:0];
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mul_r <= 0; mul_g <= 0; mul_b <= 0;
            center_r <= 0; center_g <= 0; center_b <= 0;
            contrast_r <= 0; contrast_g <= 0; contrast_b <= 0;
            contrast_s1 <= 8'd128; contrast_s2 <= 8'd128;
            rgb_out <= 24'd0;
            // Active-low syncs idle high, matching adjacent video stages.
            // A low reset value would inject false sync edges while filling.
            hs_pipe <= 4'b1111; vs_pipe <= 4'b1111; de_pipe <= 0;
            for (i=0; i<4; i=i+1) begin
                x_pipe[i] <= 0;
                y_pipe[i] <= 0;
            end
        end else begin
            // Stage 1: unsigned brightness products.
            mul_r <= rgb_in[23:16] * brightness;
            mul_g <= rgb_in[15:8] * brightness;
            mul_b <= rgb_in[7:0] * brightness;
            contrast_s1 <= contrast;
            // Stage 2: exact brightness normalization and signed centering.
            center_r <= $signed({1'b0,divide_255(mul_r)}) - 9'sd128;
            center_g <= $signed({1'b0,divide_255(mul_g)}) - 9'sd128;
            center_b <= $signed({1'b0,divide_255(mul_b)}) - 9'sd128;
            contrast_s2 <= contrast_s1;
            // Stage 3: signed contrast products, with per-pixel coefficients.
            contrast_r <= center_r * $signed({1'b0,contrast_s2});
            contrast_g <= center_g * $signed({1'b0,contrast_s2});
            contrast_b <= center_b * $signed({1'b0,contrast_s2});
            // Stage 4: restore the midpoint and clamp without wrapping.
            rgb_out <= {saturate_contrast(contrast_r),
                        saturate_contrast(contrast_g),
                        saturate_contrast(contrast_b)};
            hs_pipe <= {hs_pipe[2:0],hs_in};
            vs_pipe <= {vs_pipe[2:0],vs_in};
            de_pipe <= {de_pipe[2:0],de_in};
            x_pipe[0] <= pixel_x;
            y_pipe[0] <= pixel_y;
            for (i=1; i<4; i=i+1) begin
                x_pipe[i] <= x_pipe[i-1];
                y_pipe[i] <= y_pipe[i-1];
            end
        end
    end
    assign hs_out = hs_pipe[3];
    assign vs_out = vs_pipe[3];
    assign de_out = de_pipe[3];
    assign pixel_x_out = x_pipe[3];
    assign pixel_y_out = y_pipe[3];
endmodule

// Four cycles, streaming horizontal edge emphasis and luma/chroma saturation.
// Default sharpness=0/saturation=50 is bit-exact passthrough. OSD is downstream.
module picture_detail_adjust(
 input clk,rst_n,hs_in,vs_in,de_in,input[11:0]pixel_x,pixel_y,input[23:0]rgb_in,
 input[7:0]sharpness,saturation,
 output hs_out,vs_out,de_out,output[11:0]x_out,y_out,output reg[23:0]rgb_out);
 wire[15:0]sat_word,edge_word;
 reg gain_valid;
 always @(posedge clk or negedge rst_n)if(!rst_n)gain_valid<=0;else gain_valid<=1;
 wire[7:0] satgain=gain_valid?sat_word[7:0]:8'd128;
 wire[7:0] edgegain=gain_valid?edge_word[7:0]:8'd0;
 EG_PHY_BRAM32K #(
.MODE("DP16K"),.DATA_WIDTH_A("16"),.DATA_WIDTH_B("16"),
.REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
.WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.SRMODE("SYNC"),
.CSAMUX("SIG"),.CSBMUX("SIG"),.OCEAMUX("SIG"),.OCEBMUX("SIG"),
.RSTAMUX("SIG"),.RSTBMUX("SIG"),.CLKAMUX("SIG"),.CLKBMUX("SIG"),
.WEAMUX("SIG"),.WEBMUX("SIG"),.READBACK("OFF"),.INIT_FILE(""),
.INIT_00(256'h002600240021001f001c001a001700140012000f000d000a0008000500030000),
.INIT_01(256'h004f004d004a0047004500420040003d003b0038003600330030002e002b0029),
.INIT_02(256'h0078007500730070006e006b0069006600630061005e005c0059005700540052),
.INIT_03(256'h00a1009e009c0099009600940091008f008c008a0087008500820080007d007a),
.INIT_04(256'h00c900c700c400c200bf00bd00ba00b800b500b300b000ad00ab00a800a600a3),
.INIT_05(256'h00f200f000ed00eb00e800e600e300e000de00db00d900d600d400d100cf00cc),
.INIT_06(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fc00fa00f700f5),
.INIT_07(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_08(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_09(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0A(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0B(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0C(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0D(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0E(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff),
.INIT_0F(256'h00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff)) u_detail_gain_rom(
 .doa(sat_word),.dob(edge_word),.dia(16'd0),.dib(16'd0),
 .addra({3'd0,saturation}),.addrb({3'd0,sharpness}),
 .bytea(1'b0),.bytewea(1'b0),.byteb(1'b0),.byteweb(1'b0),
 .csa(1'b1),.csb(1'b1),.wea(1'b0),.web(1'b0),
 .clka(clk),.clkb(clk),.rsta(1'b0),.rstb(1'b0),.ocea(1'b1),.oceb(1'b1));
 function[7:0]clip;input signed[18:0]p;begin
 if(p<0)clip=0;else if(p>255)clip=255;else clip=p[7:0];end endfunction
 wire[9:0]luma_sum={2'd0,rgb_in[23:16]}+{1'd0,rgb_in[15:8],1'b0}+{2'd0,rgb_in[7:0]};
 wire[7:0]luma=luma_sum[9:2];
 reg[7:0]previous_luma;
 reg signed[8:0]chroma[0:2],edge1[0:2];
 (* use_dsp="yes" *)reg signed[17:0]satprod[0:2],edgeprod[0:2];
 reg[7:0]y1,y2,sat3[0:2];reg signed[9:0]edge3[0:2];
 reg[3:0]hp,vp,dp;reg[11:0]xp[0:3],yp[0:3];integer i;
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
 previous_luma<=0;rgb_out<=0;y1<=0;y2<=0;hp<=15;vp<=15;dp<=0;
 for(i=0;i<4;i=i+1)begin xp[i]<=0;yp[i]<=0;end
 for(i=0;i<3;i=i+1)begin chroma[i]<=0;edge1[i]<=0;satprod[i]<=0;edgeprod[i]<=0;sat3[i]<=0;edge3[i]<=0;end
 end else begin
 if(de_in)previous_luma<=luma;
 y1<=luma;y2<=y1;
 for(i=0;i<3;i=i+1)begin
 chroma[i]<=$signed({1'b0,rgb_in[i*8+:8]})-$signed({1'b0,luma});
 // Shared luminance edge keeps zero saturation monochrome, even at full
 // sharpness, and lets synthesis share the three identical edge multipliers.
 edge1[i]<=pixel_x==0 ? 9'sd0 : $signed({1'b0,luma})-$signed({1'b0,previous_luma});
 satprod[i]<=chroma[i]*$signed({1'b0,satgain});edgeprod[i]<=edge1[i]*$signed({1'b0,edgegain});
 sat3[i]<=clip(($signed(satprod[i])>>>7)+$signed({11'd0,y2}));edge3[i]<=edgeprod[i]>>>9;
 rgb_out[i*8+:8]<=clip($signed({11'd0,sat3[i]})+edge3[i]);
 end
 hp<={hp[2:0],hs_in};vp<={vp[2:0],vs_in};dp<={dp[2:0],de_in};xp[0]<=pixel_x;yp[0]<=pixel_y;
 for(i=1;i<4;i=i+1)begin xp[i]<=xp[i-1];yp[i]<=yp[i-1];end
 end end
 assign hs_out=hp[3];assign vs_out=vp[3];assign de_out=dp[3];assign x_out=xp[3];assign y_out=yp[3];
endmodule
