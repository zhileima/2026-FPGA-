`timescale 1ns/1ps
// One-read-port frame transition. The original player token is held until a
// safe pixel-domain arm returns; this preserves the reader/player ACK contract.
// Kind 0 fades through black; kinds 1..8 reveal one committed new frame.
// Kind 9 rotates the old page to its edge, commits, then opens the new page.
// Kind 15 is the initial/direct handoff. No second full-frame read is required.
module video_fade_transition #(
    parameter integer BANK_BITS=2,
    parameter integer FADE_FRAMES = 16,
    parameter integer ACTIVE_WIDTH = 640,
    parameter integer COMMIT_TIMEOUT_FRAMES = 120,
    parameter integer AUDIO_FADE_ENABLE = 0,
    parameter integer REQUEST_ENABLE_GATE = 0
) (
    input wire ctrl_clk, input wire ctrl_rst_n,
    input wire switch_req_toggle, input wire switch_req_enable,
    input wire [BANK_BITS-1:0] switch_req_index, input wire [3:0] switch_req_kind,
    output wire reader_req_toggle, output wire [BANK_BITS-1:0] reader_req_index,
    output wire ctrl_busy,
    input wire pix_clk, input wire pix_rst_n,
    input wire frame_start, input wire vblank, input wire display_active,
    input wire pixel_commit, input wire [BANK_BITS-1:0] pixel_index,
    output wire [7:0] alpha, output wire wipe_active,
    output wire [9:0] wipe_boundary,
    output wire flip_active, output wire [4:0] flip_phase,
    output wire flip_reveal,
    output wire [2:0] pixel_state, output wire [3:0] pixel_kind,
    output wire [BANK_BITS-1:0] pixel_target,
    output wire [3:0] error_flags,
    output wire [1:0] start_mod4, output wire [1:0] complete_mod4,
    output wire pixel_pending,
    input wire audio_source_ready,
    output wire [7:0] audio_alpha
);
    generate if (FADE_FRAMES == 0) begin : g_bypass
        if(REQUEST_ENABLE_GATE==0)begin:g_no_gate
            assign reader_req_toggle=switch_req_toggle;
            assign reader_req_index=switch_req_index;
        end else begin:g_gate
            reg token;reg[BANK_BITS-1:0]index;
            always @(posedge ctrl_clk or negedge ctrl_rst_n)begin
                if(!ctrl_rst_n)begin token<=0;index<=0;end
                else if(switch_req_enable)begin token<=switch_req_toggle;index<=switch_req_index;end
            end
            assign reader_req_toggle=token;assign reader_req_index=index;
        end
        assign ctrl_busy = 1'b0;
        assign alpha = 8'd255;
        assign wipe_active = 1'b0;
        assign wipe_boundary = ACTIVE_WIDTH;
        assign flip_active = 1'b0;
        assign flip_phase = 5'd0;
        assign flip_reveal = 1'b0;
        assign pixel_target = {BANK_BITS{1'b0}};
        assign pixel_state = 3'd0;
        assign pixel_kind = 4'hf;
        assign error_flags = 4'd0;
        assign start_mod4 = 2'd0;
        assign complete_mod4 = 2'd0;
        assign pixel_pending = 1'b0;
        assign audio_alpha = 8'd255;
    end else begin : g_effect
        localparam [2:0] IDLE=3'd0, FADE_OUT=3'd1, WAIT_COMMIT=3'd2,
                         FADE_IN=3'd3, WIPE_IN=3'd4;
        localparam [3:0] INIT=4'hf, FADE=4'd0, FLIP=4'd9;
        localparam integer COUNT_BITS = (FADE_FRAMES < 2) ? 1 : $clog2(FADE_FRAMES+1);
        localparam integer TIMER_BITS = (COMMIT_TIMEOUT_FRAMES < 2) ? 1 :
                                       $clog2(COMMIT_TIMEOUT_FRAMES+1);
        localparam integer WIPE_STEP = (ACTIVE_WIDTH+FADE_FRAMES-1)/FADE_FRAMES;

        reg busy, source_seen, request_toggle, forwarded_toggle;
        reg request_forwarded, reader_token;
        reg [BANK_BITS-1:0] reader_bank;
        // Held transaction token, BANK_BITS context bits, then four effect bits.
        reg [BANK_BITS+4:0] payload_hold;
        (* ASYNC_REG = "TRUE" *) reg [1:0] arm_sync, done_sync;
        reg arm_toggle, done_toggle;
        (* ASYNC_REG = "TRUE" *) reg [2:0] request_sync, forwarded_sync;
        (* ASYNC_REG = "TRUE" *) reg [BANK_BITS+4:0] payload_meta, payload_sync;
        reg request_seen;
        reg [BANK_BITS-1:0] target_bank;
        reg [3:0] kind;
        reg [2:0] state;
        reg [7:0] alpha_reg;
        reg [9:0] boundary;
        reg [4:0] phase;
        reg [COUNT_BITS-1:0] ramp_count;
        reg [TIMER_BITS-1:0] wait_frames;
        reg [3:0] errors;
        reg [1:0] starts, completes;
        reg commit_pending;
        reg audio_initialized;
        reg audio_transition;
        wire safe_blank = !display_active && (frame_start || vblank);
        wire forwarded = forwarded_sync[2] == request_seen;
        wire matching_commit = pixel_commit && pixel_index == target_bank && forwarded;

        assign reader_req_toggle = reader_token;
        assign reader_req_index = reader_bank;
        assign ctrl_busy = busy;
        assign alpha = alpha_reg;
        assign wipe_active = state == WIPE_IN;
        assign wipe_boundary = boundary;
        assign flip_active = kind == FLIP && state != IDLE;
        assign flip_phase = phase;
        assign flip_reveal = state == FADE_IN;
        assign pixel_target = target_bank;
        assign pixel_state = state;
        assign pixel_kind = kind;
        assign error_flags = errors;
        assign start_mod4 = starts;
        assign complete_mod4 = completes;
        assign pixel_pending = state != IDLE || request_sync[2] != request_seen;

        function [7:0] ramp_alpha;
            input [COUNT_BITS-1:0] step_count;
            integer scaled;
            begin
                scaled = (step_count * 255) / FADE_FRAMES;
                ramp_alpha = scaled[7:0];
            end
        endfunction

        function [4:0] ramp_phase;
            input [COUNT_BITS-1:0] step_count;
            integer scaled;
            begin
                scaled = (step_count * 16) / FADE_FRAMES;
                ramp_phase = scaled[4:0];
            end
        endfunction

        if(AUDIO_FADE_ENABLE!=0)begin: g_audio_envelope
            reg [COUNT_BITS-1:0] audio_step;
            reg ready_latched;
            assign audio_alpha=ramp_alpha(audio_step);
            // Keep the old PCM alive during the pre-commit fade. In top, the
            // reader's new bank starts OSD scene selection only after this ramp
            // reaches zero. New audio cannot fade in until SELECT has drained
            // the old stream and the new chapter has a first valid PCM sample.
            // Only the first ready is latched: ordinary sample-valid gaps do
            // not restart an envelope during ongoing playback.
            always @(posedge pix_clk or negedge pix_rst_n)begin
                if(!pix_rst_n)begin audio_step<=0;ready_latched<=0;end
                else if(state==FADE_OUT)begin
                    ready_latched<=0;
                    if(frame_start && audio_step!=0)audio_step<=audio_step-1'b1;
                end else if(state==WAIT_COMMIT && audio_transition)begin
                    audio_step<=0;ready_latched<=0;
                end else begin
                    if(audio_source_ready)ready_latched<=1;
                    if(frame_start && (ready_latched || audio_source_ready) && audio_step<FADE_FRAMES)
                        audio_step<=audio_step+1'b1;
                end
            end
        end else begin: g_no_audio_envelope
            assign audio_alpha=alpha_reg;
        end

        // A raw request received while busy remains held in media_player_control.
        // It is accepted after done, so an ACK during fade-in cannot lose the next
        // queued request. ctrl_busy locks immediately in this local clock domain.
        always @(posedge ctrl_clk or negedge ctrl_rst_n) begin
            if (!ctrl_rst_n) begin
                busy<=0; source_seen<=0; request_toggle<=0; forwarded_toggle<=0;
                request_forwarded<=0; reader_token<=0; reader_bank<=0;
                payload_hold<=0; arm_sync<=0; done_sync<=0;
            end else begin
                arm_sync <= {arm_sync[0],arm_toggle};
                done_sync <= {done_sync[0],done_toggle};
                if (!busy) begin
                    if ((REQUEST_ENABLE_GATE==0 || switch_req_enable) && switch_req_toggle != source_seen) begin
                        source_seen <= switch_req_toggle;
                        payload_hold <= {switch_req_toggle,switch_req_index,switch_req_kind};
                        request_toggle <= ~request_toggle;
                        request_forwarded <= 0;
                        busy <= 1;
                    end
                end else begin
                    if (!request_forwarded && arm_sync[1] == request_toggle) begin
                        reader_token <= payload_hold[BANK_BITS+4];
                        reader_bank <= payload_hold[BANK_BITS+3:4];
                        forwarded_toggle <= request_toggle;
                        request_forwarded <= 1;
                    end
                    if (request_forwarded && done_sync[1] == request_toggle)
                        busy <= 0;
                end
            end
        end

        always @(posedge pix_clk or negedge pix_rst_n) begin
            if (!pix_rst_n) begin
                request_sync<=0; forwarded_sync<=0; payload_meta<=0; payload_sync<=0;
                request_seen<=0; arm_toggle<=0; done_toggle<=0;
                target_bank<=0; kind<=INIT; state<=IDLE; alpha_reg<=255;
                boundary<=ACTIVE_WIDTH; phase<=0; ramp_count<=0; wait_frames<=0;
                errors<=0; starts<=0; completes<=0; commit_pending<=0;audio_initialized<=0;audio_transition<=0;
            end else begin
                request_sync <= {request_sync[1:0],request_toggle};
                forwarded_sync <= {forwarded_sync[1:0],forwarded_toggle};
                payload_meta <= payload_hold;
                payload_sync <= payload_meta;
                // Preserve a matching commit until a blank boundary; never
                // change brightness or the reveal edge inside active pixels.
                if (state == WAIT_COMMIT && matching_commit) begin
                    commit_pending <= 1;
                    audio_initialized<=1;
                    if (display_active) errors[1] <= 1;
                end
                if (frame_start && display_active) errors[3] <= 1;
                if (safe_blank) begin
                    case (state)
                    IDLE: begin
                        if (request_sync[2] != request_seen) begin
                            request_seen <= request_sync[2];
                            target_bank <= payload_sync[BANK_BITS+3:4];
                            kind <= payload_sync[3:0];
                            audio_transition <= !audio_initialized || payload_sync[3:0]<=4'd9 ||
                                payload_sync[BANK_BITS+3:4]!=pixel_index;
                            starts <= starts + 1'b1;
                            ramp_count <= 0;
                            wait_frames <= 0;
                            commit_pending <= 0;
                            boundary <= ACTIVE_WIDTH;
                            phase <= 0;
                            alpha_reg <= 255;
                            if (payload_sync[3:0] == FADE || payload_sync[3:0] == FLIP ||
                                (AUDIO_FADE_ENABLE!=0 && (payload_sync[3:0]<=4'd9 ||
                                 (payload_sync[3:0]==INIT && audio_initialized &&
                                  payload_sync[BANK_BITS+3:4]!=pixel_index)))) begin
                                state <= FADE_OUT;
                            end else begin
                                state <= WAIT_COMMIT;
                                arm_toggle <= request_sync[2];
                                if (payload_sync[3:0] > 4'd9 && payload_sync[3:0] != INIT) begin
                                    kind <= INIT;
                                    errors[2] <= 1;
                                end
                            end
                        end
                    end
                    FADE_OUT: if (frame_start) begin
                        if (ramp_count == FADE_FRAMES-1) begin
                            alpha_reg <= kind == FADE ? 0 : 255;
                            phase <= kind == FLIP ? 16 : 0;
                            state <= WAIT_COMMIT;
                            wait_frames <= 0;
                            commit_pending <= 0;
                            arm_toggle <= request_seen;
                        end else begin
                            ramp_count <= ramp_count + 1'b1;
                            alpha_reg <= kind == FADE ? ramp_alpha(FADE_FRAMES-ramp_count-1'b1) : 255;
                            if (kind == FLIP) phase <= ramp_phase(ramp_count+1'b1);
                        end
                    end
                    WAIT_COMMIT: begin
                        if (commit_pending || matching_commit) begin
                            commit_pending <= 0;
                            ramp_count <= 0;
                            wait_frames <= 0;
                            if (kind == FADE || kind == FLIP) begin
                                state <= FADE_IN;
                                alpha_reg <= kind == FLIP ? 255 : 0;
                                phase <= kind == FLIP ? 16 : 0;
                            end else if (kind >= 4'd1 && kind <= 4'd8) begin
                                state <= WIPE_IN;
                                alpha_reg <= 255;
                                boundary <= 0;
                            end else begin
                                state <= IDLE;
                                alpha_reg <= 255;
                                boundary <= ACTIVE_WIDTH;
                                phase <= 0;
                                done_toggle <= request_seen;
                                completes <= completes + 1'b1;
                            end
                        end else if (frame_start) begin
                            if (wait_frames == COMMIT_TIMEOUT_FRAMES-1) begin
                                errors[0] <= 1;
                                state <= IDLE;
                                alpha_reg <= 255;
                                boundary <= ACTIVE_WIDTH;
                                phase <= 0;
                                done_toggle <= request_seen;
                                completes <= completes + 1'b1;
                            end else wait_frames <= wait_frames + 1'b1;
                        end
                    end
                    FADE_IN: if (frame_start) begin
                        if (ramp_count == FADE_FRAMES-1) begin
                            alpha_reg <= 255;
                            state <= IDLE;
                            boundary <= ACTIVE_WIDTH;
                            phase <= 0;
                            done_toggle <= request_seen;
                            completes <= completes + 1'b1;
                        end else begin
                            ramp_count <= ramp_count + 1'b1;
                            alpha_reg <= kind == FLIP ? 255 : ramp_alpha(ramp_count+1'b1);
                            if (kind == FLIP) phase <= 16-ramp_phase(ramp_count+1'b1);
                        end
                    end
                    WIPE_IN: if (frame_start) begin
                        if (boundary + WIPE_STEP >= ACTIVE_WIDTH) begin
                            boundary <= ACTIVE_WIDTH;
                            state <= IDLE;
                            done_toggle <= request_seen;
                            completes <= completes + 1'b1;
                        end else boundary <= boundary + WIPE_STEP;
                    end
                    default: begin
                        errors[3] <= 1;
                        state <= IDLE;
                        alpha_reg <= 255;
                        boundary <= ACTIVE_WIDTH;
                        phase <= 0;
                        done_toggle <= request_seen;
                    end
                    endcase
                end
            end
        end
    end endgenerate
endmodule
