`timescale 1ns/1ps

// Stream-only settings overlay: one synchronous glyph-ROM stage and one
// registered composition stage. ALL RGB/timing/coordinates have TWO clocks
// latency. No frame buffer, divider or multiplier. State inputs are supplied
// atomically in vertical blank by the top-level control snapshot.
module player_settings_osd (
    input wire clk, input wire rst,
    input wire hs_in, input wire vs_in, input wire de_in,
    input wire [11:0] pixel_x, input wire [11:0] pixel_y,
    input wire [23:0] rgb_in,
    input wire menu_visible, input wire [3:0] selected_row,
    input wire [3:0] image_number, input wire [3:0] music_index,
    input wire auto_play, input wire [2:0] period_sel,
    input wire [3:0] effect_sel,
    input wire [7:0] volume, input wire [7:0] brightness,
    input wire [7:0] contrast, input wire thumbnail_context,
    output reg hs_out, output reg vs_out, output reg de_out,
    output reg [11:0] pixel_x_out, output reg [11:0] pixel_y_out,
    output reg [23:0] rgb_out
);
    // volume/brightness/contrast are already mapped to 0..100 by the controller.
    // A shared eight-bit double-dabble engine services all three controls.
    // Freeze displayed digits at vertical sync, so even a changed value cannot
    // split within one visible frame. Conversion throughput is 27 clocks/set.
    reg [1:0] decimal_channel;
    reg [3:0] decimal_step;
    reg [7:0] binary_work;
    reg [11:0] decimal_work;
    reg [11:0] decimal_adjusted;
    reg [11:0] converted_volume, converted_brightness, converted_contrast;
    reg [11:0] display_volume, display_brightness, display_contrast;
    reg vs_q;
    wire [11:0] decimal_next = {decimal_adjusted[10:0], binary_work[7]};
    always @* begin
        decimal_adjusted = decimal_work;
        if (decimal_work[3:0] >= 5) decimal_adjusted[3:0] = decimal_work[3:0] + 4'd3;
        if (decimal_work[7:4] >= 5) decimal_adjusted[7:4] = decimal_work[7:4] + 4'd3;
        if (decimal_work[11:8] >= 5) decimal_adjusted[11:8] = decimal_work[11:8] + 4'd3;
    end
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            decimal_channel <= 0; decimal_step <= 0;
            binary_work <= 0; decimal_work <= 0;
            converted_volume <= 0; converted_brightness <= 0; converted_contrast <= 0;
            display_volume <= 0; display_brightness <= 0; display_contrast <= 0;
            vs_q <= 1'b1;
        end else begin
            vs_q <= vs_in;
            if (decimal_step == 0) begin
                case (decimal_channel)
                    0: binary_work <= volume;
                    1: binary_work <= brightness;
                    default: binary_work <= contrast;
                endcase
                decimal_work <= 0;
                decimal_step <= 1;
            end else begin
                binary_work <= {binary_work[6:0], 1'b0};
                decimal_work <= decimal_next;
                if (decimal_step == 8) begin
                    case (decimal_channel)
                        0: converted_volume <= decimal_next;
                        1: converted_brightness <= decimal_next;
                        default: converted_contrast <= decimal_next;
                    endcase
                    decimal_channel <= decimal_channel == 2 ? 0 : decimal_channel + 1'b1;
                    decimal_step <= 0;
                end else decimal_step <= decimal_step + 1'b1;
            end
            if (vs_q && !vs_in) begin
                display_volume <= converted_volume;
                display_brightness <= converted_brightness;
                display_contrast <= converted_contrast;
            end
        end
    end


    // Full-screen opaque settings page. The existing seven controls retain
    // their original row order. Native 22x23 sharp glyphs use 24-pixel
    // character pitch, with no font enlargement or gray edge blur.
    wire menu_on=menu_visible && de_in;
    reg [3:0] row_index;
    reg [8:0] row_top;
    always @* begin
        if(pixel_y>=384)begin row_index=6;row_top=384;end
        else if(pixel_y>=336)begin row_index=5;row_top=336;end
        else if(pixel_y>=288)begin row_index=4;row_top=288;end
        else if(pixel_y>=240)begin row_index=3;row_top=240;end
        else if(pixel_y>=192)begin row_index=2;row_top=192;end
        else if(pixel_y>=144)begin row_index=1;row_top=144;end
        else begin row_index=0;row_top=96;end
    end
    wire [5:0] row_y=pixel_y[5:0]-row_top[5:0];
    wire row_region=pixel_y>=96 && pixel_y<432;
    wire row_selected=row_index==selected_row;
    // Four fixed cells need only comparisons and five-bit wraparound offsets.
    // This avoids division while keeping Chinese labels and numbers compact.
    wire [1:0] label_slot=pixel_x<12'd88 ? 2'd0 : pixel_x<12'd112 ? 2'd1 : pixel_x<12'd136 ? 2'd2 : 2'd3;
    wire [1:0] value_slot=pixel_x<12'd328 ? 2'd0 : pixel_x<12'd352 ? 2'd1 : pixel_x<12'd376 ? 2'd2 : 2'd3;
    wire [4:0] label_offset=pixel_x[4:0]+{label_slot,3'b0};
    wire [4:0] value_offset=pixel_x[4:0]-5'd16+{value_slot,3'b0};
    wire title_slot=pixel_x>=12'd56;
    wire [4:0] title_offset=pixel_x[4:0]+(title_slot?5'd8:5'd0);
    wire [4:0] title_y=pixel_y[4:0]-5'd24;
    reg [5:0] value_code,label_code,glyph_code;
    reg [3:0] value_digit;
    reg [4:0] glyph_row,glyph_column;
    reg [11:0] number_bcd;
    reg glyph_valid,glyph_light;
    always @* begin
        case(row_index)
            3: number_bcd=display_volume;
            4: number_bcd=display_brightness;
            5: number_bcd=display_contrast;
            default: number_bcd=0;
        endcase
        // Resolve one character before row/effect selection. Avoid carrying
        // and multiplexing all four 6-bit characters through every setting.
        case(value_slot)
            0: value_digit=number_bcd[11:8];
            1: value_digit=number_bcd[7:4];
            default: value_digit=number_bcd[3:0];
        endcase
        value_code=0;
        case(row_index)
            0: if(value_slot==0)value_code=auto_play ? 6'd24:6'd25;
            1: begin
                case({period_sel,value_slot})
                    5'd0,5'd12: value_code=6'd47;
                    5'd1,5'd5,5'd9,5'd14,5'd18,5'd22,5'd26,5'd30: value_code=6'd45;
                    5'd4,5'd16: value_code=6'd49;
                    5'd8,5'd13: value_code=6'd51;
                    5'd17,5'd21,5'd25,5'd29: value_code=6'd46;
                    5'd20,5'd24,5'd28: value_code=6'd52;
                    default: value_code=0;
                endcase
            end
            2: begin
                case({effect_sel,value_slot})
                    6'd0,6'd2: value_code=6'd26;
                    6'd1: value_code=6'd27;
                    6'd3: value_code=6'd28;
                    6'd4,6'd8,6'd12,6'd16: value_code=6'd29;
                    6'd5: value_code=6'd30;
                    6'd6,6'd10,6'd14,6'd18,6'd22,6'd34: value_code=6'd31;
                    6'd7,6'd11,6'd15,6'd19,6'd23,6'd35: value_code=6'd24;
                    6'd9: value_code=6'd32;
                    6'd13: value_code=6'd33;
                    6'd17: value_code=6'd34;
                    6'd20: value_code=6'd35;
                    6'd21: value_code=6'd36;
                    6'd24: value_code=6'd37;
                    6'd25: value_code=6'd38;
                    6'd26: value_code=6'd39;
                    6'd28: value_code=6'd40;
                    6'd29: value_code=6'd41;
                    6'd30: value_code=6'd42;
                    6'd32: value_code=6'd43;
                    6'd33: value_code=6'd44;
                    6'd36: value_code=6'd49;
                    6'd37: value_code=6'd58;
                    6'd38: value_code=6'd59;
                    6'd39: value_code=6'd60;
                    default: value_code=0;
                endcase
            end
            3,4,5: value_code=value_slot==3  ?  6'd57 : 6'd46+{2'b0,value_digit};
            6: if(value_slot==0)value_code=thumbnail_context ? 6'd24:6'd25;
            default: value_code=0;
        endcase
        label_code=0;
        case({row_index,label_slot})
            6'd0: label_code=6'd5;
            6'd1: label_code=6'd6;
            6'd2: label_code=6'd7;
            6'd3: label_code=6'd8;
            6'd4: label_code=6'd7;
            6'd5: label_code=6'd8;
            6'd6: label_code=6'd9;
            6'd7: label_code=6'd10;
            6'd8: label_code=6'd11;
            6'd9: label_code=6'd12;
            6'd10: label_code=6'd13;
            6'd11: label_code=6'd14;
            6'd12: label_code=6'd15;
            6'd13: label_code=6'd16;
            6'd16: label_code=6'd17;
            6'd17: label_code=6'd18;
            6'd20: label_code=6'd19;
            6'd21: label_code=6'd20;
            6'd22: label_code=6'd18;
            6'd24: label_code=6'd21;
            6'd25: label_code=6'd22;
            6'd26: label_code=6'd23;
            default: label_code=0;
        endcase
        glyph_code=0;glyph_row=0;glyph_column=0;glyph_valid=0;glyph_light=0;
        if(menu_on)begin
            if(pixel_x>=32 && pixel_x<80 && pixel_y>=29 && pixel_y<52 && title_offset>=1 && title_offset<23)begin
                glyph_code=title_slot?6'd2:6'd1;
                glyph_row=title_y-5'd5;glyph_column=title_offset-5'd1;
                glyph_valid=1;glyph_light=1;
            end else if(row_region && row_y>=13 && row_y<36)begin
                glyph_row=row_y-6'd13;
                glyph_light=row_selected;
                if(pixel_x>=64 && pixel_x<160 && label_offset>=1 && label_offset<23)begin
                    glyph_code=label_code;glyph_column=label_offset-5'd1;glyph_valid=1;
                end else if(pixel_x>=304 && pixel_x<400 && value_offset>=1 && value_offset<23)begin
                    glyph_code=value_code;glyph_column=value_offset-5'd1;glyph_valid=1;
                end
            end
        end
    end

    // The progress bar uses the SAME frame-latched BCD as its printed value;
    // changing settings never leaves a new bar beside the previous frame's digits.
    wire [7:0] percent_units={1'b0,number_bcd[7:4],3'b0}+
                            {3'b0,number_bcd[7:4],1'b0}+{4'b0,number_bcd[3:0]};
    wire [7:0] percent=(|number_bcd[11:8])?8'd100:percent_units;
    wire [6:0] bar_x=pixel_x[6:0]-7'd84; // x=468 modulo128
    wire bar_region=row_region && row_index>=3 && row_index<=5 &&
                    pixel_x>=468 && pixel_x<568 && row_y>=21 && row_y<27;
    wire bar_fill=bar_region && {1'b0,bar_x}<percent;
    wire highlight=row_region && row_selected && row_y>=4 && row_y<44 &&
                   pixel_x>=32 && pixel_x<608;
    wire accent=highlight && pixel_x<36;
    wire rule=(pixel_y>=78 && pixel_y<80) ||
              (pixel_x>=252 && pixel_x<254 && pixel_y>=96 && pixel_y<432);
    // Only an 8-colour geometry class crosses the glyph-ROM clock stage.
    reg [2:0] background_code;
    always @* begin
        if(accent)background_code=7;
        else if(rule)background_code=4;
        else if(bar_fill)background_code=6;
        else if(bar_region)background_code=5;
        else if(highlight)background_code=3;
        else if(pixel_y<72)background_code=1;
        else if(pixel_x<252)background_code=2;
        else background_code=0;
    end
    wire [31:0] font_row_bits;
    // Packed index is 22*row+column. Shifts/adds keep the original ROM size.
    wire [8:0] glyph_bit_index={glyph_row,4'b0}+{2'b0,glyph_row,2'b0}+
                                {3'b0,glyph_row,1'b0}+{4'b0,glyph_column};
    player_settings_font_rom font_rom(.clk(clk),
        .address({glyph_code,glyph_bit_index[8:5]}),.row_bits(font_row_bits));
    reg hs_q,vs_pipe_q,de_q,menu_q,glyph_valid_q,glyph_light_q;
    reg [11:0] x_q,y_q;
    reg [23:0] rgb_q;
    reg [2:0] background_q;
    reg [4:0] glyph_bit_q;
    wire font_on=glyph_valid_q && font_row_bits[5'd31-glyph_bit_q];
    // Opaque high-contrast page; sharp solid text needs no blend multipliers.
    function [23:0] menu_colour;
        input [2:0] background;
        input light;
        input ink;
        begin
            if(ink)menu_colour=light?24'hffffff:24'he4ebf4;
            else case(background)
                0:menu_colour=24'h0b1019;
                1:menu_colour=24'h111c2b;
                2:menu_colour=24'h101722;
                3:menu_colour=24'h253951;
                4:menu_colour=24'h2e425b;
                5:menu_colour=24'h304050;
                6:menu_colour=24'hef6570;
                default:menu_colour=24'hff6b72;
            endcase
        end
    endfunction
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            hs_q<=0;vs_pipe_q<=0;de_q<=0;x_q<=0;y_q<=0;rgb_q<=0;
            menu_q<=0;background_q<=0;glyph_valid_q<=0;glyph_light_q<=0;glyph_bit_q<=0;
            hs_out<=0;vs_out<=0;de_out<=0;pixel_x_out<=0;pixel_y_out<=0;rgb_out<=0;
        end else begin
            hs_q<=hs_in;vs_pipe_q<=vs_in;de_q<=de_in;x_q<=pixel_x;y_q<=pixel_y;rgb_q<=rgb_in;
            menu_q<=menu_on;background_q<=background_code;
            glyph_valid_q<=glyph_valid;glyph_light_q<=glyph_light;glyph_bit_q<=glyph_bit_index[4:0];
            hs_out<=hs_q;vs_out<=vs_pipe_q;de_out<=de_q;pixel_x_out<=x_q;pixel_y_out<=y_q;
            rgb_out<=menu_q?menu_colour(background_q,glyph_light_q,font_on):rgb_q;
        end
    end
endmodule
