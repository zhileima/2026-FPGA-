`timescale 1ns/1ps
// 512-point, 48-kHz real-audio spectrum. No decimation or synthetic motion.
// Periodic Hann window; radix-2 DIT; Q15 twiddles; one shared signed multiplier.
// Each FFT stage divides by two, so the transform is normalized by 512.
// Frames are captured contiguously, processed, then committed at video VS.
// The video-side output has exactly ONE pixel-clock latency, like the waveform.
module physics_fft_spectrum512(
    input wire clk,rst_n,frame_start,
    input wire sample_valid,input wire signed [15:0] sample,
    input wire region_enable,
    input wire signed [10:0] local_x,local_y,
    input wire [9:0] region_width,region_height,
    output wire pixel_on,
    input wire source_change
);
    localparam [4:0] CAPTURE=0,CAP_WAIT=1,CAP_MUL=2,CAP_SAVE=3,
        FFT_INIT=4,READ_A=5,READ_B=6,READ_COEF=7,
        MUL_RR=8,MUL_II=9,MUL_RI=10,MUL_IR=11,COMPLEX=12,
        WRITE_A=13,WRITE_B=14,NEXT_BFLY=15,
        MAG_READ=16,MAG_WAIT=17,MAG_SAVE=18,WAIT_FRAME=19,DISPLAY_UPDATE=20;
    reg [4:0] state;
    reg [8:0] capture_index,half_size,base_index,butterfly_index,twiddle_step,twiddle_phase;
    reg [8:0] magnitude_index;
    reg signed [15:0] captured_sample,ar,ai,br,bi,wr,wi,partial_product;
    reg signed [16:0] tr,ti;
    reg signed [31:0] product;
    reg signed [15:0] mul_a,mul_b;
    // Each base is aligned to 2*half_size and j<half_size, so these
    // bit fields never overlap in any radix-2 stage. OR avoids carry chains.
    wire [8:0] address_a=base_index|butterfly_index;
    wire [8:0] address_b=address_a|half_size;
    wire [9:0] next_base={1'b0,base_index}+{half_size,1'b0};
    wire [8:0] reverse_capture={capture_index[0],capture_index[1],capture_index[2],
        capture_index[3],capture_index[4],capture_index[5],capture_index[6],
        capture_index[7],capture_index[8]};
    wire [8:0] coefficient_address=(state<=CAP_SAVE)?capture_index:twiddle_phase;
    wire [31:0] coefficient_data;
    physics_fft_twiddle512 u_coefficients(.clk(clk),.address(coefficient_address),.q(coefficient_data));
    // (32767 - signed_cos) / 2 is exactly this sign/invert wiring for
    // all 65536 coefficient bit patterns, including -32768.
    wire signed [15:0] window_coefficient={1'b0,coefficient_data[31],~coefficient_data[30:17]};
    always @*begin
        mul_a=br;mul_b=wr;
        case(state)
            CAP_MUL:begin mul_a=captured_sample;mul_b=window_coefficient;end
            MUL_II:begin mul_a=bi;mul_b=wi;end
            MUL_RI:begin mul_a=br;mul_b=wi;end
            MUL_IR:begin mul_a=bi;mul_b=wr;end
            default:begin mul_a=br;mul_b=wr;end
        endcase
    end
    // This is the only variable multiplication in the complete module.
    always @(posedge clk) product<=mul_a*mul_b;
    wire subtract=(state==WRITE_B);
    wire [17:0] signed_operand_real={tr[16],tr}^{18{subtract}};
    wire [17:0] signed_operand_imag={ti[16],ti}^{18{subtract}};
    wire signed [17:0] sum_real={{2{ar[15]}},ar}+signed_operand_real+subtract;
    wire signed [17:0] sum_imag={{2{ai[15]}},ai}+signed_operand_imag+subtract;
    reg [8:0] ram_address;
    always @*begin
        ram_address=address_a;
        case(state)
            CAP_SAVE:ram_address=reverse_capture;
            READ_B,WRITE_B:ram_address=address_b;
            MAG_READ,MAG_WAIT,MAG_SAVE:ram_address=magnitude_index;
            default:ram_address=address_a;
        endcase
    end
    wire ram_write=(state==CAP_SAVE || state==WRITE_A || state==WRITE_B);
    wire [31:0] ram_write_data=(state==CAP_SAVE)?{product[30:15],16'd0}:
        {sum_real[16:1],sum_imag[16:1]};
    wire [31:0] ram_read_data;
    physics_fft_work_ram512 u_work(.clk(clk),.we(ram_write),.address(ram_address),
        .data(ram_write_data),.q(ram_read_data));
    wire [15:0] absolute_real=ram_read_data[31]?(~ram_read_data[31:16]+16'd1):ram_read_data[31:16];
    wire [15:0] absolute_imag=ram_read_data[15]?(~ram_read_data[15:0]+16'd1):ram_read_data[15:0];
    wire [16:0] bin_magnitude={1'b0,absolute_real}+{1'b0,absolute_imag};
    reg [16:0] band_peak;
    reg [3:0] band_index;
    wire [16:0] next_peak=(bin_magnitude>band_peak)?bin_magnitude:band_peak;
    reg [7:0] band_end;
    always @*begin
        case(band_index)
            0:band_end=1;1:band_end=2;2:band_end=3;3:band_end=4;
            4:band_end=6;5:band_end=8;6:band_end=12;7:band_end=16;
            8:band_end=24;9:band_end=32;10:band_end=48;11:band_end=64;
            12:band_end=96;13:band_end=128;14:band_end=192;default:band_end=255;
        endcase
    end
    // Log-like display only: the bins above remain an actual fixed-point FFT.
    // <8 LSB is the quantisation floor. +~6dB increases height about 3 pixels.
    function [5:0] level_from_magnitude;
        input [16:0] value;
        integer p;
        reg [5:0] level;
        reg found;
        begin
            level=0;found=0;
            for(p=16;p>=3;p=p-1)begin
                if(!found && value[p])begin
                    if(p>=13)level=32;
                    else level=(p-2)*3+((value>>(p-2))&3);
                    found=1;
                end
            end
            level_from_magnitude=level>32?32:level;
        end
    endfunction
    // Two 16x6 LUT RAMs replace the rotating 192-bit register payload.
    // DISPLAY_UPDATE occupies sixteen VS-blank clocks. During that interval
    // the display read port supplies the old level for release; otherwise it
    // supplies the pixel column. The original level_q keeps one pixel latency.
    reg [3:0] update_index;
    reg display_valid;
    // Keep the already-scanning frame intact. At its vertical boundary the
    // previous source becomes invisible; the next fresh FFT replaces it
    // without releasing old bars into the new source.
    reg blank_at_frame;
    wire [10:0] plot_x=local_x-11'sd6;
    wire [3:0] column=plot_x[6:3];
    wire display_write=(state==DISPLAY_UPDATE);
    wire target_write=(state==MAG_SAVE && magnitude_index[7:0]==band_end);
    wire [3:0] target_write_index=band_index;
    wire [5:0] target_write_data=level_from_magnitude(next_peak);
    wire [3:0] display_read_index=display_write?update_index:column;
    wire [5:0] target_head,display_head;
    wire [5:0] released_level=(!display_valid || target_head>=display_head)?target_head:
        (display_head>target_head+6'd2)?display_head-6'd2:target_head;
    physics_fft_level_ram16x6 u_targets(.clk(clk),.we(target_write),
        .waddr(target_write_index),.data(target_write_data),.raddr(update_index),.q(target_head));
    physics_fft_level_ram16x6 u_display(.clk(clk),.we(display_write),
        .waddr(update_index),.data(released_level),.raddr(display_read_index),.q(display_head));
`ifdef FFT_BEHAVIORAL_RAM
    // Simulation aliases only. Synthesis sees neither a wide mux nor a
    // second read port; native-model tests observe write ports independently.
    wire [95:0] target_levels,display_levels;
    wire [5:0] target_level[0:15];
    wire [5:0] display_level[0:15];
    genvar level_index;
    generate for(level_index=0;level_index<16;level_index=level_index+1)begin: g_levels
        assign target_level[level_index]=u_targets.mem[level_index];
        assign display_level[level_index]=u_display.mem[level_index];
        assign target_levels[level_index*6+:6]=target_level[level_index];
        assign display_levels[level_index*6+:6]=display_level[level_index];
    end endgenerate
`endif
    // Payload is overwritten before use after every reset. Avoid distributing
    // async reset through FFT datapath and the display-level storage.
    always @(posedge clk)begin
        case(state)
            CAPTURE:if(sample_valid)captured_sample<=sample;
            READ_B:begin ar<=ram_read_data[31:16];ai<=ram_read_data[15:0];end
            READ_COEF:begin
                br<=ram_read_data[31:16];bi<=ram_read_data[15:0];
                wr<=coefficient_data[31:16];wi<=coefficient_data[15:0];
            end
            MUL_II,MUL_IR:partial_product<=product[30:15];
            MUL_RI:tr<=$signed({partial_product[15],partial_product})-$signed({product[30],product[30:15]});
            COMPLEX:ti<=$signed({partial_product[15],partial_product})+$signed({product[30],product[30:15]});
        endcase
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=CAPTURE;capture_index<=0;half_size<=1;base_index<=0;
            butterfly_index<=0;twiddle_step<=256;twiddle_phase<=0;magnitude_index<=1;
            band_peak<=0;band_index<=0;display_valid<=0;update_index<=0;blank_at_frame<=0;
        end else if(source_change)begin
            // The accompanying boundary sample remains on HDMI. Analysis
            // restarts with the following sample, independent of old FSM state.
            state<=CAPTURE;capture_index<=0;
            blank_at_frame<=!frame_start && state!=DISPLAY_UPDATE;
            if(frame_start || state==DISPLAY_UPDATE)display_valid<=0;
        end else begin
            if(frame_start && blank_at_frame)begin
                display_valid<=0;blank_at_frame<=0;
            end
            case(state)
                CAPTURE:if(sample_valid)state<=CAP_WAIT;
                CAP_WAIT:state<=CAP_MUL;
                CAP_MUL:state<=CAP_SAVE;
                CAP_SAVE:begin
                    if(capture_index==511)state<=FFT_INIT;
                    else begin capture_index<=capture_index+1'b1;state<=CAPTURE;end
                end
                FFT_INIT:begin
                    half_size<=1;twiddle_step<=256;base_index<=0;butterfly_index<=0;
                    twiddle_phase<=0;state<=READ_A;
                end
                READ_A:state<=READ_B;
                READ_B:state<=READ_COEF;
                READ_COEF:state<=MUL_RR;
                MUL_RR:state<=MUL_II;
                MUL_II:state<=MUL_RI;
                MUL_RI:state<=MUL_IR;
                MUL_IR:state<=COMPLEX;
                COMPLEX:state<=WRITE_A;
                WRITE_A:state<=WRITE_B;
                WRITE_B:state<=NEXT_BFLY;
                NEXT_BFLY:begin
                    if(butterfly_index==half_size-1'b1)begin
                        butterfly_index<=0;twiddle_phase<=0;
                        if(next_base[9])begin
                            base_index<=0;
                            if(half_size==256)begin
                                magnitude_index<=1;band_index<=0;band_peak<=0;state<=MAG_READ;
                            end else begin half_size<=half_size<<1;twiddle_step<=twiddle_step>>1;state<=READ_A;end
                        end else begin base_index<=next_base[8:0];state<=READ_A;end
                    end else begin
                        butterfly_index<=butterfly_index+1'b1;twiddle_phase<=twiddle_phase+twiddle_step;state<=READ_A;
                    end
                end
                MAG_READ:state<=MAG_WAIT;
                MAG_WAIT:state<=MAG_SAVE;
                MAG_SAVE:begin
                    if(magnitude_index[7:0]==band_end)begin
                        band_index<=band_index+1'b1;band_peak<=0;
                    end else band_peak<=next_peak;
                    if(magnitude_index==255)state<=WAIT_FRAME;
                    else begin magnitude_index<=magnitude_index+1'b1;state<=MAG_READ;end
                end
                WAIT_FRAME:if(frame_start)begin update_index<=0;state<=DISPLAY_UPDATE;end
                DISPLAY_UPDATE:begin
                    update_index<=update_index+1'b1;
                    if(update_index==15)begin display_valid<=1;capture_index<=0;state<=CAPTURE;end
                end
                default:state<=CAPTURE;
            endcase
        end
    end
    wire in_region=region_enable && !local_x[10] && !local_y[10] &&
        local_x>=11'sd6 && local_x<11'sd134 && local_x<region_width &&
        local_y>=11'sd3 && local_y<11'sd35 && local_y<region_height;
    reg region_q,display_valid_q,column_on_q;
    reg [5:0] row_q,level_q;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin region_q<=0;display_valid_q<=0;column_on_q<=0;row_q<=0;level_q<=0;end
        else begin
            region_q<=in_region;display_valid_q<=display_valid;column_on_q<=plot_x[2:0]<6;
            row_q<=local_y[5:0]-6'd3;level_q<=display_head;
        end
    end
    assign pixel_on=region_q && display_valid_q && column_on_q && level_q!=0 && row_q>=6'd32-level_q;
endmodule

module physics_fft_work_ram512(input wire clk,we,input wire [8:0] address,
    input wire [31:0] data,output wire [31:0] q);
`ifdef FFT_BEHAVIORAL_RAM
    reg [31:0] mem[0:511];reg [31:0] read_q;
    assign q=read_q;
    always @(posedge clk)begin if(we)mem[address]<=data;read_q<=mem[address];end
`else
    EG_LOGIC_BRAM #(.DATA_WIDTH_A(32),.DATA_WIDTH_B(32),.ADDR_WIDTH_A(9),.ADDR_WIDTH_B(9),
        .DATA_DEPTH_A(512),.DATA_DEPTH_B(512),.BYTE_ENABLE(0),.BYTE_A(1),.BYTE_B(1),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),.WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),
        .RESETMODE("SYNC"),.DEBUGGABLE("NO"),.PACKABLE("NO"),.FORCE_KEEP("OFF"),
        .INIT_FILE("NONE"),.FILL_ALL("NONE"),.IMPLEMENT("9K")) u_ram(
        .doa(),.dob(q),.dia(data),.dib(32'd0),.cea(we),.ocea(1'b1),.clka(clk),.wea(we),.rsta(1'b0),
        .ceb(1'b1),.oceb(1'b1),.clkb(clk),.web(1'b0),.rstb(1'b0),.bea(1'b1),.beb(1'b1),
        .addra(address),.addrb(address));
`endif
endmodule

module physics_fft_level_ram16x6(input wire clk,we,input wire [3:0] waddr,raddr,
    input wire [5:0] data,output wire [5:0] q);
`ifdef FFT_BEHAVIORAL_RAM
    reg [5:0] mem[0:15];
    assign q=mem[raddr];
    always @(posedge clk)if(we)mem[waddr]<=data;
`else
    EG_LOGIC_DRAM #(.DATA_WIDTH_W(6),.DATA_WIDTH_R(6),
        .ADDR_WIDTH_W(4),.ADDR_WIDTH_R(4),.DATA_DEPTH_W(16),.DATA_DEPTH_R(16),
        .INIT_FILE("NONE"),.FILL_ALL("NONE")) u_ram(
        .di(data),.we(we),.wclk(clk),.waddr(waddr),.raddr(raddr),.do(q));
`endif
endmodule
