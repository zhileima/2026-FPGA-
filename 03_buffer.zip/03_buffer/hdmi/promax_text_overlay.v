`timescale 1ns/1ps
// Exact four-image subtitles. All inputs are in the pixel clock domain.
// active_index is the reader's committed bank, held throughout active video.
// The synchronous glyph ROM and output stage delay *all* video signals by
// exactly two pixel clocks. Every non-glyph RGB888 pixel is bit-exact.
// Subtitles enter from the right, scroll left, then repeat after leaving fully.
module promax_text_overlay #(
    parameter integer H_ACTIVE = 640,
    parameter integer SUBTITLE_Y = 440,
    parameter integer SCROLL_CYCLE_FRAMES = 297,
    parameter [23:0] TEXT_COLOR = 24'hffffff
)(
    input wire clk,
    input wire rst_n,
    input wire frame_start,
    input wire [1:0] active_index,
    input wire enable,
    input wire hs_in,
    input wire vs_in,
    input wire de_in,
    input wire [11:0] pixel_x,
    input wire [11:0] pixel_y,
    input wire [23:0] rgb_in,
    output reg hs_out,
    output reg vs_out,
    output reg de_out,
    output reg [11:0] pixel_x_out,
    output reg [11:0] pixel_y_out,
    output reg [23:0] rgb_out,
    output reg overlay_active
);
    // A 297-step traverse plus one completely off-screen frame is 5.0064 s
    // at the existing 25 MHz / (800 * 525) video rate. Constant quotient and
    // remainder values distribute motion evenly for every sentence length.
    localparam integer STEPS = SCROLL_CYCLE_FRAMES < 1 ? 1 : SCROLL_CYCLE_FRAMES;
    localparam integer PHASE_WIDTH = STEPS < 2 ? 1 : $clog2(STEPS+1);
    localparam signed [12:0] SCREEN_RIGHT = H_ACTIVE;
    reg [1:0] index_seen;
    reg signed [12:0] scroll_x;
    reg [PHASE_WIDTH-1:0] cycle_count;
    reg [PHASE_WIDTH-1:0] fraction;
    reg frame_blank;
    reg [95:0] message_codes;
    reg [3:0] message_length;
    reg [11:0] text_width;
    reg [12:0] step_base;
    reg [PHASE_WIDTH-1:0] step_remainder;
    wire [PHASE_WIDTH:0] fraction_sum = {1'b0,fraction} + {1'b0,step_remainder};

    always @* begin
        case (index_seen)
            2'd0: begin step_base=(H_ACTIVE+192)/STEPS; step_remainder=(H_ACTIVE+192)%STEPS; end
            2'd1: begin step_base=(H_ACTIVE+288)/STEPS; step_remainder=(H_ACTIVE+288)%STEPS; end
            2'd2: begin step_base=(H_ACTIVE+352)/STEPS; step_remainder=(H_ACTIVE+352)%STEPS; end
            default: begin step_base=(H_ACTIVE+480)/STEPS; step_remainder=(H_ACTIVE+480)%STEPS; end
        endcase
    end

    // Accept a committed reader bank anywhere in the initial vertical blank.
    // Once the first active pixel starts, even horizontal blank cannot commit
    // a different sentence. A bank restart takes priority over a frame step.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            index_seen <= 2'd0;
            scroll_x <= SCREEN_RIGHT;
            cycle_count <= 0;
            fraction <= 0;
            frame_blank <= 1'b1;
        end else begin
            if (frame_start) frame_blank <= 1'b1;
            else if (de_in) frame_blank <= 1'b0;
            if (!enable) begin
                index_seen <= active_index;
                scroll_x <= SCREEN_RIGHT;
                cycle_count <= 0;
                fraction <= 0;
            end else if ((frame_blank || frame_start) && !de_in &&
                         active_index != index_seen) begin
                index_seen <= active_index;
                scroll_x <= SCREEN_RIGHT;
                cycle_count <= 0;
                fraction <= 0;
            end else if (frame_start) begin
                if (cycle_count == STEPS) begin
                    // Keep one full completely exited frame before re-entry.
                    scroll_x <= SCREEN_RIGHT;
                    cycle_count <= 0;
                    fraction <= 0;
                end else begin
                    cycle_count <= cycle_count + 1'b1;
                    if (fraction_sum >= STEPS) begin
                        fraction <= fraction_sum - STEPS;
                        scroll_x <= scroll_x - $signed(step_base) - 13'sd1;
                    end else begin
                        fraction <= fraction_sum;
                        scroll_x <= scroll_x - $signed(step_base);
                    end
                end
            end
        end
    end

    reg signed [12:0] local_x;
    reg [3:0] char_index;
    reg [5:0] glyph_code;
    reg [4:0] glyph_row;
    reg [4:0] glyph_column;
    reg glyph_valid;
    // Six-bit glyph IDs, first displayed character at bits 5:0.
    // Unicode strings and the reproducible font subset are in glyphs.json.
    always @* begin
        case (index_seen)
            2'd0: begin
                // PIC1: 雷姆yyds
                message_codes = 96'h0000000000000001440c3081;
                message_length = 4'd6;
            end
            2'd1: begin
                // PIC2: 一人之下，万人之上
                message_codes = 96'h00000000000c2072ca2481c6;
                message_length = 4'd9;
            end
            2'd2: begin
                // PIC3: 紫电青霜，王将军之武库
                message_codes = 96'h0000000155084d244a40f38d;
                message_length = 4'd11;
            end
            default: begin
                // PIC4: 落霞与孤鹜齐飞，秋水共长天一色
                message_codes = 96'h0221a181f79d29c6da6585d6;
                message_length = 4'd15;
            end
        endcase
        text_width = {3'd0,message_length,5'd0};
        local_x = $signed({1'b0,pixel_x}) - scroll_x;
        char_index = local_x[8:5];
        glyph_code = 6'd0;
        glyph_row = pixel_y-SUBTITLE_Y;
        glyph_column = local_x[4:0]-5'd4;
        glyph_valid = 1'b0;
        if (enable && de_in && local_x >= 0 &&
            local_x < $signed({1'b0,text_width}) &&
            pixel_y >= SUBTITLE_Y && pixel_y < SUBTITLE_Y+24) begin
            glyph_code = message_codes[char_index*6 +: 6];
            glyph_valid = local_x[4:0] >= 4 && local_x[4:0] < 28;
        end
    end

    wire [23:0] font_row_bits;
    subtitle_font_rom u_subtitle_font(
        .clk(clk), .address({glyph_code,glyph_row}),
        .row_bits(font_row_bits)
    );

    reg hs_q,vs_q,de_q;
    reg [11:0] x_q,y_q;
    reg [23:0] rgb_q;
    reg glyph_valid_q;
    reg [4:0] column_q;
    wire glyph_hit = glyph_valid_q && font_row_bits[23-column_q];
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hs_q<=1'b1; vs_q<=1'b1; de_q<=1'b0;
            x_q<=12'd0; y_q<=12'd0; rgb_q<=24'd0;
            glyph_valid_q<=1'b0; column_q<=5'd0;
            hs_out<=1'b1; vs_out<=1'b1; de_out<=1'b0;
            pixel_x_out<=12'd0; pixel_y_out<=12'd0; rgb_out<=24'd0;
            overlay_active<=1'b0;
        end else begin
            hs_q<=hs_in; vs_q<=vs_in; de_q<=de_in;
            x_q<=pixel_x; y_q<=pixel_y; rgb_q<=rgb_in;
            glyph_valid_q<=glyph_valid;
            column_q<=glyph_column;
            hs_out<=hs_q; vs_out<=vs_q; de_out<=de_q;
            pixel_x_out<=x_q; pixel_y_out<=y_q;
            rgb_out<=glyph_hit ? TEXT_COLOR : rgb_q;
            overlay_active<=glyph_hit;
        end
    end
endmodule
