`timescale 1ns/1ps
// MUSIC-ENVELOPE ANIMATION, NOT A MEASURED TIME-DOMAIN OSCILLOSCOPE.
// A smooth fitted sine is scaled by actual post-volume, HDMI-accepted PCM
// peak envelope. The wide orange rectangle represents the user gain setting;
// a separate narrow rectangle retains the linear measured PCM amplitude.
// The left FFT remains the frequency measurement. This visualizer never
// changes/backpressures audio. One pixel-clock output latency, no new CDC.
module physics_pcm_scope256(
 input wire clk,rst_n,frame_start,
 input wire sample_valid,input wire signed[15:0] sample,
 // Existing video-domain gain setting, not a new clock-domain crossing.
 input wire[7:0] volume_level,
 input wire region_enable,input wire signed[10:0] local_x,local_y,
 input wire[9:0] region_width,region_height,
 output wire pixel_on,output wire wave_on,output wire level_on,
 output wire volume_on,
 input wire source_change
);
 // floor(abs(PCM)/256), including -32768 and negative values near zero.
 // The carry from low eight bits is needed only when they are all zero.
 wire[7:0] sample_peak=sample[15]?
     (~sample[15:8]+{7'd0,(sample[7:0]==0)}):sample[15:8];
 // Seed the next interval with the released previous envelope. The same
 // sample maximum then implements max(actual_peak, previous_envelope-2),
 // eliminating two redundant comparators/muxes without changing any frame.
 reg[7:0] interval_peak,envelope;
 wire[7:0] frame_peak=sample_valid && sample_peak>interval_peak?sample_peak:interval_peak;
 wire[7:0] release_peak=frame_peak>2?frame_peak-8'd2:8'd0;
 reg[6:0] phase;
 // Rounded gain/8 gives 0..32 display pixels with exact mute/full-scale
 // endpoints. These pixels represent gain, not measured sample amplitude.
 wire[5:0] setting_height={1'b0,volume_level[7:3]}+{5'd0,volume_level[2]};
 reg[5:0] volume_height;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin interval_peak<=0;envelope<=0;phase<=0;volume_height<=0;end
  else begin
   if(sample_valid && sample_peak>interval_peak)interval_peak<=sample_peak;
   if(frame_start)begin
    interval_peak<=release_peak;
    envelope<=frame_peak;
    phase<=phase+1'b1;
    volume_height<=setting_height;
   end
   // Envelope and gain remain frame-aligned. Start the new source's
   // measurement with its first accepted sample, discarding old release.
   if(source_change)begin
    interval_peak<=sample_valid ? sample_peak : 8'd0;
    if(frame_start)envelope<=sample_valid ? sample_peak : 8'd0;
   end
  end
 end
 // Monotonic display compression: quiet music remains visible, loud music
 // changes height without clipping/flattening the fitted sine crests.
 // The adjacent meter does NOT use this nonlinear display mapping.
 function[3:0] visual_amplitude;
  input[7:0] value;
  begin
   if(value>=64)visual_amplitude=14;
   else if(value>=32)visual_amplitude=13;
   else if(value>=16)visual_amplitude=11+value[3];
   else if(value>=8)visual_amplitude=7+value[2:1];
   else if(value>=4)visual_amplitude=5+value[1];
   else if(value!=0)visual_amplitude=value[1:0]+1'b1;
   else visual_amplitude=0;
  end
 endfunction
 wire[3:0] amplitude=visual_amplitude(envelope);
 wire[5:0] meter_height={1'b0,envelope[7:2]}+{5'd0,(|envelope[1:0])};
 wire[10:0] plot_x=local_x-11'sd4;
 wire[6:0] sine_address=plot_x[6:0]+phase;
 reg signed[6:0] sine_q;
 (* ram_style="block" *) reg signed[6:0] sine_rom[0:127];
 initial begin
  sine_rom[0]=7'sd0;
  sine_rom[1]=7'sd3;
  sine_rom[2]=7'sd6;
  sine_rom[3]=7'sd9;
  sine_rom[4]=7'sd12;
  sine_rom[5]=7'sd15;
  sine_rom[6]=7'sd18;
  sine_rom[7]=7'sd21;
  sine_rom[8]=7'sd24;
  sine_rom[9]=7'sd27;
  sine_rom[10]=7'sd30;
  sine_rom[11]=7'sd32;
  sine_rom[12]=7'sd35;
  sine_rom[13]=7'sd38;
  sine_rom[14]=7'sd40;
  sine_rom[15]=7'sd42;
  sine_rom[16]=7'sd45;
  sine_rom[17]=7'sd47;
  sine_rom[18]=7'sd49;
  sine_rom[19]=7'sd51;
  sine_rom[20]=7'sd52;
  sine_rom[21]=7'sd54;
  sine_rom[22]=7'sd56;
  sine_rom[23]=7'sd57;
  sine_rom[24]=7'sd58;
  sine_rom[25]=7'sd59;
  sine_rom[26]=7'sd60;
  sine_rom[27]=7'sd61;
  sine_rom[28]=7'sd62;
  sine_rom[29]=7'sd62;
  sine_rom[30]=7'sd63;
  sine_rom[31]=7'sd63;
  sine_rom[32]=7'sd63;
  sine_rom[33]=7'sd63;
  sine_rom[34]=7'sd63;
  sine_rom[35]=7'sd62;
  sine_rom[36]=7'sd62;
  sine_rom[37]=7'sd61;
  sine_rom[38]=7'sd60;
  sine_rom[39]=7'sd59;
  sine_rom[40]=7'sd58;
  sine_rom[41]=7'sd57;
  sine_rom[42]=7'sd56;
  sine_rom[43]=7'sd54;
  sine_rom[44]=7'sd52;
  sine_rom[45]=7'sd51;
  sine_rom[46]=7'sd49;
  sine_rom[47]=7'sd47;
  sine_rom[48]=7'sd45;
  sine_rom[49]=7'sd42;
  sine_rom[50]=7'sd40;
  sine_rom[51]=7'sd38;
  sine_rom[52]=7'sd35;
  sine_rom[53]=7'sd32;
  sine_rom[54]=7'sd30;
  sine_rom[55]=7'sd27;
  sine_rom[56]=7'sd24;
  sine_rom[57]=7'sd21;
  sine_rom[58]=7'sd18;
  sine_rom[59]=7'sd15;
  sine_rom[60]=7'sd12;
  sine_rom[61]=7'sd9;
  sine_rom[62]=7'sd6;
  sine_rom[63]=7'sd3;
  sine_rom[64]=7'sd0;
  sine_rom[65]=-7'sd3;
  sine_rom[66]=-7'sd6;
  sine_rom[67]=-7'sd9;
  sine_rom[68]=-7'sd12;
  sine_rom[69]=-7'sd15;
  sine_rom[70]=-7'sd18;
  sine_rom[71]=-7'sd21;
  sine_rom[72]=-7'sd24;
  sine_rom[73]=-7'sd27;
  sine_rom[74]=-7'sd30;
  sine_rom[75]=-7'sd32;
  sine_rom[76]=-7'sd35;
  sine_rom[77]=-7'sd38;
  sine_rom[78]=-7'sd40;
  sine_rom[79]=-7'sd42;
  sine_rom[80]=-7'sd45;
  sine_rom[81]=-7'sd47;
  sine_rom[82]=-7'sd49;
  sine_rom[83]=-7'sd51;
  sine_rom[84]=-7'sd52;
  sine_rom[85]=-7'sd54;
  sine_rom[86]=-7'sd56;
  sine_rom[87]=-7'sd57;
  sine_rom[88]=-7'sd58;
  sine_rom[89]=-7'sd59;
  sine_rom[90]=-7'sd60;
  sine_rom[91]=-7'sd61;
  sine_rom[92]=-7'sd62;
  sine_rom[93]=-7'sd62;
  sine_rom[94]=-7'sd63;
  sine_rom[95]=-7'sd63;
  sine_rom[96]=-7'sd63;
  sine_rom[97]=-7'sd63;
  sine_rom[98]=-7'sd63;
  sine_rom[99]=-7'sd62;
  sine_rom[100]=-7'sd62;
  sine_rom[101]=-7'sd61;
  sine_rom[102]=-7'sd60;
  sine_rom[103]=-7'sd59;
  sine_rom[104]=-7'sd58;
  sine_rom[105]=-7'sd57;
  sine_rom[106]=-7'sd56;
  sine_rom[107]=-7'sd54;
  sine_rom[108]=-7'sd52;
  sine_rom[109]=-7'sd51;
  sine_rom[110]=-7'sd49;
  sine_rom[111]=-7'sd47;
  sine_rom[112]=-7'sd45;
  sine_rom[113]=-7'sd42;
  sine_rom[114]=-7'sd40;
  sine_rom[115]=-7'sd38;
  sine_rom[116]=-7'sd35;
  sine_rom[117]=-7'sd32;
  sine_rom[118]=-7'sd30;
  sine_rom[119]=-7'sd27;
  sine_rom[120]=-7'sd24;
  sine_rom[121]=-7'sd21;
  sine_rom[122]=-7'sd18;
  sine_rom[123]=-7'sd15;
  sine_rom[124]=-7'sd12;
  sine_rom[125]=-7'sd9;
  sine_rom[126]=-7'sd6;
  sine_rom[127]=-7'sd3;
 end
 always @(posedge clk)sine_q<=sine_rom[sine_address];
 reg[3:0] amplitude_q;
 wire signed[35:0] product;
`ifdef SCOPE_BEHAVIORAL_DSP
 assign product=$signed(sine_q)*$signed({1'b0,amplitude_q});
`else
 // Explicit native multiplier: use spare DSP, not a LUT multiplier fabric.
 EG_LOGIC_MULT #(.INPUT_WIDTH_A(18),.INPUT_WIDTH_B(18),.OUTPUT_WIDTH(36),
  .INPUTFORMAT("SIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
  .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC"))u_scale(
  .p(product),.a({{11{sine_q[6]}},sine_q}),.b({14'd0,amplitude_q}),
  .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
  .rstan(rst_n),.rstbn(rst_n),.rstpdn(rst_n));
`endif
 wire in_region=region_enable && !local_x[10] && !local_y[10] &&
   local_x<region_width && local_y<region_height && local_y>=4 && local_y<36;
 reg wave_region_q,meter_region_q,volume_region_q;
 reg[5:0] y_q,meter_q,volume_q;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin wave_region_q<=0;meter_region_q<=0;volume_region_q<=0;
    y_q<=0;meter_q<=0;volume_q<=0;amplitude_q<=0;end
  else begin
   wave_region_q<=in_region && local_x>=4 && local_x<260;
   // Eight-pixel gain bar and two-pixel measured-amplitude bar.
   // Neither overlaps the unchanged x=4..259 fitted-wave area.
   volume_region_q<=in_region && local_x>=266 && local_x<274;
   meter_region_q<=in_region && local_x>=276 && local_x<278;
   y_q<=local_y[5:0];meter_q<=meter_height;volume_q<=volume_height;amplitude_q<=amplitude;
  end
 end
 // Two-pixel trace: y+round(product/64) must be20or21. Discarding
 // bit0 of this single sum replaces two ycomparators and a second adder.
 wire[6:0] wave_sum={1'b0,y_q}+$signed({product[11],product[11:6]})+product[5];
 assign wave_on=wave_region_q && wave_sum[6:1]==6'd10;
 wire[6:0] meter_sum={1'b0,y_q}+{1'b0,meter_q};
 assign level_on=meter_region_q && meter_q!=0 && meter_sum>=7'd36;
 wire[6:0] volume_sum={1'b0,y_q}+{1'b0,volume_q};
 assign volume_on=volume_region_q && volume_q!=0 && volume_sum>=7'd36;
 assign pixel_on=wave_on || level_on || volume_on;
endmodule
