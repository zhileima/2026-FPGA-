`timescale 1ns/1ps
// Raw signed 16-bit little-endian, 48 kHz mono PCM sector streamer.
// The SD response is speculative until done/error/512 ordered bytes agree.
// One staging sector is copied into the asynchronous FIFO only after that
// check. FIFO pointers have an extra wrap bit and are Gray registered in
// their OWN clock domain. No binary pointer or state bus crosses clocks.
module wav_stream_player #(
    parameter integer ADDR_WIDTH = 12,
    parameter integer LBA_BITS = 32,
    parameter integer PREFILL_SAMPLES = 1024,
    parameter integer LOOP_ENABLE = 1,
    parameter integer SD_TIMEOUT_CYCLES = 100000000
) (
    input wire wr_clk, input wire wr_rst_n,
    input wire play_enable,
    input wire [31:0] start_lba, input wire [31:0] total_sectors,
    output wire sd_req, output wire [31:0] sd_lba,
    input wire sd_ready,
    input wire sd_valid, output wire sd_byte_ready, input wire [7:0] sd_byte,
    input wire [8:0] sd_byte_index,
    input wire sd_done, input wire [7:0] sd_error,
    input wire rd_clk, input wire rd_rst_n,
    output reg signed [15:0] sample_out,
    output reg sample_valid, input wire sample_ready,
    output wire stream_active, output reg stream_end,
    output wire buffer_low, output wire [ADDR_WIDTH:0] buffer_level,
    output reg [31:0] sample_counter,
    output reg [15:0] underflow_count,
    output wire [31:0] current_lba,
    output wire [31:0] sectors_read,
    output reg [31:0] loop_count,
    output reg [7:0] error_flags, output reg [7:0] last_sd_error,
    output wire player_idle, output wire prefill_ready, output wire stream_session
);
    localparam integer DEPTH = 1 << ADDR_WIDTH;
    localparam integer PTR_WIDTH = ADDR_WIDTH + 1;
    localparam integer TIMER_WIDTH = SD_TIMEOUT_CYCLES < 2 ? 1 : $clog2(SD_TIMEOUT_CYCLES);
    localparam [3:0] W_IDLE=0, W_ARM=1, W_SPACE=2, W_READ=3,
        W_COPY=4, W_FINISHED=5, W_STOP=6, W_CHECK=7;
    reg [3:0] wstate;
    reg [15:0] audio_ram [0:DEPTH-1];
    reg [15:0] sector_ram [0:255];
    reg [PTR_WIDTH-1:0] wr_ptr, wr_gray, rd_ptr, rd_gray;
    // FIFO storage is released on actual PCM acceptance, not prefetch.
    // This keeps RAM + RAM-output + PCM-output occupancy <= DEPTH.
    reg [PTR_WIDTH-1:0] rd_commit_ptr;
    (* async_reg = "true" *) reg [PTR_WIDTH-1:0] rd_gray_meta, rd_gray_sync;
    (* async_reg = "true" *) reg [PTR_WIDTH-1:0] wr_gray_meta, wr_gray_sync;
    reg run_req, finished;
    (* async_reg = "true" *) reg run_meta, run_sync;
    (* async_reg = "true" *) reg finished_meta, finished_sync;
    reg rd_armed;
    (* async_reg = "true" *) reg rd_armed_meta, rd_armed_sync;
    reg [LBA_BITS-1:0] saved_start_lba, saved_total_sectors;
    reg [LBA_BITS-1:0] current_lba_i, sectors_read_i;
    wire [LBA_BITS-1:0] sectors_next = sectors_read_i + 1'b1;
    assign current_lba = {{(32-LBA_BITS){1'b0}},current_lba_i};
    assign sectors_read = {{(32-LBA_BITS){1'b0}},sectors_read_i};
    reg [9:0] received_bytes;
    reg [7:0] low_byte;
    reg sector_bad;
    reg [8:0] copy_issued;
    reg [15:0] sector_q;
    reg copy_valid;
    reg [TIMER_WIDTH-1:0] timer;
    reg transaction_active;
    assign player_idle=wstate==W_IDLE && !rd_armed_sync && !transaction_active;
    function [PTR_WIDTH-1:0] ungray;
        input [PTR_WIDTH-1:0] value;
        integer j;
        begin
            ungray[PTR_WIDTH-1] = value[PTR_WIDTH-1];
            for (j=PTR_WIDTH-2; j>=0; j=j-1)
                ungray[j] = ungray[j+1] ^ value[j];
        end
    endfunction
    // Register the local Gray decode to keep FIFO capacity/request logic
    // out of the synchronizer fanout path. Delayed retirement is conservative.
    reg [PTR_WIDTH-1:0] rd_ptr_wr;
    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) rd_ptr_wr<=0;
        else if (!run_req) rd_ptr_wr<=0;
        else rd_ptr_wr<=ungray(rd_gray_sync);
    end
    wire [PTR_WIDTH-1:0] wr_ptr_rd = ungray(wr_gray_sync);
    wire [PTR_WIDTH-1:0] used_wr = wr_ptr - rd_ptr_wr;
    // Write-domain, current-run qualification. Stop clears run_req and the
    // pointers before the caller may select another chapter. Reuse the actual
    // committed FIFO occupancy; no new sample counter or CDC path is added.
    assign prefill_ready=run_req && (used_wr>=PREFILL_SAMPLES ||
        (finished && used_wr!=0));
    wire [PTR_WIDTH-1:0] used_rd = wr_ptr_rd - rd_ptr;
    wire [32:0] last_lba = {1'b0,start_lba} + {1'b0,total_sectors} - 33'd1;
    wire extent_valid = start_lba != 0 && total_sectors != 0 && !last_lba[32] &&
        (LBA_BITS==32 || (last_lba < (33'd1 << LBA_BITS) &&
          {1'b0,total_sectors} < (33'd1 << LBA_BITS)));
    // Only the registered capacity decision reaches the SD request/arbiter.
    // W_CHECK follows ARM and the LAST copy write. That mandatory bubble
    // includes wr_ptr's final +1 before computing the next sector reserve.
    // In SPACE wr_ptr stays fixed and delayed retirement only frees space.
    reg reserve_sector;
    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) reserve_sector <= 0;
        else if (wstate == W_CHECK || wstate == W_SPACE)
            reserve_sector <= used_wr <= DEPTH - 256;
        else reserve_sector <= 0;
    end
    assign sd_req = wstate == W_SPACE && reserve_sector && play_enable;
    assign sd_lba = current_lba;
    assign sd_byte_ready = (wstate == W_READ && play_enable) ||
        (transaction_active && (wstate == W_STOP || wstate == W_FINISHED));
    wire byte_fire = sd_valid && sd_byte_ready;

    // Staging RAM synchronous read and FIFO RAM synchronous write. A sector
    // reserves 256 FIFO slots before requesting any bytes, so this copy
    // cannot overtake the synchronized consumer pointer.
    always @(posedge wr_clk) begin
        if (wstate == W_READ && byte_fire && !sector_bad &&
            received_bytes < 512 && sd_byte_index == received_bytes[8:0] &&
            sd_byte_index[0])
            sector_ram[sd_byte_index[8:1]] <= {sd_byte,low_byte};
        if (wstate == W_COPY && copy_issued < 256)
            sector_q <= sector_ram[copy_issued[7:0]];
        if (wstate == W_COPY && copy_valid)
            audio_ram[wr_ptr[ADDR_WIDTH-1:0]] <= sector_q;
    end

    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) begin
            rd_gray_meta <= 0; rd_gray_sync <= 0;
            rd_armed_meta <= 0; rd_armed_sync <= 0;
        end else begin
            rd_gray_meta <= rd_gray; rd_gray_sync <= rd_gray_meta;
            rd_armed_meta <= rd_armed; rd_armed_sync <= rd_armed_meta;
        end
    end
    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) begin
            wstate<=W_IDLE; wr_ptr<=0; wr_gray<=0; run_req<=0; finished<=0;
            saved_start_lba<=0; saved_total_sectors<=0;
            current_lba_i<=0; sectors_read_i<=0; loop_count<=0;
            received_bytes<=0; low_byte<=0; sector_bad<=0;
            copy_issued<=0; copy_valid<=0; timer<=0;
            error_flags<=0; last_sd_error<=0; transaction_active<=0;
        end else begin
            if (sd_done) transaction_active <= 0;
            if (!play_enable && wstate != W_IDLE && wstate != W_STOP) begin
                run_req<=0; finished<=0; copy_valid<=0; timer<=0;
                wstate<=W_STOP;
            end else case (wstate)
                W_IDLE: begin
                    wr_ptr<=0; wr_gray<=0; run_req<=0; finished<=0;
                    copy_valid<=0; transaction_active<=0;
                    if (play_enable && !rd_armed_sync) begin
                        saved_start_lba<=start_lba;
                        saved_total_sectors<=total_sectors;
                        current_lba_i<=start_lba; sectors_read_i<=0; loop_count<=0;
                        error_flags<=0; last_sd_error<=0;
                        run_req<=1;
                        if (extent_valid) wstate<=W_ARM;
                        else begin error_flags[0]<=1; finished<=1; wstate<=W_FINISHED; end
                    end
                end
                W_ARM: if (rd_armed_sync) wstate<=W_CHECK;
                W_CHECK: wstate<=W_SPACE;
                W_SPACE: if (sd_req && sd_ready) begin
                    received_bytes<=0; sector_bad<=0; low_byte<=0;
                    timer<=0; transaction_active<=1; wstate<=W_READ;
                end
                W_READ: begin
                    if (timer != SD_TIMEOUT_CYCLES-1) timer <= timer+1'b1;
                    if (byte_fire) begin
                        if (received_bytes >= 512 || sd_byte_index != received_bytes[8:0])
                            sector_bad<=1;
                        else begin
                            if (!sd_byte_index[0]) low_byte<=sd_byte;
                            received_bytes<=received_bytes+1'b1;
                        end
                    end
                    if (sd_done) begin
                        // done may share the final byte cycle.
                        if (sd_error != 0 || sector_bad ||
                            (byte_fire ? (received_bytes != 511 || sd_byte_index != 511) :
                                        (received_bytes != 512))) begin
                            if (sd_error != 0) begin error_flags[1]<=1; last_sd_error<=sd_error; end
                            if (sector_bad || (byte_fire ? (received_bytes != 511 || sd_byte_index != 511) :
                                                          (received_bytes != 512))) error_flags[2]<=1;
                            finished<=1; wstate<=W_FINISHED;
                        end else begin
                            copy_issued<=0; copy_valid<=0; wstate<=W_COPY;
                        end
                    end else if (timer == SD_TIMEOUT_CYCLES-1) begin
                        error_flags[3]<=1; finished<=1; wstate<=W_FINISHED;
                    end
                end
                W_COPY: begin
                    copy_valid <= copy_issued < 256;
                    if (copy_issued < 256) copy_issued <= copy_issued+1'b1;
                    if (copy_valid) begin
                        wr_ptr <= wr_ptr+1'b1;
                        wr_gray <= ((wr_ptr+1'b1) >> 1) ^ (wr_ptr+1'b1);
                        if (copy_issued == 256) begin
                            copy_valid<=0;
                            if (sectors_next == saved_total_sectors) begin
                                if (LOOP_ENABLE != 0) begin
                                    sectors_read_i<=0; current_lba_i<=saved_start_lba;
                                    loop_count<=loop_count+1'b1; wstate<=W_CHECK;
                                end else begin
                                    sectors_read_i<=sectors_next;
                                    finished<=1; wstate<=W_FINISHED;
                                end
                            end else begin
                                sectors_read_i<=sectors_next;
                                current_lba_i<=current_lba_i+1'b1; wstate<=W_CHECK;
                            end
                        end
                    end
                end
                W_FINISHED: begin end
                W_STOP: begin
                    wr_ptr<=0; wr_gray<=0; copy_valid<=0;
                    // A stopped transaction must finish before another one
                    // is started. A timeout is sticky and requires reset;
                    // never relabel a late old response as a new sector.
                    if (!transaction_active && !rd_armed_sync) wstate<=W_IDLE;
                end
                default: begin error_flags[4]<=1; finished<=1; wstate<=W_FINISHED; end
            endcase
        end
    end

    // RAM read is registered. q_valid and the separate PCM output register
    // preserve every sample under ready backpressure, including wraparound.
    reg [15:0] audio_q;
    reg q_valid, primed, active_reg, sample_is_real;
    reg [2:0] eof_empty_cycles;
    wire output_slot = !sample_valid || sample_ready;
    wire take_q = q_valid && output_slot;
    wire fetch = run_sync && primed && (!q_valid || take_q) && used_rd != 0;
    always @(posedge rd_clk) begin
        if (fetch) audio_q <= audio_ram[rd_ptr[ADDR_WIDTH-1:0]];
    end
    always @(posedge rd_clk or negedge rd_rst_n) begin
        if (!rd_rst_n) begin
            wr_gray_meta<=0; wr_gray_sync<=0;
            run_meta<=0; run_sync<=0; finished_meta<=0; finished_sync<=0;
        end else begin
            wr_gray_meta<=wr_gray; wr_gray_sync<=wr_gray_meta;
            run_meta<=run_req; run_sync<=run_meta;
            finished_meta<=finished; finished_sync<=finished_meta;
        end
    end
    assign stream_session = run_sync && !stream_end;
    assign stream_active = active_reg && run_sync && !stream_end;
    assign buffer_level = used_rd + {{ADDR_WIDTH{1'b0}},q_valid} +
                          {{ADDR_WIDTH{1'b0}},(sample_valid && sample_is_real)};
    assign buffer_low = buffer_level < DEPTH/4;
    always @(posedge rd_clk or negedge rd_rst_n) begin
        if (!rd_rst_n) begin
            rd_ptr<=0; rd_gray<=0; rd_commit_ptr<=0; rd_armed<=0;
            q_valid<=0; primed<=0; active_reg<=0;
            sample_out<=0; sample_valid<=0; sample_is_real<=0;
            stream_end<=0; sample_counter<=0; underflow_count<=0; eof_empty_cycles<=0;
        end else if (!run_sync) begin
            rd_ptr<=0; rd_gray<=0; rd_commit_ptr<=0; rd_armed<=0;
            q_valid<=0; primed<=0; active_reg<=0;
            sample_out<=0; sample_valid<=0; sample_is_real<=0;
            stream_end<=0; sample_counter<=0; underflow_count<=0; eof_empty_cycles<=0;
        end else begin
            rd_armed<=1;
            if (!primed && (used_rd >= PREFILL_SAMPLES || (finished_sync && used_rd != 0))) primed<=1;
            if (finished_sync && used_rd == 0 && !q_valid) begin
                if (eof_empty_cycles != 7) eof_empty_cycles<=eof_empty_cycles+1'b1;
            end else eof_empty_cycles<=0;
            if (sample_valid && sample_ready) begin
                if (sample_is_real) begin
                    sample_counter<=sample_counter+1'b1;
                    rd_commit_ptr<=rd_commit_ptr+1'b1;
                    rd_gray<=((rd_commit_ptr+1'b1) >> 1) ^ (rd_commit_ptr+1'b1);
                end
                else if (underflow_count != 16'hffff) underflow_count<=underflow_count+1'b1;
            end
            if (take_q) q_valid<=0;
            if (fetch) begin
                rd_ptr<=rd_ptr+1'b1;
                q_valid<=1;
            end
            if (output_slot) begin
                if (q_valid) begin
                    sample_out<=audio_q; sample_valid<=1; sample_is_real<=1; active_reg<=1;
                end else if (eof_empty_cycles >= 3) begin
                    sample_out<=0; sample_valid<=0; sample_is_real<=0;
                    stream_end<=1; active_reg<=0;
                end else if (active_reg && !finished_sync) begin
                    sample_out<=0; sample_valid<=1; sample_is_real<=0;
                end else begin
                    sample_valid<=0; sample_is_real<=0;
                end
            end
        end
    end
    initial begin
        if (LBA_BITS < 1 || LBA_BITS > 32 || ADDR_WIDTH < 9 || ADDR_WIDTH > 16 || PREFILL_SAMPLES < 1 ||
            PREFILL_SAMPLES > DEPTH || SD_TIMEOUT_CYCLES < 2) begin
            $display("WAV_STREAM_CONFIG_ERROR invalid FIFO/prefill/timeout"); $finish;
        end
    end
endmodule





