`timescale 1ns/1ps
// Five card-resident PCM effects, loaded once before music owns the raw port.
// Decimate 48 kHz signed 16-bit PCM to an 8 kHz signed 8-bit cache. Playback
// repeats each cached sample six times on the downstream 48 kHz demand tick.
// Metadata and RAM become immutable before load_done crosses to pixel_clk.
module dental_sfx_cache #(
    parameter integer CACHE_BYTES=36864,
    parameter integer TIMEOUT_CYCLES=50000000
)(
    input wire clk, input wire rst, input wire load_start,
    output wire load_busy, output reg load_done,
    output wire [4:0] selected_index,
    input wire file_present, input wire [31:0] file_sectors,
    output reg raw_enable, output reg raw_req, output wire [31:0] raw_lba,
    input wire raw_ready, input wire raw_valid, input wire [7:0] raw_byte,
    input wire [8:0] raw_index, input wire raw_done, input wire [7:0] raw_error,
    input wire raw_idle, output wire raw_byte_ready,
    output reg [4:0] valid_mask, output reg [7:0] load_error,
    input wire pixel_clk, input wire pixel_rst,
    input wire cue_toggle, input wire [2:0] cue_id, input wire sample_tick,
    output reg signed [15:0] sfx_sample, output reg active,
    output wire playback_ready
);
    localparam [2:0] IDLE=0, SELECT=1, METADATA=2, REQUEST=3,
                     RECEIVE=4, DRAIN=5, NEXT=6, DONE=7;
    localparam integer TIMER_BITS=TIMEOUT_CYCLES<2 ? 1:$clog2(TIMEOUT_CYCLES+1);
    localparam integer RAM_ADDR_BITS=CACHE_BYTES<2 ? 1:$clog2(CACHE_BYTES);
    // The full-width metadata check precedes every truncation. No accepted
    // effect exceeds this cache-derived count (864 sectors for 36864 bytes).
    localparam [31:0] MAX_SECTORS=(CACHE_BYTES*6)/256;
    localparam integer SECTOR_BITS=MAX_SECTORS<2 ? 1:$clog2(MAX_SECTORS+1);
    reg [2:0] state,track;
    reg [2:0] settle_count,decimation;
    reg [9:0] sector_bytes;
    reg [SECTOR_BITS-1:0] sector_total,sector_lba;
    reg [15:0] cursor,track_base,track_length;
    reg [15:0] base0,base1,base2,base3,base4;
    reg [15:0] len0,len1,len2,len3,len4;
    reg [TIMER_BITS-1:0] timer;
    wire byte_accept=state==RECEIVE && raw_valid;
    wire capture_byte=byte_accept && raw_index[0] && decimation==0;
    wire index_error=byte_accept && raw_index!=sector_bytes[8:0];
    wire space_error=capture_byte && cursor>=CACHE_BYTES;
    wire ram_write=capture_byte && !index_error && !space_error && raw_error==0;
    wire expired=timer==TIMEOUT_CYCLES-1;
    assign selected_index=5'd16+{2'b0,track};
    assign raw_lba={{(32-SECTOR_BITS){1'b0}},sector_lba};
    assign raw_byte_ready=state==RECEIVE;
    assign load_busy=state!=IDLE && !load_done;
    task fail_file;
        input [7:0] code;
        begin
            if(load_error==0)load_error<=code;
            valid_mask[track]<=0;cursor<=track_base;track_length<=0;
            raw_enable<=0;state<=DRAIN;timer<=0;
        end
    endtask
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE;track<=0;settle_count<=0;decimation<=0;
            sector_bytes<=0;sector_total<=0;cursor<=0;track_base<=0;track_length<=0;
            base0<=0;base1<=0;base2<=0;base3<=0;base4<=0;
            len0<=0;len1<=0;len2<=0;len3<=0;len4<=0;
            timer<=0;raw_enable<=0;raw_req<=0;sector_lba<=1;
            valid_mask<=0;load_error<=0;load_done<=0;
        end else begin
            raw_req<=0;
            if(state==REQUEST || state==RECEIVE)begin
                if(byte_accept)timer<=0;
                else if(!expired)timer<=timer+1'b1;
            end else timer<=0;
            case(state)
                IDLE:if(load_start)begin track<=0;state<=SELECT;end
                SELECT:begin
                    raw_enable<=0;settle_count<=4;sector_lba<=1;
                    track_base<=cursor;track_length<=0;decimation<=0;
                    sector_bytes<=0;state<=METADATA;
                end
                METADATA:begin
                    if(settle_count!=0)settle_count<=settle_count-1'b1;
                    else if(raw_idle)begin
                        if(!file_present || file_sectors==0)begin
                            if(load_error==0)load_error<=8'hc1;
                            state<=NEXT;
                        end else if(file_sectors>MAX_SECTORS)begin
                            // No one effect can fit more than the entire cache.
                            if(load_error==0)load_error<=8'hc3;
                            state<=NEXT;
                        end else begin
                            sector_total<=file_sectors[SECTOR_BITS-1:0];raw_enable<=1;state<=REQUEST;
                        end
                    end
                end
                REQUEST:begin
                    if(raw_ready)begin raw_req<=1;sector_bytes<=0;timer<=0;state<=RECEIVE;end
                    else if(expired)fail_file(8'hc2);
                end
                RECEIVE:begin
                    if(index_error)fail_file(8'hc4);
                    else if(space_error)fail_file(8'hc3);
                    else if(raw_done && raw_error!=0)fail_file(raw_error);
                    else if(expired && !byte_accept)fail_file(8'hc2);
                    else begin
                        if(byte_accept)begin
                            sector_bytes<=sector_bytes+1'b1;
                            if(raw_index[0])begin
                                if(decimation==5)decimation<=0;
                                else decimation<=decimation+1'b1;
                            end
                        end
                        if(ram_write)begin cursor<=cursor+1'b1;track_length<=track_length+1'b1;end
                        if(raw_done)begin
                            if(sector_bytes+byte_accept!=512)fail_file(8'hc4);
                            else if(sector_lba==sector_total)begin
                                valid_mask[track]<=1;
                                case(track)
                                    0:begin base0<=track_base;len0<=track_length+ram_write;end
                                    1:begin base1<=track_base;len1<=track_length+ram_write;end
                                    2:begin base2<=track_base;len2<=track_length+ram_write;end
                                    3:begin base3<=track_base;len3<=track_length+ram_write;end
                                    default:begin base4<=track_base;len4<=track_length+ram_write;end
                                endcase
                                state<=DRAIN;
                            end else begin sector_lba<=sector_lba+1'b1;timer<=0;state<=REQUEST;end
                        end
                    end
                end
                DRAIN:if(raw_idle)begin raw_enable<=0;state<=NEXT;end
                NEXT:begin
                    if(track==4)begin state<=DONE;load_done<=1;end
                    else begin track<=track+1'b1;state<=SELECT;end
                end
                DONE:begin raw_enable<=0;load_done<=1;end
                default:state<=IDLE;
            endcase
        end
    end

    (* ASYNC_REG="TRUE" *) reg [1:0] ready_sync;
    (* ASYNC_REG="TRUE" *) reg [4:0] valid_meta,valid_sync;
    reg cue_seen;
    reg [15:0] play_addr,play_remaining;
    reg [2:0] repeat_count;
    reg [1:0] fetch_wait;
    wire [7:0] ram_sample;
    wire cue_valid=cue_id>=1 && cue_id<=5 && valid_sync[cue_id-1'b1];
    reg [15:0] selected_base,selected_length;
    assign playback_ready=ready_sync[1];
    always @* begin
        case(cue_id)
            1:begin selected_base=base0;selected_length=len0;end
            2:begin selected_base=base1;selected_length=len1;end
            3:begin selected_base=base2;selected_length=len2;end
            4:begin selected_base=base3;selected_length=len3;end
            default:begin selected_base=base4;selected_length=len4;end
        endcase
    end
    // This held-data crossing is qualified by ready_sync. The source metadata
    // is final before load_done and never changes again until common reset.
    always @(posedge pixel_clk or posedge pixel_rst) begin
        if(pixel_rst)begin
            ready_sync<=0;valid_meta<=0;valid_sync<=0;cue_seen<=0;
            play_addr<=0;play_remaining<=0;repeat_count<=0;fetch_wait<=0;
            active<=0;sfx_sample<=0;
        end else begin
            ready_sync<={ready_sync[0],load_done};valid_meta<=valid_mask;valid_sync<=valid_meta;
            if(fetch_wait!=0)fetch_wait<=fetch_wait-1'b1;
            if(!ready_sync[1])begin cue_seen<=cue_toggle;active<=0;sfx_sample<=0;end
            else if(cue_toggle!=cue_seen)begin
                cue_seen<=cue_toggle;sfx_sample<=0;repeat_count<=0;
                if(cue_valid && selected_length!=0 && selected_base+{1'b0,selected_length}<=CACHE_BYTES)begin
                    play_addr<=selected_base;play_remaining<=selected_length;
                    active<=1;fetch_wait<=2;
                end else active<=0;
            end else if(sample_tick && active && fetch_wait==0)begin
                sfx_sample<={ram_sample,8'h00};
                if(repeat_count==5)begin
                    repeat_count<=0;
                    if(play_remaining<=1)begin
                        // Last sample is held until the next 48 kHz demand.
                        play_remaining<=0;
                    end else begin play_addr<=play_addr+1'b1;play_remaining<=play_remaining-1'b1;fetch_wait<=2;end
                end else repeat_count<=repeat_count+1'b1;
                if(play_remaining==0)begin active<=0;sfx_sample<=0;end
            end
        end
    end
    EG_LOGIC_BRAM #(
        .DATA_WIDTH_A(8),.DATA_WIDTH_B(8),.ADDR_WIDTH_A(RAM_ADDR_BITS),.ADDR_WIDTH_B(RAM_ADDR_BITS),
        .DATA_DEPTH_A(CACHE_BYTES),.DATA_DEPTH_B(CACHE_BYTES),
        .BYTE_ENABLE(0),.BYTE_A(1),.BYTE_B(1),.MODE("DP"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.RESETMODE("SYNC"),
        .DEBUGGABLE("NO"),.PACKABLE("NO"),.FORCE_KEEP("OFF"),
        .INIT_FILE("NONE"),.FILL_ALL("NONE"),.IMPLEMENT("32K")
    ) u_sample_cache (
        .doa(),.dob(ram_sample),.dia(raw_byte),.dib(8'd0),
        .cea(ram_write),.ocea(1'b1),.clka(clk),.wea(ram_write),.rsta(rst),
        .ceb(active),.oceb(1'b1),.clkb(pixel_clk),.web(1'b0),.rstb(pixel_rst),
        .bea(1'b1),.beb(1'b1),.addra(cursor[RAM_ADDR_BITS-1:0]),.addrb(play_addr[RAM_ADDR_BITS-1:0])
    );
endmodule
