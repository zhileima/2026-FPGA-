`timescale 1ns/1ps
module frame_fifo_write
#
(
	parameter MEM_DATA_BITS          = 32,
	parameter ADDR_BITS              = 21,
	parameter BURST_BITS             = 9,
	parameter BURST_SIZE             = 128,
	parameter WRITE_V_FLIP           = 1,      // 1: write image rows upside-down to cancel BMP bottom-up storage
	parameter FRAME_WIDTH            = 640,
	parameter FRAME_HEIGHT           = 480,
    parameter EXTERNAL_ARBITER       = 0, // 0 preserves legacy App_rd_busy arbitration
    parameter BANK_BITS             = 2,
    parameter START_PAGE_ENABLE      = 0,
    parameter [ADDR_BITS-1:0] START_BASE_ADDR = 1536000,
    parameter integer END_PAGE_ENABLE=0,
    parameter [ADDR_BITS-1:0] END_BASE_ADDR=1689600
)               
(
	input                            rst,                  
	input                            mem_clk,                    // external memory controller user interface clock
	input							 Sdr_init_done,
	input							 Sdr_init_ref_vld,
    input							 Sdr_busy,
	input							 App_rd_busy,
    output							 O_wr_busy,
	
	output 							 App_wr_en,
	output  [ADDR_BITS - 1:0]	 	App_wr_addr,
	/*
    output reg                       wr_burst_req,               // to external memory controller,send out a burst write request  
	output reg[BURST_BITS - 1:0]     wr_burst_len,               // to external memory controller,data length of the burst write request, not bytes 
	output reg[ADDR_BITS - 1:0]      wr_burst_addr,              // to external memory controller,base address of the burst write request 
	input                            wr_burst_data_req,          // from external memory controller,write data request ,before data 1 clock 
	input                            wr_burst_finish,            // from external memory controller,burst write finish
	*/
	input                            write_req,                  // data write module write request,keep '1' until read_req_ack = '1'
	output reg                       write_req_ack,              // data write module write request response
	output                           write_finish,               // data write module write request finish
	input[ADDR_BITS - 1:0]           write_addr_0,               // data write module write request base address 0, used when write_addr_index = 0
	input[ADDR_BITS - 1:0]           write_addr_1,               // data write module write request base address 1, used when write_addr_index = 1
	input[ADDR_BITS - 1:0]           write_addr_2,               // data write module write request base address 1, used when write_addr_index = 2
	input[ADDR_BITS - 1:0]           write_addr_3,               // data write module write request base address 1, used when write_addr_index = 3
    input[ADDR_BITS - 1:0]           write_addr_4, write_addr_5, write_addr_6, write_addr_7,
	input[BANK_BITS-1:0]             write_addr_index,
    input wire write_is_start,input wire write_is_end,
	input[ADDR_BITS - 1:0]           write_len,                  // data write module write request data length
	output reg                       fifo_aclr,                  // to fifo asynchronous clear
	input[9:0]                      rdusedw,                    // from fifo read used words
    input                            burst_grant,                // used only with EXTERNAL_ARBITER=1
    output                           burst_request,              // eligible burst, independent of grant
    output                           burst_busy                  // actual owned command burst + drain
);
localparam ONE                       = 256'd1;                   //256 bit '1'   you can use ONE[n-1:0] for n bit '1'
localparam ZERO                      = 256'd0;                   //256 bit '0'

// Vertical flip address mapping for 640x480 frame buffer.
// Input stream order remains unchanged; only SDRAM write addresses are remapped:
// stream row 0 -> memory row FRAME_HEIGHT-1, stream row 1 -> memory row FRAME_HEIGHT-2, ...
localparam [ADDR_BITS - 1:0] VFLIP_FIRST_ADDR_OFFSET = (FRAME_HEIGHT - 1) * FRAME_WIDTH;
localparam [ADDR_BITS - 1:0] VFLIP_LINE_JUMP         = (FRAME_WIDTH * 2) - 1;
localparam [15:0]            VFLIP_LINE_LAST_X       = FRAME_WIDTH - 1;
// Preserve the original 16-bit last-column truncation for every parameter.
// A reset row counter only visits 0..VFLIP_LINE_LAST_X, so extra bits are zero.
localparam integer WR_X_BITS = (VFLIP_LINE_LAST_X == 0) ? 1 :
                               $clog2({1'b0,VFLIP_LINE_LAST_X} + 17'd1);
localparam [ADDR_BITS-1:0] VFLIP_ROW_STEP = {ADDR_BITS{1'b0}} - VFLIP_LINE_JUMP;

//write state machine code
localparam S_IDLE                    = 0;                        //idle state,waiting for write
localparam S_ACK                     = 1;                        //written request response
localparam S_CHECK_FIFO              = 2;                        //check the FIFO status, ensure that there is enough space to burst write
localparam S_WRITE_BURST             = 3;                        //begin a burst write
localparam S_WRITE_BURST_END         = 4;                        //a burst write complete
localparam S_END                     = 5;                        //a frame of data is written to complete


(* ASYNC_REG = "TRUE" *) reg        write_req_d0;                //asynchronous write request, synchronize to 'mem_clk' clock domain,first beat
(* ASYNC_REG = "TRUE" *) reg        write_req_d1;                //the second
(* ASYNC_REG = "TRUE" *) reg        write_req_d2;                //third,Why do you need 3 ? Here's the design habit
reg[ADDR_BITS - 1:0]                write_len_d0;                //asynchronous write_len(write data length), synchronize to 'mem_clk' clock domain first
reg[ADDR_BITS - 1:0]                write_len_d1;                //second
reg[ADDR_BITS - 1:0]                write_len_latch;             //lock write data length
reg[ADDR_BITS - 1:0]                write_cnt;                   //write data counter
// Prepare the tail requirement in the existing ACK / burst-end cycles.
// During CHECK_FIFO no words are consumed, so these values stay valid while
// the FIFO fills. Keep the original finite-width sum's wrap behavior too.
localparam FIFO_COMPARE_BITS = (ADDR_BITS < 10) ? 10 : ADDR_BITS;
reg [FIFO_COMPARE_BITS-1:0] remaining_words,room_before_wrap;
wire [FIFO_COMPARE_BITS-1:0] fifo_words={{(FIFO_COMPARE_BITS-10){1'b0}},rdusedw};
wire [FIFO_COMPARE_BITS-1:0] length_wide={{(FIFO_COMPARE_BITS-ADDR_BITS){1'b0}},write_len_latch};
wire [FIFO_COMPARE_BITS-1:0] written_wide={{(FIFO_COMPARE_BITS-ADDR_BITS){1'b0}},write_cnt};
reg[BANK_BITS-1:0]                  write_addr_index_d0;
reg[BANK_BITS-1:0]                  write_addr_index_d1;
(* ASYNC_REG="TRUE" *) reg boot_meta, boot_sync,end_meta,end_sync;
reg[3:0]                            state;                       //state machine
reg [ADDR_BITS - 1:0]	 App_wr_addr_r;
reg [WR_X_BITS-1:0]                     wr_x;                       // current x position in one input row

reg [BURST_BITS - 1:0]				burst_cnt;
wire								wr_burst_finish;

reg App_wr_en_r;
reg App_wr_en_d0;


// Select the finite-width increment before one shared address adder.
wire [ADDR_BITS-1:0] write_addr_step =
    (WRITE_V_FLIP && wr_x == VFLIP_LINE_LAST_X) ? VFLIP_ROW_STEP : ONE[ADDR_BITS-1:0];
wire into_burst;
wire burst_eligible;
assign burst_eligible = (((fifo_words >= remaining_words) && (fifo_words <= room_before_wrap)) ||
                         rdusedw > BURST_SIZE) && !App_rd_busy && !Sdr_init_ref_vld;
assign burst_request = (state == S_CHECK_FIFO) && burst_eligible;
assign into_burst = burst_eligible && (!EXTERNAL_ARBITER || burst_grant);
// Retain ownership through the command tail and the inherited end state.
assign burst_busy = (state == S_WRITE_BURST) || (state == S_WRITE_BURST_END) || App_wr_en_d0;//当rd在突发时不会进入burst

assign App_wr_addr = {App_wr_addr_r[ADDR_BITS - 1:0]};
//assign O_wr_busy = (state != S_IDLE || (S_IDLE && write_req_d2));
assign O_wr_busy = (state == S_WRITE_BURST || (state == S_CHECK_FIFO && into_burst));//在突发，或者将要突发，则显示busy
assign wr_burst_finish = (burst_cnt >= BURST_SIZE);
assign write_finish = (state == S_END) ? 1'b1 : 1'b0;            //write finish at state 'S_END'
// Do not pop the source FIFO or issue writes while refresh/init owns the core.
assign App_wr_en = App_wr_en_d0 && !Sdr_init_ref_vld;

function [ADDR_BITS-1:0] select_base;
    input [BANK_BITS-1:0] bank;
    begin
        case(bank)
            0:select_base=write_addr_0;
            1:select_base=write_addr_1;
            2:select_base=write_addr_2;
            3:select_base=write_addr_3;
            4:select_base=write_addr_4;
            5:select_base=write_addr_5;
            6:select_base=write_addr_6;
            default:select_base=write_addr_7;
        endcase
    end
endfunction

always@(posedge mem_clk or posedge rst)
begin
	if(rst == 1'b1)
	begin
		write_req_d0    <=  1'b0;
		write_req_d1    <=  1'b0;
		write_req_d2    <=  1'b0;
		write_len_d0    <=  ZERO[ADDR_BITS - 1:0];              //equivalent to write_len_d0 <= 0;
		write_len_d1    <=  ZERO[ADDR_BITS - 1:0];              //equivalent to write_len_d1 <= 0;
		write_addr_index_d0    <=  2'b00;
		write_addr_index_d1    <=  2'b00;
        boot_meta<=0;boot_sync<=0;end_meta<=0;end_sync<=0;
	end
	else
	begin
		write_req_d0    <=  write_req;
		write_req_d1    <=  write_req_d0;
		write_req_d2    <=  write_req_d1;
		write_len_d0    <=  write_len;
		write_len_d1    <=  write_len_d0;
		write_addr_index_d0 <= write_addr_index;
		write_addr_index_d1 <= write_addr_index_d0;
        boot_meta<=(START_PAGE_ENABLE!=0) && write_is_start;boot_sync<=boot_meta;
        end_meta<=(END_PAGE_ENABLE!=0) && write_is_end;end_sync<=end_meta;
	end 
end
always @(posedge mem_clk or posedge rst)
begin
	if(rst == 1'b1)
	begin
		burst_cnt <= ZERO[BURST_BITS - 1:0];
		App_wr_addr_r <= ZERO[ADDR_BITS - 1:0];
		App_wr_en_d0 <= 1'b0;
		wr_x <= {WR_X_BITS{1'b0}};
	end
	else begin
	
		if(state == S_CHECK_FIFO)
			burst_cnt <= ZERO[BURST_BITS - 1:0];
		else if(App_wr_en)
			burst_cnt <= burst_cnt + 1'b1;
		else
			burst_cnt <= burst_cnt;
		//
		if(state == S_ACK)
			begin
				wr_x <= {WR_X_BITS{1'b0}};
                App_wr_addr_r <= (end_sync ? END_BASE_ADDR : boot_sync ? START_BASE_ADDR : select_base(write_addr_index_d1)) +
                    (WRITE_V_FLIP ? VFLIP_FIRST_ADDR_OFFSET : 0);
			end
		else if(App_wr_en)
			begin
				if(WRITE_V_FLIP) begin
					if(wr_x == VFLIP_LINE_LAST_X) wr_x <= {WR_X_BITS{1'b0}};
					else wr_x <= wr_x + 1'b1;
				end
				App_wr_addr_r <= App_wr_addr_r + write_addr_step;
			end
		else
			App_wr_addr_r <= App_wr_addr_r;
		//
		if(App_wr_en_r && burst_cnt + App_wr_en < BURST_SIZE && (burst_cnt + write_cnt + App_wr_en < write_len_latch))begin
            App_wr_en_d0 <= 1'b1;
        end
		else
			App_wr_en_d0 <= 1'b0;
	
	end		
end
always@(posedge mem_clk or posedge rst)
begin
	if(rst == 1'b1)
	begin
		state <= S_IDLE;
		write_len_latch <= ZERO[ADDR_BITS - 1:0];
		remaining_words <= {FIFO_COMPARE_BITS{1'b0}};
		room_before_wrap <= {FIFO_COMPARE_BITS{1'b1}};
		
		//wr_burst_addr <= ZERO[ADDR_BITS - 1:0];
		//wr_burst_req <= 1'b0;
		App_wr_en_r <= 1'b0;
		
		write_cnt <= ZERO[ADDR_BITS - 1:0];
		fifo_aclr <= 1'b0;
		write_req_ack <= 1'b0;
		//wr_burst_len <= ZERO[BURST_BITS - 1:0];
		
		
	end
	else 
		case(state)
			//idle state,waiting for write write_req_d2 == '1' goto the 'S_ACK'
			S_IDLE:
			begin
				if(write_req_d2 == 1'b1 && Sdr_init_done)
				begin
					state <= S_ACK;
				end
				write_req_ack <= 1'b0;
			end
			//'S_ACK' state completes the write request response, the FIFO reset, the address latch, and the data length latch
			S_ACK:
			begin
				//after write request revocation(write_req_d2 == '0'),goto 'S_CHECK_FIFO',write_req_ack goto '0'
				if(write_req_d2 == 1'b0)
				begin
					state <= S_CHECK_FIFO;
					fifo_aclr <= 1'b0;
					write_req_ack <= 1'b0;
				end
				else
				begin
					//write request response
					write_req_ack <= 1'b1;
					//FIFO reset
					fifo_aclr <= 1'b1;
					//select valid base address from write_addr_0 write_addr_1 write_addr_2 write_addr_3
					/*
					if(write_addr_index_d1 == 2'd0)
						wr_burst_addr <= write_addr_0;
					else if(write_addr_index_d1 == 2'd1)
						wr_burst_addr <= write_addr_1;
					else if(write_addr_index_d1 == 2'd2)
						wr_burst_addr <= write_addr_2;
					else if(write_addr_index_d1 == 2'd3)
						wr_burst_addr <= write_addr_3;
					*/
					//latch data length
					write_len_latch <= write_len_d1;                    
					remaining_words <= {{(FIFO_COMPARE_BITS-ADDR_BITS){1'b0}},write_len_d1};
				end
				//write data counter reset, write_cnt <= 0;
				write_cnt <= ZERO[ADDR_BITS - 1:0];
				room_before_wrap <= {FIFO_COMPARE_BITS{1'b1}};
			end
			S_CHECK_FIFO:
			begin
				//if there is a write request at this time, enter the 'S_ACK' state
				if(write_req_d2 == 1'b1)
				begin
					state <= S_ACK;
				end
				//if the FIFO space is a burst write request, goto burst write state
				else if(into_burst)
				begin
					state <= S_WRITE_BURST;
					//wr_burst_len <= BURST_SIZE[BURST_BITS - 1:0];
					//wr_burst_req <= 1'b1;
					App_wr_en_r <= 1'b1;
				end
			end 
			
			S_WRITE_BURST:
			begin
				//burst finish
				if(wr_burst_finish == 1'b1)
				begin
					App_wr_en_r <= 1'b0;
					state <= S_WRITE_BURST_END;
					//write counter + burst length
					write_cnt <= write_cnt + BURST_SIZE[ADDR_BITS - 1:0];
					//the next burst write address is generated
					//wr_burst_addr <= wr_burst_addr + BURST_SIZE[ADDR_BITS - 1:0];
				end     
			end
			S_WRITE_BURST_END:
			begin
				remaining_words <= length_wide - written_wide;
				room_before_wrap <= ~written_wide;
				//if there is a write request at this time, enter the 'S_ACK' state
				if(write_req_d2 == 1'b1)
				begin
					state <= S_ACK;
				end
				//if the write counter value is less than the frame length, continue writing,
				//otherwise the writing is complete
				else if(write_cnt < write_len_latch)
				begin
					state <= S_CHECK_FIFO;
				end
				else
				begin
					state <= S_END;
				end
			end
			S_END:
			begin
				state <= S_IDLE;
			end
			default:
				state <= S_IDLE;
		endcase
end
endmodule
