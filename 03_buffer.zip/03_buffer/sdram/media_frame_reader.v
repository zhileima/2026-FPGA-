`timescale 1ns/1ps
// RGB888 output reader. Optional full-screen storage packs two RGB565 pixels
// per word; thumbnail atlases retain one RGB888 pixel per word.
// Bank is a logical frame-base selector, unrelated to SDRAM physical BA pins.
module media_frame_reader #(
    parameter integer ADDR_BITS = 21,
    parameter integer BURST_SIZE = 128,
    parameter integer FIFO_DEPTH = 512,
    parameter integer FIFO_MARGIN = 8,
    parameter integer MAX_INFLIGHT_BURSTS = 2,
    parameter integer BURST_GAP_CYCLES = 12,
    parameter integer TIMEOUT_CYCLES = 1000000,
    parameter integer THUMBNAIL_ENABLE = 0,
    parameter integer BANK_BITS = 2,
    parameter integer RGB565_ENABLE = 0,
    parameter integer THUMBNAIL_PAGE_WORDS = 0,
    parameter integer START_PAGE_ENABLE = 0,
    parameter [ADDR_BITS-1:0] START_BASE_ADDR = 1536000,
    parameter integer END_PAGE_ENABLE=0,
    parameter [ADDR_BITS-1:0] END_BASE_ADDR=1689600
) (
    input wire rst, input wire read_rst,
    input wire mem_clk, input wire read_clk,
    input wire Sdr_init_done, input wire Sdr_init_ref_vld,
    input wire Sdr_busy, input wire Sdr_rd_en,
    input wire [31:0] Sdr_rd_dout,
    output wire App_rd_en, output wire [ADDR_BITS-1:0] App_rd_addr,
    output wire burst_request, input wire burst_grant,
    output wire burst_busy,
    input wire read_req, output reg read_req_ack,
    output reg read_finish,
    input wire [ADDR_BITS-1:0] read_addr_0, read_addr_1,
    input wire [ADDR_BITS-1:0] read_addr_2, read_addr_3,
    input wire [ADDR_BITS-1:0] read_addr_4, read_addr_5, read_addr_6, read_addr_7,
    input wire [BANK_BITS-1:0] read_addr_index,
    input wire read_switch_req_toggle,
    output reg read_switch_ack_toggle,
    output reg [BANK_BITS-1:0] read_switch_ack_idx,
    input wire [ADDR_BITS-1:0] read_len,
    input wire frame_start, input wire display_valid,
    input wire read_en, output wire [31:0] read_data,
    output wire pixel_valid, output reg underflow,
    // Pixel-domain bank travels with the same readiness token as the FIFO.
    output reg [BANK_BITS-1:0] pixel_index, output reg pixel_frame_commit,
    output wire reader_busy, output reg [BANK_BITS-1:0] reader_index,
    output reg [7:0] reader_error,
    output wire [9:0] debug_read_count,
    output wire debug_read_empty, output wire debug_read_full,
    output reg debug_read_overflow, output wire debug_read_underflow,
    input wire [2:0] zoom_level,
    output wire [2:0] pixel_zoom_level,
    input wire read_view_mode,
    input wire read_is_start, output reg pixel_is_start,
    input wire read_is_end, output reg pixel_is_end,
    input wire read_view_page,
    // This base is a top-level constant, not a live asynchronous address bus.
    input wire [ADDR_BITS-1:0] read_addr_thumbnail,
    output reg pixel_view_mode,
    output reg pixel_view_page
);
    localparam [3:0] WAIT_REQ=0, DRAIN=1, FLUSH=2,
                     RELEASE=3, ACK=4, RUN=5;
    localparam [7:0] ERR_OVERRUN=8'h71, ERR_OVERFLOW=8'h72,
                     ERR_UNDERFLOW=8'h73, ERR_TIMEOUT=8'h74,
                     ERR_REQUEST=8'h75;
    localparam integer COUNT_BITS = $clog2(MAX_INFLIGHT_BURSTS*BURST_SIZE+1);
    localparam integer BURST_BITS = $clog2(BURST_SIZE+1);
    localparam integer RESERVE_BITS = (COUNT_BITS+2 > 11) ? COUNT_BITS+2 : 11;
    localparam [COUNT_BITS:0] WINDOW_LIMIT = MAX_INFLIGHT_BURSTS*BURST_SIZE;
    localparam [RESERVE_BITS-1:0] FIFO_LIMIT = FIFO_DEPTH-FIFO_MARGIN;
    localparam integer TIMER_BITS = (TIMEOUT_CYCLES < 2) ? 1 : $clog2(TIMEOUT_CYCLES+1);
    localparam integer GAP_BITS = (BURST_GAP_CYCLES < 2) ? 1 : $clog2(BURST_GAP_CYCLES+1);
    wire reset_all = rst | read_rst;
    reg [3:0] state;
    (* ASYNC_REG = "TRUE" *) reg [2:0] request_sync, switch_sync;
    (* ASYNC_REG = "TRUE" *) reg [BANK_BITS-1:0] bank_meta, bank_sync;
    (* ASYNC_REG = "TRUE" *) reg [1:0] display_sync;
    (* ASYNC_REG = "TRUE" *) reg [ADDR_BITS-1:0] len_meta, len_sync;
    (* ASYNC_REG = "TRUE" *) reg view_meta, view_sync;
    (* ASYNC_REG = "TRUE" *) reg page_meta, page_sync;
    reg [BANK_BITS-1:0] requested_bank;
    reg requested_token;
    (* ASYNC_REG="TRUE" *) reg boot_meta,boot_sync;
    reg requested_boot,pending_boot,reader_boot;
    (* ASYNC_REG="TRUE" *) reg end_meta,end_sync,pixel_end_meta,pixel_end_sync;
    reg requested_end,pending_end,reader_end;
    (* ASYNC_REG="TRUE" *) reg pixel_boot_meta,pixel_boot_sync;
    reg [ADDR_BITS-1:0] frame_base, frame_length;
    reg [ADDR_BITS:0] issued_words, returned_words;
    // Reservation counts both commands not yet emitted in the granted burst
    // and responses still in flight, so no delayed response can exceed FIFO.
    reg [COUNT_BITS-1:0] reserved_words;
    reg command_active;
    reg [BURST_BITS-1:0] command_count, command_target;
    reg [BURST_BITS-1:0] planned_words;
    reg plan_valid;
    reg [COUNT_BITS:0] plan_window_budget;
    reg [RESERVE_BITS-1:0] plan_fifo_budget;
    reg plan_fits_fifo;
    reg [GAP_BITS-1:0] gap_count;
    reg [TIMER_BITS-1:0] response_timer, handshake_timer;
    reg pending_frame, pending_token;
    reg [BANK_BITS-1:0] pending_index;
    reg [ADDR_BITS-1:0] pending_length, pending_base;
    reg pending_view, reader_view;
    reg pending_page, reader_page;
    reg [2:0] clear_count;
    reg fifo_clear;
    reg ready_toggle;
    (* ASYNC_REG = "TRUE" *) reg [2:0] ready_sync;
    (* ASYNC_REG = "TRUE" *) reg [BANK_BITS-1:0] pixel_bank_meta, pixel_bank_sync;
    (* ASYNC_REG = "TRUE" *) reg pixel_view_meta, pixel_view_sync;
    (* ASYNC_REG = "TRUE" *) reg pixel_page_meta, pixel_page_sync;
    (* ASYNC_REG = "TRUE" *) reg [1:0] underflow_sync, release_sync;
    reg ready_seen, frame_armed, frame_drop;
    wire fifo_reset = reset_all | fifo_clear;
    wire fifo_full, fifo_empty, fifo_raw_valid, fifo_raw_read;
    wire fifo_wr_done, fifo_rd_done;
    wire [8:0] fifo_wr_count;
    wire [31:0] fifo_raw_data;
    wire prefetch_valid;
    wire [31:0] prefetch_data;
    reg pixel_half;
    wire packed_pixels = RGB565_ENABLE && !pixel_view_mode;
    wire [15:0] current565 = pixel_half ? prefetch_data[31:16] : prefetch_data[15:0];
    wire [31:0] expanded565 = {current565[15:11],current565[15:13],
                              current565[10:5],current565[10:9],
                              current565[4:0],current565[4:2],8'h00};
    reg[1:0]pixel_skip;
    wire zoom_consume;
    wire consume_word = frame_armed && prefetch_valid &&
                        ((pixel_skip!=0) || (read_en && (!packed_pixels || (pixel_half && zoom_consume))));
    (* ASYNC_REG = "TRUE" *) reg [1:0] fifo_rd_done_sync;
    wire [ADDR_BITS:0] frame_remaining = {1'b0,frame_length} - issued_words;
    wire [ADDR_BITS:0] remaining_words;
    // Frame-width subtraction/minimum is isolated in the planner. Only the
    // short FIFO/reservation counts participate in the command grant path.
    wire [BURST_BITS-1:0] next_burst_words = planned_words;
    // With a valid plan p, r+p<=W iff r<=W-p. Likewise f+r+p<=L
    // iff f+r<=L-p (provided p<=L). The planner registers both budgets on
    // the same edge as planned_words, removing p from the grant carry chain.
    // This changes neither the planning cycle nor the command/response ABI.
    wire [RESERVE_BITS-1:0] fifo_reserved =
           {{(RESERVE_BITS-10){1'b0}},debug_read_count} +
           {{(RESERVE_BITS-COUNT_BITS){1'b0}},reserved_words};
    wire window_ok = {1'b0,reserved_words} <= plan_window_budget;
    // A full 512-word FIFO cannot satisfy a positive safety margin. Keep
    // that full indication out of the count adder's carry chain: the stored
    // plan budget is FIFO_LIMIT-planned_words whenever plan_fits_fifo is true.
    // This is a same-cycle Boolean rewrite; debug_read_count remains exact.
    wire [RESERVE_BITS-1:0] fifo_reserved_not_full =
           {{(RESERVE_BITS-9){1'b0}},fifo_wr_count} +
           {{(RESERVE_BITS-COUNT_BITS){1'b0}},reserved_words};
    wire capacity_ok;
    generate if(FIFO_DEPTH==512 && FIFO_MARGIN>0 && FIFO_MARGIN<FIFO_DEPTH) begin : g_capacity_short_full
        assign capacity_ok = plan_fits_fifo && !fifo_full &&
                             fifo_reserved_not_full <= plan_fifo_budget;
    end else begin : g_capacity_legacy
        assign capacity_ok = plan_fits_fifo && fifo_reserved <= plan_fifo_budget;
    end endgenerate
    wire grant = burst_request && burst_grant;
    wire expected_return = Sdr_rd_en &&
                           (returned_words != issued_words || App_rd_en) &&
                           reserved_words != 0;
    wire unexpected_return = Sdr_rd_en && !expected_return;
    wire overflow_event = expected_return && state == RUN && fifo_full;
    wire response_timeout = reserved_words != 0 && !Sdr_rd_en &&
                            response_timer == TIMEOUT_CYCLES-1;
    wire request_timeout = ((state == ACK && request_sync[2]) ||
                            (state == RELEASE && pending_frame)) &&
                           handshake_timer == TIMEOUT_CYCLES-1;
    wire new_frame = state == RUN && request_sync[2];
    wire frame_overrun = new_frame && display_sync[1] &&
                         (issued_words != frame_length || reserved_words != 0);
    wire bad_length = (state == RELEASE && fifo_wr_done && fifo_rd_done_sync[1]) &&
                      pending_length == 0;
    wire fifo_write = expected_return && state == RUN && !request_sync[2] &&
                      !fifo_reset && !fifo_full;
    wire thumbnail_selected = (THUMBNAIL_ENABLE != 0) && view_sync && !requested_boot && !requested_end;
    wire thumbnail_page_selected = (THUMBNAIL_PAGE_WORDS != 0) && page_sync;
    wire [ADDR_BITS-1:0] thumbnail_base = read_addr_thumbnail +
        (thumbnail_page_selected ? THUMBNAIL_PAGE_WORDS : 0);
    // The core's busy is checked before beginning a command train. Once a
    // granted train starts, preserve its continuous command contract, pausing
    // only for the same refresh indication used by the validated legacy core.
    assign burst_request = state == RUN && plan_valid && !command_active && !request_sync[2] &&
                           gap_count == 0 &&
                           Sdr_init_done && !Sdr_init_ref_vld && !Sdr_busy &&
                           !fifo_reset && fifo_wr_done && window_ok && capacity_ok;
    assign App_rd_en = command_active && Sdr_init_done && !Sdr_init_ref_vld && !reset_all;
    // SDRAM app command trains are strictly contiguous. Read a cropped
    // source row, split the train at its end, and expand word pairs in the
    // pixel domain. A repeated source row is a new train, never a repeated
    // address inside a native SDRAM burst. No extra line/frame RAM is needed.
    reg[19:0]zy;reg[10:0]zstep;reg[8:0]zcol,zwidth,zx_start;
    reg[17:0]zrow;reg zoom_active;reg[2:0]reader_zoom;
    reg[19:0]cfg_y;reg[8:0]cfg_x,cfg_width;reg[10:0]cfg_step;
    reg[17:0]cfg_length;
    wire cfg_zoom_ok=RGB565_ENABLE && !pending_view && !pending_boot && !pending_end &&
                     pending_length==153600 && zoom_level>=1 && zoom_level<=4;
    always @*begin
     cfg_x=0;cfg_y=0;cfg_step=1024;cfg_width=320;cfg_length=153600;
     case(zoom_level)
      1:begin cfg_x=32;cfg_y=49152;cfg_step=819;cfg_width=256;cfg_length=122880;end
      2:begin cfg_x=52;cfg_y=81920;cfg_step=683;cfg_width=216;cfg_length=103680;end
      3:begin cfg_x=68;cfg_y=105326;cfg_step=585;cfg_width=184;cfg_length=88320;end
      4:begin cfg_x=80;cfg_y=122880;cfg_step=512;cfg_width=160;cfg_length=76800;end
     endcase
    end
    wire[19:0]zy_next=zy+zstep;
    wire[17:0]initial_row=({8'd0,cfg_y[19:10]}<<8)+({8'd0,cfg_y[19:10]}<<6);
    wire[17:0]next_row=({8'd0,zy_next[19:10]}<<8)+({8'd0,zy_next[19:10]}<<6);
    always @(posedge mem_clk or posedge reset_all)begin
     if(reset_all)begin zy<=0;zcol<=0;zwidth<=320;zx_start<=0;zstep<=1024;zrow<=0;zoom_active<=0;reader_zoom<=0;end
     else if(state==RELEASE && fifo_wr_done && fifo_rd_done_sync[1])begin
      zy<=cfg_y;zcol<=0;zwidth<=cfg_width;zx_start<=cfg_x;zstep<=cfg_step;zrow<=initial_row;
      zoom_active<=cfg_zoom_ok;reader_zoom<=cfg_zoom_ok?zoom_level:0;
     end else if(App_rd_en)begin
      if(zcol==zwidth-1'b1)begin zcol<=0;zy<=zy_next;zrow<=next_row;end
      else zcol<=zcol+1'b1;
     end
    end
    assign remaining_words=zoom_active ? (zwidth-zcol) : frame_remaining;
    wire[17:0]zoom_offset=zrow+zx_start+zcol;
    assign App_rd_addr=frame_base+(zoom_active?zoom_offset:issued_words[ADDR_BITS-1:0]);
    // Held metadata crosses with the existing three-stage ready token, after
    // the memory domain freezes the exact crop used for this frame.
    (* ASYNC_REG="TRUE" *)reg[2:0]pixel_zoom_meta,pixel_zoom_sync;
    reg[2:0]pixel_zoom;reg[19:0]pixel_zx,pixel_zstart;reg[10:0]pixel_zstep;reg[8:0]pixel_pair;
    // Native SDRAM uses four-word physical bursts. Aligned row padding is
    // discarded during horizontal blanking; it is never visible as a pixel.
    reg[19:0]pixel_cfg_x;reg[10:0]pixel_cfg_step;
    always @*begin
     pixel_cfg_x=0;pixel_cfg_step=1024;
     case(pixel_zoom_sync)
      1:begin pixel_cfg_x=32768;pixel_cfg_step=819;end
      2:begin pixel_cfg_x=54613;pixel_cfg_step=683;end
      3:begin pixel_cfg_x=70217;pixel_cfg_step=585;end
      4:begin pixel_cfg_x=81920;pixel_cfg_step=512;end
     endcase
    end
    wire[19:0]pixel_znext=pixel_zx+pixel_zstep;
    assign pixel_zoom_level=pixel_zoom;
    assign zoom_consume=(pixel_zoom==0)||(pixel_pair==319)||(pixel_znext[19:10]!=pixel_zx[19:10]);
    always @(posedge read_clk or posedge reset_all)begin
     if(reset_all)begin pixel_zoom_meta<=0;pixel_zoom_sync<=0;pixel_zoom<=0;pixel_zx<=0;pixel_zstart<=0;pixel_zstep<=1024;pixel_pair<=0;pixel_skip<=0;end
     else begin
      pixel_zoom_meta<=reader_zoom;pixel_zoom_sync<=pixel_zoom_meta;
      if(ready_sync[2]!=ready_seen)begin
       pixel_zoom<=pixel_zoom_sync;pixel_zx<=pixel_cfg_x;pixel_zstart<=pixel_cfg_x;pixel_zstep<=pixel_cfg_step;pixel_pair<=0;
       pixel_skip<=(pixel_zoom_sync==2)?1:0;
      end else if(frame_armed && prefetch_valid && pixel_skip!=0)pixel_skip<=pixel_skip-1'b1;
      else if(read_en && frame_armed && prefetch_valid && pixel_half)begin
       if(pixel_pair==319)begin pixel_pair<=0;pixel_zx<=pixel_zstart;pixel_skip<=(pixel_zoom==2)?2:(pixel_zoom==3)?1:0;end
       else begin pixel_pair<=pixel_pair+1'b1;pixel_zx<=pixel_znext;end
      end
     end
    end
    assign burst_busy = command_active || reserved_words != 0;
    assign reader_busy = burst_busy || (state != WAIT_REQ &&
                         (state != RUN || returned_words < frame_length));
    assign debug_read_count = fifo_full ? 10'd512 : {1'b0,fifo_wr_count};
    assign debug_read_full = fifo_full;
    assign debug_read_empty = !pixel_valid;
    assign debug_read_underflow = underflow;
    assign read_data = packed_pixels ? expanded565 : prefetch_data;
    assign pixel_valid = frame_armed && !frame_drop && prefetch_valid && pixel_skip==0 && !fifo_reset;

    function [ADDR_BITS-1:0] select_base;
        input [BANK_BITS-1:0] bank;
        begin
            case (bank)
                0: select_base=read_addr_0;
                1: select_base=read_addr_1;
                2: select_base=read_addr_2;
                3: select_base=read_addr_3;
                4: select_base=read_addr_4;
                5: select_base=read_addr_5;
                6: select_base=read_addr_6;
                default: select_base=read_addr_7;
            endcase
        end
    endfunction

    always @(posedge read_clk or posedge reset_all) begin
        if (reset_all) begin
            ready_sync<=0; ready_seen<=0; frame_armed<=0;
            underflow<=0; frame_drop<=0; release_sync<=0; pixel_half<=0;
            pixel_bank_meta<=0; pixel_bank_sync<=0; pixel_index<=0; pixel_frame_commit<=0;
            pixel_view_meta<=0; pixel_view_sync<=0; pixel_view_mode<=0;
            pixel_page_meta<=0; pixel_page_sync<=0; pixel_view_page<=0;
            pixel_boot_meta<=0;pixel_boot_sync<=0;pixel_is_start<=0;
            pixel_end_meta<=0;pixel_end_sync<=0;pixel_is_end<=0;
        end else begin
            ready_sync <= {ready_sync[1:0],ready_toggle};
            pixel_bank_meta<=reader_index; pixel_bank_sync<=pixel_bank_meta;
            pixel_view_meta<=reader_view; pixel_view_sync<=pixel_view_meta;
            pixel_page_meta<=reader_page; pixel_page_sync<=pixel_page_meta;
            pixel_boot_meta<=reader_boot;pixel_boot_sync<=pixel_boot_meta;
            pixel_end_meta<=reader_end;pixel_end_sync<=pixel_end_meta;
            pixel_frame_commit<=0;
            release_sync <= {release_sync[0],!fifo_reset && fifo_rd_done};
            // A word stays at the prefetch head for both pixels. Flush and
            // frame readiness always restart at the low/even halfword.
            if(fifo_reset || frame_start || ready_sync[2] != ready_seen)
                pixel_half<=0;
            else if(read_en && frame_armed && prefetch_valid && pixel_skip==0)
                pixel_half<=packed_pixels ? ~pixel_half : 1'b0;
            if (frame_start) begin
                frame_armed<=0;
                frame_drop<=0;
            end
            if (ready_sync[2] != ready_seen) begin
                ready_seen<=ready_sync[2];
                frame_armed<=1;
                pixel_index<=pixel_bank_sync;
                pixel_view_mode<=pixel_view_sync;
                pixel_view_page<=pixel_page_sync;
                pixel_is_start<=pixel_boot_sync;pixel_is_end<=pixel_end_sync;
                pixel_frame_commit<=1;
            end
            if (fifo_reset) frame_armed<=0;
            if (read_en && display_valid && frame_armed && release_sync[1] &&
                !fifo_reset && !prefetch_valid) begin
                underflow<=1;
                // A missing pixel invalidates the rest of this video frame;
                // continue draining so late words cannot shift later pixels.
                frame_drop<=1;
            end
        end
    end

    always @(posedge mem_clk or posedge reset_all) begin
        if (reset_all) begin
            state<=WAIT_REQ; request_sync<=0; switch_sync<=0;
            bank_meta<=0; bank_sync<=0; display_sync<=0;
            view_meta<=0;view_sync<=0;pending_view<=0;reader_view<=0;
            page_meta<=0;page_sync<=0;pending_page<=0;reader_page<=0;
            requested_bank<=0; requested_token<=0;
            boot_meta<=0;boot_sync<=0;requested_boot<=0;pending_boot<=0;reader_boot<=0;
            end_meta<=0;end_sync<=0;requested_end<=0;pending_end<=0;reader_end<=0;
            len_meta<=0; len_sync<=0; frame_base<=0; frame_length<=0;
            issued_words<=0; returned_words<=0; reserved_words<=0;
            command_active<=0; command_count<=0; command_target<=0;
            planned_words<=0; plan_valid<=0;
            plan_window_budget<=0;plan_fifo_budget<=0;plan_fits_fifo<=0;
            gap_count<=0; response_timer<=0; handshake_timer<=0;
            pending_frame<=0; pending_token<=0; pending_index<=0;
            pending_length<=0; pending_base<=0; clear_count<=0;
            fifo_clear<=0; ready_toggle<=0; read_req_ack<=0;
            read_finish<=0; read_switch_ack_toggle<=0; read_switch_ack_idx<=0;
            reader_index<=0; reader_error<=0; debug_read_overflow<=0;
            underflow_sync<=0; fifo_rd_done_sync<=0;
        end else begin
            request_sync<={request_sync[1:0],read_req};
            switch_sync<={switch_sync[1:0],read_switch_req_toggle};
            bank_meta<=read_addr_index; bank_sync<=bank_meta;
            boot_meta<=START_PAGE_ENABLE!=0 && read_is_start;boot_sync<=boot_meta;
            end_meta<=END_PAGE_ENABLE!=0 && read_is_end;end_sync<=end_meta;
            view_meta<=(THUMBNAIL_ENABLE != 0) && read_view_mode;
            view_sync<=view_meta;
            page_meta<=(THUMBNAIL_ENABLE != 0 && THUMBNAIL_PAGE_WORDS != 0) && read_view_page;
            page_sync<=page_meta;
            // A token qualifies its bank after the payload has settled. A
            // video request racing this update uses the previous complete
            // registered pair and defers the new request to the next frame.
            // Sampling bank_sync directly with the longer token synchronizer
            // could freeze a new bank together with the preceding token.
            if (switch_sync[2] != requested_token) begin
                requested_bank<=bank_sync;requested_boot<=boot_sync;requested_end<=end_sync;
                requested_token<=switch_sync[2];
            end
            len_meta<=read_len; len_sync<=len_meta;
            display_sync<={display_sync[0],display_valid};
            underflow_sync<={underflow_sync[0],underflow};
            fifo_rd_done_sync<={fifo_rd_done_sync[0],fifo_rd_done};
            read_finish<=0;
            if (gap_count != 0) gap_count<=gap_count-1'b1;
            if (reserved_words == 0 || Sdr_rd_en) response_timer<=0;
            else if (response_timer < TIMEOUT_CYCLES-1) response_timer<=response_timer+1'b1;
            if (!((state == ACK && request_sync[2]) ||
                  (state == RELEASE && pending_frame))) handshake_timer<=0;
            else if (handshake_timer < TIMEOUT_CYCLES-1) handshake_timer<=handshake_timer+1'b1;

            if (reader_error == 0) begin
                if (unexpected_return || overflow_event) reader_error<=ERR_OVERFLOW;
                else if (response_timeout) reader_error<=ERR_TIMEOUT;
                else if (bad_length || request_timeout) reader_error<=ERR_REQUEST;
                else if (frame_overrun) reader_error<=ERR_OVERRUN;
                else if (underflow_sync[1]) reader_error<=ERR_UNDERFLOW;
            end
            if (unexpected_return || overflow_event) debug_read_overflow<=1;

            // The last command updates issued_words on its clock edge. Wait
            // one further edge to register the remaining target, and require
            // this registered validity before granting. Even a configured
            // zero gap therefore cannot re-use the preceding burst's plan.
            if (state != RUN || request_sync[2]) begin
                plan_valid<=0;
                planned_words<=0;
                plan_window_budget<=0;plan_fifo_budget<=0;plan_fits_fifo<=0;
            end else if (!command_active && !plan_valid && issued_words < frame_length) begin
                if (remaining_words >= BURST_SIZE) begin
                    planned_words<=BURST_SIZE;
                    plan_window_budget<=WINDOW_LIMIT-BURST_SIZE;
                    plan_fifo_budget<=FIFO_LIMIT-BURST_SIZE;
                    plan_fits_fifo<=BURST_SIZE<=FIFO_LIMIT;
                end else begin
                    planned_words<=remaining_words[BURST_BITS-1:0];
                    plan_window_budget<=WINDOW_LIMIT-remaining_words[BURST_BITS-1:0];
                    plan_fifo_budget<=FIFO_LIMIT-remaining_words[BURST_BITS-1:0];
                    plan_fits_fifo<=remaining_words[BURST_BITS-1:0]<=FIFO_LIMIT;
                end
                plan_valid<=1;
            end

            case ({grant,expected_return})
                2'b10: reserved_words<=reserved_words+next_burst_words;
                2'b01: reserved_words<=reserved_words-1'b1;
                2'b11: reserved_words<=reserved_words+next_burst_words-1'b1;
                default: reserved_words<=reserved_words;
            endcase
            if (grant) begin
                plan_valid<=0;
                command_active<=1;
                command_target<=next_burst_words;
                command_count<=0;
            end
            if (App_rd_en) begin
                issued_words<=issued_words+1'b1;
                command_count<=command_count+1'b1;
                if (command_count == command_target-1'b1) begin
                    command_active<=0;
                    gap_count<=BURST_GAP_CYCLES;
                end
            end
            if (expected_return) begin
                returned_words<=returned_words+1'b1;
                if (state == RUN && !request_sync[2] && returned_words+1'b1 == frame_length)
                    read_finish<=1;
            end

            case (state)
                WAIT_REQ: begin
                    read_req_ack<=0;
                    if (request_sync[2] && Sdr_init_done) begin
                        pending_frame<=1;
                        pending_index<=requested_bank;
                        pending_token<=requested_token;
                        pending_length<=(RGB565_ENABLE && !thumbnail_selected) ? (len_sync >> 1) : len_sync;
                        pending_view<=thumbnail_selected;
                        pending_page<=thumbnail_page_selected;
                        pending_base<=requested_end ? END_BASE_ADDR : requested_boot ? START_BASE_ADDR :
                                      (thumbnail_selected ? thumbnail_base : select_base(requested_bank));
                        pending_boot<=requested_boot;pending_end<=requested_end;
                        state<=DRAIN;
                    end
                end
                DRAIN: begin
                    // Finish an already granted command train and discard all
                    // its responses. There is no fabricated timeout completion.
                    if (!burst_busy) begin
                        fifo_clear<=1;
                        clear_count<=4;
                        state<=FLUSH;
                    end
                end
                FLUSH: begin
                    if (clear_count == 0) begin fifo_clear<=0; state<=RELEASE; end
                    else clear_count<=clear_count-1'b1;
                end
                RELEASE: begin
                    if (fifo_wr_done && fifo_rd_done_sync[1]) begin
                        if (pending_frame && pending_length != 0) begin
                            reader_index<=pending_index;
                            reader_view<=pending_view;
                            reader_page<=pending_page;reader_boot<=pending_boot;reader_end<=pending_end;
                            frame_base<=pending_base;
                            frame_length<=cfg_zoom_ok?cfg_length:pending_length;
                            issued_words<=0; returned_words<=0;
                            read_req_ack<=1;
                            state<=ACK;
                        end else begin pending_frame<=0; state<=WAIT_REQ; end
                    end
                end
                ACK: begin
                    if (!request_sync[2]) begin
                        read_req_ack<=0;
                        // The request payload was frozen before old data drain;
                        // a later user switch waits for the next frame boundary.
                        read_switch_ack_idx<=pending_index;
                        read_switch_ack_toggle<=pending_token;
                        ready_toggle<=~ready_toggle;
                        pending_frame<=0;
                        state<=RUN;
                    end
                end
                RUN: begin
                    if (request_sync[2]) begin
                        pending_frame<=1;
                        pending_index<=requested_bank;
                        pending_token<=requested_token;
                        pending_length<=(RGB565_ENABLE && !thumbnail_selected) ? (len_sync >> 1) : len_sync;
                        pending_view<=thumbnail_selected;
                        pending_page<=thumbnail_page_selected;
                        pending_base<=requested_end ? END_BASE_ADDR : requested_boot ? START_BASE_ADDR :
                                      (thumbnail_selected ? thumbnail_base : select_base(requested_bank));
                        pending_boot<=requested_boot;pending_end<=requested_end;
                        state<=DRAIN;
                    end else if (response_timeout || overflow_event || unexpected_return) begin
                        pending_frame<=0;
                        state<=DRAIN;
                    end
                end
                default: state<=WAIT_REQ;
            endcase
        end
    end

    // Use the saved, generated, protected Soft_FIFO v3 without parameter or
    // source changes. Its standard mode exports valid with the BRAM data.
    rfifo_32_32_512 u_read_fifo (
        .rst(fifo_reset), .clkw(mem_clk), .clkr(read_clk),
        .we(fifo_write), .di(Sdr_rd_dout), .re(fifo_raw_read),
        .dout(fifo_raw_data), .valid(fifo_raw_valid),
        .full_flag(fifo_full), .empty_flag(fifo_empty),
        .afull(), .aempty(), .wrusedw(fifo_wr_count), .rdusedw(),
        .wr_rst_done(fifo_wr_done), .rd_rst_done(fifo_rd_done),
        .overflow(), .underflow(), .wr_success()
    );
    fifo_prefetch_2 #(.DATA_WIDTH(32)) u_prefetch (
        .clk(read_clk), .rst(fifo_reset),
        .raw_empty(fifo_empty || !fifo_rd_done), .raw_valid(fifo_raw_valid),
        .raw_data(fifo_raw_data), .raw_read_en(fifo_raw_read),
        .consume(consume_word),
        .out_valid(prefetch_valid), .out_empty(), .out_data(prefetch_data)
    );
endmodule
