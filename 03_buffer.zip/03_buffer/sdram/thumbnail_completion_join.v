`timescale 1ns/1ps
// Publish a loaded bank only after BOTH immutable image representations have
// drained to SDRAM. This prevents the next start cancelling a trailing tile.
module thumbnail_completion_join #(parameter integer BANK_BITS=2) (
    input wire clk,rst,start,abort,source_done,
    input wire [BANK_BITS-1:0] bank,
    input wire full_finish_toggle,
    input wire [(1<<BANK_BITS)-1:0] thumbnail_complete,
    output reg finish_toggle
);
    (* ASYNC_REG="TRUE" *) reg [2:0] full_sync;
    reg full_seen,active,full_done,source_ok;
    reg [BANK_BITS-1:0] active_bank;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            full_sync<=0;full_seen<=0;active<=0;full_done<=0;source_ok<=0;
            active_bank<=0;finish_toggle<=0;
        end else begin
            full_sync<={full_sync[1:0],full_finish_toggle};
            full_seen<=full_sync[2];
            if(abort) begin active<=0;full_done<=0;source_ok<=0;end
            else if(start) begin
                active<=1;active_bank<=bank;full_done<=0;source_ok<=0;
            end else if(active) begin
                // The real loader cannot finish until its source_done has
                // crossed into MEM. Ignore any old finish token still in the
                // CDC pipeline after an aborted/new session.
                if((source_ok || source_done) && full_sync[2]!=full_seen) full_done<=1;
                if(source_done) source_ok<=1;
                if(full_done && source_ok && thumbnail_complete[active_bank]) begin
                    finish_toggle<=~finish_toggle;active<=0;
                end
            end
        end
    end
endmodule
