`timescale 1ns/1ps
// The native write FIFO is show-ahead, 32 bits x 512 words. Only RGB words
// cross this FIFO; all per-frame metadata uses the loader's held handshake.
module media_sdram_write_cdc #(
    parameter integer DATA_BITS = 32
)(
    input wire rst, input wire write_rst,
    input wire write_clk, input wire mem_clk, input wire fifo_aclr,
    input wire write_en, input wire [DATA_BITS-1:0] write_data,
    input wire mem_read_en,
    output wire [DATA_BITS-1:0] mem_data,
    output wire [9:0] mem_count,
    output wire src_full, output wire mem_empty,
    output wire src_ready, output wire mem_ready, output wire src_accept,
    output wire mem_ready_no_global_reset,
    output reg debug_overflow, output reg debug_underflow
);
    wire fifo_reset = rst | write_rst | fifo_aclr;
    wire wr_rst_done, rd_rst_done;
    reg src_ready_q;
    (* ASYNC_REG = "TRUE" *) reg [1:0] wr_ready_sync;
    // Assert the source inhibit immediately on any native FIFO clear, but
    // release it only on write_clk after the native write reset is complete.
    // Never place the memory-domain clear/reset on the producer's ready/CE
    // combinational path. Full remains the native write-domain indication.
    always @(posedge write_clk or posedge fifo_reset) begin
        if(fifo_reset) src_ready_q<=1'b0;
        else src_ready_q<=wr_rst_done;
    end
    assign src_ready = src_ready_q;
    assign mem_ready = rd_rst_done && wr_ready_sync[1] && !fifo_reset;
    // Only consume this inside a process whose reset branch excludes rst/write_rst.
    // Keep per-session FIFO clear qualified; public mem_ready is unchanged.
    assign mem_ready_no_global_reset = rd_rst_done && wr_ready_sync[1] && !fifo_aclr;
    assign src_accept = write_en && src_ready && !src_full;
    wfifo_32_32_512 u_fifo (
        .rst(fifo_reset), .di(write_data), .clkw(write_clk), .clkr(mem_clk),
        .we(src_accept), .re(mem_read_en), .dout(mem_data),
        .empty_flag(mem_empty), .full_flag(src_full), .rdusedw(mem_count),
        .wrusedw(), .wr_rst_done(wr_rst_done), .rd_rst_done(rd_rst_done),
        .valid(), .aempty(), .afull(), .overflow(), .underflow(), .wr_success()
    );
    always @(posedge mem_clk or posedge rst or posedge write_rst) begin
        if(rst || write_rst) begin wr_ready_sync<=0;debug_underflow<=0;end
        else begin
            // The memory ACK must also wait for the qualified source ready,
            // including its additional write-clock release cycle.
            wr_ready_sync <= {wr_ready_sync[0],src_ready_q};
            if(mem_read_en && (mem_empty || !mem_ready)) debug_underflow<=1;
        end
    end
    always @(posedge write_clk or posedge rst or posedge write_rst) begin
        if(rst || write_rst) debug_overflow<=0;
        else if(write_en && (!src_ready || src_full)) debug_overflow<=1;
    end
endmodule
