`timescale 1ns/1ps
// Builds one atlas while frames load: eight 128x96 (BANK_BITS=3) or four
// legacy 160x120 RGB888 previews. Both fit a single 640x480 SDRAM canvas.
// Source pixels are the accepted, bottom-up 640x480 stream used by the existing
// V-flipping full-frame writer. No full-frame or published preview is read back.
module thumbnail_cache_writer #(
    parameter integer BANK_BITS=2,
    parameter integer ADDR_BITS=21,
    parameter integer WIDTH=640, HEIGHT=480,
    parameter integer MEM_CLK_HZ=100000000,
    parameter [ADDR_BITS-1:0] BASE_ADDR=1228800,
    parameter integer STALL_TIMEOUT_CYCLES=MEM_CLK_HZ*5
)(
    input wire rst, input wire write_rst,
    input wire mem_clk, input wire write_clk,
    input wire capture_start, input wire [BANK_BITS-1:0] capture_bank,
    input wire capture_en, input wire [23:0] capture_rgb,
    input wire capture_done, input wire capture_abort,
    output wire capture_ready,
    output reg [(1<<BANK_BITS)-1:0] complete_mask,
    output reg [7:0] error,
    input wire Sdr_init_done, input wire Sdr_init_ref_vld, input wire Sdr_busy,
    output wire burst_request, input wire burst_grant, output wire burst_busy,
    output wire App_wr_en, output wire [ADDR_BITS-1:0] App_wr_addr,
    output wire [31:0] App_wr_din, output wire [3:0] App_wr_dm
);
    localparam integer FRAME_WORDS=WIDTH*HEIGHT;
    localparam integer THUMB_WIDTH=(BANK_BITS==3)?128:160;
    localparam integer THUMB_HEIGHT=(BANK_BITS==3)?96:120;
    localparam integer THUMB_WORDS=THUMB_WIDTH*THUMB_HEIGHT;
    localparam integer TIMER_BITS=STALL_TIMEOUT_CYCLES<2 ? 1 : $clog2(STALL_TIMEOUT_CYCLES);
    localparam [7:0] ERR_NOT_READY=8'h81, ERR_INPUT_COUNT=8'h82,
                     ERR_SAMPLE_COUNT=8'h83, ERR_UNDERFLOW=8'h84,
                     ERR_STALL=8'h85;
    localparam [1:0] M_CLEAR=0, M_RELEASE=1, M_IDLE=2, M_ACTIVE=3;
    wire reset_all=rst | write_rst;

    // A pending start cancels the previous session, waits for its safe tail,
    // then launches one held mailbox. New data is barred until its matching
    // memory ACK and both native FIFO reset domains have become ready.
    reg src_pending, src_active, src_commit, src_cancel;
    reg [BANK_BITS-1:0] pending_bank, src_bank;
    reg request_toggle;
    reg [18:0] input_count;
    reg [14:0] sample_count;
    reg [9:0] source_x;
    reg [8:0] source_y;
    reg [2:0] sample_x_phase,sample_y_phase;
    (* ASYNC_REG="TRUE" *) reg [2:0] ack_sync, done_sync, error_sync;
    (* ASYNC_REG="TRUE" *) reg [1:0] idle_sync;
    (* ASYNC_REG="TRUE" *) reg [BANK_BITS-1:0] done_bank_meta, done_bank_sync;
    (* ASYNC_REG="TRUE" *) reg done_epoch_meta, done_epoch_sync;
    (* ASYNC_REG="TRUE" *) reg error_epoch_meta, error_epoch_sync;
    (* ASYNC_REG="TRUE" *) reg [7:0] error_code_meta, error_code_sync;

    reg [1:0] mem_state;
    reg [3:0] clear_count;
    reg start_pending_mem;
    reg ack_toggle, done_toggle, error_toggle;
    reg [BANK_BITS-1:0] done_bank;
    reg done_epoch, error_epoch;
    reg [7:0] error_code;
    reg request_seen, active_epoch;
    reg [BANK_BITS-1:0] active_bank;
    (* ASYNC_REG="TRUE" *) reg [2:0] request_sync, commit_sync, cancel_sync;
    (* ASYNC_REG="TRUE" *) reg [BANK_BITS-1:0] bank_meta, bank_sync;
    reg command_active, abort_pending;
    reg [5:0] command_left;
    reg [1:0] tail_count;
    reg [14:0] words_written;
    reg [7:0] thumb_x;
    reg [ADDR_BITS-1:0] write_address;
    localparam [ADDR_BITS-1:0] THUMB_ROW_JUMP=WIDTH+THUMB_WIDTH-1;
    localparam [ADDR_BITS-1:0] THUMB_ROW_STEP={ADDR_BITS{1'b0}}-THUMB_ROW_JUMP;
    wire [ADDR_BITS-1:0] write_addr_step=(thumb_x==THUMB_WIDTH-1) ?
                                        THUMB_ROW_STEP : {{(ADDR_BITS-1){1'b0}},1'b1};
    reg [TIMER_BITS-1:0] stall_count;
    // Register the idle indication in its source domain before synchronizing
    // it. A combinational binary-state decoder could otherwise glitch.
    reg mem_idle;
    wire fifo_clear=mem_state==M_CLEAR;
    wire fifo_full, fifo_empty, fifo_src_ready, fifo_mem_ready, fifo_accept;
    wire fifo_mem_ready_no_global_reset;
    wire [9:0] fifo_count;
    // Only the watchdog uses this one-cycle occupancy summary. Keep actual
    // burst reservation, SDRAM/FIFO pop and final completion on live signals.
    // This breaks count-reduction -> timeout -> state-priority at 100 MHz.
    reg fifo_has_data_q;
    always @(posedge mem_clk or posedge reset_all) begin
        if(reset_all) fifo_has_data_q<=1'b0;
        else if(fifo_clear) fifo_has_data_q<=1'b0;
        else fifo_has_data_q<=fifo_count!=0;
    end
    wire fifo_overflow, fifo_underflow;
    // Bottom-up source: y mod5=4 maps to top-down y mod5=0. Phase counters
    // replace division/modulo hardware and advance only on accepted pixels.
    wire selected_pixel=(BANK_BITS==3) ? (sample_x_phase==0 && sample_y_phase==4) :
                                                   (source_x[1:0]==0 && source_y[1:0]==3);
    wire accepted=capture_en && capture_ready;
    // The source-state branches below already exclude start/abort/pending and
    // input overrun. Reuse only the remaining transport conditions there,
    // rather than feeding the producer's ready -> valid path back into ready.
    wire capture_transport_ready=!src_commit && !src_cancel &&
                                 ack_sync[2]==request_toggle && fifo_src_ready &&
                                 (!selected_pixel || !fifo_full);
    assign capture_ready=src_active && !src_pending && !capture_start && !capture_abort &&
                         input_count<FRAME_WORDS && capture_transport_ready;
    wire sample_en=accepted && selected_pixel;

    assign burst_busy=command_active || tail_count!=0;
    assign burst_request=mem_state==M_ACTIVE && !command_active && tail_count==0 &&
                         !abort_pending && !cancel_sync[2] && fifo_mem_ready &&
                         fifo_count>=32 && words_written<THUMB_WORDS &&
                         Sdr_init_done && !Sdr_init_ref_vld && !Sdr_busy;
    assign App_wr_en=command_active && fifo_mem_ready && !fifo_empty &&
                     Sdr_init_done && !Sdr_init_ref_vld && !reset_all;
    // Same accepted write as App_wr_en whenever reset_all is false.
    // Only used by the existing non-reset mem-clock branch. Public FIFO pop
    // and SDRAM write enable retain their immediate asynchronous reset masks.
    wire internal_write_fire=command_active && fifo_mem_ready_no_global_reset &&
                             !fifo_empty && Sdr_init_done && !Sdr_init_ref_vld;
    assign App_wr_addr=write_address;
    assign App_wr_dm=4'b0000;
    wire underflow_event=command_active && !Sdr_init_ref_vld && Sdr_init_done &&
                         (!fifo_mem_ready_no_global_reset || fifo_empty);
    wire timeout_event=mem_state==M_ACTIVE && !abort_pending &&
                       (fifo_has_data_q || commit_sync[2]) && !internal_write_fire &&
                       stall_count==STALL_TIMEOUT_CYCLES-1;

    function [ADDR_BITS-1:0] tile_last_row_base;
        input [BANK_BITS-1:0] bank;
        begin
            if(BANK_BITS==3) begin
                case(bank)
                    0:tile_last_row_base=BASE_ADDR+(112+95)*WIDTH+40;
                    1:tile_last_row_base=BASE_ADDR+(112+95)*WIDTH+184;
                    2:tile_last_row_base=BASE_ADDR+(112+95)*WIDTH+328;
                    3:tile_last_row_base=BASE_ADDR+(112+95)*WIDTH+472;
                    4:tile_last_row_base=BASE_ADDR+(256+95)*WIDTH+40;
                    5:tile_last_row_base=BASE_ADDR+(256+95)*WIDTH+184;
                    6:tile_last_row_base=BASE_ADDR+(256+95)*WIDTH+328;
                    default:tile_last_row_base=BASE_ADDR+(256+95)*WIDTH+472;
                endcase
            end else case(bank[1:0])
                0:tile_last_row_base=BASE_ADDR+((bank>>2)*FRAME_WORDS)+(112+119)*WIDTH+128;
                1:tile_last_row_base=BASE_ADDR+((bank>>2)*FRAME_WORDS)+(112+119)*WIDTH+352;
                2:tile_last_row_base=BASE_ADDR+((bank>>2)*FRAME_WORDS)+(272+119)*WIDTH+128;
                default:tile_last_row_base=BASE_ADDR+((bank>>2)*FRAME_WORDS)+(272+119)*WIDTH+352;
            endcase
        end
    endfunction

    initial begin
        if(WIDTH!=640 || HEIGHT!=480 || ADDR_BITS<21 || MEM_CLK_HZ<=0 ||
           (BANK_BITS!=2 && BANK_BITS!=3) || STALL_TIMEOUT_CYCLES<2 || BASE_ADDR<4*FRAME_WORDS ||
           {1'b0,BASE_ADDR}+FRAME_WORDS>(64'd1<<ADDR_BITS)) begin
            $display("THUMBNAIL_WRITER_CONFIG_ERROR"); $finish;
        end
    end

    media_sdram_write_cdc #(.DATA_BITS(32)) u_write_cdc(
        .rst(rst),.write_rst(write_rst),.write_clk(write_clk),.mem_clk(mem_clk),
        .fifo_aclr(fifo_clear),.write_en(sample_en),.write_data({capture_rgb,8'h00}),
        .mem_read_en(App_wr_en),.mem_data(App_wr_din),.mem_count(fifo_count),
        .src_full(fifo_full),.mem_empty(fifo_empty),
        .src_ready(fifo_src_ready),.mem_ready(fifo_mem_ready),.src_accept(fifo_accept),
        .mem_ready_no_global_reset(fifo_mem_ready_no_global_reset),
        .debug_overflow(fifo_overflow),.debug_underflow(fifo_underflow)
    );

    always @(posedge write_clk or posedge reset_all) begin
        if(reset_all) begin
            src_pending<=0;src_active<=0;src_commit<=0;src_cancel<=0;
            pending_bank<=0;src_bank<=0;request_toggle<=0;
            input_count<=0;sample_count<=0;source_x<=0;source_y<=0;
            sample_x_phase<=0;sample_y_phase<=0;
            complete_mask<=0;error<=0;
            ack_sync<=0;done_sync<=0;error_sync<=0;idle_sync<=0;
            done_bank_meta<=0;done_bank_sync<=0;done_epoch_meta<=0;done_epoch_sync<=0;
            error_epoch_meta<=0;error_epoch_sync<=0;error_code_meta<=0;error_code_sync<=0;
        end else begin
            ack_sync<={ack_sync[1:0],ack_toggle};
            done_sync<={done_sync[1:0],done_toggle};
            error_sync<={error_sync[1:0],error_toggle};
            idle_sync<={idle_sync[0],mem_idle};
            done_bank_meta<=done_bank;done_bank_sync<=done_bank_meta;
            done_epoch_meta<=done_epoch;done_epoch_sync<=done_epoch_meta;
            error_epoch_meta<=error_epoch;error_epoch_sync<=error_epoch_meta;
            error_code_meta<=error_code;error_code_sync<=error_code_meta;
            if(capture_abort) begin
                src_active<=0;src_pending<=0;src_commit<=0;src_cancel<=1;
            end else if(capture_start) begin
                // One coalescing pending start is sufficient: the producer
                // cannot send its new frame until capture_ready acknowledges it.
                pending_bank<=capture_bank;src_pending<=1;src_active<=0;
                src_commit<=0;src_cancel<=1;complete_mask[capture_bank]<=0;error<=0;
                input_count<=0;sample_count<=0;source_x<=0;source_y<=0;
                sample_x_phase<=0;sample_y_phase<=0;
            end else if(src_pending) begin
                if(idle_sync[1] && ack_sync[2]==request_toggle) begin
                    src_bank<=pending_bank;request_toggle<=~request_toggle;
                    src_pending<=0;src_active<=1;src_cancel<=0;src_commit<=0;
                    input_count<=0;sample_count<=0;source_x<=0;source_y<=0;
                    sample_x_phase<=0;sample_y_phase<=0;
                end
            end else if(src_active) begin
                if(error_sync[2]!=error_sync[1] && error_epoch_sync==request_toggle) begin
                    if(error==0) error<=error_code_sync;
                    src_active<=0;src_commit<=0;src_cancel<=1;
                end else if(src_commit) begin
                    // Commit is set only after both exact final counts pass.
                    // Thus input_count==FRAME_WORDS and sample_count==THUMB_WORDS
                    // throughout this branch. Preserve overrun/error priority,
                    // while completion no longer traverses the pixel handshake.
                    if(capture_en) begin
                        error<=ERR_INPUT_COUNT;src_active<=0;src_commit<=0;src_cancel<=1;
                    end else if(done_sync[2]!=done_sync[1] && done_epoch_sync==request_toggle &&
                                done_bank_sync==src_bank) begin
                        complete_mask[src_bank]<=1;src_active<=0;src_commit<=0;
                    end
                end else if(capture_en && input_count>=FRAME_WORDS) begin
                    error<=ERR_INPUT_COUNT;src_active<=0;src_commit<=0;src_cancel<=1;
                end else if(capture_en && !capture_transport_ready) begin
                    error<=ERR_NOT_READY;src_active<=0;src_commit<=0;src_cancel<=1;
                // The preceding ERR_NOT_READY branch has already excluded
                // capture_en && !capture_ready. Here accepted==capture_en;
                // avoid feeding the ready handshake back through count checks.
                end else if(capture_done &&
                            (capture_en ? input_count!=FRAME_WORDS-1 : input_count!=FRAME_WORDS)) begin
                    error<=ERR_INPUT_COUNT;src_active<=0;src_commit<=0;src_cancel<=1;
                end else if(capture_done &&
                            ((capture_en && selected_pixel) ? sample_count!=THUMB_WORDS-1 : sample_count!=THUMB_WORDS)) begin
                    error<=ERR_SAMPLE_COUNT;src_active<=0;src_commit<=0;src_cancel<=1;
                end else begin
                    if(capture_en) begin
                        input_count<=input_count+1'b1;
                        if(source_x==WIDTH-1) begin
                            source_x<=0;source_y<=source_y+1'b1;sample_x_phase<=0;
                            sample_y_phase<=(sample_y_phase==4)?3'd0:sample_y_phase+1'b1;
                        end else begin
                            source_x<=source_x+1'b1;
                            sample_x_phase<=(sample_x_phase==4)?3'd0:sample_x_phase+1'b1;
                        end
                    end
                    if(capture_en && selected_pixel) sample_count<=sample_count+1'b1;
                    if(capture_done) src_commit<=1;
                end
            end
        end
    end

    always @(posedge mem_clk or posedge reset_all) begin
        if(reset_all) begin
            mem_state<=M_CLEAR;mem_idle<=0;clear_count<=7;start_pending_mem<=0;
            ack_toggle<=0;done_toggle<=0;error_toggle<=0;
            done_bank<=0;done_epoch<=0;error_epoch<=0;error_code<=0;
            request_seen<=0;active_epoch<=0;active_bank<=0;
            request_sync<=0;commit_sync<=0;cancel_sync<=0;bank_meta<=0;bank_sync<=0;
            command_active<=0;abort_pending<=0;command_left<=0;tail_count<=0;
            words_written<=0;thumb_x<=0;write_address<=BASE_ADDR;stall_count<=0;
        end else begin
            request_sync<={request_sync[1:0],request_toggle};
            commit_sync<={commit_sync[1:0],src_commit};
            cancel_sync<={cancel_sync[1:0],src_cancel};
            bank_meta<=src_bank;bank_sync<=bank_meta;
            if(tail_count!=0) tail_count<=tail_count-1'b1;
            if(mem_state!=M_ACTIVE || internal_write_fire || abort_pending ||
               (!fifo_has_data_q && !commit_sync[2])) stall_count<=0;
            else if(stall_count!=STALL_TIMEOUT_CYCLES-1) stall_count<=stall_count+1'b1;

            if(burst_request && burst_grant) begin command_active<=1;command_left<=32;end
            if(internal_write_fire) begin
                words_written<=words_written+1'b1;
                if(thumb_x==THUMB_WIDTH-1) thumb_x<=0;
                else thumb_x<=thumb_x+1'b1;
                write_address<=write_address+write_addr_step;
                if(command_left==1) begin command_active<=0;command_left<=0;tail_count<=2;end
                else command_left<=command_left-1'b1;
            end
            if(mem_state==M_ACTIVE) begin
                if(cancel_sync[2]) abort_pending<=1;
                if((underflow_event || timeout_event) && !abort_pending && !cancel_sync[2]) begin
                    error_code<=underflow_event ? ERR_UNDERFLOW : ERR_STALL;
                    error_epoch<=active_epoch;error_toggle<=~error_toggle;
                    abort_pending<=1;command_active<=0;
                    // A denied grant owns no train and needs no invented tail.
                    // Only an interrupted, already-owned train must retire it.
                    if(command_active) tail_count<=2;
                end
            end
            case(mem_state)
                M_CLEAR: begin
                    if(clear_count==0) mem_state<=M_RELEASE;
                    else clear_count<=clear_count-1'b1;
                end
                M_RELEASE: begin
                    if(fifo_mem_ready) begin
                        if(start_pending_mem) begin
                            // Even a request cancelled before its first pixel
                            // must be acknowledged, otherwise a queued retry
                            // would wait forever for the retired mailbox.
                            ack_toggle<=active_epoch;start_pending_mem<=0;abort_pending<=0;
                            if(cancel_sync[2]) begin mem_state<=M_IDLE;mem_idle<=1;end
                            else begin
                                words_written<=0;thumb_x<=0;
                                write_address<=tile_last_row_base(active_bank);
                                mem_state<=M_ACTIVE;
                            end
                        end else if(!start_pending_mem) begin mem_state<=M_IDLE;mem_idle<=1;end
                    end
                end
                M_IDLE: begin
                    if(request_sync[2]!=request_seen) begin
                        request_seen<=request_sync[2];active_epoch<=request_sync[2];
                        active_bank<=bank_sync;start_pending_mem<=1;
                        clear_count<=7;mem_state<=M_CLEAR;mem_idle<=0;stall_count<=0;
                    end
                end
                M_ACTIVE: begin
                    if((abort_pending || cancel_sync[2]) && !burst_busy) begin
                        start_pending_mem<=0;clear_count<=7;mem_state<=M_CLEAR;
                        abort_pending<=0;stall_count<=0;
                    end else if(!abort_pending && !cancel_sync[2] && !underflow_event &&
                                !timeout_event && commit_sync[2] && words_written==THUMB_WORDS &&
                                fifo_count==0 && fifo_empty && !burst_busy) begin
                        done_bank<=active_bank;done_epoch<=active_epoch;done_toggle<=~done_toggle;
                        mem_state<=M_IDLE;mem_idle<=1;stall_count<=0;
                    end
                end
                default:begin start_pending_mem<=0;clear_count<=7;mem_state<=M_CLEAR;mem_idle<=0;end
            endcase
        end
    end
endmodule
