`timescale 1ns/1ps
// Independent SD/BMP -> SDRAM writer. The inherited command sequencer keeps
// its validated show-ahead timing, row reversal and refresh behavior. A bank
// is published only after BOTH the checked source and every FIFO word finish.
module media_frame_loader #(
    parameter integer MEM_DATA_BITS=32, WRITE_DATA_BITS=32, ADDR_BITS=21,
    parameter integer BURST_BITS=9, BURST_SIZE=128,
    parameter integer WRITE_V_FLIP=1, FRAME_WIDTH=640, FRAME_HEIGHT=480,
    parameter integer STALL_TIMEOUT=500000000,
    parameter integer BANK_BITS=2, RGB565_ENABLE=0, START_PAGE_ENABLE=0,
    parameter [ADDR_BITS-1:0] START_BASE_ADDR=1536000,
    parameter integer END_PAGE_ENABLE=0,
    parameter [ADDR_BITS-1:0] END_BASE_ADDR=1689600
)(
    input wire rst, input wire write_rst, input wire mem_clk,
    input wire Sdr_init_done, input wire Sdr_init_ref_vld, input wire Sdr_busy,
    output wire App_wr_en, output wire [ADDR_BITS-1:0] App_wr_addr,
    output wire [MEM_DATA_BITS-1:0] App_wr_din, output wire [3:0] App_wr_dm,
    input wire write_clk, input wire write_req, output wire write_req_ack,
    output reg write_finish,
    input wire [ADDR_BITS-1:0] write_addr_0, write_addr_1, write_addr_2, write_addr_3,
    input wire [ADDR_BITS-1:0] write_addr_4, write_addr_5, write_addr_6, write_addr_7,
    input wire [BANK_BITS-1:0] write_addr_index, input wire write_is_start,input wire write_is_end,
    input wire [ADDR_BITS-1:0] write_len,
    input wire write_en, input wire [WRITE_DATA_BITS-1:0] write_data,
    output wire write_ready,
    input wire source_done, input wire load_abort,
    output wire load_busy, output reg [(1<<BANK_BITS)-1:0] image_complete,
    output reg [7:0] memory_error,
    output wire burst_request, output wire burst_busy, input wire burst_grant,
    output wire [9:0] debug_write_count,
    output wire debug_write_full, output wire debug_write_empty,
    output wire debug_write_overflow, output wire debug_write_underflow
);
    localparam [7:0] ERR_NOT_ACTIVE=8'h61, ERR_OVERFLOW=8'h62,
        ERR_PIXEL_COUNT=8'h63, ERR_UNDERFLOW=8'h64,
        ERR_SHORT_FRAME=8'h65, ERR_STALL=8'h66;
    wire core_ack, core_finish, core_clear, core_write_en;
    wire core_request, core_busy, src_ready, mem_ready, src_accept;
    reg ack_hold;
    reg [3:0] abort_flush;
    wire writer_reset=rst | write_rst | (abort_flush!=0);
    wire fifo_clear=core_clear | (abort_flush!=0);
    reg src_req_previous, src_active, src_commit, src_cancel, src_boot;
    reg [BANK_BITS-1:0] src_bank;
    reg [ADDR_BITS:0] src_received;
    reg [ADDR_BITS-1:0] src_length;
    reg [ADDR_BITS-1:0] src_last_index;
    reg mem_done_toggle, mem_error_toggle;
    reg [BANK_BITS-1:0] mem_done_bank;
    reg [7:0] mem_error_code;
    (* ASYNC_REG = "TRUE" *) reg [2:0] done_sync, error_sync;
    reg [7:0] error_code_d0, error_code_d1;
    reg [BANK_BITS-1:0] done_bank_d0, done_bank_d1;
    (* ASYNC_REG = "TRUE" *) reg [2:0] commit_sync, cancel_sync;
    reg [ADDR_BITS:0] received_d0, received_d1;
    reg [ADDR_BITS-1:0] length_d0, length_d1;
    reg [BANK_BITS-1:0] bank_d0, bank_d1;
    reg mem_active, core_ack_previous, finish_seen, abort_pending;
    reg [ADDR_BITS:0] words_written;
    reg [ADDR_BITS-1:0] frame_length;
    reg [BANK_BITS-1:0] frame_bank;
    reg [31:0] stall_count;
    localparam [31:0] STALL_LIMIT = STALL_TIMEOUT-1;
    // Exact predicate of the CURRENT count. Maintain it beside every count
    // update so the error/abort path no longer includes a wide comparator.
    // Increment is allowed only below LIMIT; its successor reaches LIMIT iff
    // the old count equals LIMIT-1. No timeout cycle or priority is changed.
    reg stall_limit_reached;
    // External lengths/counts stay in pixels. Only the SDRAM side changes to
    // two RGB565 pixels per word, first/even pixel in the low halfword.
    wire [ADDR_BITS-1:0] memory_length = RGB565_ENABLE ? (write_len >> 1) : write_len;
    wire [ADDR_BITS:0] expected_pixels = RGB565_ENABLE ?
        {frame_length,1'b0} : {1'b0,frame_length};
    wire [15:0] pixel565 = {write_data[31:27],write_data[23:18],write_data[15:11]};
    reg [15:0] first_pixel565;
    reg half_valid;
    wire [31:0] memory_data = RGB565_ENABLE ? {pixel565,first_pixel565} : write_data;
    wire memory_write = write_en && src_active && !src_cancel &&
                        (!RGB565_ENABLE || half_valid);
    wire memory_accept;
    assign load_busy=src_active;
    // The scaled producer may repeat rows much faster than the card delivers
    // bytes. Apply true source-clock FIFO backpressure, never drop a pixel.
    assign write_ready=src_active && !src_cancel && src_ready && !debug_write_full;
    assign src_accept=write_en && write_ready;
    // ACK stays asserted until BOTH native FIFO reset domains are ready.
    // The BMP parser must continue waiting for returned ACK to FALL before
    // sending its first word; equal-frequency independent PLLs are asynchronous.
    assign write_req_ack=core_ack | ack_hold;
    assign App_wr_en=core_write_en;
    assign App_wr_dm=4'b0000;
    assign burst_request=core_request && mem_active && !abort_pending &&
                         !cancel_sync[2] && abort_flush==0 && mem_ready;
    assign burst_busy=core_busy;
    media_sdram_write_cdc #(.DATA_BITS(WRITE_DATA_BITS)) u_write_cdc(
        .rst(rst),.write_rst(write_rst),.write_clk(write_clk),.mem_clk(mem_clk),
        .fifo_aclr(fifo_clear),.write_en(memory_write),
        .write_data(memory_data),.mem_read_en(core_write_en),.mem_data(App_wr_din),
        .mem_count(debug_write_count),.src_full(debug_write_full),.mem_empty(debug_write_empty),
        .src_ready(src_ready),.mem_ready(mem_ready),.mem_ready_no_global_reset(),.src_accept(memory_accept),
        .debug_overflow(debug_write_overflow),.debug_underflow(debug_write_underflow)
    );
    frame_fifo_write #(.MEM_DATA_BITS(MEM_DATA_BITS),.ADDR_BITS(ADDR_BITS),
        .BURST_BITS(BURST_BITS),.BURST_SIZE(BURST_SIZE),.WRITE_V_FLIP(WRITE_V_FLIP),
        .FRAME_WIDTH(RGB565_ENABLE ? FRAME_WIDTH/2 : FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT),.BANK_BITS(BANK_BITS),.EXTERNAL_ARBITER(1),
        .START_PAGE_ENABLE(START_PAGE_ENABLE),.START_BASE_ADDR(START_BASE_ADDR),
        .END_PAGE_ENABLE(END_PAGE_ENABLE),.END_BASE_ADDR(END_BASE_ADDR)) u_writer(
        .rst(writer_reset),.mem_clk(mem_clk),.Sdr_init_done(Sdr_init_done),
        .Sdr_init_ref_vld(Sdr_init_ref_vld),.Sdr_busy(Sdr_busy),.App_rd_busy(1'b0),.O_wr_busy(),
        .App_wr_en(core_write_en),.App_wr_addr(App_wr_addr),.write_req(write_req),
        .write_req_ack(core_ack),.write_finish(core_finish),
        .write_addr_0(write_addr_0),.write_addr_1(write_addr_1),
        .write_addr_2(write_addr_2),.write_addr_3(write_addr_3),
        .write_addr_4(write_addr_4),.write_addr_5(write_addr_5),
        .write_addr_6(write_addr_6),.write_addr_7(write_addr_7),
        .write_addr_index(write_addr_index),.write_is_start(write_is_start),.write_is_end(write_is_end),.write_len(memory_length),.fifo_aclr(core_clear),
        .rdusedw(debug_write_count),.burst_grant(burst_grant && burst_request),
        .burst_request(core_request),.burst_busy(core_busy)
    );
    always @(posedge write_clk or posedge rst or posedge write_rst) begin
        if(rst || write_rst) begin first_pixel565<=0;half_valid<=0;end
        else if((write_req && !src_req_previous) || load_abort || src_cancel || !src_active)
            half_valid<=0;
        else if(RGB565_ENABLE && src_accept) begin
            if(!half_valid) first_pixel565<=pixel565;
            half_valid<=~half_valid;
        end
    end
`ifndef SYNTHESIS
    initial begin
        if((BANK_BITS!=2 && BANK_BITS!=3) ||
           (RGB565_ENABLE && (FRAME_WIDTH%2!=0 || WRITE_DATA_BITS!=32 || MEM_DATA_BITS!=32))) begin
            $display("FRAME_LOADER_CONFIG_ERROR");$finish;
        end
    end
`endif
    always @(posedge write_clk or posedge rst or posedge write_rst) begin
        if(rst || write_rst) begin
            src_req_previous<=0;src_active<=0;src_commit<=0;src_cancel<=0;src_boot<=0;
            src_bank<=0;src_length<=0;src_last_index<=0;src_received<=0;image_complete<=0;memory_error<=0;
            done_sync<=0;error_sync<=0;error_code_d0<=0;error_code_d1<=0;
            done_bank_d0<=0;done_bank_d1<=0;
        end else begin
            src_req_previous<=write_req;
            done_sync<={done_sync[1:0],mem_done_toggle};
            error_sync<={error_sync[1:0],mem_error_toggle};
            error_code_d0<=mem_error_code;error_code_d1<=error_code_d0;
            done_bank_d0<=mem_done_bank;done_bank_d1<=done_bank_d0;
            if(write_req && !src_req_previous) begin
                src_active<=1;src_commit<=0;src_cancel<=0;src_received<=0;
                src_boot<=(START_PAGE_ENABLE!=0 && write_is_start) || (END_PAGE_ENABLE!=0 && write_is_end);
                src_bank<=write_addr_index;src_length<=write_len;src_last_index<=write_len-1'b1;
                if(!((START_PAGE_ENABLE!=0 && write_is_start) || (END_PAGE_ENABLE!=0 && write_is_end))) image_complete[write_addr_index]<=0;
                memory_error<=0;
                if(RGB565_ENABLE && write_len[0]) begin
                    src_active<=0;src_cancel<=1;memory_error<=ERR_PIXEL_COUNT;
                end
            end else begin
                if(src_active) begin
                    if(load_abort) begin
                        // A decoder/file failure already has its own player
                        // error; cancellation does not invent a memory fault.
                        src_active<=0;src_cancel<=1;src_commit<=0;
                    end else if(error_sync[2]!=error_sync[1]) begin
                        memory_error<=error_code_d1;src_active<=0;src_cancel<=1;
                    end else if(write_en && src_received>=src_length) begin
                        memory_error<=ERR_PIXEL_COUNT;src_active<=0;src_cancel<=1;
                    end else if(write_en && !src_accept) begin
                        memory_error<=ERR_OVERFLOW;src_active<=0;src_cancel<=1;
                    // Precompute the final index at request acceptance. The
                    // asynchronous FIFO ready/reset path must not traverse a
                    // count increment before selecting the short-frame error.
                    end else if(source_done && (src_accept ?
                        src_received!={1'b0,src_last_index} : src_received!={1'b0,src_length})) begin
                        memory_error<=ERR_SHORT_FRAME;src_active<=0;src_cancel<=1;
                    end else begin
                        if(src_accept) src_received<=src_received+1'b1;
                        if(source_done) src_commit<=1;
                        if(done_sync[2]!=done_sync[1]) begin
                            if(!src_boot) image_complete[done_bank_d1]<=1;
                            src_active<=0;
                        end
                    end
                end else if(write_en && !load_abort && !src_cancel && memory_error==0) begin
                    memory_error<=ERR_NOT_ACTIVE;
                end
            end
        end
    end
    always @(posedge mem_clk or posedge rst or posedge write_rst) begin
        if(rst || write_rst) begin
            commit_sync<=0;cancel_sync<=0;received_d0<=0;received_d1<=0;
            length_d0<=0;length_d1<=0;bank_d0<=0;bank_d1<=0;
            ack_hold<=0;abort_flush<=0;core_ack_previous<=0;mem_active<=0;
            finish_seen<=0;abort_pending<=0;words_written<=0;frame_length<=0;frame_bank<=0;
            stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0);write_finish<=0;mem_done_toggle<=0;mem_done_bank<=0;
            mem_error_toggle<=0;mem_error_code<=0;
        end else begin
            commit_sync<={commit_sync[1:0],src_commit};
            cancel_sync<={cancel_sync[1:0],src_cancel};
            received_d0<=src_received;received_d1<=received_d0;
            length_d0<=src_length;length_d1<=length_d0;bank_d0<=src_bank;bank_d1<=bank_d0;
            core_ack_previous<=core_ack;write_finish<=0;
            if(core_ack) ack_hold<=1;
            else if(mem_ready && !fifo_clear) ack_hold<=0;
            if(abort_flush!=0) abort_flush<=abort_flush-1'b1;
            if(core_ack && !core_ack_previous) begin
                mem_active<=1;finish_seen<=0;abort_pending<=0;words_written<=0;
                frame_length<=RGB565_ENABLE ? (length_d1 >> 1) : length_d1;
                frame_bank<=bank_d1;stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0);
            end
            if(mem_active && !core_ack) begin
                if(cancel_sync[2]) abort_pending<=1;
                if(core_finish) finish_seen<=1;
                if(core_write_en) begin words_written<=words_written+1'b1;stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0);end
                else if((burst_request || commit_sync[2]) && !abort_pending) begin
                    if(stall_limit_reached) begin
                        mem_error_code<=ERR_STALL;mem_error_toggle<=~mem_error_toggle;
                        abort_pending<=1;stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0);
                    end else begin
                        stall_count<=stall_count+1'b1;
                        stall_limit_reached<=(stall_count==STALL_LIMIT-32'd1);
                    end
                end else begin stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0); end
                if(core_write_en && (debug_write_empty || !mem_ready) && !abort_pending) begin
                    mem_error_code<=ERR_UNDERFLOW;mem_error_toggle<=~mem_error_toggle;
                    abort_pending<=1;
                end
                // A healthy burst already reserved all of its input words.
                // Cancel at its tail; never clear the native FIFO mid-burst.
                if((abort_pending || cancel_sync[2]) && !core_busy) begin
                    abort_flush<=8;mem_active<=0;abort_pending<=0;finish_seen<=0;
                end else if(!abort_pending && !cancel_sync[2] && commit_sync[2] && finish_seen &&
                            words_written==frame_length && received_d1==expected_pixels &&
                            debug_write_count==0 && debug_write_empty && !core_busy) begin
                    write_finish<=1;mem_done_toggle<=~mem_done_toggle;mem_done_bank<=frame_bank;
                    mem_active<=0;finish_seen<=0;stall_count<=0;stall_limit_reached<=(STALL_LIMIT==0);
                end
            end
        end
    end
endmodule
