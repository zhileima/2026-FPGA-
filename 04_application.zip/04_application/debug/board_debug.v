`timescale 1ns/1ps
// Passive diagnostics. Source probes never feed the functional datapath.
// Telemetry stays alive on the board's 50 MHz clock when a PLL unlocks.
module board_debug #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200,
    parameter integer REPORT_CYCLES = 5_000_000,
    parameter integer SNAPSHOT_TIMEOUT = 50_000
)(
    input ref_clk, input board_reset,
    input sd_clk, input mem_clk, input video_clk,
    input rst_sd, input rst_mem, input rst_video,
    input [7:0] ref_status,
    input [31:0] sd_status, input [31:0] mem_status,
    // V4: sampled atomically with sd_status in the existing SD handshake.
    input [63:0] stability_status,
    // V2: low 32 bits retain the video/counter layout; high 16 are
    // Route B audio diagnostics. They travel in the SAME coherent snapshot.
    input [47:0] video_status,
    // V8: pixel-domain wall clock/subtitle plus local UART RX diagnostics.
    input [95:0] osd_status, input [63:0] clock_rx_status,
    input [31:0] transition_status,
    // V10: local-domain WAV producer/consumer diagnostics.
    input [63:0] wav_wr_status, input [63:0] wav_rd_status,
    input frame_write_finish, input video_vs,
    output uart_tx_pin
);
wire dbg_rst_ref, dbg_rst_sd, dbg_rst_mem, dbg_rst_video;
reset_sync u_ref_reset(.clk(ref_clk),.async_reset(board_reset),.reset_out(dbg_rst_ref));
reset_sync u_sd_reset(.clk(sd_clk),.async_reset(board_reset),.reset_out(dbg_rst_sd));
reset_sync u_mem_reset(.clk(mem_clk),.async_reset(board_reset),.reset_out(dbg_rst_mem));
reset_sync u_video_reset(.clk(video_clk),.async_reset(board_reset),.reset_out(dbg_rst_video));

(* KEEP = "TRUE", ASYNC_REG = "TRUE" *) reg [7:0] ref_sync1, ref_sync2;
reg [7:0] ref_probe;
reg [31:0] write_frame_count, video_frame_count;
// Source-local values are frozen by debug_snapshot_cdc.src_hold_data.
// Avoid an extra free-running copy of all 496 diagnostic bits.
wire [159:0] sd_probe={wav_wr_status,stability_status,sd_status};
wire [63:0] mem_probe={write_frame_count,mem_status};
wire [271:0] video_probe={wav_rd_status,transition_status,osd_status,video_frame_count,video_status};
reg video_vs_d;
always @(posedge ref_clk or posedge dbg_rst_ref) begin
    if (dbg_rst_ref) begin ref_sync1<=0; ref_sync2<=0; ref_probe<=0; end
    else begin ref_sync1<=ref_status; ref_sync2<=ref_sync1; ref_probe<=ref_sync2; end
end
always @(posedge mem_clk or posedge dbg_rst_mem) begin
    if (dbg_rst_mem) begin write_frame_count<=0; end
    else begin
        if (rst_mem) write_frame_count<=0;
        else if (frame_write_finish) write_frame_count<=write_frame_count+1'b1;
    end
end
always @(posedge video_clk or posedge dbg_rst_video) begin
    if (dbg_rst_video) begin video_frame_count<=0; video_vs_d<=0; end
    else begin
        video_vs_d<=video_vs;
        if (rst_video) video_frame_count<=0;
        else if (video_vs_d && !video_vs) video_frame_count<=video_frame_count+1'b1;
    end
end

reg capture;
wire sd_busy,mem_busy,video_busy,sd_done,mem_done,video_done;
wire [159:0] sd_snapshot;
wire [63:0] mem_snapshot;
wire [271:0] video_snapshot;
debug_snapshot_cdc #(.WIDTH(160),.HOLD_OUTPUT(0)) u_sd_snapshot(
    .src_clk(sd_clk),.src_rst(dbg_rst_sd),.src_data(sd_probe),
    .dst_clk(ref_clk),.dst_rst(dbg_rst_ref),.capture(capture),
    .busy(sd_busy),.done(sd_done),.data(sd_snapshot));
debug_snapshot_cdc #(.WIDTH(64),.HOLD_OUTPUT(0)) u_mem_snapshot(
    .src_clk(mem_clk),.src_rst(dbg_rst_mem),.src_data(mem_probe),
    .dst_clk(ref_clk),.dst_rst(dbg_rst_ref),.capture(capture),
    .busy(mem_busy),.done(mem_done),.data(mem_snapshot));
debug_snapshot_cdc #(.WIDTH(272),.HOLD_OUTPUT(0)) u_video_snapshot(
    .src_clk(video_clk),.src_rst(dbg_rst_video),.src_data(video_probe),
    .dst_clk(ref_clk),.dst_rst(dbg_rst_ref),.capture(capture),
    .busy(video_busy),.done(video_done),.data(video_snapshot));

// Version 10: A5 5A 0A 48 seq, 72 payload bytes, XOR(0A..payload).
// Bytes0..55 retain V9;56..63=SD-domain WAV,64..71=VIDEO-domain WAV.
// Bytes0..51 retain V8;52..55 atomically append transition state/alpha/boundary/errors.
// Bytes0..31 retain V7 layout;32..43=96-bit pixel OSD;44..51=ref UART RX.
// Stability bits40..44 carry POR/locks/SDRAM-ready/TF-reset/startup-error.
// Bits45..52 carry FAT mount, SD CCS, matched slots, fragmentation, large LBA.
// Bits53..60 carry the coherent reader error; bits61..63 carry control error.
// Loader errors 0x61..0x66 use the existing stability last_error_code field.
// SD status bit 29 reports all discovered image frames cached in SDRAM.
// Original 24 bytes stay fixed; appended bytes24..31 are stability_status.
// Original bytes22..23 carry audio_status[15:0].
// V2 ref_status[2] is pixel-PLL audio_clock_ready, not a separate audio PLL.
// A qualified source snapshot stays frozen until serialization completes.
localparam integer REPORT_BITS=REPORT_CYCLES<2 ? 1 : $clog2(REPORT_CYCLES);
localparam integer TIMEOUT_BITS=SNAPSHOT_TIMEOUT<2 ? 1 : $clog2(SNAPSHOT_TIMEOUT);
reg [REPORT_BITS-1:0] report_count;
reg [TIMEOUT_BITS-1:0] timeout_count;
reg [1:0] state;
reg [2:0] got;
reg [2:0] requested;
reg [7:0] ref_packet;
reg [63:0] clock_rx_packet;
// All snapshot buses are REGISTERED in ref_clk. ACK3+consume qualifies got.
// Selected valid domains stay frozen until next report's capture; late
// unrequested domains are masked AFTER the 8-bit byte mux, never per bit.
wire [575:0] raw_payload={video_snapshot[271:208],sd_snapshot[159:96],
    video_snapshot[207:176],clock_rx_packet,video_snapshot[175:80],
    sd_snapshot[95:32],video_snapshot[47:32],video_snapshot[79:48],
    mem_snapshot[63:32],video_snapshot[31:0],mem_snapshot[31:0],
    sd_snapshot[31:0],{5'b0,got},ref_packet};
wire close_snapshot = (got==3'b111 || timeout_count==SNAPSHOT_TIMEOUT-1);
reg [7:0] packet_sequence,checksum;
reg [6:0] byte_index;
reg tx_start,tx_pending;
reg [7:0] tx_data;
wire tx_busy;
uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) u_uart(
    .clk(ref_clk),.rst(dbg_rst_ref),.start(tx_start),.data(tx_data),
    .tx(uart_tx_pin),.busy(tx_busy));
function [7:0] packet_byte;
    input [6:0] idx;
    reg [7:0] raw_byte;
    begin
        case(idx)
            0: packet_byte=8'hA5;
            1: packet_byte=8'h5A;
            2: packet_byte=8'h0A;
            3: packet_byte=8'd72;
            4: packet_byte=packet_sequence;
            77: packet_byte=checksum;
            default: begin
                raw_byte=raw_payload[(idx-5)*8 +: 8];
                if ((idx>=7 && idx<=10) || (idx>=29 && idx<=36) || (idx>=61 && idx<=68))
                    packet_byte=got[0] ? raw_byte : 8'd0;
                else if ((idx>=11 && idx<=14) || (idx>=19 && idx<=22))
                    packet_byte=got[1] ? raw_byte : 8'd0;
                else if ((idx>=15 && idx<=18) || (idx>=23 && idx<=28) ||
                         (idx>=37 && idx<=48) || (idx>=57 && idx<=60) || (idx>=69 && idx<=76))
                    packet_byte=got[2] ? raw_byte : 8'd0;
                else packet_byte=raw_byte;
            end
        endcase
    end
endfunction
always @(posedge ref_clk or posedge dbg_rst_ref) begin
    if (dbg_rst_ref) begin
        report_count<=0; timeout_count<=0; state<=0; capture<=0;
        got<=0; requested<=0;
        ref_packet<=0; clock_rx_packet<=0; packet_sequence<=0; checksum<=0; byte_index<=0;
        tx_start<=0; tx_pending<=0; tx_data<=0;
    end else begin
        capture<=0; tx_start<=0;
        // A valid domain cannot receive another capture until TX finishes.
        // An old late completion remains masked when requested/got is zero.
        // Ignore completions on the closing edge exactly as the held-payload version.
        if (state==1 && !close_snapshot) begin
            if(sd_done && requested[0]) got[0]<=1;
            if(mem_done && requested[1]) got[1]<=1;
            if(video_done && requested[2]) got[2]<=1;
        end
        case(state)
            0: begin
                if(report_count==REPORT_CYCLES-1) begin
                    report_count<=0; capture<=1; got<=0; timeout_count<=0;
                    requested<=~{video_busy,mem_busy,sd_busy};
                    ref_packet<=0; clock_rx_packet<=0;
                    state<=1;
                end else report_count<=report_count+1'b1;
            end
            1: begin
                if(close_snapshot) begin
                    // Source snapshot fields are qualified by got and frozen for TX.
                    ref_packet<=ref_probe;
                    clock_rx_packet<=clock_rx_status;
                    checksum<=0;
                    byte_index<=0; state<=2;
                end else timeout_count<=timeout_count+1'b1;
            end
            2: begin
                if(!tx_busy && !tx_pending) begin
                    tx_data<=packet_byte(byte_index); tx_start<=1; tx_pending<=1;
                    if(byte_index>=2 && byte_index<=76)
                        checksum<=checksum ^ packet_byte(byte_index);
                end else if(tx_pending && tx_busy) tx_pending<=0;
                // Advance only after the byte has actually been accepted.
                if(tx_pending && tx_busy) begin
                    if(byte_index==77) state<=3;
                    else byte_index<=byte_index+1'b1;
                end
            end
            3: if(!tx_busy) begin state<=0; packet_sequence<=packet_sequence+1'b1; end
        endcase
    end
end
endmodule
