`include "wav_audio_config.vh"
`include "global_def.v"

module top(
    input                       clk,
    input                       rst_n,          // Board KEY1 GPIO: short next / 0.5s hold previous image
    input                       key1,           // Board KEY2: contrast +5 / 0.5s hold -5
    input                       key2,           // Board KEY4: short local auto / 0.5s hold read-only information
    input                       key3,           // Board KEY3: brightness +5 / 0.5s hold -5
    input                       tjc_rx, // J1 pin1 D14; 5V screen TX requires level conversion
    output                      tjc_tx, // J1 pin2 G11; functional control only
    input [3:0]                 dip_switches,   // SW1..SW4: up=1, down=0

    output [7:0]                seg_sel,
    output [7:0]                seg_data,

    // HDMI TMDS
    output                      HDMI_CLK_P,
    output                      HDMI_D2_P,
    output                      HDMI_D1_P,
    output                      HDMI_D0_P,

    // HDMI DDC
    output                      HDMI_DDC_SCL,
    inout                       HDMI_DDC_SDA,

    // TF card SPI
    output                      sd_ncs,
    output                      sd_dclk,
    output                      sd_mosi,
    input                       sd_miso
);

parameter MEM_DATA_BITS = 32;
parameter ADDR_BITS     = 21;
parameter BUSRT_BITS    = 10;
// Central player configuration. Clock/resolution constants must match the
// generated PLLs and the current 640x480 HDMI timing implementation.
parameter integer REF_CLK_HZ = 50_000_000;
parameter integer SD_CLK_HZ = 50_000_000;
parameter integer MEM_CLK_HZ = 100_000_000;
// SPI divider counts half-periods: 200 kHz initialization / 25 MHz reads.
parameter integer SD_SPI_INIT_CLK_DIV = SD_CLK_HZ / 400_000;
parameter integer SD_SPI_READ_CLK_DIV = SD_CLK_HZ / 50_000_000;
parameter integer PIXEL_CLK_HZ = 25_000_000;
parameter integer BMP_WIDTH = 640;
parameter integer BMP_HEIGHT = 480;
parameter [ADDR_BITS-1:0] FRAME_PIXELS = BMP_WIDTH * BMP_HEIGHT;
parameter [ADDR_BITS-1:0] FRAME_WORDS = FRAME_PIXELS / 2;
parameter [ADDR_BITS-1:0] BUF0_ADDR    = 0;
parameter [ADDR_BITS-1:0] BUF1_ADDR    = FRAME_WORDS;
parameter [ADDR_BITS-1:0] BUF2_ADDR    = 2 * FRAME_WORDS;
parameter [ADDR_BITS-1:0] BUF3_ADDR    = 3 * FRAME_WORDS;
parameter [ADDR_BITS-1:0] BUF4_ADDR=4*FRAME_WORDS, BUF5_ADDR=5*FRAME_WORDS;
parameter [ADDR_BITS-1:0] BUF6_ADDR=6*FRAME_WORDS, BUF7_ADDR=7*FRAME_WORDS;
parameter [31:0] SCAN_START_SECTOR = 32'd0;
parameter [31:0] SCAN_MAX_SECTOR = 32'd131071;
parameter [3:0] SCAN_TARGET_COUNT = 4'd8;
parameter integer SECTOR_TIMEOUT_MS = 500;
parameter integer WRITE_ACK_TIMEOUT_MS = 500;
parameter integer LOAD_TIMEOUT_MS = 60000;
parameter integer IMAGE_SCALE_ENABLE = 1;
// Sound-detective TF package uses exact root names PIC1.BMP through PIC8.BMP.
parameter integer IMAGE_LONG_NAME_ENABLE = 0;
parameter integer MAX_SOURCE_DIM = 1920;
parameter integer MAX_FAST_SKIP_SECTORS = 16384;
parameter integer MAX_RETRIES = 1;
parameter integer FAST_BOOT_ENABLE = 1;
// FAT32 root-directory 8.3 names: eight name bytes plus three extension bytes.
parameter [87:0] FAT_NAME0 = "PIC1    BMP";
parameter [87:0] FAT_NAME1 = "PIC2    BMP";
parameter [87:0] FAT_NAME2 = "PIC3    BMP";
parameter [87:0] FAT_NAME3 = "PIC4    BMP";
parameter [87:0] FAT_NAME4="PIC5    BMP",FAT_NAME5="PIC6    BMP";
parameter [87:0] FAT_NAME6="PIC7    BMP",FAT_NAME7="PIC8    BMP";
parameter integer FAT_MAX_DIR_SECTORS = 256;
parameter integer FAT_MAX_FILE_CLUSTERS = 131072;
// Change these values, rebuild F1 and download the new bitstream.
parameter integer AUTO_PLAY_MS  = 15000;
parameter integer LONG_PRESS_MS = 1000;
// Lesson 10: 16 frames per fade/wipe ramp, about 0.269 s at 25 MHz.
parameter integer TRANSITION_FRAMES = 16;
parameter integer TRANSITION_TIMEOUT_FRAMES = 120;
parameter integer DEBOUNCE_MS   = 20;
// Browser exit: 0 fade, 1 focus-anchored wipe, 2 geometric thumbnail zoom.
parameter integer THUMBNAIL_EXIT_EFFECT = 0;
parameter [ADDR_BITS-1:0] THUMBNAIL_ADDR = 4 * FRAME_PIXELS;
// Eight RGB565 chapter frames + eight RGB888 thumbnails precede START.BMP.
parameter [ADDR_BITS-1:0] START_PAGE_ADDR = 21'd1536000;
parameter [ADDR_BITS-1:0] END_PAGE_ADDR = 21'd1689600;
// Build-time audio mode: 0 = continuous 440 Hz / 48 kHz test sine;
// 1 = chapter A/B PCM1..PCM16. No independent menu song selection.
parameter integer AUDIO_SOURCE = 1;
parameter integer AUDIO_VOLUME_PERCENT = 38; // UI range 0..100
parameter integer AUDIO_VOLUME = 97; // round(38*255/100), internal PCM gain
parameter integer AUDIO_MUTE = 0;
parameter integer AUDIO_TEST_HZ = 440;
parameter integer AUDIO_CUE_MS = 28;
parameter integer AUDIO_CUE_HZ = 1800;
parameter integer AUDIO_SAMPLE_HZ = 48000;
// Lesson 11: transparent waveform and peak meter above the scrolling captions.
parameter integer AUDIO_WAVEFORM_ENABLE = 1;
parameter integer AUDIO_WAVEFORM_DECIMATE = 12;
parameter integer AUDIO_WAVEFORM_REFRESH_FRAMES = 6;
parameter integer AUDIO_WAVEFORM_FILTER_SHIFT = 2;
parameter integer AUDIO_WAVEFORM_TRIGGER_TIMEOUT = 128;
parameter integer AUDIO_WAVEFORM_FRAME_SMOOTH_SHIFT = 2;
// PC-prepared S16LE/48k mono. FAT32 mode discovers PCM1.PCM..PCM3.PCM at boot;
// raw extent parameters remain available only for the legacy mode.
parameter integer WAV_ENABLE = `F1_WAV_ENABLE;
parameter integer WAV_FAT32_ENABLE = `F1_WAV_FAT32_ENABLE;
parameter [31:0] WAV_START_LBA = `F1_WAV_START_LBA;
parameter [31:0] WAV_TOTAL_SECTORS = `F1_WAV_TOTAL_SECTORS;
parameter integer WAV_LOOP_ENABLE = 0;
parameter integer WAV_PREFILL_SAMPLES = 1024;
// Lesson 8: independent loader/reader, bounded read reservations and prefetch.
parameter integer FRAME_BURST_WORDS = 128;
parameter integer READ_FIFO_MARGIN = 8;
parameter integer READ_MAX_INFLIGHT_BURSTS = 2;
parameter integer READ_RESPONSE_TIMEOUT_CYCLES = 1_000_000;
parameter integer POR_DELAY_MS = 20;
parameter integer PLL_LOCK_STABLE_US = 1000;

initial begin
    if (REF_CLK_HZ != 50_000_000 || SD_CLK_HZ != 50_000_000 || MEM_CLK_HZ != 100_000_000 ||
        SD_SPI_INIT_CLK_DIV < 2 || SD_SPI_READ_CLK_DIV < 1 ||
        64'd400000 * SD_SPI_INIT_CLK_DIV != SD_CLK_HZ ||
        64'd50000000 * SD_SPI_READ_CLK_DIV != SD_CLK_HZ ||
        PIXEL_CLK_HZ != 25_000_000 || BMP_WIDTH != 640 || BMP_HEIGHT != 480 ||
        FRAME_PIXELS != BMP_WIDTH * BMP_HEIGHT || SCAN_TARGET_COUNT < 1 ||
        SCAN_TARGET_COUNT > 8 || SCAN_START_SECTOR > SCAN_MAX_SECTOR ||
        MAX_RETRIES < 0 || MAX_RETRIES > 15 ||
        SECTOR_TIMEOUT_MS <= 0 || WRITE_ACK_TIMEOUT_MS <= 0 || LOAD_TIMEOUT_MS <= 0 ||
        MAX_FAST_SKIP_SECTORS <= 0 || FAT_MAX_DIR_SECTORS <= 0 || FAT_MAX_FILE_CLUSTERS <= 0 ||
        IMAGE_SCALE_ENABLE != 1 || MAX_SOURCE_DIM < 1 || MAX_SOURCE_DIM > 4096 ||
        (FAST_BOOT_ENABLE != 0 && FAST_BOOT_ENABLE != 1) ||
        AUDIO_VOLUME < 0 || AUDIO_VOLUME > 255 || AUDIO_SAMPLE_HZ != 48000 ||
        (AUDIO_WAVEFORM_ENABLE != 0 && AUDIO_WAVEFORM_ENABLE != 1) ||
        AUDIO_WAVEFORM_DECIMATE < 1 || AUDIO_WAVEFORM_DECIMATE > 65536 ||
        AUDIO_WAVEFORM_REFRESH_FRAMES < 1 || AUDIO_WAVEFORM_REFRESH_FRAMES > 65536 ||
        AUDIO_WAVEFORM_FILTER_SHIFT < 0 || AUDIO_WAVEFORM_FILTER_SHIFT > 7 ||
        AUDIO_WAVEFORM_TRIGGER_TIMEOUT < 1 || AUDIO_WAVEFORM_TRIGGER_TIMEOUT > 65536 ||
        AUDIO_WAVEFORM_FRAME_SMOOTH_SHIFT < 0 || AUDIO_WAVEFORM_FRAME_SMOOTH_SHIFT > 7 ||
        FRAME_BURST_WORDS != 128 || READ_FIFO_MARGIN < 2 || READ_FIFO_MARGIN > 128 ||
        READ_MAX_INFLIGHT_BURSTS < 1 || READ_MAX_INFLIGHT_BURSTS > 3 ||
        READ_RESPONSE_TIMEOUT_CYCLES <= 512 ||
        POR_DELAY_MS <= 0 || PLL_LOCK_STABLE_US <= 0) begin
        $display("F1_PLAYER_CONFIG_ERROR: configuration does not match active board/IP contract");
        $finish;
    end
end

wire Sdr_init_done;
wire Sdr_init_ref_vld;
wire Sdr_busy;

wire sd_card_clk;
wire ext_mem_clk;
wire ext_mem_clk_sft;
wire video_clk;
wire hdmi_5x_clk;

wire hs;
wire vs;
wire de;
wire hs_base,vs_base,de_base;

wire [2:0] reader_pixel_index;
wire rst_tf,rst_video,vs_transition,sfx_load_done;
wire reader_pixel_frame_commit;
wire write_is_start,start_cached;wire [7:0] start_error;
wire write_is_end,end_cached;wire [7:0] end_error;
wire write_is_special=write_is_start || write_is_end;
wire reader_pixel_is_start,physical_read_is_start,physical_read_request;
wire reader_pixel_is_end,physical_read_is_end,ending_committed_sd;
wire [2:0] physical_read_index;
wire physical_read_ack;wire [2:0] physical_read_ack_index;
wire start_read_enabled,admit_player,chapter_committed_sd;
wire unified_write_finish_toggle;
(* ASYNC_REG="TRUE" *) reg [1:0] start_read_enable_video_sync;
reg start_frame_seen,chapter_frame_seen,start_reader_run;
reg [10:0] osd_start_pipe,osd_end_pipe;
wire chapter_pixel_commit,display_frame_ready,reader_start_context,story_frame_started;

wire [23:0] vout_data_raw;
wire [23:0] vout_data;
wire [23:0] waveform_rgb;
wire menu_hs,menu_vs,menu_de;
wire settings_visible,settings_visible_video,auto_play_status,auto_play_video;
wire [3:0] settings_row,settings_row_video;
wire [2:0] period_sel,period_sel_video;
wire [3:0] settings_music_video;
wire [3:0] effect_sel,effect_sel_video;
wire settings_thumbnail_video;
wire [48:0] settings_snapshot;
wire [2:0] info_zoom_video;
wire [2:0] reader_pixel_zoom;
reg [2:0] scene_zoom_pipe[0:5];integer scene_zoom_delay;
wire adventure_started,ending_requested,choice_cursor,choice_confirm_toggle,choice_open_toggle;
wire relative_page_event,relative_page_end,auto_end_event,auto_restart_event;
wire adventure_started_video,choice_cursor_video,choice_confirm_video,choice_open_video;
wire story_prompt,choice_requested_video;
wire choice_confirmed_video,choice_correct_video,scene_ready_video;
wire remote_valid,remote_ready,replay_audio_event,chapter_select_event,remote_navigation_busy;
wire [7:0] remote_cmd,remote_arg;
wire [2:0] chapter_select_index;
wire [18:0] tjc_state0_video,tjc_state0_sd,tjc_status_sd;
wire settings_page_request,app_reset_request,thumbnail_controls_ready_video;
// Hold the application reset request until the domain reset acknowledges it.
// Both handoff stages use the independent reference clock's FALLING edge.
// Their release is therefore half a reference period away from POR's rising
// edge, and all D/recovery/removal paths retain ordinary timing checks.
// Do not reset this bridge from its own output: it must clear while PLL/SD
// clocks are stopped. FPGA configuration initializes both stages low.
(* ASYNC_REG="TRUE" *) reg app_reset_meta,app_reset_ref;
initial begin app_reset_meta=1'b0;app_reset_ref=1'b0;end
always @(negedge clk) begin
    app_reset_meta<=app_reset_request;
    app_reset_ref<=app_reset_meta;
end

wire [20:0] tjc_state1_sd;
wire [3:0] desired_music_index;
wire [2:0] story_chapter,story_chapter_video;
wire [3:0] story_context_sd;
wire [7:0] volume_percent_sd,brightness_percent_sd,contrast_percent_sd;
wire [7:0] volume_percent_video,brightness_percent_video,contrast_percent_video;
wire [23:0] subtitle_rgb;
wire [23:0] resolution_osd_rgb;
wire [7:0] brightness_sd,contrast_sd,brightness_video,contrast_video;
wire [7:0] sharpness_sd,saturation_sd,sharpness_video,saturation_video;
wire [2:0] zoom_sd,zoom_mem;
wire [20:0] tjc_state2_sd={saturation_sd[6:0],sharpness_sd[6:0],4'd0,zoom_sd};
wire [1:0] menu_mode_sd,menu_mode_video;
wire [5:0] menu_step_sd,menu_step_video;
wire hs_adjusted,vs_adjusted,de_adjusted;
wire [11:0] video_x_adjusted,video_y_adjusted;
wire [23:0] adjusted_rgb;
wire [15:0] source_width0,source_height0,source_width1,source_height1;
wire [15:0] source_width2,source_height2,source_width3,source_height3;
wire [15:0] source_width4,source_height4,source_width5,source_height5;
wire [15:0] source_width6,source_height6,source_width7,source_height7;
wire [15:0] source_width_video,source_height_video;
wire source_resolution_valid;
wire [7:0] image_cache_valid;
wire scaled_write_ready, full_write_ready, thumb_capture_ready;
wire [7:0] thumb_complete_mask,image_present_mask,image_failed_mask;
wire [7:0] thumbnail_memory_error;
wire image_scan_complete,thumbnail_context,pause_navigation;
wire thumb_mode_event,thumb_next_event,thumb_prev_event,thumb_confirm_event,thumb_cancel_event;
wire direct_select_valid,direct_select_ready,direct_select_done,direct_select_manual;
wire thumb_direct_valid,thumb_direct_ready,thumb_direct_done;
wire [2:0] thumb_direct_index;
wire [2:0] direct_select_index,thumbnail_focus;
wire thumbnail_requested_view,reader_pixel_view,focus_cache_ready,thumbnail_animation;
wire [7:0] thumbnail_valid,thumbnail_present,thumbnail_failed;
wire thumbnail_scan_complete;
wire [4:0] thumbnail_step;
wire [1:0] thumbnail_kind;
wire [7:0] thumbnail_full_alpha;
wire navigation_busy;
wire hs_browser,vs_browser,de_browser;
wire [11:0] video_x_browser,video_y_browser;
wire [23:0] browser_rgb;
wire thumb_burst_request,thumb_burst_grant,thumb_burst_busy;
wire full_App_wr_en,thumb_App_wr_en;
wire [ADDR_BITS-1:0] full_App_wr_addr,thumb_App_wr_addr;
wire [31:0] full_App_wr_din,thumb_App_wr_din;
wire [3:0] full_App_wr_dm,thumb_App_wr_dm;
reg prefer_thumb_writer;
reg sd_write_req_previous;
reg [10:0] osd_view_pipe;
reg [2:0] osd_bank_pipe9,osd_bank_pipe10;
reg [4:0] thumbnail_page_pipe;
wire reader_pixel_page;
reg [2:0] osd_bank_pipe0,osd_bank_pipe1,osd_bank_pipe2,osd_bank_pipe3,osd_bank_pipe4;
reg [2:0] osd_bank_pipe5,osd_bank_pipe8;
wire [5:0] transition_meta;
wire transition_flip, transition_flip_reveal;
wire [4:0] transition_flip_phase;
wire [11:0] video_x_subtitle,video_y_subtitle;
wire audio_pcm_tap_valid;
wire signed [15:0] audio_pcm_tap_left;
wire        display_valid;
(* ASYNC_REG = "TRUE" *) reg [1:0] display_valid_video_sync;

wire [3:0]  image_number;
wire        cache_ready, button_event_toggle, button_cue;
wire wav_sd_req,wav_sd_ready,wav_sd_valid,wav_sd_done,wav_sd_byte_ready;
wire [31:0] wav_sd_lba;
wire [7:0] wav_sd_byte,wav_sd_error;
wire [8:0] wav_sd_index;
wire signed [15:0] wav_sample;
wire wav_valid,wav_ready,wav_active,wav_end;
wire auto_audio_ready,wav_prefill_ready;
wire music_present;
wire [31:0] music_total_sectors;
wire [20:0] music_valid_mask;
wire [3:0] music_index;
wire music_stop,music_storage_idle,wav_player_idle;
wire osd_ready,osd_present,osd_valid,osd_done;
wire [7:0] osd_byte,osd_error; wire [15:0] osd_offset;
reg osd_start,osd_requested,osd_complete;
wire osd_asset_ready,osd_asset_error;
wire [3:0] scene_music_track;
wire scene_changed_toggle,scene_cue_toggle;
wire [2:0] scene_cue_id;
(* ASYNC_REG="TRUE" *) reg [3:0] scene_music_meta,scene_music_sync;
(* ASYNC_REG="TRUE" *) reg [2:0] scene_toggle_sync;
reg scene_toggle_seen,scene_select_pending;
reg [3:0] scene_select_index;
wire scene_select_event;
reg [2:0] music_story_chapter_previous;
wire chapter_play_permitted,chapter_silent_ready,chapter_audio_restart;
wire [2:0] disp_buf_idx;
wire raw_req,raw_ready,raw_valid,raw_done,raw_byte_ready;
wire [31:0] raw_lba;wire [7:0] raw_byte,raw_error;wire [8:0] raw_index;
wire sfx_req,sfx_raw_enable,sfx_byte_ready;
wire [31:0] sfx_lba;wire [4:0] sfx_selected_index;
wire [4:0] sfx_valid_mask;wire [7:0] sfx_load_error;
wire signed [15:0] sfx_sample;wire sfx_active;
reg cue_toggle;reg [2:0] cue_id;reg scene_cue_seen;
reg result_cue_seen;
reg [4:0] result_cue_hold;
reg [2:0] last_cue_bank;
// Hold catalog selection and cancellation as one SD-clock transaction.
// SFX metadata already settles four clocks; music uses STOP/SELECT/RELEASE.
// This cuts the SFX state/index mux before the reader's abort/error priority.
reg [4:0] storage_index;
reg storage_stop;
always @(posedge sd_card_clk or posedge rst_tf) begin
    if(rst_tf) begin storage_index<=5'd16;storage_stop<=1'b1;end
    else begin
        storage_index<=sfx_load_done?{1'b0,music_index}:sfx_selected_index;
        storage_stop<=!osd_complete || (sfx_load_done ? (music_stop || AUDIO_SOURCE==0) : !sfx_raw_enable);
    end
end
wire assets_ready=sfx_load_done && osd_complete;
// Independently transferred scene metadata and story context may arrive in
// either order. Wait one SD edge after the context changes, so the shared
// controller has committed its chapter-entry cursor=A before issuing audio.
assign desired_music_index={scene_select_index[3:1],choice_cursor};
wire music_route_ready=adventure_started && !ending_requested && chapter_committed_sd && assets_ready &&
    story_chapter==scene_select_index[3:1] && story_chapter==music_story_chapter_previous && story_chapter==disp_buf_idx;
chapter_audio_policy u_chapter_audio_policy(
    .clk(sd_card_clk),.rst(rst_tf),.chapter_active(adventure_started && chapter_committed_sd),
    .chapter_ready(music_route_ready),.navigation_active(navigation_busy || remote_navigation_busy),
    .chapter_index(disp_buf_idx),.audition_event(replay_audio_event),
    .play_permitted(chapter_play_permitted),.silent_ready(chapter_silent_ready),.restart_event(chapter_audio_restart));
wire music_replay_request=chapter_audio_restart;
wire music_direct_valid=music_route_ready &&
    (scene_select_pending || desired_music_index!=music_index || music_replay_request);
wire music_direct_restart=music_route_ready && music_replay_request;
assign scene_select_event=scene_select_pending && music_route_ready;
always @(posedge sd_card_clk or posedge rst_tf)begin
    if(rst_tf)begin music_story_chapter_previous<=0;end
    else begin
        music_story_chapter_previous<=story_chapter;

    end
end
(* ASYNC_REG="TRUE" *) reg [1:0] assets_ready_sync;
reg scene_vs_q;
wire scene_frame_start=scene_vs_q && !vs_browser;
// The diagnostic build uses the same accepted 48 kHz sample demand as PCM.
// AUDIO_SOURCE is a compile-time choice; normal scene playback synthesizes
// away the test oscillator and its multiplexer.
wire signed [15:0] test_tone_sample;
physics_test_tone u_physics_test_tone(.clk(video_clk),.rst(rst_video),
    .enable(AUDIO_SOURCE==0 && assets_ready_sync[1]),
    .sample_tick(wav_ready),.sample(test_tone_sample));
wire signed [15:0] content_sample=(AUDIO_SOURCE==0)?test_tone_sample:(wav_valid?wav_sample:16'sd0);
// Apply the existing exact mono fade before mixing card-resident effects.
// A deliberately silent revisited chapter may keep transition alpha at zero;
// UI/result sounds must still pass through the downstream master volume/mute.
    function signed [15:0] fade_pcm;
        input signed [15:0] pcm;
        input [7:0] alpha;
        reg [15:0] magnitude,a;
        reg [23:0] product;
        reg [16:0] folded,small_div,total;
        begin
            magnitude=pcm[15] ? (~pcm+16'd1) : pcm;
            product=magnitude*alpha;
            a=product[23:8];
            folded={1'b0,a}+{9'd0,product[7:0]};
            small_div=folded+17'd1+{9'd0,folded[15:8]};
            total={1'b0,a}+{8'd0,small_div[16:8]};
            fade_pcm=pcm[15] ? -$signed(total[15:0]) : $signed(total[15:0]);
        end
    endfunction
// Physical page tags suppress stale background samples; effects retain master-volume control.
wire signed [15:0] page_content_sample=(reader_start_context || reader_pixel_is_end) ? 16'sd0 : content_sample;
wire signed [15:0] faded_content_sample=fade_pcm(page_content_sample,transition_audio_alpha);
wire signed [15:0] mixed_sample;
wire [7:0] wav_error_flags;
wire audio_pcm_consume,audio_visual_source_change,wav_read_session,music_ready_video;
wire media_audio_ready=assets_ready_sync[1] || music_ready_video;
wire audition_pending_sd;
audition_reservation u_audition_reservation(
    .clk(sd_card_clk),.rst(rst_tf),
    .eligible(adventure_started && !ending_requested && !navigation_busy && !remote_navigation_busy && assets_ready && !osd_asset_error && AUDIO_SOURCE!=0 && music_valid_mask[desired_music_index]),
    .request(replay_audio_event || chapter_audio_restart),.music_stop(music_stop),
    .target_selected(!storage_stop && storage_index=={1'b0,music_index} && music_index==desired_music_index),
    .prefill_ready(wav_prefill_ready),.terminal_error(!wav_player_idle && |wav_error_flags),.pending(audition_pending_sd));
(* ASYNC_REG="TRUE" *) reg [1:0] audition_pending_sync;
always @(posedge video_clk or posedge rst_video)begin
    if(rst_video)audition_pending_sync<=0;
    else audition_pending_sync<={audition_pending_sync[0],audition_pending_sd};
end
wire music_visible_origin;
scene_audio_route u_scene_audio_route(
    .clk(video_clk),.rst(rst_video),.normal_audio(AUDIO_SOURCE!=0),
    .visible_origin(music_visible_origin),.visible_meta(transition_meta),
    .reader_start(reader_start_context),.reader_end(reader_pixel_is_end),.reader_chapter(reader_pixel_index),
    .sample_tick(wav_ready),.pcm_tap_valid(audio_pcm_tap_valid),.audition_pending(audition_pending_sync[1]),
    .wav_session(wav_read_session),.wav_valid(wav_valid),.animal_track(settings_music_video),
    .faded_animal(faded_content_sample),.sfx_active(sfx_active),.sfx_sample(sfx_sample),
    .cue_id(cue_id),.cue_toggle(cue_toggle),.animal_consume(audio_pcm_consume),.music_ready(music_ready_video),.sample(mixed_sample),
    .visual_source_change(audio_visual_source_change));
always @(posedge sd_card_clk or posedge rst_tf) begin
    if(rst_tf) begin
        osd_start<=0;osd_requested<=0;osd_complete<=0;
        scene_music_meta<=0;scene_music_sync<=0;scene_toggle_sync<=0;
        scene_toggle_seen<=0;scene_select_pending<=0;scene_select_index<=0;
    end else begin
        osd_start<=0;
        if((start_cached || (|image_cache_valid)) && image_scan_complete && !osd_requested && osd_ready) begin osd_start<=1;osd_requested<=1;end
        if(osd_done) osd_complete<=1;
        scene_music_meta<=scene_music_track;scene_music_sync<=scene_music_meta;
        scene_toggle_sync<={scene_toggle_sync[1:0],scene_changed_toggle};
        if(scene_select_event) scene_select_pending<=0;
        if(scene_toggle_sync[2]!=scene_toggle_seen) begin
            scene_toggle_seen<=scene_toggle_sync[2];
            if(scene_music_sync>=1 && scene_music_sync<=15 && scene_music_sync[0]) begin scene_select_index<=scene_music_sync-1'b1;scene_select_pending<=1;end
        end
    end
end
always @(posedge video_clk or posedge rst_video) begin
    if(rst_video) begin assets_ready_sync<=0;cue_toggle<=0;cue_id<=1;scene_cue_seen<=0;scene_vs_q<=1;last_cue_bank<=0;result_cue_seen<=0;result_cue_hold<=0;end
    else begin
        assets_ready_sync<={assets_ready_sync[0],assets_ready};scene_vs_q<=vs_browser;
        scene_cue_seen<=scene_cue_toggle;
        result_cue_seen<=choice_confirmed_video;
        if(scene_frame_start && result_cue_hold!=0) result_cue_hold<=result_cue_hold-1'b1;
        if(chapter_pixel_commit && !reader_pixel_view) last_cue_bank<=reader_pixel_index;
        // The visible result uses the answer loaded from OSD.BIN. Protect the
        // short success/retry sound from ordinary clicks for 25 video frames.
        if(choice_confirmed_video && !result_cue_seen && adventure_started_video && !reader_start_context && !reader_pixel_is_end) begin
            cue_id<=choice_correct_video ? 3'd3 : 3'd2;
            cue_toggle<=~cue_toggle;result_cue_hold<=5'd25;
        end else if(result_cue_hold==0) begin
            if(button_cue) begin cue_id<=1;cue_toggle<=~cue_toggle;end
            // Slots 2/3 are reserved for retry/success, not narration ticks.
            else if(!reader_start_context && !reader_pixel_is_end && scene_cue_toggle!=scene_cue_seen && scene_cue_id!=2 && scene_cue_id!=3) begin cue_id<=scene_cue_id;cue_toggle<=~cue_toggle;end
            else if(chapter_pixel_commit && reader_pixel_index!=last_cue_bank && display_valid_video_sync[1] && !reader_pixel_view) begin cue_id<=5;cue_toggle<=~cue_toggle;end
        end
    end
end
assign raw_req=sfx_load_done?wav_sd_req:sfx_req;
assign raw_lba=sfx_load_done?wav_sd_lba:sfx_lba;
assign raw_byte_ready=sfx_load_done?wav_sd_byte_ready:sfx_byte_ready;
assign wav_sd_ready=raw_ready && sfx_load_done;
assign wav_sd_valid=raw_valid && sfx_load_done;
assign wav_sd_byte=raw_byte;assign wav_sd_index=raw_index;
assign wav_sd_done=raw_done && sfx_load_done;
assign wav_sd_error=sfx_load_done?raw_error:8'd0;

wire next_image_event,previous_image_event,auto_toggle_event,next_music_event,previous_music_event,key_cue_event;
wire local_auto_enable;
wire [7:0] volume_sd,volume_video;
wire volume_toggle;
wire sdram_init_done_sd;

wire loader_frame_commit, loader_abort;
wire [7:0] loader_memory_error;
wire [7:0] full_memory_error;
wire joined_write_finish_toggle;
wire reader_pixel_valid;
wire write_burst_request, write_burst_grant, write_burst_busy;
wire read_burst_request, read_burst_grant, read_burst_busy;
wire frame_start_raw, vblank_raw;
wire [11:0] video_x_raw, video_y_raw, video_x_aligned, video_y_aligned;
wire [6:0]  seg_data_0;

wire        video_read_req;
wire        video_read_req_ack;
(* ASYNC_REG = "TRUE" *) reg [1:0] video_read_ack_sync;
wire        video_read_en;
wire [31:0] video_read_data;

wire        sd_card_write_en;
wire [31:0] sd_card_write_data;
wire        sd_card_write_req;
wire        sd_card_write_req_ack;
(* ASYNC_REG = "TRUE" *) reg [1:0] sd_write_ack_sync;
wire        frame_write_finish;
reg         frame_write_toggle_mem;

wire [2:0]  write_buf_idx;
wire [2:0]  read_buf_req_idx;
wire        read_switch_req_toggle;
wire [3:0] read_switch_req_kind,transition_kind;

wire reader_switch_toggle;
wire [7:0] transition_alpha;
wire transition_wipe;
wire [9:0] transition_boundary;
wire hs_transition,de_transition;
wire [11:0] video_x_transition,video_y_transition;
wire [23:0] transition_rgb;
wire        read_switch_ack_toggle;
wire [2:0]  read_switch_ack_idx;

wire App_rd_en;
wire [ADDR_BITS-1:0] App_rd_addr;
wire Sdr_rd_en;
wire [MEM_DATA_BITS-1:0] Sdr_rd_dout;
wire App_wr_en;
wire [ADDR_BITS-1:0] App_wr_addr;
wire [MEM_DATA_BITS-1:0] App_wr_din;
wire [3:0] App_wr_dm;

wire hs_0;
wire vs_0;
wire de_0;

// Pixel-clock audio: no independent audio PLL or I2S clock crossings.
wire sys_pll_lock, video_pll_lock;
wire [9:0] video_x;
wire video_next_line_active, video_timing_locked;

wire [9:0]  tmds_ch0_data;
wire [9:0]  tmds_ch1_data;
wire [9:0]  tmds_ch2_data;
wire [9:0]  tmds_clk_data;

// Board/configuration POR holds the PLLs first. Lock qualification uses the
// independent reference clock; a raw lock loss still asserts reset immediately.
wire rst_async;
wire pll_reset;
wire rst_sd;
wire rst_mem;

wire rst_serial;
boot_reset_controller #(.REF_CLK_HZ(REF_CLK_HZ), .POR_MS(POR_DELAY_MS),
    .LOCK_STABLE_US(PLL_LOCK_STABLE_US)) u_boot_reset (
    .ref_clk(clk), .board_reset_n(~app_reset_ref), // Explicit TJC reset reuses POR/PLL/domain-reset qualification; KEY1 remains navigation.
    .sys_pll_lock(sys_pll_lock), .video_pll_lock(video_pll_lock),
    .pll_reset(pll_reset), .system_reset_async(rst_async),
    .por_done(), .pll_locks_stable()
);

reset_sync u_reset_sd    (.clk(sd_card_clk), .async_reset(rst_async), .reset_out(rst_sd));
reset_sync u_reset_mem   (.clk(ext_mem_clk), .async_reset(rst_async), .reset_out(rst_mem));
reset_sync u_reset_video (.clk(video_clk),   .async_reset(rst_async), .reset_out(rst_video));
reset_sync u_reset_serial(.clk(hdmi_5x_clk),  .async_reset(rst_async), .reset_out(rst_serial));

// Keep the memory controller alive while TF waits: feeding this readiness
// back into rst_mem would prevent SDRAM initialization from ever completing.
sync_2ff u_sdram_init_sync (.clk(sd_card_clk), .rst_n(~rst_sd),
    .async_in(Sdr_init_done), .sync_out(sdram_init_done_sd));
reset_sync u_reset_tf (.clk(sd_card_clk),
    .async_reset(rst_sd | ~sdram_init_done_sd), .reset_out(rst_tf));
// These ACKs are levels held by the memory controller until the source drops
// its request, so two-flop synchronization preserves the request/ACK handshake.
always @(posedge video_clk or posedge rst_video) begin
    if (rst_video)
        video_read_ack_sync <= 2'b00;
    else
        video_read_ack_sync <= {video_read_ack_sync[0], video_read_req_ack};
end
always @(posedge sd_card_clk or posedge rst_sd) begin
    if (rst_sd)
        sd_write_ack_sync <= 2'b00;
    else
        sd_write_ack_sync <= {sd_write_ack_sync[0], sd_card_write_req_ack};
end

// 保持你原来的 TF / SDRAM / video 时钟
sys_pll sys_pll_m0(
    .refclk     (clk),
    .clk0_out   (sd_card_clk),
    .clk1_out   (ext_mem_clk),
    .clk2_out   (ext_mem_clk_sft),
    .extlock    (sys_pll_lock),
    .reset      (pll_reset)
);

video_pll video_pll_m0(
    .refclk     (clk),
    .clk0_out   (video_clk),
    .clk1_out   (hdmi_5x_clk),
    .extlock    (video_pll_lock),
    .reset      (pll_reset)
);

// mem_clk 域把 write_finish 单拍转成 toggle，供 sd_card_clk 域可靠同步
always @(posedge ext_mem_clk or posedge rst_mem) begin
    if (rst_mem)
        frame_write_toggle_mem <= 1'b0;
    else if (frame_write_finish)
        frame_write_toggle_mem <= ~frame_write_toggle_mem;
end

// ===================== TF scan and immutable four-image SDRAM cache =====================
sd_card_bmp_cached #(.END_PAGE_SEQUENCE_ENABLE(1),.END_PAGE_ENABLE(1),.START_PAGE_ENABLE(1),.IMAGE_LONG_NAME_ENABLE(IMAGE_LONG_NAME_ENABLE),
    .IMAGE_SCALE_ENABLE(IMAGE_SCALE_ENABLE),.MAX_SOURCE_DIM(MAX_SOURCE_DIM),
    .CLK_FREQ_HZ       (SD_CLK_HZ),
    .SPI_INIT_CLK_DIV  (SD_SPI_INIT_CLK_DIV),
    .SPI_READ_CLK_DIV  (SD_SPI_READ_CLK_DIV),
    .SCAN_START_SECTOR (SCAN_START_SECTOR),
    .SCAN_MAX_SECTOR   (SCAN_MAX_SECTOR),
    .SCAN_TARGET_COUNT (SCAN_TARGET_COUNT),
    .SECTOR_TIMEOUT_MS (SECTOR_TIMEOUT_MS),
    .WRITE_ACK_TIMEOUT_MS(WRITE_ACK_TIMEOUT_MS),
    .LOAD_TIMEOUT_MS   (LOAD_TIMEOUT_MS),
    .MAX_FAST_SKIP_SECTORS(MAX_FAST_SKIP_SECTORS),
    .MAX_RETRIES       (MAX_RETRIES),
    .FAST_BOOT_ENABLE  (FAST_BOOT_ENABLE),
    .EARLY_ASSETS_ENABLE(1),.AUDIO_DWELL_ENABLE(1),
    .FAT_NAME0         (FAT_NAME0),
    .FAT_NAME1         (FAT_NAME1),
    .FAT_NAME2         (FAT_NAME2),
    .FAT_NAME3         (FAT_NAME3),
    .FAT_NAME4(FAT_NAME4),.FAT_NAME5(FAT_NAME5),.FAT_NAME6(FAT_NAME6),.FAT_NAME7(FAT_NAME7),
    .FAT_MAX_DIR_SECTORS(FAT_MAX_DIR_SECTORS),
    .FAT_MAX_FILE_CLUSTERS(FAT_MAX_FILE_CLUSTERS),
    .RAW_AUDIO_ENABLE(WAV_ENABLE),
    .FAT_AUDIO_ENABLE(WAV_FAT32_ENABLE),
    .MUSIC_TRACK_COUNT(21),.EXTERNAL_KEY_EVENTS(1),.THUMBNAIL_CONTROL_ENABLE(1),.SETTINGS_ENABLE(1),.DIRECT_MANUAL_ENABLE(1),
    // KEY4 can own the local timer; TJC 29/04 atomically take screen ownership.
    .AUTO_ADVANCE_ENABLE(1),.EXTERNAL_SCHEDULER_ENABLE(1),
    .AUTO_PLAY_MS      (AUTO_PLAY_MS),
    .LONG_PRESS_MS     (LONG_PRESS_MS),
    .DEBOUNCE_MS       (DEBOUNCE_MS)
) sd_card_bmp_m0(
    .clk               (sd_card_clk),
    .rst               (rst_tf),
    .key_next          (1'b1),
    .key_auto          (1'b1),
    .nav_next_event(1'b0),.nav_prev_event(1'b0),
    .auto_toggle_event(auto_toggle_event),.cue_event(key_cue_event),.local_auto_enable(local_auto_enable),
    .end_page_active(ending_committed_sd && ending_requested),.auto_end_event(auto_end_event),.auto_restart_event(auto_restart_event),
    .period_sel(period_sel),.effect_sel(effect_sel),.auto_play_status(auto_play_status),
    // A manual story prompt freezes its OSD timer but KEY1 may still skip.
    // Automatic playback also offers choices; title/remote ownership block navigation.
    .pause_navigation(pause_navigation || !chapter_committed_sd || remote_navigation_busy),.direct_select_valid(direct_select_valid),
    .direct_select_index(direct_select_index),.direct_select_manual(direct_select_manual),.direct_select_ready(direct_select_ready),
    .direct_select_done(direct_select_done),
    .state_code        (),
    .image_number      (image_number),
    .cache_ready       (cache_ready),
    .startup_assets_ready(assets_ready),.auto_audio_ready(auto_audio_ready),
    .button_event_toggle(button_event_toggle),
    .debug_status      (),
    .last_error_code   (),
    .error_event_toggle(),
    .failed_mask       (image_failed_mask),
    .cache_valid_mask  (image_cache_valid),
    .recovery_state    (),
    .retry_count       (),
    .error_count       (),
    .scan_complete     (image_scan_complete),
    .fs_mounted        (),
    .fs_present_mask   (image_present_mask),
    .fs_fragment_seen  (),
    .fs_large_lba_seen (),
    .sd_high_capacity  (),
    .bmp_width         (BMP_WIDTH[15:0]),
    .bmp_height        (BMP_HEIGHT[15:0]),
    .display_valid     (display_valid),

    .write_finish_toggle(unified_write_finish_toggle),
    .write_is_start(write_is_start),.start_cached(start_cached),.start_error(start_error),
    .write_is_end(write_is_end),.end_cached(end_cached),.end_error(end_error),
    .write_buf_idx     (write_buf_idx),
    .disp_buf_idx      (disp_buf_idx),
    .read_buf_req_idx  (read_buf_req_idx),
    .read_switch_req_toggle(read_switch_req_toggle),
    .read_switch_req_kind(read_switch_req_kind),
    .read_switch_ack_toggle(read_switch_ack_toggle),
    .read_switch_ack_idx(read_switch_ack_idx),

    .write_req         (sd_card_write_req),
    .write_req_ack     (sd_write_ack_sync[1]),
    .write_en          (sd_card_write_en),
    .write_data        (sd_card_write_data),
    .write_ready(scaled_write_ready),
    .source_width0(source_width0),.source_height0(source_height0),
    .source_width1(source_width1),.source_height1(source_height1),
    .source_width2(source_width2),.source_height2(source_height2),
    .source_width3(source_width3),.source_height3(source_height3),
    .source_width4(source_width4),.source_height4(source_height4),
    .source_width5(source_width5),.source_height5(source_height5),
    .source_width6(source_width6),.source_height6(source_height6),
    .source_width7(source_width7),.source_height7(source_height7),
    .osd_start(osd_start),.osd_ready(osd_ready),.osd_present(osd_present),
    .osd_valid(osd_valid),.osd_byte(osd_byte),.osd_offset(osd_offset),
    .osd_done(osd_done),.osd_error(osd_error),.osd_byte_ready(1'b1),
    .raw_req(raw_req),.raw_lba(raw_lba),.raw_ready(raw_ready),
    .raw_valid(raw_valid),.raw_byte(raw_byte),.raw_index(raw_index),
    .raw_done(raw_done),.raw_error(raw_error),.raw_byte_ready(raw_byte_ready),
    .music_present(music_present),.music_total_sectors(music_total_sectors),
    .music_index(storage_index),.music_stop(storage_stop),
    .music_valid_mask(music_valid_mask),.music_idle(music_storage_idle),
    .SD_nCS            (sd_ncs),
    .SD_DCLK           (sd_dclk),
    .SD_MOSI           (sd_mosi),
    .SD_MISO           (sd_miso),
    .loader_memory_error(loader_memory_error),
    .loader_frame_commit(loader_frame_commit), .loader_abort(loader_abort),
    .control_error()
);

seg_decoder seg_decoder_m0(
    .bin_data          ((|start_error) && !chapter_committed_sd ? 4'he : image_number),
    .seg_data          (seg_data_0)
);

// HX4S20 SEL drives PNP bases: FPGA select LOW powers the common anode.
// Eight active-LOW selects/segments; SW6 up. Keep the image-number clock domain.
seg_scan_hx4s20 #(.CLK_FREQ(SD_CLK_HZ), .SCAN_FREQ(200), .SEL_ACTIVE_LOW(1)) seg_scan_m0(
    .clk               (sd_card_clk),
    .rst_n             (~rst_tf),
    .seg_sel           (seg_sel),
    .seg_data          (seg_data),
    .seg_data_0        ({1'b1,7'b1111_111}),
    .seg_data_1        ({1'b1,7'b1111_111}),
    .seg_data_2        ({1'b1,7'b1111_111}),
    .seg_data_3        ({1'b1,7'b1111_111}),
    .seg_data_4        ({1'b1,7'b1111_111}),
    .seg_data_5        ({1'b1,7'b1111_111}),
    .seg_data_6        ({1'b1,7'b1111_111}),
    .seg_data_7        ({~cache_ready,seg_data_0})
);

// ===================== Lesson 8: timing and immutable four-bank data plane =====================
video_timing_ctrl #(.H_ACT(BMP_WIDTH), .V_ACT(BMP_HEIGHT)) u_video_timing (
    .video_clk(video_clk), .rst(rst_video), .read_req(video_read_req),
    .read_req_ack(video_read_ack_sync[1]), .hs(hs_0), .vs(vs_0), .de(de_0),
    .frame_start(frame_start_raw), .vblank(vblank_raw),
    .x(video_x_raw), .y(video_y_raw)
);
assign video_read_en = de_0;
// Every pixel and its timing/coordinates pass the same single register stage.
// A missing pixel is black; DE stays intact for HDMI audio/data-island timing.
rgb_video_adapter u_rgb_video_adapter (
    .pclk(video_clk), .rst_n(~rst_video),
    .hs_in(hs_0), .vs_in(vs_0), .de_in(de_0),
    .x_in(video_x_raw), .y_in(video_y_raw), .rgb_in(video_read_data[31:8]),
    .pixel_valid(reader_pixel_valid), .display_enable(display_frame_ready),
    .video_clk(), .video_hs(hs_base), .video_vs(vs_base), .video_de(de_base),
    .video_rgb(vout_data_raw), .video_x(video_x_aligned), .video_y(video_y_aligned)
);
always @(posedge video_clk or posedge rst_video) begin
    if (rst_video) display_valid_video_sync <= 2'b00;
    else display_valid_video_sync <= {display_valid_video_sync[0], display_valid};
end
// A selected cached target enters the transition handshake. The reader
// retains its ACK/token contract. Repeated frame commits cannot retrigger it.
wire [7:0] transition_audio_alpha;
// The frame-latched selected song is published only after the old PCM FIFO
// and storage stream have drained. Require both matching chapter and new PCM
// before releasing the audio envelope; wav_valid alone could be the old song.
wire chapter_audio_ready=assets_ready_sync[1] &&
    (AUDIO_SOURCE==0 || (wav_valid && settings_music_video=={reader_pixel_index,choice_cursor_video}));
// All dwell qualification is local to the SD clock. The selected WAV
// writer has already committed its initial PCM prefill into the existing FIFO.
// The existing audio envelope still controls when HDMI fades the samples in.
reg audio_terminal_seen;

always @(posedge sd_card_clk or posedge rst_tf) begin
    if(rst_tf) audio_terminal_seen<=0;
    else begin
        // A terminal stream error releases the dwell barrier for this boot.
        // W_IDLE excludes stale error bits before a new playback start clears
        // them. Failed media must not prevent the picture slideshow forever.
        if(assets_ready && !wav_player_idle && (|wav_error_flags)) audio_terminal_seen<=1;
    end
end
assign auto_audio_ready=assets_ready && (AUDIO_SOURCE==0 || osd_asset_error || audio_terminal_seen || chapter_silent_ready ||
    !music_valid_mask[{disp_buf_idx,choice_cursor}] ||
    (!music_stop && music_index=={disp_buf_idx,choice_cursor} && wav_prefill_ready));

// Startup owns its own physical reader token. Logical player/transition tokens
// and ACKs keep their original contract, including the first PIC1 request.
wire transition_issue,transition_player_token;
wire [3:0] transition_target,transition_issue_kind,transition_reader_target,transition_pixel_target;
wire [2:0] transition_pixel_state;
wire end_effect_active=transition_pixel_target[3] && transition_pixel_state!=0;
wire transition_pixel_commit=chapter_pixel_commit || (reader_pixel_frame_commit && reader_pixel_is_end && start_reader_run);
chapter_end_transition_dispatch u_page_transition_dispatch(
    .clk(sd_card_clk),.rst(rst_tf),.player_admitted(admit_player),.player_request(read_switch_req_toggle),
    .player_index(read_buf_req_idx),.player_kind(read_switch_req_kind),.ending_requested(ending_requested),
    .end_available(end_cached && !(|end_error)),.reader_is_end(physical_read_is_end),.effect_sel(effect_sel),
    .transition_busy(navigation_busy),.forwarded_request(reader_switch_toggle),.request(transition_issue),
    .target(transition_target),.kind(transition_issue_kind),.player_token(transition_player_token));
start_page_switch_control #(.END_PAGE_ENABLE(1),.TRANSITION_DRAIN_ENABLE(1),.END_EFFECT_ENABLE(1)) u_start_page_switch(
    .clk(sd_card_clk),.rst(rst_tf),.start_cached(start_cached),.start_failed(|start_error),
    .first_cached(|image_cache_valid),.adventure_started(adventure_started),
    .end_cached(end_cached),.end_failed(|end_error),.ending_requested(ending_requested),.transition_busy(navigation_busy),
    .transition_request(reader_switch_toggle),.transition_index(transition_reader_target[2:0]),
    .transition_is_end(transition_reader_target[3]),.transition_player_token(transition_player_token),
    .raw_ack_toggle(physical_read_ack),.raw_ack_index(physical_read_ack_index),.admit_player(admit_player),
    .read_enabled(start_read_enabled),.read_request(physical_read_request),
    .read_index(physical_read_index),.read_is_start(physical_read_is_start),.read_is_end(physical_read_is_end),
    .player_ack_toggle(read_switch_ack_toggle),.player_ack_index(read_switch_ack_idx),
    .chapter_committed(chapter_committed_sd),.ending_committed(ending_committed_sd));
always @(posedge video_clk or posedge rst_video)begin
    if(rst_video)begin start_read_enable_video_sync<=0;start_frame_seen<=0;chapter_frame_seen<=0;start_reader_run<=0;end
    else begin
        start_read_enable_video_sync<={start_read_enable_video_sync[0],start_read_enabled};
        if(frame_start_raw && start_read_enable_video_sync[1])start_reader_run<=1;
        if(reader_pixel_frame_commit && start_reader_run)begin
            if(reader_pixel_is_start)start_frame_seen<=1;
            else if(!reader_pixel_is_end) chapter_frame_seen<=1;
        end
    end
end
video_fade_transition #(.REQUEST_ENABLE_GATE(1),.BANK_BITS(4),.FADE_FRAMES(TRANSITION_FRAMES),.ACTIVE_WIDTH(BMP_WIDTH),.AUDIO_FADE_ENABLE(1),
    .COMMIT_TIMEOUT_FRAMES(TRANSITION_TIMEOUT_FRAMES)) u_transition (
    .ctrl_clk(sd_card_clk),.ctrl_rst_n(~rst_sd),
    .switch_req_enable(1'b1),.switch_req_toggle(transition_issue),.switch_req_index(transition_target),
    .switch_req_kind(transition_issue_kind),.reader_req_toggle(reader_switch_toggle),
    .reader_req_index(transition_reader_target),.ctrl_busy(navigation_busy),
    .pix_clk(video_clk),.pix_rst_n(~rst_video),.frame_start(frame_start_raw),
    .vblank(vblank_raw),.display_active(de_0),
    .pixel_commit(transition_pixel_commit),.pixel_index({reader_pixel_is_end,reader_pixel_index}),
    .alpha(transition_alpha),.audio_source_ready(chapter_audio_ready),.audio_alpha(transition_audio_alpha),
    .wipe_active(transition_wipe),.wipe_boundary(transition_boundary),
    .pixel_state(transition_pixel_state),.pixel_target(transition_pixel_target),.pixel_kind(transition_kind),.error_flags(),
    .start_mod4(),.complete_mod4(),.pixel_pending(),
    .flip_active(transition_flip),.flip_phase(transition_flip_phase),.flip_reveal(transition_flip_reveal)
);
wire detail_hs,detail_vs,detail_de;wire[11:0]detail_x,detail_y;wire[23:0]detail_rgb;
picture_detail_adjust u_picture_detail(.clk(video_clk),.rst_n(~rst_video),
 .hs_in(hs_base),.vs_in(vs_base),.de_in(de_base),.pixel_x(video_x_aligned),.pixel_y(video_y_aligned),.rgb_in(vout_data_raw),
 .sharpness(sharpness_video),.saturation(saturation_video),
 .hs_out(detail_hs),.vs_out(detail_vs),.de_out(detail_de),.x_out(detail_x),.y_out(detail_y),.rgb_out(detail_rgb));
reg [9:0] detail_meta[0:3];integer dm;
always @(posedge video_clk or posedge rst_video)begin
 if(rst_video)begin for(dm=0;dm<4;dm=dm+1)detail_meta[dm]<=10'b0000100000;end
 else begin detail_meta[0]<={reader_pixel_zoom,reader_pixel_is_end,reader_start_context,reader_pixel_page,reader_pixel_view,reader_pixel_index};
 for(dm=1;dm<4;dm=dm+1)detail_meta[dm]<=detail_meta[dm-1];end
end
wire detail_end=detail_meta[3][6],detail_start=detail_meta[3][5],detail_page=detail_meta[3][4],detail_view=detail_meta[3][3];
wire[2:0]detail_bank=detail_meta[3][2:0];
// Adjust picture pixels before transitions; OSD stays readable even at BRI 000.
brightness_contrast_adjust u_image_adjust (
    .clk(video_clk),.rst_n(~rst_video),.hs_in(detail_hs),.vs_in(detail_vs),.de_in(detail_de),
    .pixel_x(detail_x),.pixel_y(detail_y),.rgb_in(detail_rgb),
    .brightness(brightness_video),.contrast(contrast_video),
    .hs_out(hs_adjusted),.vs_out(vs_adjusted),.de_out(de_adjusted),
    .pixel_x_out(video_x_adjusted),.pixel_y_out(video_y_adjusted),.rgb_out(adjusted_rgb)
);
thumbnail_ui_controller #(.BANK_BITS(3),.EXIT_EFFECT(THUMBNAIL_EXIT_EFFECT)) u_thumbnail_ui (
    .ctrl_clk(sd_card_clk),.ctrl_rst(rst_tf),.pixel_clk(video_clk),.pixel_rst(rst_video),
    .frame_start(frame_start_raw),.mode_event(thumb_mode_event && chapter_committed_sd),.next_event(thumb_next_event && chapter_committed_sd),
    .prev_event(thumb_prev_event && chapter_committed_sd),.confirm_event(thumb_confirm_event && chapter_committed_sd),.cancel_event(thumb_cancel_event && chapter_committed_sd),
    .valid_mask(image_cache_valid & thumb_complete_mask),.present_mask(image_present_mask),
    .failed_mask(image_failed_mask),
    .scan_complete(image_scan_complete),.navigation_busy(navigation_busy),
    .actual_view(reader_pixel_view),.actual_index(reader_pixel_index),.focus_cache_ready(focus_cache_ready),
    .pause_navigation(pause_navigation),.thumbnail_context(thumbnail_context),.controls_ready(thumbnail_controls_ready_video),
    .direct_select_valid(thumb_direct_valid),.direct_select_index(thumb_direct_index),
    .direct_select_ready(thumb_direct_ready),.direct_select_done(thumb_direct_done),
    .requested_view(thumbnail_requested_view),.focus(thumbnail_focus),
    .frame_valid(thumbnail_valid),.frame_present(thumbnail_present),.frame_failed(thumbnail_failed),
    .frame_scan_complete(thumbnail_scan_complete),.animation_active(thumbnail_animation),
    .animation_step(thumbnail_step),.animation_kind(thumbnail_kind),
    .full_alpha(thumbnail_full_alpha),.error_flags());
sound_chapter_arbiter #(.PAGE_SEQUENCE_ENABLE(1),.RELATIVE_ENABLE(1)) u_sound_chapter_arbiter(
    .clk(sd_card_clk),.rst(rst_tf),.adventure_started(adventure_started),
    .chapter_committed(chapter_committed_sd || (adventure_started && !ending_requested)),.thumbnail_context(thumbnail_context),
    .thumbnail_enter_event(thumb_mode_event),.remote_event(chapter_select_event),
    .remote_index(chapter_select_index),
    .relative_next(next_image_event),.relative_previous(previous_image_event),.actual_index(disp_buf_idx),
    .available_mask(image_present_mask & ~image_failed_mask),.scan_complete(image_scan_complete),
    .thumb_valid(thumb_direct_valid),.thumb_index(thumb_direct_index),
    .thumb_ready(thumb_direct_ready),.thumb_done(thumb_direct_done),
    .media_valid(direct_select_valid),.media_index(direct_select_index),.media_manual(direct_select_manual),
    .media_ready(direct_select_ready),.media_done(direct_select_done),.remote_busy(remote_navigation_busy),
    .relative_page_event(relative_page_event),.relative_page_end(relative_page_end));
dental_thumbnail_renderer u_thumbnail_renderer (
    .clk(video_clk),.rst_n(~rst_video),.frame_start(frame_start_raw),
    .hs_in(hs_adjusted),.vs_in(vs_adjusted),.de_in(de_adjusted),
    .pixel_x(video_x_adjusted),.pixel_y(video_y_adjusted),.rgb_in(adjusted_rgb),
    .view_page(thumbnail_page_pipe[4]),.view_mode(osd_view_pipe[4]),.focus(thumbnail_focus),
    .valid_mask(thumbnail_valid),.present_mask(thumbnail_present),.failed_mask(thumbnail_failed),
    .scan_complete(thumbnail_scan_complete),.animation_active(thumbnail_animation),
    .animation_step(thumbnail_step),.animation_kind(thumbnail_kind),
    .hs_out(hs_browser),.vs_out(vs_browser),.de_out(de_browser),
    .pixel_x_out(video_x_browser),.pixel_y_out(video_y_browser),.rgb_out(browser_rgb),
    .focus_cache_ready(focus_cache_ready));
// Compose every chapter layer before the shared transition scanline memory.
// The subtitle registers delay RGB, HS/VS/DE and coordinates together; the
// bank/start/view tags follow those same three registers below.
// Match the reader's committed zoom tag to the existing4+6 metadata path.
always @(posedge video_clk or posedge rst_video)begin
    if(rst_video)begin for(scene_zoom_delay=0;scene_zoom_delay<6;scene_zoom_delay=scene_zoom_delay+1)scene_zoom_pipe[scene_zoom_delay]<=0;end
    else begin
        scene_zoom_pipe[0]<=(detail_start || detail_end) ? 3'd0 : detail_meta[3][9:7];
        for(scene_zoom_delay=1;scene_zoom_delay<6;scene_zoom_delay=scene_zoom_delay+1)scene_zoom_pipe[scene_zoom_delay]<=scene_zoom_pipe[scene_zoom_delay-1];
    end
end
dental_scene_osd #(.PIXEL_HZ(PIXEL_CLK_HZ),.LAYER_ZOOM_ENABLE(1),.SPECIAL_AUDIO_ENABLE(1)) u_dental_osd (
    .load_clk(sd_card_clk),.load_rst_n(~rst_tf),.load_start(osd_start),
    .load_valid(osd_valid),.load_addr(osd_offset),.load_data(osd_byte),
    .load_done(osd_done),.load_error(|osd_error),.asset_ready_load(osd_asset_ready),.asset_error_load(osd_asset_error),
    .clk(video_clk),.rst_n(~rst_video),.frame_start(scene_frame_start),
    .active_index(osd_bank_pipe5),.enable((osd_start_pipe[5] ? start_frame_seen : (chapter_frame_seen && display_valid_video_sync[1])) && !osd_view_pipe[5] && !osd_end_pipe[5]),
    .auto_play(auto_play_video),.period_sel(period_sel_video),
    .adventure_started(story_frame_started),.choice_cursor(choice_cursor_video),
    .choice_confirm_toggle(choice_confirm_video),.choice_open_toggle(choice_open_video),
    .menu_visible(1'b0),.thumbnail_active(osd_view_pipe[5]),
    .choice_requested(choice_requested_video),.story_chapter(story_chapter_video),
    .choice_confirmed(choice_confirmed_video),.choice_correct(choice_correct_video),.scene_ready_status(scene_ready_video),
    .hs_in(hs_browser),.vs_in(vs_browser),.de_in(de_browser),
    .pixel_x(video_x_browser),.pixel_y(video_y_browser),.layer_zoom(scene_zoom_pipe[5]),.rgb_in(browser_rgb),
    .volume_level(volume_video),
    .audio_valid(audio_pcm_tap_valid),.audio_sample(audio_pcm_tap_left),
    .special_audio_page(osd_end_pipe[5] || (osd_start_pipe[5] && start_frame_seen)),
    .audio_source_change(audio_visual_source_change),
    .hs_out(hs),.vs_out(vs),.de_out(de),.pixel_x_out(video_x_subtitle),.pixel_y_out(video_y_subtitle),
    .rgb_out(subtitle_rgb),.overlay_active(),.scene_music_track(scene_music_track),
    .scene_changed_toggle(scene_changed_toggle),.cue_toggle(scene_cue_toggle),.cue_id(scene_cue_id));
// Six stages follow detail adjustment before the browser output. Stages
// 8/9/10 then track the subtitle's three registers, before the effect buffer.
always @(posedge video_clk or posedge rst_video) begin
    if(rst_video) begin
        osd_bank_pipe0<=0;osd_bank_pipe1<=0;osd_bank_pipe2<=0;osd_bank_pipe3<=0;osd_bank_pipe4<=0;
        osd_bank_pipe5<=0;osd_bank_pipe8<=0;osd_bank_pipe9<=0;osd_bank_pipe10<=0;osd_view_pipe<=0;thumbnail_page_pipe<=0;osd_start_pipe<=11'h7ff;osd_end_pipe<=0;
    end else begin
        osd_bank_pipe0<=detail_bank;osd_bank_pipe1<=osd_bank_pipe0;
        osd_bank_pipe2<=osd_bank_pipe1;osd_bank_pipe3<=osd_bank_pipe2;osd_bank_pipe4<=osd_bank_pipe3;
        osd_bank_pipe5<=osd_bank_pipe4;
        osd_bank_pipe8<=osd_bank_pipe5;osd_bank_pipe9<=osd_bank_pipe8;osd_bank_pipe10<=osd_bank_pipe9;
        thumbnail_page_pipe<={thumbnail_page_pipe[3:0],detail_page};
        osd_view_pipe<={osd_view_pipe[9:8],osd_view_pipe[5],2'b00,osd_view_pipe[4:0],detail_view};
        osd_start_pipe<={osd_start_pipe[9:8],osd_start_pipe[5],2'b00,osd_start_pipe[4:0],detail_start};
        osd_end_pipe<={osd_end_pipe[9:8],osd_end_pipe[5],2'b00,osd_end_pipe[4:0],detail_end};
    end
end
image_resolution_cdc #(.BANK_BITS(3),.DIM_BITS($clog2(MAX_SOURCE_DIM+1))) u_resolution_cdc(
    .src_clk(sd_card_clk),.src_rst(rst_tf),
    .width0(source_width0),.height0(source_height0),.width1(source_width1),.height1(source_height1),
    .width2(source_width2),.height2(source_height2),.width3(source_width3),.height3(source_height3),
    .width4(source_width4),.height4(source_height4),.width5(source_width5),.height5(source_height5),
    .width6(source_width6),.height6(source_height6),.width7(source_width7),.height7(source_height7),
    .valid_mask(image_cache_valid),.dst_clk(video_clk),.dst_rst(rst_video),.bank_index(osd_view_pipe[10] ? thumbnail_focus : osd_bank_pipe10),
    .width_out(source_width_video),.height_out(source_height_video),.valid_out(source_resolution_valid));
// Parameter values are shown only in the centered settings menu.
image_resolution_osd #(.TEXT_Y(84)) u_resolution_osd(
    .clk(video_clk),.rst_n(~rst_video),.vsync(vs),.de(de),
    .pixel_x(video_x_subtitle),.pixel_y(video_y_subtitle),
    .enable(chapter_frame_seen && !osd_start_pipe[10] && !osd_end_pipe[10] && (display_valid_video_sync[1] || osd_view_pipe[10]) && source_resolution_valid),
    .image_width(source_width_video),.image_height(source_height_video),
    .rgb_in(subtitle_rgb),.rgb_out(resolution_osd_rgb),.overlay_active());
assign waveform_rgb=resolution_osd_rgb;
// One unchanged scanline effect now owns background, actors, dialogue,
// subtitles, experiments and resolution text together. Its input tags and
// RGB describe the same composed pixel; total video latency is unchanged.
// Boot, thumbnail and stationary END stay fully visible. During an END
// transaction every outgoing/incoming image layer follows its chosen effect.
wire bypass_page_effect=(osd_start_pipe[10] || osd_end_pipe[10] || osd_view_pipe[10]) && !end_effect_active;
video_transition_pixels #(.META_BITS(6)) u_transition_pixels (
    .clk(video_clk),.rst_n(~rst_video),.hs_in(hs),.vs_in(vs),.de_in(de),
    .pixel_x(video_x_subtitle),.pixel_y(video_y_subtitle),.rgb_in(waveform_rgb),
    .alpha(bypass_page_effect ? 8'd255 : ((!end_effect_active && thumbnail_full_alpha!=255) ? thumbnail_full_alpha : transition_alpha)),
    .wipe_active(transition_wipe && !bypass_page_effect),.wipe_boundary(transition_boundary),
    .transition_kind(transition_kind),
    .flip_active(transition_flip && !bypass_page_effect),
    .flip_phase(transition_flip_phase),.flip_reveal(transition_flip_reveal),
    .meta_in({osd_end_pipe[10],osd_start_pipe[10],osd_bank_pipe10,osd_view_pipe[10]}),.meta_out(transition_meta),
    .hs_out(hs_transition),.vs_out(vs_transition),.de_out(de_transition),
    .pixel_x_out(video_x_transition),.pixel_y_out(video_y_transition),.rgb_out(transition_rgb)
);
// Capture only the first pixel of a fully presented, non-thumbnail frame.
// The optional information card and transition stages retain the previous melody.
assign music_visible_origin=de_transition && video_x_transition==0 && video_y_transition==0 &&
    transition_pixel_state==0 && !(settings_visible_video && !transition_meta[5]) &&
    (transition_meta[5] || (transition_meta[4] ? start_frame_seen : (chapter_frame_seen && display_valid_video_sync[1])));
// Highest-priority overlay. Its registered RGB and syncs travel together to
// HDMI position recovery and audio packetization; the upstream timing remains
// unchanged for SDRAM, thumbnails and existing OSD coordinates.
player_settings_cdc #(.WIDTH(49),.RESET_VALUE({4'd0,1'b0,4'd0,3'd5,4'd0,4'd0,1'b0,1'b0,8'd38,8'd100,8'd50,3'd0})) u_settings_cdc(
    .src_clk(sd_card_clk),.src_rst(rst_tf),
    .source_state({adventure_started,choice_cursor,choice_confirm_toggle,choice_open_toggle,
        settings_visible,settings_row,period_sel,effect_sel,music_index,auto_play_status,thumbnail_context,
        volume_percent_sd,brightness_percent_sd,contrast_percent_sd,zoom_sd}),
    .dst_clk(video_clk),.dst_rst(rst_video),.frame_start(frame_start_raw),.active_state(settings_snapshot));
assign {adventure_started_video,choice_cursor_video,choice_confirm_video,choice_open_video,
        settings_visible_video,settings_row_video,period_sel_video,effect_sel_video,
        settings_music_video,auto_play_video,settings_thumbnail_video,
        volume_percent_video,brightness_percent_video,contrast_percent_video,info_zoom_video}=settings_snapshot;
// Return the prompt and its chapter atomically. This is a held mailbox,
// not four independently synchronized bits. SD has no display-frame boundary.
player_settings_cdc #(.WIDTH(4),.RESET_VALUE(4'd0)) u_story_context_cdc(
    .src_clk(video_clk),.src_rst(rst_video),
    .source_state({choice_requested_video,story_chapter_video}),
    .dst_clk(sd_card_clk),.dst_rst(rst_tf),.frame_start(1'b1),.active_state(story_context_sd));
assign {story_prompt,story_chapter}=story_context_sd;
// A coherent video-domain status snapshot, with the existing held-mailbox CDC.
// sys0: chapter[2:0], A/B[3], confirmed[4], started[5], assets[6],
// autoplay[7], scene ready[8], correct[9], thumbnail GRID ready[10], thumbnails[11].
assign tjc_state0_video={effect_sel_video,period_sel_video,settings_thumbnail_video,thumbnail_controls_ready_video,
    choice_correct_video,scene_ready_video,auto_play_video,assets_ready_sync[1],
    adventure_started_video,choice_confirmed_video,choice_cursor_video,story_chapter_video};
// The visible bank is authoritative for chapter identity. Do not expose old
// chapter-specific answer/result flags while the story CDC still trails a commit.
wire tjc_story_matches_commit=tjc_state0_sd[2:0]==disp_buf_idx;
assign tjc_status_sd={tjc_state0_sd[18:10],
    tjc_state0_sd[9] && tjc_story_matches_commit,tjc_state0_sd[8] && tjc_story_matches_commit,
    tjc_state0_sd[7:5],tjc_state0_sd[4] && tjc_story_matches_commit,
    tjc_state0_sd[3] && tjc_story_matches_commit,disp_buf_idx};
assign tjc_state1_sd={contrast_percent_sd[6:0],brightness_percent_sd[6:0],volume_percent_sd[6:0]};
player_settings_cdc #(.WIDTH(19),.RESET_VALUE({4'd0,3'd5,12'd0})) u_tjc_status_cdc(
    .src_clk(video_clk),.src_rst(rst_video),.source_state(tjc_state0_video),
    .dst_clk(sd_card_clk),.dst_rst(rst_tf),.frame_start(1'b1),.active_state(tjc_state0_sd));
tjc_control_uart #(.EXTENDED_SETTINGS(1),.CLK_HZ(50000000),.BAUD(115200)) u_tjc_control_uart(
    .clk(sd_card_clk),.rst(rst_tf),.rx(tjc_rx),.tx(tjc_tx),
    .state0(tjc_status_sd),.state1(tjc_state1_sd),.state2(tjc_state2_sd),.settings_page_request(settings_page_request),
    .remote_valid(remote_valid),.remote_ready(remote_ready),.remote_cmd(remote_cmd),.remote_arg(remote_arg));

player_info_osd u_settings_osd(
    .clk(video_clk),.rst(rst_video),.hs_in(hs_transition),.vs_in(vs_transition),.de_in(de_transition),
    .pixel_x(video_x_transition),.pixel_y(video_y_transition),.rgb_in(transition_rgb),
    .view_visible(settings_visible_video && !transition_meta[5]),.zoom_index(info_zoom_video),
    .volume(volume_percent_video),.brightness(brightness_percent_video),.contrast(contrast_percent_video),
    .sharpness(sharpness_video),.saturation(saturation_video),
    .image_width(source_width_video),.image_height(source_height_video),
    .source_resolution_valid(source_resolution_valid),
    .hs_out(menu_hs),.vs_out(menu_vs),.de_out(menu_de),
    .pixel_x_out(),.pixel_y_out(),.rgb_out(vout_data));
// A grant owns the complete command train and every outstanding read response.
// Read priority refills the pixel FIFO before allowing background loading.
// Mirror the vendor's public refresh counter, including its inclusive end.
// Reserve 256 MEM clocks for a 128-word train and the native command tail.
// Never rephase this counter on refresh ACK/busy: the vendor timer free-runs.
localparam integer MEM_REFRESH_GUARD_CYCLES = 256;
reg [13:0] mem_refresh_count;
wire mem_burst_window = Sdr_init_done && !Sdr_init_ref_vld &&
    (mem_refresh_count < (`SELF_REFRESH_INTERVAL - MEM_REFRESH_GUARD_CYCLES));
always @(posedge ext_mem_clk or posedge rst_mem) begin
    if(rst_mem) mem_refresh_count<=0;
    else if(!Sdr_init_done || mem_refresh_count==`SELF_REFRESH_INTERVAL)
        mem_refresh_count<=0;
    else mem_refresh_count<=mem_refresh_count+1'b1;
end
assign read_burst_grant = read_burst_request && mem_burst_window && !write_burst_busy && !thumb_burst_busy;
// The thumbnail command tail can end before the native SDRAM pipeline drains.
// Check backend idle only at grant; never interrupt an already-owned train.
assign write_burst_grant = write_burst_request && mem_burst_window && !Sdr_busy && !read_burst_busy && !read_burst_request &&
    !thumb_burst_busy && !(thumb_burst_request && prefer_thumb_writer);
assign thumb_burst_grant = thumb_burst_request && mem_burst_window && !read_burst_busy && !read_burst_request &&
    !write_burst_busy && !(write_burst_request && !prefer_thumb_writer);
always @(posedge ext_mem_clk or posedge rst_mem) begin
    if(rst_mem) prefer_thumb_writer<=0;
    else if(write_burst_grant) prefer_thumb_writer<=1;
    else if(thumb_burst_grant) prefer_thumb_writer<=0;
end
assign App_wr_en=full_App_wr_en | thumb_App_wr_en;
assign App_wr_addr=thumb_App_wr_en ? thumb_App_wr_addr : full_App_wr_addr;
assign App_wr_din=thumb_App_wr_en ? thumb_App_wr_din : full_App_wr_din;
assign App_wr_dm=thumb_App_wr_en ? thumb_App_wr_dm : full_App_wr_dm;
assign scaled_write_ready=full_write_ready && (write_is_special || thumb_capture_ready);
assign loader_memory_error=(write_is_special || (|full_memory_error)) ? full_memory_error : thumbnail_memory_error;
always @(posedge sd_card_clk or posedge rst_tf) begin
    if(rst_tf) sd_write_req_previous<=0;
    else sd_write_req_previous<=sd_card_write_req;
end
start_write_completion_mux u_start_write_completion(
    .clk(sd_card_clk),.rst(rst_tf),.write_is_start(write_is_special),
    .full_finish_toggle(frame_write_toggle_mem),.joined_finish_toggle(joined_write_finish_toggle),
    .finish_toggle(unified_write_finish_toggle));
thumbnail_completion_join #(.BANK_BITS(3)) u_thumbnail_join (
    .clk(sd_card_clk),.rst(rst_tf),.start(sd_card_write_req && !sd_write_req_previous && !write_is_special),
    .abort(loader_abort && !write_is_special),.source_done(loader_frame_commit && !write_is_special),.bank(write_buf_idx),
    .full_finish_toggle(frame_write_toggle_mem),.thumbnail_complete(thumb_complete_mask),
    .finish_toggle(joined_write_finish_toggle));
thumbnail_cache_writer #(.BANK_BITS(3),.ADDR_BITS(ADDR_BITS),.WIDTH(BMP_WIDTH),.HEIGHT(BMP_HEIGHT),
    .MEM_CLK_HZ(MEM_CLK_HZ),.BASE_ADDR(THUMBNAIL_ADDR)) u_thumbnail_writer (
    .rst(rst_mem),.write_rst(rst_tf),.mem_clk(ext_mem_clk),.write_clk(sd_card_clk),
    .capture_start(sd_card_write_req && !sd_write_req_previous && !write_is_special),.capture_bank(write_buf_idx),
    .capture_en(sd_card_write_en && !write_is_special),.capture_rgb(sd_card_write_data[31:8]),
    .capture_done(loader_frame_commit && !write_is_special),.capture_abort(loader_abort && !write_is_special),
    .capture_ready(thumb_capture_ready),.complete_mask(thumb_complete_mask),.error(thumbnail_memory_error),
    .Sdr_init_done(Sdr_init_done),.Sdr_init_ref_vld(Sdr_init_ref_vld),.Sdr_busy(Sdr_busy),
    .burst_request(thumb_burst_request),.burst_grant(thumb_burst_grant),.burst_busy(thumb_burst_busy),
    .App_wr_en(thumb_App_wr_en),.App_wr_addr(thumb_App_wr_addr),
    .App_wr_din(thumb_App_wr_din),.App_wr_dm(thumb_App_wr_dm));
media_frame_loader #(.END_PAGE_ENABLE(1),.END_BASE_ADDR(END_PAGE_ADDR),.START_PAGE_ENABLE(1),.START_BASE_ADDR(START_PAGE_ADDR),.BANK_BITS(3),.RGB565_ENABLE(1),.MEM_DATA_BITS(MEM_DATA_BITS), .WRITE_DATA_BITS(32),
    .ADDR_BITS(ADDR_BITS), .BURST_BITS(9), .BURST_SIZE(FRAME_BURST_WORDS),
    .WRITE_V_FLIP(1), .FRAME_WIDTH(BMP_WIDTH), .FRAME_HEIGHT(BMP_HEIGHT),
    .STALL_TIMEOUT((64'd1*MEM_CLK_HZ*5000+999)/1000)) u_frame_loader (
    .rst(rst_mem), .write_rst(rst_sd), .mem_clk(ext_mem_clk),
    .Sdr_init_done(Sdr_init_done), .Sdr_init_ref_vld(Sdr_init_ref_vld), .Sdr_busy(Sdr_busy),
    .App_wr_en(full_App_wr_en), .App_wr_addr(full_App_wr_addr), .App_wr_din(full_App_wr_din), .App_wr_dm(full_App_wr_dm),
    .write_clk(sd_card_clk), .write_req(sd_card_write_req), .write_req_ack(sd_card_write_req_ack),
    .write_ready(full_write_ready),
    .write_finish(frame_write_finish), .write_addr_0(BUF0_ADDR), .write_addr_1(BUF1_ADDR),
    .write_addr_2(BUF2_ADDR), .write_addr_3(BUF3_ADDR),
    .write_addr_4(BUF4_ADDR),.write_addr_5(BUF5_ADDR),.write_addr_6(BUF6_ADDR),.write_addr_7(BUF7_ADDR), .write_addr_index(write_buf_idx),.write_is_start(write_is_start),.write_is_end(write_is_end),
    .write_len(FRAME_PIXELS), .write_en(sd_card_write_en), .write_data(sd_card_write_data),
    .source_done(loader_frame_commit), .load_abort(loader_abort), .load_busy(),
    .image_complete(), .memory_error(full_memory_error),
    .burst_request(write_burst_request), .burst_grant(write_burst_grant), .burst_busy(write_burst_busy),
    .debug_write_count(), .debug_write_full(),
    .debug_write_empty(), .debug_write_overflow(),
    .debug_write_underflow()
);
player_settings_cdc #(.WIDTH(3),.RESET_VALUE(3'd0)) u_zoom_cdc(
 .src_clk(sd_card_clk),.src_rst(rst_tf),.source_state(zoom_sd),
 .dst_clk(ext_mem_clk),.dst_rst(rst_mem),.frame_start(1'b1),.active_state(zoom_mem));
media_frame_reader #(.END_PAGE_ENABLE(1),.END_BASE_ADDR(END_PAGE_ADDR),.START_PAGE_ENABLE(1),.START_BASE_ADDR(START_PAGE_ADDR),.BANK_BITS(3),.RGB565_ENABLE(1),.THUMBNAIL_PAGE_WORDS(0),.THUMBNAIL_ENABLE(1),.ADDR_BITS(ADDR_BITS), .BURST_SIZE(FRAME_BURST_WORDS),
    .FIFO_MARGIN(READ_FIFO_MARGIN), .MAX_INFLIGHT_BURSTS(READ_MAX_INFLIGHT_BURSTS),
    .TIMEOUT_CYCLES(READ_RESPONSE_TIMEOUT_CYCLES)) u_frame_reader (
    .rst(rst_mem), .read_rst(rst_video), .mem_clk(ext_mem_clk), .read_clk(video_clk),
    .Sdr_init_done(Sdr_init_done), .Sdr_init_ref_vld(Sdr_init_ref_vld), .Sdr_busy(Sdr_busy),
    .Sdr_rd_en(Sdr_rd_en), .Sdr_rd_dout(Sdr_rd_dout), .App_rd_en(App_rd_en), .App_rd_addr(App_rd_addr),
    .burst_request(read_burst_request), .burst_grant(read_burst_grant), .burst_busy(read_burst_busy),
    .read_req(video_read_req && start_reader_run), .read_req_ack(video_read_req_ack), .read_finish(),
    .read_addr_0(BUF0_ADDR), .read_addr_1(BUF1_ADDR), .read_addr_2(BUF2_ADDR), .read_addr_3(BUF3_ADDR),
    .read_addr_4(BUF4_ADDR),.read_addr_5(BUF5_ADDR),.read_addr_6(BUF6_ADDR),.read_addr_7(BUF7_ADDR),
    .read_addr_index(physical_read_index), .read_switch_req_toggle(physical_read_request),
    .read_is_start(physical_read_is_start),.pixel_is_start(reader_pixel_is_start),
    .read_is_end(physical_read_is_end),.pixel_is_end(reader_pixel_is_end),
    .read_switch_ack_toggle(physical_read_ack), .read_switch_ack_idx(physical_read_ack_index),
    .read_view_mode(thumbnail_requested_view && !physical_read_is_start && !physical_read_is_end),.read_view_page(thumbnail_focus[2]),.pixel_view_page(reader_pixel_page),.read_addr_thumbnail(THUMBNAIL_ADDR),
    .pixel_view_mode(reader_pixel_view),
    .zoom_level(zoom_mem),.pixel_zoom_level(reader_pixel_zoom),.read_len(FRAME_PIXELS), .frame_start(frame_start_raw),
    .display_valid(display_frame_ready), .read_en(video_read_en), .read_data(video_read_data),
    .pixel_valid(reader_pixel_valid), .underflow(),
    .pixel_index(reader_pixel_index), .pixel_frame_commit(reader_pixel_frame_commit),
    .reader_busy(), .reader_index(), .reader_error(),
    .debug_read_count(), .debug_read_empty(), .debug_read_full(),
    .debug_read_overflow(), .debug_read_underflow()
);
sdram U3(
    .Clk               (ext_mem_clk),
    .Clk_sft           (ext_mem_clk_sft),
    .Rst               (rst_mem),
    .Sdr_init_done     (Sdr_init_done),
    .Sdr_init_ref_vld  (Sdr_init_ref_vld),
    .Sdr_busy          (Sdr_busy),
    .App_wr_en         (App_wr_en),
    .App_wr_addr       (App_wr_addr),
    .App_wr_dm         (App_wr_dm),
    .App_wr_din        (App_wr_din),
    .App_rd_en         (App_rd_en),
    .App_rd_addr       (App_rd_addr),
    .Sdr_rd_en         (Sdr_rd_en),
    .Sdr_rd_dout       (Sdr_rd_dout)
);

// ===================== Lesson 3: PCM + open HDMI packets =====================
event_toggle_sync u_button_cue_sync (
    .dst_clk(video_clk), .dst_rst(rst_video),
    .src_toggle(button_event_toggle), .event_pulse(button_cue)
);
hdmi_video_position u_hdmi_video_position (
    .clk(video_clk), .rst(rst_video), .hsync(menu_hs), .vsync(menu_vs), .de(menu_de),
    .video_x(video_x), .video_next_line_active(video_next_line_active),
    .timing_locked(video_timing_locked), .coordinate_error()
);
// The card serves pictures first. Once complete, their four immutable SDRAM
// banks need no SD traffic; the same CRC-checked reader streams raw audio.
player_settings_control #(.PAGE_SEQUENCE_ENABLE(1),.NAVIGATION_GUARD_ENABLE(1),.CLK_FREQ_HZ(SD_CLK_HZ),.DEBOUNCE_MS(DEBOUNCE_MS),
    .LONG_PRESS_MS(500),.INITIAL_VOLUME_PERCENT(AUDIO_VOLUME_PERCENT)) u_key_controls(
    .clk(sd_card_clk),.rst(rst_tf),.key1_n(rst_n),.key2_n(key1),.key3_n(key3),.key4_n(key2),
    .thumbnail_context(thumbnail_context),.thumbnail_ready(tjc_state0_sd[10]),.thumbnail_mode_event(thumb_mode_event),
    .story_prompt(story_prompt),.story_ready(tjc_status_sd[8]),.story_chapter(story_chapter),
    .remote_valid(remote_valid),.remote_ready(remote_ready),.remote_cmd(remote_cmd),.remote_arg(remote_arg),
    .auto_play_state(auto_play_status),.display_ready(chapter_committed_sd),
    .navigation_busy(navigation_busy || remote_navigation_busy),.committed_chapter(disp_buf_idx),
    .relative_page_event(relative_page_event),.relative_page_end(relative_page_end),
    .auto_end_event(auto_end_event),.auto_restart_event(auto_restart_event),
    .replay_audio_event(replay_audio_event),.chapter_select_event(chapter_select_event),
    .settings_page_request(settings_page_request),.app_reset_request(app_reset_request),
    .chapter_select_index(chapter_select_index),
    .adventure_started(adventure_started),.ending_requested(ending_requested),.choice_cursor(choice_cursor),
    .choice_confirm_toggle(choice_confirm_toggle),.choice_open_event_toggle(choice_open_toggle),
    .thumbnail_next_event(thumb_next_event),.thumbnail_prev_event(thumb_prev_event),
    .thumbnail_confirm_event(thumb_confirm_event),.thumbnail_cancel_event(thumb_cancel_event),
    .next_image(next_image_event),.previous_image(previous_image_event),
    .auto_toggle(auto_toggle_event),.next_music(next_music_event),.cue_event(key_cue_event),.local_auto_enable(local_auto_enable),
    .previous_music(previous_music_event),.menu_visible(settings_visible),.selected_row(settings_row),
    .period_sel(period_sel),.effect_sel(effect_sel),
    .volume(volume_sd),.volume_toggle(volume_toggle),.dip_switches(dip_switches),
    .zoom_level(zoom_sd),.sharpness_percent(sharpness_sd),.saturation_percent(saturation_sd),
    .volume_percent(volume_percent_sd),.brightness_percent(brightness_percent_sd),.contrast_percent(contrast_percent_sd),
    .brightness(brightness_sd),.contrast(contrast_sd),.menu_mode(menu_mode_sd),.menu_step(menu_step_sd));
image_adjust_cdc u_image_adjust_cdc(
    .src_clk(sd_card_clk),.src_rst(rst_tf),
    .brightness(brightness_sd),.contrast(contrast_sd),.sharpness(sharpness_sd),.saturation(saturation_sd),.menu_mode(menu_mode_sd),.menu_step(menu_step_sd),
    .dst_clk(video_clk),.dst_rst(rst_video),.frame_start(frame_start_raw),
    .brightness_out(brightness_video),.contrast_out(contrast_video),.sharpness_out(sharpness_video),.saturation_out(saturation_video),
    .menu_mode_out(menu_mode_video),.menu_step_out(menu_step_video));
// Touch commands can arrive on adjacent SD clocks. An acknowledged held
// mailbox transfers the latest gain safely, unlike a debounced-key toggle.
player_settings_cdc #(.WIDTH(8),.RESET_VALUE(AUDIO_VOLUME)) u_volume_cdc(
    .src_clk(sd_card_clk),.src_rst(rst_tf),.source_state(volume_sd),
    .dst_clk(video_clk),.dst_rst(rst_video),.frame_start(1'b1),.active_state(volume_video));
music_switch_controller #(.PREVIOUS_ENABLE(0),.TRACK_COUNT(16),.INDEX_BITS(4),.DIRECT_ENABLE(1),.DIRECT_ONLY(1),.RESTART_ENABLE(1)) u_music_switch(
    .clk(sd_card_clk),.rst(rst_tf),.next_music(1'b0),.valid_mask(music_valid_mask[15:0]),
    .direct_valid(music_direct_valid),
    .direct_index(desired_music_index),.direct_restart(music_direct_restart),
    .previous_music(1'b0),
    .player_idle(wav_player_idle),.storage_idle(music_storage_idle),
    .music_index(music_index),.music_stop(music_stop));

dental_sfx_cache #(.CACHE_BYTES(16384),.TIMEOUT_CYCLES(SD_CLK_HZ)) u_sfx_cache (
    .clk(sd_card_clk),.rst(rst_tf),.load_start(osd_complete),.load_busy(),.load_done(sfx_load_done),
    .selected_index(sfx_selected_index),.file_present(music_present),.file_sectors(music_total_sectors),
    .raw_enable(sfx_raw_enable),.raw_req(sfx_req),.raw_lba(sfx_lba),
    .raw_ready(raw_ready && !sfx_load_done),.raw_valid(raw_valid && !sfx_load_done),
    .raw_byte(raw_byte),.raw_index(raw_index),.raw_done(raw_done && !sfx_load_done),
    .raw_error(sfx_load_done?8'd0:raw_error),.raw_idle(music_storage_idle),.raw_byte_ready(sfx_byte_ready),
    .valid_mask(sfx_valid_mask),.load_error(sfx_load_error),
    .pixel_clk(video_clk),.pixel_rst(rst_video),.cue_toggle(cue_toggle),.cue_id(cue_id),
    .sample_tick(wav_ready),.sfx_sample(sfx_sample),.active(sfx_active),.playback_ready());

wav_stream_player #(.ADDR_WIDTH(12),.LBA_BITS(WAV_FAT32_ENABLE!=0 ? 23 : 32),.PREFILL_SAMPLES(WAV_PREFILL_SAMPLES),
    .LOOP_ENABLE(WAV_LOOP_ENABLE),.SD_TIMEOUT_CYCLES(SD_CLK_HZ)) u_wav_player (
    .wr_clk(sd_card_clk),.wr_rst_n(~rst_tf),
    .play_enable(chapter_play_permitted && chapter_committed_sd && WAV_ENABLE!=0 && AUDIO_SOURCE!=0 && assets_ready && !osd_asset_error && !music_stop && !storage_stop && storage_index=={1'b0,music_index} && (WAV_FAT32_ENABLE==0 || music_present)),
    .start_lba(WAV_FAT32_ENABLE!=0 ? 32'd1 : WAV_START_LBA),
    .total_sectors(WAV_FAT32_ENABLE!=0 ? music_total_sectors : WAV_TOTAL_SECTORS),
    .sd_req(wav_sd_req),.sd_lba(wav_sd_lba),.sd_ready(wav_sd_ready),
    .sd_valid(wav_sd_valid),.sd_byte_ready(wav_sd_byte_ready),.sd_byte(wav_sd_byte),
    .sd_byte_index(wav_sd_index),.sd_done(wav_sd_done),.sd_error(wav_sd_error),
    .rd_clk(video_clk),.rd_rst_n(~rst_video),.sample_out(wav_sample),
    .sample_valid(wav_valid),.sample_ready(audio_pcm_consume),.stream_session(wav_read_session),.stream_active(wav_active),
    .stream_end(wav_end),.buffer_low(),.buffer_level(),
    .sample_counter(),.underflow_count(),
    .current_lba(),.sectors_read(),.loop_count(),
    .error_flags(wav_error_flags),.last_sd_error(),.player_idle(wav_player_idle),
    .prefill_ready(wav_prefill_ready)
);
media_hdmi_audio_bridge #(.PIXEL_HZ(PIXEL_CLK_HZ), .SAMPLE_HZ(AUDIO_SAMPLE_HZ),
    .TEST_HZ(AUDIO_TEST_HZ), .RAMP_SAMPLES(256),
    .CUE_MS(AUDIO_CUE_MS), .CUE_HZ(AUDIO_CUE_HZ),.CUE_STYLE(2),.WAV_FADE_ENABLE(0),.EXTERNAL_ONLY(1)) u_audio_bridge (
    .pixel_clk(video_clk), .pixel_rst_n(~rst_video),
    .timing_locked(video_timing_locked),
    .video_hsync(menu_hs), .video_vsync(menu_vs), .video_de(menu_de), .video_x(video_x),
    .video_next_line_active(video_next_line_active), .video_rgb(vout_data),
    .media_valid(media_audio_ready), .media_commit(1'b0), .media_id(2'd0),
    .cue_trigger(1'b0),
    .source_select(2'd2), .volume(volume_video), .mute(AUDIO_MUTE != 0 || !media_audio_ready),
    .fade_alpha(transition_audio_alpha),
    // EOF keeps zero PCM available while the existing source envelope fades out.
    .external_valid(1'b1), .external_ready(wav_ready),
    .external_left(mixed_sample), .external_right(mixed_sample),
    .channel0_symbol(tmds_ch0_data), .channel1_symbol(tmds_ch1_data),
    .channel2_symbol(tmds_ch2_data),
    .sequence_error(), .tone_overflow(),
    .tone_underrun(), .pcm_contract_error(),
    .blip_active(), .active_media_id(),
    .active_source(), .pcm_tap_valid(audio_pcm_tap_valid),
    .pcm_tap_left(audio_pcm_tap_left), .pcm_tap_right(), .pcm_ready(),
    .packet_sent(), .packet_type(),
    .packet_count()
);
assign tmds_clk_data = 10'b1111100000;
// Fixed 640x480 RGB mode, 25 MHz (~59.52 fps). DDC stays electrically idle;
// the public core sends AVI VIC=0 and does not claim EDID auto-detection.
assign HDMI_DDC_SCL = 1'b1;
assign HDMI_DDC_SDA = 1'bz;

hdmi_phy_wrapper #(
    .DEVICE ( "EG" )
) u_hdmi2phy_wrapper(
    .I_pixel_clk        (video_clk),
    .I_serial_clk       (hdmi_5x_clk),
    .I_rst              (rst_video),
    .I_serial_rst       (rst_serial),
    .I_tmds_channel_0   (tmds_ch0_data),
    .I_tmds_channel_1   (tmds_ch1_data),
    .I_tmds_channel_2   (tmds_ch2_data),
    .I_tmds_channel_clk (tmds_clk_data),
    .O_tmds_ch0_p       (HDMI_D0_P),
    .O_tmds_ch1_p       (HDMI_D1_P),
    .O_tmds_ch2_p       (HDMI_D2_P),
    .O_tmds_clk_p       (HDMI_CLK_P)
);

assign chapter_pixel_commit=reader_pixel_frame_commit && !reader_pixel_is_start && !reader_pixel_is_end && start_reader_run;
assign display_frame_ready=reader_pixel_is_start || reader_pixel_is_end || (chapter_frame_seen && display_valid_video_sync[1]) || reader_pixel_view;
assign reader_start_context=reader_pixel_is_start || (!chapter_frame_seen && !reader_pixel_is_end);
// The physical picture owns the foreground until the reader commits the new page.
assign story_frame_started=chapter_frame_seen && !osd_start_pipe[5] && !osd_end_pipe[5];
endmodule
