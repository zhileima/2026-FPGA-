`timescale 1ns/1ps
// One coalescing touch queue and explicit ownership of the reader's completion.
// A one-clock idle boundary after done deliberately separates old and new ACKs.
module sound_chapter_arbiter #(parameter integer RELATIVE_ENABLE=0, parameter integer PAGE_SEQUENCE_ENABLE=0)(
 input wire clk,rst,adventure_started,chapter_committed,
 input wire thumbnail_context,thumbnail_enter_event,
 input wire remote_event,input wire[2:0]remote_index,
 input wire relative_next,relative_previous,input wire [2:0]actual_index,
 input wire [7:0]available_mask,input wire scan_complete,
 input wire thumb_valid,input wire[2:0]thumb_index,
 output wire thumb_ready,thumb_done,
 output wire media_valid,output wire[2:0]media_index,output wire media_manual,
 input wire media_ready,media_done,output wire remote_busy,
 output reg relative_page_event,relative_page_end
);
 localparam[1:0]IDLE=0,THUMB=1,REMOTE=2;
 reg[1:0]owner;
 reg remote_pending;
 reg[2:0]pending_index;
 wire thumb_offer=owner==IDLE && thumb_valid;
 wire remote_offer=owner==IDLE && !thumb_valid && remote_pending &&
   adventure_started && chapter_committed && !thumbnail_context && !thumbnail_enter_event;
 assign media_valid=thumb_offer||remote_offer;
 assign media_index=thumb_offer?thumb_index:pending_index;
 assign thumb_ready=thumb_offer&&media_ready;
 assign thumb_done=owner==THUMB&&media_done;
 // Reuse the three-bit queued target as the cumulative navigation intent.
 // While an older target is draining, every relative gesture advances this
 // target rather than repeatedly advancing the still-displayed old chapter.
 wire relative_event=RELATIVE_ENABLE!=0 && (relative_next||relative_previous) &&
   adventure_started && !thumbnail_context && !thumbnail_enter_event;
 wire [2:0]relative_base=(remote_pending||owner==REMOTE)?pending_index:actual_index;
 function [2:0] relative_target;
  input [2:0]base;input backwards;input [7:0]mask;
  integer i;reg found;reg[2:0]candidate;
  begin
   relative_target=base;found=0;
   for(i=1;i<8;i=i+1)begin
    candidate=backwards?base-i:base+i;
    if(!found&&mask[candidate])begin relative_target=candidate;found=1;end
   end
  end
 endfunction
 // Only the chapter boundary leaves the existing eight-bank sequence.
 // Use the queued intent rather than the lagging committed frame index.
 wire boundary_backward=relative_previous&&!relative_next;
 wire relative_boundary=PAGE_SEQUENCE_ENABLE!=0 && relative_event &&
   (boundary_backward ? relative_base==0 : relative_base==7);
 assign media_manual=remote_offer;
 // Include an arriving manual event so autoplay cannot start on this edge.
 assign remote_busy=remote_pending||owner==REMOTE||relative_event||
   (remote_event&&adventure_started&&!thumbnail_context&&!thumbnail_enter_event);
 always @(posedge clk or posedge rst)begin
  if(rst)begin owner<=IDLE;remote_pending<=0;pending_index<=0;relative_page_event<=0;relative_page_end<=0;end
  else begin
   relative_page_event<=0;
   if(media_done && owner!=IDLE)owner<=IDLE;
   if(media_valid&&media_ready)begin
    owner<=thumb_offer?THUMB:REMOTE;
    if(remote_offer)remote_pending<=0;
   end
   // A discovered but uncached chapter remains pending. A terminal missing/
   // failed target is released once directory discovery is complete.
   if(RELATIVE_ENABLE!=0 && remote_pending && scan_complete && !available_mask[pending_index])
    remote_pending<=0;
   if(relative_event && |available_mask)begin
    if(relative_boundary)begin
     relative_page_event<=1;relative_page_end<=!boundary_backward;remote_pending<=0;
    end else begin
     pending_index<=relative_target(relative_base,boundary_backward,available_mask);
     remote_pending<=1;
    end
   end
   // Absolute selection wins over a simultaneous relative gesture.
   // Requests received during a drain replace only the queued next target.
   // A simultaneous acceptance plus new event keeps the new queue entry.
   if(remote_event && adventure_started && !thumbnail_context && !thumbnail_enter_event)begin
    pending_index<=remote_index;remote_pending<=1;relative_page_event<=0;
   end
   if(!adventure_started || thumbnail_context || thumbnail_enter_event)remote_pending<=0;
  end
 end
endmodule
