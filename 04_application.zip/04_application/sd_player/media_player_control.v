`timescale 1ns/1ps
// Four-bank navigation policy, separate from FAT discovery and frame loading.
// A request is held as a stable {bank, token} bundle until the reader commits
// it at a frame boundary. Number/audio publication follows the matching ACK.
module media_player_control #(
    parameter integer BANK_BITS=2,
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer AUTO_PLAY_MS = 1000,
    parameter integer THUMBNAIL_CONTROL_ENABLE = 0,
    parameter integer SETTINGS_ENABLE = 0,
    parameter integer AUDIO_DWELL_ENABLE = 0,
    // Keep the auto mode/status for OSD pacing even when an external screen
    // owns every chapter request. Legacy instances retain their own scheduler.
    parameter integer AUTO_ADVANCE_ENABLE = 1,
    parameter integer EXTERNAL_SCHEDULER_ENABLE = 0,
    parameter integer DIRECT_MANUAL_ENABLE = 0,
    parameter integer END_PAGE_SEQUENCE_ENABLE = 0
)(
    input wire clk, input wire rst,
    input wire key_next_press, input wire key_auto_short, input wire key_auto_long,
    input wire [(1<<BANK_BITS)-1:0] available_mask, input wire [(1<<BANK_BITS)-1:0] cache_valid_mask,
    input wire first_publish_allowed, input wire [BANK_BITS-1:0] first_valid_index,
    input wire first_valid_found, input wire cache_ready,
    input wire read_switch_ack_toggle, input wire [BANK_BITS-1:0] read_switch_ack_idx,
    output reg [BANK_BITS-1:0] img_idx, output reg [3:0] image_number,
    output reg display_valid, output reg first_image_committed,
    output reg auto_play_en, output reg [32:0] auto_cnt,
    output reg switch_pending, output reg [BANK_BITS-1:0] read_buf_req_idx,
    output reg read_switch_req_toggle, output reg [3:0] read_switch_req_kind,
    output reg [BANK_BITS-1:0] pending_display_idx,
    output reg [BANK_BITS-1:0] disp_buf_idx,
    output reg next_req_pending, output reg prev_req_pending,
    output reg auto_req_pending, output reg [7:0] control_error,
    input wire pause_navigation, input wire direct_select_valid,
    input wire [BANK_BITS-1:0] direct_select_index,input wire direct_select_manual,
    output wire direct_select_ready, output reg direct_select_done,
    input wire [2:0] period_sel, input wire [3:0] effect_sel,
    input wire auto_audio_ready,input wire local_auto_enable,
    input wire end_page_active,output reg auto_end_event,auto_restart_event
);
    localparam [63:0] AUTO_PLAY_CYCLES =
        (64'd1 * CLK_FREQ_HZ * AUTO_PLAY_MS + 999) / 1000;
    initial begin
        if (CLK_FREQ_HZ <= 0 || AUTO_PLAY_MS <= 0 ||
            AUTO_PLAY_CYCLES < 1 || AUTO_PLAY_CYCLES > 64'hffffffff) begin
            $display("MEDIA_CONTROL_CONFIG_ERROR invalid autoplay period");
            $finish;
        end
    end

    // Payload settles one destination clock before its token is recognized.
    (* ASYNC_REG = "TRUE" *) reg [2:0] read_ack_tgl_sync;
    (* ASYNC_REG = "TRUE" *) reg [BANK_BITS-1:0] read_ack_idx_d0, read_ack_idx_d1;
    wire has_other_image = |(available_mask & ~({{((1<<BANK_BITS)-1){1'b0}},1'b1} << img_idx));
    // Constant options avoid a runtime multiplier/divider. The period is
    // measured from the last fully committed image, including after edits.
    reg [32:0] selected_period;
    reg [2:0] previous_period;
    always @* begin
        case(period_sel)
            0:selected_period=CLK_FREQ_HZ;
            1:selected_period=3*CLK_FREQ_HZ;
            2:selected_period=5*CLK_FREQ_HZ;
            3:selected_period=64'd15*CLK_FREQ_HZ;
            4:selected_period=64'd30*CLK_FREQ_HZ;
            default:selected_period=64'd60*CLK_FREQ_HZ;
        endcase
    end
    wire period_changed=SETTINGS_ENABLE!=0 && period_sel!=previous_period;
    wire auto_tick = auto_cnt == (SETTINGS_ENABLE!=0 ? selected_period-1'b1 : AUTO_PLAY_CYCLES-1);
    wire auto_advance_allowed=AUTO_ADVANCE_ENABLE!=0 &&
        (EXTERNAL_SCHEDULER_ENABLE==0 || local_auto_enable);
    // Menu IDs 0..8 map directly to effects. Internal 15 is reserved for the
    // initial image and thumbnail handoff, which own their reveal separately.
    wire [3:0] manual_kind = SETTINGS_ENABLE==0 ? 4'd0 : effect_sel;
    wire [3:0] automatic_kind = SETTINGS_ENABLE==0 ? 4'd1 : effect_sel;
    wire navigation_paused = (THUMBNAIL_CONTROL_ENABLE != 0) && pause_navigation;
    // Existing auto_cnt starts only once this committed chapter has PCM ready.
    // Keep the latch through sample-valid gaps and same-bank thumbnail ACKs.
    // Missing/terminal audio is explicitly qualified by top as silent-ready.
    reg audio_dwell_started;
    wire dwell_allowed=AUDIO_DWELL_ENABLE==0 || audio_dwell_started;
    reg direct_inflight;
    assign direct_select_ready = (THUMBNAIL_CONTROL_ENABLE != 0) &&
        first_image_committed && display_valid && !switch_pending &&
        available_mask[direct_select_index] && cache_valid_mask[direct_select_index];
    wire direct_select_fire = direct_select_ready && direct_select_valid;

    function [BANK_BITS-1:0] next_available;
        input [BANK_BITS-1:0] cur; input [(1<<BANK_BITS)-1:0] available;
        integer k; reg found; reg [BANK_BITS-1:0] candidate;
        begin
            next_available=cur;found=0;
            for(k=1;k<(1<<BANK_BITS);k=k+1) begin
                candidate=cur+k;
                if(!found && available[candidate]) begin next_available=candidate;found=1;end
            end
        end
    endfunction
    function [BANK_BITS-1:0] prev_available;
        input [BANK_BITS-1:0] cur; input [(1<<BANK_BITS)-1:0] available;
        integer k; reg found; reg [BANK_BITS-1:0] candidate;
        begin
            prev_available=cur;found=0;
            for(k=1;k<(1<<BANK_BITS);k=k+1) begin
                candidate=cur-k;
                if(!found && available[candidate]) begin prev_available=candidate;found=1;end
            end
        end
    endfunction
    wire [BANK_BITS-1:0] next_from_current = next_available(img_idx, available_mask);
    wire [BANK_BITS-1:0] prev_from_current = prev_available(img_idx, available_mask);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            read_ack_tgl_sync<=0; read_ack_idx_d0<=0; read_ack_idx_d1<=0;
            img_idx<=0; image_number<=0; display_valid<=0; first_image_committed<=0;
            auto_play_en<=0; auto_cnt<=0; switch_pending<=0;
            read_buf_req_idx<=0; read_switch_req_toggle<=0; read_switch_req_kind<=4'hf;
            pending_display_idx<=0; disp_buf_idx<=0;
            next_req_pending<=0; prev_req_pending<=0; auto_req_pending<=0;
            control_error<=0;direct_inflight<=0;direct_select_done<=0;previous_period<=2;audio_dwell_started<=0;auto_end_event<=0;auto_restart_event<=0;
        end else begin
            previous_period<=period_sel;auto_end_event<=0;auto_restart_event<=0;
            if(AUDIO_DWELL_ENABLE!=0) begin
                if(switch_pending && read_ack_tgl_sync[2]==read_switch_req_toggle &&
                   read_ack_idx_d1==pending_display_idx &&
                   (!display_valid || img_idx!=pending_display_idx)) audio_dwell_started<=0;
                else if(display_valid && auto_audio_ready) audio_dwell_started<=1;
            end
            direct_select_done<=0;
            read_ack_tgl_sync<={read_ack_tgl_sync[1:0],read_switch_ack_toggle};
            read_ack_idx_d0<=read_switch_ack_idx; read_ack_idx_d1<=read_ack_idx_d0;
            if (switch_pending && read_ack_tgl_sync[2]==read_switch_req_toggle) begin
                if (read_ack_idx_d1==pending_display_idx) begin
                    switch_pending<=0; disp_buf_idx<=pending_display_idx;
                    img_idx<=pending_display_idx;
                    image_number<=pending_display_idx+4'd1;
                    display_valid<=1; first_image_committed<=1; auto_cnt<=0;
                    if(direct_inflight) begin direct_select_done<=1;direct_inflight<=0;end
                end else begin
                    // 1: reader echoed this request's token with a wrong bank.
                    // A queued request or an incomplete target is not an error.
                    control_error<=8'd1;
                end
            end

            if (!navigation_paused && key_next_press && display_valid && has_other_image) next_req_pending<=1;
            if (!navigation_paused && key_auto_long && display_valid && has_other_image) prev_req_pending<=1;
            if ((!navigation_paused || SETTINGS_ENABLE!=0) && key_auto_short && (display_valid || SETTINGS_ENABLE!=0)) begin
                auto_play_en<=~auto_play_en; auto_cnt<=0; auto_req_pending<=0;
            end
            // Keep the user's auto-enable choice while the thumbnail UI owns
            // navigation. Old gestures must not execute on return to fullscreen.
            if(navigation_paused) begin
                next_req_pending<=0;prev_req_pending<=0;auto_req_pending<=0;
            end
            // Dwell starts after publication and terminal preload, as before.
            if (END_PAGE_SEQUENCE_ENABLE!=0 && end_page_active && auto_advance_allowed &&
                auto_play_en && !key_auto_short && !period_changed && !direct_select_valid)begin
                // END uses the existing dwell timer, starting only after its
                // physical reader commit. It has no chapter audio dependency.
                if(auto_tick)begin auto_cnt<=0;auto_restart_event<=1;end
                else auto_cnt<=auto_cnt+1'b1;
            end else if (auto_advance_allowed && !navigation_paused && cache_ready && auto_play_en && !key_auto_short && display_valid && dwell_allowed &&
                !switch_pending && !next_req_pending && !prev_req_pending && !period_changed) begin
                if (auto_tick) begin auto_cnt<=0; auto_req_pending<=1; end
                else auto_cnt<=auto_cnt+1'b1;
            end else auto_cnt<=0;
            if(period_changed || !auto_advance_allowed) auto_req_pending<=0;

            if (!switch_pending) begin
                if (!first_image_committed && first_valid_found && first_publish_allowed &&
                    cache_valid_mask[first_valid_index]) begin
                    pending_display_idx<=first_valid_index; read_buf_req_idx<=first_valid_index;
                    read_switch_req_kind<=4'hf; read_switch_req_toggle<=~read_switch_req_toggle; switch_pending<=1;
                end else if (direct_select_fire) begin
                    // Even the current bank receives a fresh token. This gives
                    // thumbnail exit an explicit matching ACK, including when
                    // only one image is available. The UI owns its own fade.
                    pending_display_idx<=direct_select_index;read_buf_req_idx<=direct_select_index;
                    read_switch_req_kind<=(DIRECT_MANUAL_ENABLE!=0 && direct_select_manual)?manual_kind:4'hf;
                    read_switch_req_toggle<=~read_switch_req_toggle;switch_pending<=1;
                    direct_inflight<=1;next_req_pending<=0;prev_req_pending<=0;auto_req_pending<=0;auto_cnt<=0;
                end else if (!navigation_paused && display_valid && has_other_image) begin
                    // Each direction has one coalescing queue slot. A discovered
                    // target that is still filling is awaited, rather than skipped.
                    if (next_req_pending || key_next_press) begin
                        if (cache_valid_mask[next_from_current]) begin
                            pending_display_idx<=next_from_current; read_buf_req_idx<=next_from_current;
                            read_switch_req_kind<=manual_kind; read_switch_req_toggle<=~read_switch_req_toggle; switch_pending<=1;
                            next_req_pending<=0; auto_req_pending<=0;
                        end
                    end else if (prev_req_pending || key_auto_long) begin
                        if (cache_valid_mask[prev_from_current]) begin
                            pending_display_idx<=prev_from_current; read_buf_req_idx<=prev_from_current;
                            read_switch_req_kind<=manual_kind; read_switch_req_toggle<=~read_switch_req_toggle; switch_pending<=1;
                            prev_req_pending<=0; auto_req_pending<=0;
                        end
                    end else if (auto_advance_allowed && auto_req_pending && cache_valid_mask[next_from_current] &&
                                 !key_auto_short && !period_changed) begin
                        if(END_PAGE_SEQUENCE_ENABLE!=0 && img_idx=={BANK_BITS{1'b1}})begin
                            // The eighth chapter completes at END instead of
                            // wrapping the three-bit chapter index to zero.
                            auto_end_event<=1;auto_cnt<=0;
                        end else begin
                            pending_display_idx<=next_from_current;read_buf_req_idx<=next_from_current;
                            read_switch_req_kind<=automatic_kind;read_switch_req_toggle<=~read_switch_req_toggle;switch_pending<=1;
                        end
                        auto_req_pending<=0;
                    end
                end
            end
        end
    end
endmodule
