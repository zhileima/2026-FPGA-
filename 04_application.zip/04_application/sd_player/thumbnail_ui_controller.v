`timescale 1ns/1ps
// Input events and a held selection mailbox cross between the SD and pixel
// domains. Visible UI state changes only at the video frame boundary.
module thumbnail_ui_controller #(
    parameter integer BANK_BITS=2,
    parameter integer EXIT_EFFECT=2,
    parameter integer TIMEOUT_FRAMES=180
)(
    input wire ctrl_clk,ctrl_rst,pixel_clk,pixel_rst,frame_start,
    input wire mode_event,next_event,prev_event,confirm_event,cancel_event,
    input wire [(1<<BANK_BITS)-1:0] valid_mask,present_mask,failed_mask,
    input wire scan_complete,navigation_busy,
    input wire actual_view, input wire [BANK_BITS-1:0] actual_index,
    input wire focus_cache_ready,
    output wire pause_navigation,thumbnail_context,controls_ready,
    output reg direct_select_valid, output reg [BANK_BITS-1:0] direct_select_index,
    input wire direct_select_ready,direct_select_done,
    output reg requested_view, output reg [BANK_BITS-1:0] focus,
    output reg [(1<<BANK_BITS)-1:0] frame_valid,frame_present,frame_failed,
    output reg frame_scan_complete,
    output wire animation_active, output reg [4:0] animation_step,
    output reg [1:0] animation_kind,
    output wire [7:0] full_alpha,
    output reg [7:0] error_flags
);
    localparam [2:0] FULL=0,ENTER=1,GRID=2,SELECT=3,ANIMATE=4,WAIT_FULL=5,REVEAL=6;
    reg [2:0] state;
    reg [4:0] event_toggle;
    (* ASYNC_REG="TRUE" *) reg [4:0] event_meta,event_sync,event_qual;
    reg [4:0] event_seen,pending_events;
    wire [4:0] requests=pending_events | (event_qual^event_seen);
    (* ASYNC_REG="TRUE" *) reg [3*(1<<BANK_BITS):0] status_meta,status_sync,status_qual;
    (* ASYNC_REG="TRUE" *) reg [1:0] busy_sync,context_sync;
    reg select_toggle,select_ack,select_seen,select_wait;
    reg [BANK_BITS-1:0] selected_index;
    (* ASYNC_REG="TRUE" *) reg [2:0] select_sync,ack_sync;
    (* ASYNC_REG="TRUE" *) reg [BANK_BITS-1:0] index_meta,index_sync;
    reg [7:0] timeout_count;
    reg [3:0] reveal_step;
    reg confirm_pending;
    reg context_pixel;
    // Register the source indication, rather than crossing a combinational
    // decode of a multi-bit state transition (for example SELECT -> ANIMATE).
    always @(posedge pixel_clk or posedge pixel_rst)
        if(pixel_rst) context_pixel<=0;
        else context_pixel<=state!=FULL;
    reg entry_hold;
    assign pause_navigation=context_sync[1] || entry_hold || mode_event;
    assign thumbnail_context=context_sync[1] || entry_hold;
    assign controls_ready=state==GRID;
    assign animation_active=state==ANIMATE || state==WAIT_FULL;
    assign full_alpha=(animation_kind==0 && state==WAIT_FULL) ? 8'd0 :
        (state==REVEAL ? (reveal_step==8 ? 8'd255 : {reveal_step[2:0],5'b0}) : 8'd255);

    // A request is held until accepted; the acknowledgment returns only after
    // the player's matching reader token commits, including same-bank picks.
    always @(posedge ctrl_clk or posedge ctrl_rst) begin
        if(ctrl_rst) begin
            event_toggle<=0;context_sync<=0;select_sync<=0;index_meta<=0;index_sync<=0;entry_hold<=0;
            select_seen<=0;select_wait<=0;select_ack<=0;
            direct_select_valid<=0;direct_select_index<=0;
        end else begin
            event_toggle<=event_toggle^{cancel_event,confirm_event,prev_event,next_event,mode_event};
            context_sync<={context_sync[0],context_pixel};
            if(mode_event && !context_sync[1]) entry_hold<=1;
            else if(context_sync[1]) entry_hold<=0;
            select_sync<={select_sync[1:0],select_toggle};
            index_meta<=selected_index;index_sync<=index_meta;
            if(select_sync[2]!=select_seen && !select_wait && !direct_select_valid) begin
                select_seen<=select_sync[2];direct_select_index<=index_sync;direct_select_valid<=1;
            end
            if(direct_select_valid && direct_select_ready) begin
                direct_select_valid<=0;select_wait<=1;
            end
            if(select_wait && direct_select_done) begin
                select_wait<=0;select_ack<=select_seen;
            end
        end
    end

    always @(posedge pixel_clk or posedge pixel_rst) begin
        if(pixel_rst) begin
            state<=FULL;event_meta<=0;event_sync<=0;event_qual<=0;event_seen<=0;pending_events<=0;
            status_meta<=0;status_sync<=0;status_qual<=0;busy_sync<=0;ack_sync<=0;
            requested_view<=0;focus<=0;frame_valid<=0;frame_present<=0;frame_failed<=0;
            frame_scan_complete<=0;animation_step<=0;animation_kind<=EXIT_EFFECT;
            select_toggle<=0;selected_index<=0;timeout_count<=0;reveal_step<=0;
            error_flags<=0;confirm_pending<=0;
        end else begin
            event_meta<=event_toggle;event_sync<=event_meta;event_qual<=event_sync;
            event_seen<=event_qual;pending_events<=requests;
            status_meta<={scan_complete,failed_mask,present_mask,valid_mask};
            status_sync<=status_meta;status_qual<=status_sync;
            busy_sync<={busy_sync[0],navigation_busy};
            ack_sync<={ack_sync[1:0],select_ack};
            if(frame_start) begin
                frame_valid<=status_qual[(1<<BANK_BITS)-1:0];frame_present<=status_qual[2*(1<<BANK_BITS)-1:(1<<BANK_BITS)];
                frame_failed<=status_qual[3*(1<<BANK_BITS)-1:2*(1<<BANK_BITS)];frame_scan_complete<=status_qual[3*(1<<BANK_BITS)];
                pending_events<=0;
                case(state)
                    FULL: begin
                        animation_step<=0;timeout_count<=0;confirm_pending<=0;
                        if(requests[0]) begin
                            // An already issued full-screen navigation finishes
                            // first; retain the mode request while it is busy.
                            if(busy_sync[1]) pending_events[0]<=1;
                            else begin focus<=actual_index;requested_view<=1;state<=ENTER;end
                        end
                    end
                    ENTER: begin
                        if(actual_view) begin state<=GRID;timeout_count<=0;end
                        else if(timeout_count==TIMEOUT_FRAMES-1) begin
                            error_flags[0]<=1;requested_view<=0;state<=WAIT_FULL;animation_kind<=0;
                        end else timeout_count<=timeout_count+1'b1;
                    end
                    GRID: begin
                        timeout_count<=0;animation_step<=0;
                        if(requests[0] || requests[4]) begin
                            animation_kind<=0;state<=ANIMATE;confirm_pending<=0;
                        end else if(requests[1] || requests[2]) begin
                            // Navigation wins over a simultaneous confirm; do
                            // not select the stale focus/cache from this frame.
                            if(requests[1] && !requests[2]) focus<=focus+1'b1;
                            else if(requests[2] && !requests[1]) focus<=focus-1'b1;
                            confirm_pending<=0;
                        end else if(requests[3] || confirm_pending) begin
                            if(frame_valid[focus] && !frame_failed[focus]) begin
                                if(focus_cache_ready) begin
                                    selected_index<=focus;select_toggle<=~select_toggle;
                                    animation_kind<=EXIT_EFFECT;state<=SELECT;confirm_pending<=0;
                                end else confirm_pending<=1;
                            end else confirm_pending<=0;
                        end
                    end
                    SELECT: begin
                        if(ack_sync[2]==select_toggle) begin state<=ANIMATE;timeout_count<=0;end
                        else if(timeout_count==TIMEOUT_FRAMES-1) begin
                            // Keep the mailbox valid and the browser stable:
                            // never fabricate completion or issue a second one.
                            error_flags[1]<=1;
                        end else timeout_count<=timeout_count+1'b1;
                    end
                    ANIMATE: begin
                        if(animation_step==20) begin requested_view<=0;state<=WAIT_FULL;timeout_count<=0;end
                        else animation_step<=animation_step+1'b1;
                    end
                    WAIT_FULL: begin
                        if(!actual_view) begin
                            timeout_count<=0;
                            if(animation_kind==0) begin state<=REVEAL;reveal_step<=0;end
                            else state<=FULL;
                        end else if(timeout_count==TIMEOUT_FRAMES-1) error_flags[2]<=1;
                        else timeout_count<=timeout_count+1'b1;
                    end
                    REVEAL: begin
                        if(reveal_step==8) state<=FULL;
                        else reveal_step<=reveal_step+1'b1;
                    end
                    default: begin state<=FULL;requested_view<=0;end
                endcase
            end
        end
    end
endmodule
