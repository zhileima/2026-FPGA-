`timescale 1ns/1ps
// One automatic A audition per chapter per reset. Re-entered chapters stay
// silent; explicit A/B/replay always restart one complete, non-looping clip.
// All inputs/outputs belong to the SD clock domain; no new CDC is introduced.
module chapter_audio_policy(
    input wire clk,rst,chapter_active,chapter_ready,navigation_active,
    input wire [2:0] chapter_index,
    input wire audition_event,
    output wire play_permitted,output wire silent_ready,
    output reg restart_event
);
    reg [7:0] visited;
    reg context_valid,play_requested,request_pending;
    reg [2:0] context_index;
    wire new_context=!context_valid || context_index!=chapter_index;
    assign play_permitted=chapter_active && !navigation_active && context_valid &&
        context_index==chapter_index && play_requested;
    assign silent_ready=chapter_active && chapter_ready && !navigation_active &&
        context_valid && context_index==chapter_index && !play_requested && !request_pending;
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            visited<=0;context_valid<=0;context_index<=0;
            play_requested<=0;request_pending<=0;restart_event<=0;
        end else begin
            restart_event<=0;
            if(!chapter_active || navigation_active)begin
                context_valid<=0;play_requested<=0;request_pending<=0;
            end else begin
                if(context_valid && context_index!=chapter_index)play_requested<=0;
                if(audition_event)request_pending<=1;
                if(chapter_ready)begin
                    if(new_context)begin
                        context_valid<=1;context_index<=chapter_index;
                        visited[chapter_index]<=1;
                        if(!visited[chapter_index] || audition_event || request_pending)begin
                            play_requested<=1;restart_event<=1;
                        end else play_requested<=0;
                        request_pending<=0;
                    end else if(audition_event || request_pending)begin
                        play_requested<=1;restart_event<=1;request_pending<=0;
                    end
                end
            end
        end
    end
endmodule
