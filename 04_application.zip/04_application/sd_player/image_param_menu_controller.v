`timescale 1ns/1ps
// Logical DIP bits: [1:0] select volume/brightness/contrast/restore;
// [3:2] select image parameter increments of 1/4/16/32. Physical switch
// polarity belongs at the board top level. KEY3 gestures are already
// debounced by player_key_gesture. A complete gesture retains its selection.
module image_param_menu_controller #(
    parameter integer CLK_FREQ_HZ=100_000_000,
    parameter integer DEBOUNCE_MS=20
)(
    input clk,input rst,input [3:0] dip_switches,
    input key_press,input key_short,input key_decrease,input key_held,
    output volume_selected,
    output reg [7:0] brightness,output reg [7:0] contrast,
    output [1:0] menu_mode,output [5:0] menu_step
);
    localparam integer DB=(CLK_FREQ_HZ/1000)*DEBOUNCE_MS;
    localparam integer DW=$clog2(DB+1)<1?1:$clog2(DB+1);
    (* async_reg="true" *) reg [3:0] dip_meta,dip_sync;
    reg [3:0] dip_candidate,dip_stable;
    reg [DW-1:0] dip_count;
    reg [1:0] gesture_mode;
    reg [5:0] gesture_step;

    function [5:0] step_value;
        input [1:0] selection;
        begin
            case(selection)
                2'b00:step_value=6'd1;
                2'b01:step_value=6'd4;
                2'b10:step_value=6'd16;
                default:step_value=6'd32;
            endcase
        end
    endfunction
    function [7:0] increase_saturated;
        input [7:0] value;
        input [5:0] step;
        reg [8:0] sum;
        begin
            sum={1'b0,value}+{3'b0,step};
            increase_saturated=sum[8]?8'd255:sum[7:0];
        end
    endfunction
    function [7:0] decrease_saturated;
        input [7:0] value;
        input [5:0] step;
        begin
            decrease_saturated=(value<{2'b0,step})?8'd0:value-{2'b0,step};
        end
    endfunction

    assign volume_selected=(gesture_mode==2'b00);
    // Show the target actually being adjusted during a held gesture.
    assign menu_mode=key_held?gesture_mode:dip_stable[1:0];
    // Volume retains its established fixed 16-step gain; DIP step bits
    // select only the brightness/contrast increment shown by the menu.
    assign menu_step=(menu_mode==2'b00)?6'd16:
                     (key_held?gesture_step:step_value(dip_stable[3:2]));

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            dip_meta<=0;dip_sync<=0;dip_candidate<=0;dip_stable<=0;dip_count<=0;
        end else begin
            dip_meta<=dip_switches;dip_sync<=dip_meta;
            // Any change to any of the four bits restarts the interval.
            if(dip_sync!=dip_candidate) begin
                dip_candidate<=dip_sync;dip_count<=0;
            end else if(dip_candidate==dip_stable) dip_count<=0;
            else if(dip_count==DB-1) begin
                dip_stable<=dip_candidate;dip_count<=0;
            end else dip_count<=dip_count+1'b1;
        end
    end

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            brightness<=8'd255;contrast<=8'd128;
            gesture_mode<=2'b00;gesture_step<=6'd1;
        end else begin
            if(key_press) begin
                gesture_mode<=dip_stable[1:0];
                gesture_step<=step_value(dip_stable[3:2]);
            end
            if(key_short) begin
                case(gesture_mode)
                    2'b01:brightness<=increase_saturated(brightness,gesture_step);
                    2'b10:contrast<=increase_saturated(contrast,gesture_step);
                    2'b11:begin brightness<=8'd255;contrast<=8'd128;end
                    default:begin end
                endcase
            end else if(key_decrease) begin
                case(gesture_mode)
                    2'b01:brightness<=decrease_saturated(brightness,gesture_step);
                    2'b10:contrast<=decrease_saturated(contrast,gesture_step);
                    default:begin end
                endcase
            end
        end
    end
    initial if(DB<1) begin $display("IMAGE_MENU_CONFIG_ERROR");$finish;end
endmodule
