`timescale 1ns/1ps
// KEY1: start/next or previous; KEY2: contrast +/-5%; KEY3: brightness +/-5%.
// KEY4: short local autoplay toggle, long read-only HDMI information toggle.
// Release-short and 500ms-long gestures are mutually exclusive and one-shot.
// Settings belong to the SD clock domain; video-side copies must use CDC.
module player_settings_control #(
    parameter integer CLK_FREQ_HZ=50_000_000,
    parameter integer DEBOUNCE_MS=20,
    parameter integer LONG_PRESS_MS=500,
    parameter integer INITIAL_VOLUME_PERCENT=38,
    parameter integer VOLUME_STEP_PERCENT=5,
    parameter integer USE_SHARED_KEY_TICK=1,
    parameter integer NAVIGATION_GUARD_ENABLE=0,
    parameter integer PAGE_SEQUENCE_ENABLE=0
)(
    input clk,input rst,
    input key1_n,input key2_n,input key3_n,input key4_n,
    input [3:0] dip_switches,input thumbnail_context,input thumbnail_ready,
    // Stable SD-domain snapshots supplied by the top-level video->SD CDC.
    input story_prompt,input story_ready,input [2:0] story_chapter,
    // Functional touch commands share the same actions and parameter ALU.
    input remote_valid,input [7:0] remote_cmd,remote_arg,
    output wire remote_ready,input wire auto_play_state,input wire display_ready,
    input wire navigation_busy,input wire [2:0]committed_chapter,
    input wire relative_page_event,relative_page_end,auto_end_event,auto_restart_event,
    output reg replay_audio_event,chapter_select_event,
    output reg settings_page_request,app_reset_request,
    output reg [2:0] chapter_select_index,
    output reg adventure_started,output reg ending_requested,output reg choice_cursor,
    output reg choice_confirm_toggle,output reg choice_open_event_toggle,
    output reg menu_visible,output wire [3:0] selected_row,
    output reg [2:0] period_sel,output reg [3:0] effect_sel,
    output reg [7:0] volume,output reg volume_toggle,
    output reg [7:0] brightness,output reg [7:0] contrast,
    output reg [7:0] volume_percent,brightness_percent,contrast_percent,
    output reg [2:0] zoom_level,output reg [7:0] sharpness_percent,saturation_percent,
    output [1:0] menu_mode,output [5:0] menu_step,
    output reg next_image,output reg previous_image,
    output wire next_music,output wire previous_music,
    output reg auto_toggle,output reg cue_event,output wire local_auto_enable,
    output reg thumbnail_mode_event,output reg thumbnail_next_event,
    output reg thumbnail_prev_event,output reg thumbnail_confirm_event,
    output reg thumbnail_cancel_event
);
    // Music is bound to the active chapter; no independent song selector.
    assign selected_row=4'd0;
    assign next_music=1'b0;
    assign previous_music=1'b0;
    localparam integer DB=(CLK_FREQ_HZ/1000)*DEBOUNCE_MS;
    localparam integer DW=$clog2(DB+1)<1?1:$clog2(DB+1);
    // Wait for the existing synchronizers/debouncers to observe a key held
    // during configuration, then consume it with the all-up context guard.
    localparam integer TICK_DIV=CLK_FREQ_HZ/1000;
    localparam integer TICK_W=$clog2(TICK_DIV)<1?1:$clog2(TICK_DIV);
    // Include synchronization/event propagation even for the 1 kHz simulation
    // corner, where one FPGA cycle itself equals one millisecond.
    localparam integer STARTUP_TICKS=DEBOUNCE_MS+1+(6+TICK_DIV-1)/TICK_DIV;
    localparam integer STARTUP_WAIT=USE_SHARED_KEY_TICK?STARTUP_TICKS:DB+6;
    localparam integer BW=$clog2(STARTUP_WAIT+1);
    wire shared_tick;
    generate if(USE_SHARED_KEY_TICK!=0)begin:g_key_tick
        reg [TICK_W-1:0] count;
        assign shared_tick=count==TICK_DIV-1;
        always @(posedge clk or posedge rst)begin
            if(rst)count<=0;
            else if(shared_tick)count<=0;
            else count<=count+1'b1;
        end
    end else begin:g_no_key_tick
        assign shared_tick=1'b0;
    end endgenerate
    initial if(USE_SHARED_KEY_TICK!=0 && (CLK_FREQ_HZ<1000 || CLK_FREQ_HZ%1000!=0))begin
        $display("SETTINGS_KEY_TICK_CONFIG_ERROR");$finish;
    end
    wire [3:0] short_event,long_event,press_event,held;
    reg input_guard,thumbnail_previous,startup_done;
    wire [3:0] physical_short,physical_long,physical_press;
    // Absolute settings/query do not depend on the HDMI menu or a held key.
    wire remote_independent=(remote_cmd>=8'h30 && remote_cmd<=8'h32) || (remote_cmd>=8'h25 && remote_cmd<=8'h2c) || remote_cmd==8'h20 || remote_cmd==8'h05;
    reg thumbnail_enter_pending,jump_after_thumbnail;
    reg [2:0] jump_after_thumbnail_index;
    // A 20 ms command gap spans one complete 640x480/25 MHz video frame.
    // Without this gap queued identical events can cancel at the toggle CDC
    // or collapse into one pending bit before the next frame consumes them.
    reg [4:0] thumbnail_command_gap;
    wire thumbnail_tick_1ms;
    generate if(USE_SHARED_KEY_TICK!=0)begin:g_thumbnail_shared_tick
        assign thumbnail_tick_1ms=shared_tick;
    end else begin:g_thumbnail_local_tick
        reg [TICK_W-1:0] count;
        assign thumbnail_tick_1ms=count==TICK_DIV-1;
        always @(posedge clk or posedge rst)begin
            if(rst)count<=0;
            else if(thumbnail_tick_1ms)count<=0;
            else count<=count+1'b1;
        end
    end endgenerate
    wire remote_thumbnail_ready=(!thumbnail_context || thumbnail_ready) &&
        (!thumbnail_enter_pending || remote_arg==0 || remote_arg==1) && thumbnail_command_gap==0;
    wire story_context_changed,thumbnail_changed;
    // A touch sent just after a chapter jump belongs to that new chapter.
    // Hold it at the FIFO head until the actual reader commit and story CDC
    // agree. Absolute settings/query/reset retain their independent path.
    wire remote_story=(remote_cmd>=8'h10 && remote_cmd<=8'h13);
    wire remote_confirm_ready=NAVIGATION_GUARD_ENABLE==0 ? story_prompt : story_ready;
    wire remote_story_ready=NAVIGATION_GUARD_ENABLE==0 || !remote_story ||
        (thumbnail_command_gap==0 && adventure_started && !ending_requested && !thumbnail_context && story_ready &&
         !navigation_busy && display_ready && story_chapter==committed_chapter &&
         (remote_cmd!=8'h12 || remote_confirm_ready));
    assign remote_ready=remote_independent ||
        (startup_done && !story_context_changed && !thumbnail_changed && remote_story_ready &&
         ((remote_cmd!=8'h02 && remote_cmd!=8'h03) || display_ready) &&
         (remote_cmd!=8'h2d || remote_thumbnail_ready) &&
         (remote_cmd!=8'h04 || (thumbnail_command_gap==0 && (!thumbnail_context || thumbnail_ready))));
    wire remote_action=remote_valid && remote_ready;
    reg auto_request_pending,auto_requested;
    reg external_scheduler;
    wire scheduler_takeover=remote_action &&
        ((remote_cmd==8'h29 && remote_arg<=1) || (remote_cmd==8'h04 && remote_arg<8) || (remote_cmd==8'h05 && remote_arg<=1));
    // Stop a pending local tick on the same edge that accepts screen ownership.
    assign local_auto_enable=!external_scheduler && !scheduler_takeover;
    wire remote_menu=remote_action && remote_cmd==8'h20;
    wire remote_next=remote_action && ((remote_cmd==8'h02 && adventure_started) ||
                        (remote_cmd==8'h01 && !adventure_started));
    wire remote_prev=remote_action && remote_cmd==8'h03 && adventure_started;
    assign short_event=physical_short | {remote_next,3'b000};
    assign long_event=physical_long | {remote_prev,3'b000};
    assign press_event=physical_press | {1'b0,remote_menu,2'b00};
    wire [3:0] keys={key1_n,key4_n,key3_n,key2_n};
    genvar k;
    generate for(k=0;k<4;k=k+1) begin:g_keys
        player_key_gesture #(.CLK_FREQ_HZ(CLK_FREQ_HZ),
            .DEBOUNCE_MS(DEBOUNCE_MS),.LONG_PRESS_MS(LONG_PRESS_MS),
            .USE_SHARED_TICK(USE_SHARED_KEY_TICK)) u_key(
            .clk(clk),.rst(rst),.key_n(keys[k]),.tick_1ms(shared_tick),.short_event(physical_short[k]),
            .long_event(physical_long[k]),.press_event(physical_press[k]),.held(held[k]));
    end endgenerate

    // DIP pins remain compatible, but no longer select parameter or step.
    reg prompt_previous,choice_sent;
    reg [2:0] chapter_previous;
    assign story_context_changed=(prompt_previous!=story_prompt) ||
                               (chapter_previous!=story_chapter);
    reg [BW-1:0] startup_count;
    reg [1:0] quiet_count;

    function [7:0] adjusted;
        input [7:0] value;
        input [7:0] step;
        input decrease;
        reg [8:0] sum;
        begin
            sum={1'b0,value}+{1'b0,step};
            if(decrease) adjusted=(value<step)?8'd0:value-step;
            else adjusted=(sum>100)?8'd100:sum[7:0];
        end
    endfunction

    // Exact round(percent*255/100), implemented as a small constant table.
    // This has no divider and the valid input domain is only 0..100.
    function [7:0] raw_percent;
        input [7:0] value;
        begin
            case(value)
                8'd0:raw_percent=8'd0;
                8'd1:raw_percent=8'd3;
                8'd2:raw_percent=8'd5;
                8'd3:raw_percent=8'd8;
                8'd4:raw_percent=8'd10;
                8'd5:raw_percent=8'd13;
                8'd6:raw_percent=8'd15;
                8'd7:raw_percent=8'd18;
                8'd8:raw_percent=8'd20;
                8'd9:raw_percent=8'd23;
                8'd10:raw_percent=8'd26;
                8'd11:raw_percent=8'd28;
                8'd12:raw_percent=8'd31;
                8'd13:raw_percent=8'd33;
                8'd14:raw_percent=8'd36;
                8'd15:raw_percent=8'd38;
                8'd16:raw_percent=8'd41;
                8'd17:raw_percent=8'd43;
                8'd18:raw_percent=8'd46;
                8'd19:raw_percent=8'd48;
                8'd20:raw_percent=8'd51;
                8'd21:raw_percent=8'd54;
                8'd22:raw_percent=8'd56;
                8'd23:raw_percent=8'd59;
                8'd24:raw_percent=8'd61;
                8'd25:raw_percent=8'd64;
                8'd26:raw_percent=8'd66;
                8'd27:raw_percent=8'd69;
                8'd28:raw_percent=8'd71;
                8'd29:raw_percent=8'd74;
                8'd30:raw_percent=8'd77;
                8'd31:raw_percent=8'd79;
                8'd32:raw_percent=8'd82;
                8'd33:raw_percent=8'd84;
                8'd34:raw_percent=8'd87;
                8'd35:raw_percent=8'd89;
                8'd36:raw_percent=8'd92;
                8'd37:raw_percent=8'd94;
                8'd38:raw_percent=8'd97;
                8'd39:raw_percent=8'd99;
                8'd40:raw_percent=8'd102;
                8'd41:raw_percent=8'd105;
                8'd42:raw_percent=8'd107;
                8'd43:raw_percent=8'd110;
                8'd44:raw_percent=8'd112;
                8'd45:raw_percent=8'd115;
                8'd46:raw_percent=8'd117;
                8'd47:raw_percent=8'd120;
                8'd48:raw_percent=8'd122;
                8'd49:raw_percent=8'd125;
                8'd50:raw_percent=8'd128;
                8'd51:raw_percent=8'd130;
                8'd52:raw_percent=8'd133;
                8'd53:raw_percent=8'd135;
                8'd54:raw_percent=8'd138;
                8'd55:raw_percent=8'd140;
                8'd56:raw_percent=8'd143;
                8'd57:raw_percent=8'd145;
                8'd58:raw_percent=8'd148;
                8'd59:raw_percent=8'd150;
                8'd60:raw_percent=8'd153;
                8'd61:raw_percent=8'd156;
                8'd62:raw_percent=8'd158;
                8'd63:raw_percent=8'd161;
                8'd64:raw_percent=8'd163;
                8'd65:raw_percent=8'd166;
                8'd66:raw_percent=8'd168;
                8'd67:raw_percent=8'd171;
                8'd68:raw_percent=8'd173;
                8'd69:raw_percent=8'd176;
                8'd70:raw_percent=8'd179;
                8'd71:raw_percent=8'd181;
                8'd72:raw_percent=8'd184;
                8'd73:raw_percent=8'd186;
                8'd74:raw_percent=8'd189;
                8'd75:raw_percent=8'd191;
                8'd76:raw_percent=8'd194;
                8'd77:raw_percent=8'd196;
                8'd78:raw_percent=8'd199;
                8'd79:raw_percent=8'd201;
                8'd80:raw_percent=8'd204;
                8'd81:raw_percent=8'd207;
                8'd82:raw_percent=8'd209;
                8'd83:raw_percent=8'd212;
                8'd84:raw_percent=8'd214;
                8'd85:raw_percent=8'd217;
                8'd86:raw_percent=8'd219;
                8'd87:raw_percent=8'd222;
                8'd88:raw_percent=8'd224;
                8'd89:raw_percent=8'd227;
                8'd90:raw_percent=8'd230;
                8'd91:raw_percent=8'd232;
                8'd92:raw_percent=8'd235;
                8'd93:raw_percent=8'd237;
                8'd94:raw_percent=8'd240;
                8'd95:raw_percent=8'd242;
                8'd96:raw_percent=8'd245;
                8'd97:raw_percent=8'd247;
                8'd98:raw_percent=8'd250;
                8'd99:raw_percent=8'd252;
                8'd100:raw_percent=8'd255;
                default:raw_percent=8'd255;
            endcase
        end
    endfunction
    assign menu_mode=2'd0;
    assign menu_step=6'd5;
    assign thumbnail_changed=thumbnail_previous!=thumbnail_context;
    wire overlapping=(held[0] && held[1]) || (held[3] && (held[0] || held[1])) ||
        (held[2] && (held[0] || held[1] || held[3]));
    wire action_allowed=startup_done && !input_guard &&
        !overlapping && !thumbnail_changed && !story_context_changed;

    // Select one transaction before arithmetic. Menu/DIP gestures are mutually
    // exclusive by the unchanged priority and context guards below. One shared
    // saturating ALU and one lookup feed the selected percentage/raw register
    // pair on the same edge: no output or gesture latency is added.
    reg parameter_update;
    reg [1:0] parameter_target;
    reg parameter_decrease;
    reg [7:0] parameter_step,parameter_value;
    always @* begin
        parameter_update=0;parameter_target=0;parameter_decrease=0;
        parameter_step=8'd5;
        if(action_allowed && !(short_event[3] || long_event[3] || short_event[2] || long_event[2])) begin
            if(short_event[0] || long_event[0]) begin
                parameter_update=1;parameter_target=2;parameter_decrease=long_event[0];
            end else if(short_event[1] || long_event[1]) begin
                parameter_decrease=long_event[1];
                parameter_update=1;parameter_target=1;
            end
        end
        if(remote_action && remote_arg<=100 &&
           remote_cmd>=8'h25 && remote_cmd<=8'h27)begin
            parameter_update=1;parameter_target=remote_cmd-8'h25;
        end
        case(parameter_target)
            0:parameter_value=volume_percent;
            1:parameter_value=brightness_percent;
            default:parameter_value=contrast_percent;
        endcase
    end
    wire remote_parameter=remote_action && remote_arg<=100 &&
        remote_cmd>=8'h25 && remote_cmd<=8'h27;
    wire [7:0] parameter_next=remote_parameter?remote_arg:
        adjusted(parameter_value,parameter_step,parameter_decrease);
    wire [7:0] parameter_raw_next=raw_percent(parameter_next);

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            zoom_level<=0;sharpness_percent<=0;saturation_percent<=50;
            period_sel<=5;effect_sel<=0;chapter_select_index<=0;
            settings_page_request<=0;app_reset_request<=0;
            thumbnail_enter_pending<=0;jump_after_thumbnail<=0;jump_after_thumbnail_index<=0;thumbnail_command_gap<=0;
            auto_request_pending<=0;auto_requested<=0;external_scheduler<=0;menu_visible<=0;
            adventure_started<=0;ending_requested<=0;choice_cursor<=0;choice_confirm_toggle<=0;choice_open_event_toggle<=0;
            prompt_previous<=0;chapter_previous<=0;choice_sent<=0;
            volume_percent<=INITIAL_VOLUME_PERCENT;volume_toggle<=0;brightness_percent<=100;contrast_percent<=50;
            volume<=raw_percent(INITIAL_VOLUME_PERCENT);brightness<=255;contrast<=128;
            input_guard<=1;quiet_count<=0;thumbnail_previous<=0;
            startup_done<=0;startup_count<=0;
            next_image<=0;previous_image<=0;
            auto_toggle<=0;cue_event<=0;
            thumbnail_mode_event<=0;thumbnail_next_event<=0;thumbnail_prev_event<=0;
            thumbnail_confirm_event<=0;thumbnail_cancel_event<=0;
            replay_audio_event<=0;chapter_select_event<=0;
        end else begin
            // Sticky request survives a stopped/phase-shifted SD clock until
            // reference-domain POR asserts this domain's asynchronous reset.
            settings_page_request<=0;
            if(thumbnail_tick_1ms && thumbnail_command_gap!=0)
                thumbnail_command_gap<=thumbnail_command_gap-1'b1;
            if(remote_action && (remote_story || (remote_cmd==8'h2d && remote_arg<=4) ||
                                remote_cmd==8'h04))
                thumbnail_command_gap<=20;
            thumbnail_previous<=thumbnail_context;
            prompt_previous<=story_prompt;chapter_previous<=story_chapter;
            // Keep the confirmed cursor stable while its token crosses to video.
            // A new prompt/chapter starts from the first option; exiting does not.
            if(chapter_previous!=story_chapter)begin
                choice_cursor<=0;choice_sent<=0;
            end else if(NAVIGATION_GUARD_ENABLE==0 &&
                        ((story_prompt && !prompt_previous) || !story_prompt))choice_sent<=0;
            // In the interactive application, an early confirmation stays
            // consumed even before the timed story prompt becomes visible.
            // Selecting A/B or replay explicitly opens another attempt.
            next_image<=0;previous_image<=0;
            auto_toggle<=0;cue_event<=0;
            thumbnail_mode_event<=0;thumbnail_next_event<=0;thumbnail_prev_event<=0;
            thumbnail_confirm_event<=0;thumbnail_cancel_event<=0;
            replay_audio_event<=0;chapter_select_event<=0;
            if(!startup_done && (!USE_SHARED_KEY_TICK || shared_tick)) begin
                if(startup_count==STARTUP_WAIT-1) startup_done<=1;
                else startup_count<=startup_count+1'b1;
            end
            // A cue belongs to the debounced press, never a long/release repeat.
            if(startup_done && !input_guard && !overlapping && (|press_event)) cue_event<=1;
            // Screen feedback follows an accepted operation, never a raw byte
            // or a speculative HMI state. Confirm has its own result sound in
            // the video domain after the actual answer becomes visible.
            if(remote_action && remote_cmd!=8'h12 && remote_cmd!=8'h2c)cue_event<=1;

            // Drain the gesture pipeline after every context boundary. Waiting
            // for three event-free all-up cycles also consumes the delayed
            // release pulse from player_key_gesture.
            if(!startup_done || overlapping || thumbnail_changed || story_context_changed) begin
                input_guard<=1;quiet_count<=0;
            end else if(input_guard) begin
                if((|held) || (|short_event) || (|long_event) || (|press_event)) quiet_count<=0;
                else if(quiet_count==2) begin input_guard<=0;quiet_count<=0;end
                else quiet_count<=quiet_count+1'b1;
            end

            // Apply the absolute configuration immediately; media gates actual navigation until a frame is ready.
            if(auto_request_pending && !auto_toggle)begin
                if(auto_play_state!=auto_requested)auto_toggle<=1;
                auto_request_pending<=0;
            end
            // Safe startup/thumbnail ownership: keep intentions until display context is usable.
            if(thumbnail_enter_pending && display_ready && !thumbnail_context)begin
                thumbnail_mode_event<=1;thumbnail_enter_pending<=0;
            end
            if(jump_after_thumbnail && !thumbnail_context)begin
                chapter_select_event<=1;chapter_select_index<=jump_after_thumbnail_index;
                jump_after_thumbnail<=0;
            end
            if(remote_action && remote_cmd==8'h2c && remote_arg==0)begin
                app_reset_request<=1;
            end else if(remote_action && remote_cmd==8'h05 && remote_arg<=1)begin
                // Independent START/END page; keep media caches and settings.
                adventure_started<=0;ending_requested<=remote_arg[0];menu_visible<=0;
                auto_requested<=0;auto_request_pending<=1;external_scheduler<=1;
                thumbnail_enter_pending<=0;jump_after_thumbnail<=0;thumbnail_mode_event<=0;
                if(thumbnail_context)thumbnail_cancel_event<=1;
                choice_cursor<=0;choice_sent<=0;input_guard<=1;quiet_count<=0;
            end else if(remote_action && remote_cmd==8'h30 && remote_arg<=4)begin
                zoom_level<=remote_arg[2:0];
            end else if(remote_action && remote_cmd==8'h31 && remote_arg<=100)begin
                sharpness_percent<=remote_arg;
            end else if(remote_action && remote_cmd==8'h32 && remote_arg<=100)begin
                saturation_percent<=remote_arg;
            end else if(remote_action && remote_cmd==8'h2d && remote_arg<=4)begin
                case(remote_arg)
                    0:begin thumbnail_enter_pending<=0;thumbnail_mode_event<=0;if(thumbnail_context)thumbnail_cancel_event<=1;end
                    1:begin
                        adventure_started<=1;
                        if(!thumbnail_context)thumbnail_enter_pending<=1;
                    end
                    2:if(thumbnail_context)thumbnail_confirm_event<=1;
                    3:if(thumbnail_context)thumbnail_next_event<=1;
                    4:if(thumbnail_context)thumbnail_prev_event<=1;
                endcase
                cue_event<=1;
            end else if(remote_action && remote_cmd==8'h29 && remote_arg<=1)begin
                auto_requested<=remote_arg[0];auto_request_pending<=1;external_scheduler<=1;
            end else if(remote_action && remote_cmd==8'h2a && remote_arg<=5)begin
                period_sel<=remote_arg[2:0];
            end else if(remote_action && remote_cmd==8'h2b && remote_arg<=9)begin
                effect_sel<=remote_arg[3:0];
            end else if(remote_action && remote_cmd==8'h01)begin
                if(!adventure_started || ending_requested)begin
                    chapter_select_event<=1;chapter_select_index<=0;
                end
                adventure_started<=1;ending_requested<=0;menu_visible<=0;
                input_guard<=1;quiet_count<=0;
            end else if(remote_action && (remote_cmd==8'h02 || remote_cmd==8'h03) && adventure_started && !thumbnail_context)begin
                next_image<=remote_cmd==8'h02;previous_image<=remote_cmd==8'h03;
                cue_event<=1;
            end else if(remote_action && remote_cmd==8'h04 && remote_arg<8)begin
                external_scheduler<=1;
                adventure_started<=1;ending_requested<=0;menu_visible<=0;thumbnail_enter_pending<=0;thumbnail_mode_event<=0;cue_event<=1;
                // Absolute page selection always opens that page at A, even
                // when selecting the current chapter after a revealed B.
                // This is not an audition: first-visit policy owns autoplay.
                choice_cursor<=0;choice_sent<=0;
                choice_open_event_toggle<=~choice_open_event_toggle;
                if(thumbnail_context)begin
                    thumbnail_cancel_event<=1;jump_after_thumbnail<=1;
                    jump_after_thumbnail_index<=remote_arg[2:0];
                end else begin
                    chapter_select_event<=1;chapter_select_index<=remote_arg[2:0];jump_after_thumbnail<=0;
                end
                input_guard<=1;quiet_count<=0;
            end else if(remote_action && adventure_started && !thumbnail_context &&
                        (remote_cmd==8'h10 || remote_cmd==8'h11 || remote_cmd==8'h13))begin
                
                menu_visible<=0;
                if(remote_cmd!=8'h13)choice_cursor<=remote_cmd[0];
                choice_open_event_toggle<=~choice_open_event_toggle;choice_sent<=0;
                replay_audio_event<=1;cue_event<=1;
                input_guard<=1;quiet_count<=0;
            end else if(remote_action && adventure_started && remote_confirm_ready && !thumbnail_context &&
                        remote_cmd==8'h12 && !choice_sent)begin
                menu_visible<=0;choice_confirm_toggle<=~choice_confirm_toggle;choice_sent<=1;
                input_guard<=1;quiet_count<=0;
            end else if(remote_menu) begin
                settings_page_request<=1;
            end else if(action_allowed) begin
                if(long_event[2])begin
                    menu_visible<=~menu_visible;
                end else if(short_event[2])begin
                    external_scheduler<=0;auto_request_pending<=0;auto_toggle<=1;
                end else if(short_event[3] || long_event[3]) begin
                    if(!adventure_started || ending_requested)begin
                        menu_visible<=0;input_guard<=1;quiet_count<=0;
                        if(PAGE_SEQUENCE_ENABLE!=0)begin
                            // Full manual ring: START -> 1..8 -> END -> START.
                            // Neither special-page step resets parameters or visited audio.
                            if(ending_requested ? short_event[3] : long_event[3])begin
                                adventure_started<=0;ending_requested<=!ending_requested;
                            end else begin
                                adventure_started<=1;ending_requested<=0;
                                chapter_select_event<=1;chapter_select_index<=ending_requested?3'd7:3'd0;
                            end
                        end else begin
                            adventure_started<=1;ending_requested<=0;
                            chapter_select_event<=1;chapter_select_index<=0;
                        end
                    end else begin
                        next_image<=short_event[3];previous_image<=long_event[3];
                    end
                end
            end
            // Boundary events may coincide with an accepted numeric parameter;
            // apply both. Explicit screen navigation and a newer local gesture
            // take priority, so no accepted parameter is swallowed by this path.
            if(PAGE_SEQUENCE_ENABLE!=0 &&
               !(remote_action && (remote_cmd==8'h01 || remote_cmd==8'h04 ||
                   remote_cmd==8'h05 || remote_cmd==8'h2c || remote_cmd==8'h2d || remote_cmd==8'h29)) &&
               !(action_allowed && (short_event[3] || long_event[3] || short_event[2])))begin
                if(relative_page_event || (auto_end_event && adventure_started))begin
                    adventure_started<=0;ending_requested<=relative_page_event?relative_page_end:1'b1;
                    menu_visible<=0;thumbnail_enter_pending<=0;jump_after_thumbnail<=0;
                    choice_cursor<=0;choice_sent<=0;input_guard<=1;quiet_count<=0;
                end else if(auto_restart_event && ending_requested && auto_play_state)begin
                    adventure_started<=1;ending_requested<=0;menu_visible<=0;
                    chapter_select_event<=1;chapter_select_index<=0;
                    choice_cursor<=0;choice_sent<=0;input_guard<=1;quiet_count<=0;
                end
            end
            if(parameter_update) begin
                if(parameter_target==0 && remote_parameter)volume_toggle<=~volume_toggle;
                case(parameter_target)
                    0:begin volume_percent<=parameter_next;volume<=parameter_raw_next;end
                    1:begin brightness_percent<=parameter_next;brightness<=parameter_raw_next;end
                    2:begin contrast_percent<=parameter_next;contrast<=parameter_raw_next;end
                endcase
            end
        end
    end
    initial if(DB<1 || INITIAL_VOLUME_PERCENT<0 || INITIAL_VOLUME_PERCENT>100 || VOLUME_STEP_PERCENT<1 || VOLUME_STEP_PERCENT>100) begin
        $display("PLAYER_SETTINGS_CONFIG_ERROR");$finish;
    end
endmodule
