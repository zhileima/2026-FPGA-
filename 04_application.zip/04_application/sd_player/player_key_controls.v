`timescale 1ns/1ps
// Board KEY2/3/4 are independent active-low inputs. Short actions occur on
// release, so a long action never also causes a short action.
module player_key_controls #(
    parameter integer CLK_FREQ_HZ=100_000_000,
    parameter integer DEBOUNCE_MS=20,
    parameter integer LONG_PRESS_MS=1000,
    parameter integer VOLUME_REPEAT_MS=250,
    parameter integer INITIAL_VOLUME=96,
    parameter integer VOLUME_STEP=16,
    parameter integer IMAGE_ADJUST_ENABLE=0,
    parameter integer THUMBNAIL_ENABLE=0
)(
    input clk,input rst,
    input key2_n,input key3_n,input key4_n,
    output next_image,output previous_image,output auto_toggle,
    output next_music,output cue_event,
    output reg [7:0] volume,output reg volume_toggle,
    input [3:0] dip_switches,
    output [7:0] brightness,output [7:0] contrast,
    output [1:0] menu_mode,output [5:0] menu_step,
    input thumbnail_context,
    output thumbnail_mode_event,output thumbnail_next_event,
    output thumbnail_prev_event,output thumbnail_confirm_event,
    output thumbnail_cancel_event
);
    wire [2:0] short_event,long_event,press_event,held;
    wire [2:0] keys={key4_n,key3_n,key2_n};
    genvar k;
    generate for(k=0;k<3;k=k+1) begin:g_keys
        player_key_gesture #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(DEBOUNCE_MS),
            .LONG_PRESS_MS(LONG_PRESS_MS)) u_key(
            .clk(clk),.rst(rst),.key_n(keys[k]),.short_event(short_event[k]),
            .long_event(long_event[k]),.press_event(press_event[k]),.held(held[k]));
    end endgenerate
    generate if(THUMBNAIL_ENABLE!=0) begin:g_thumbnail_keys
        player_thumbnail_key_router #(.CLK_FREQ_HZ(CLK_FREQ_HZ),
            .LONG_PRESS_MS(LONG_PRESS_MS),.REPEAT_MS(VOLUME_REPEAT_MS)) u_router(
            .clk(clk),.rst(rst),.thumbnail_context(thumbnail_context),
            .held({held[2],held[0]}),.short_event({short_event[2],short_event[0]}),
            .long_event({long_event[2],long_event[0]}),
            .next_image(next_image),.previous_image(previous_image),
            .auto_toggle(auto_toggle),.next_music(next_music),
            .mode_event(thumbnail_mode_event),.focus_next(thumbnail_next_event),
            .focus_prev(thumbnail_prev_event),.confirm_event(thumbnail_confirm_event),
            .cancel_event(thumbnail_cancel_event));
    end else begin:g_legacy_keys
        assign next_image=short_event[0];
        assign previous_image=long_event[0];
        assign auto_toggle=short_event[2];
        assign next_music=long_event[2];
        assign thumbnail_mode_event=1'b0;
        assign thumbnail_next_event=1'b0;
        assign thumbnail_prev_event=1'b0;
        assign thumbnail_confirm_event=1'b0;
        assign thumbnail_cancel_event=1'b0;
    end endgenerate
    assign cue_event=|press_event;
    localparam integer REPEAT_CYCLES=(CLK_FREQ_HZ/1000)*VOLUME_REPEAT_MS;
    localparam integer RW=$clog2(REPEAT_CYCLES+1)<1?1:$clog2(REPEAT_CYCLES+1);
    reg volume_repeating;
    reg [RW-1:0] repeat_count;
    wire decrease=long_event[1] || (volume_repeating && held[1] && repeat_count==REPEAT_CYCLES-1);
    wire volume_selected;
    generate if(IMAGE_ADJUST_ENABLE!=0) begin:g_image_menu
        image_param_menu_controller #(.CLK_FREQ_HZ(CLK_FREQ_HZ),
            .DEBOUNCE_MS(DEBOUNCE_MS)) u_menu(
            .clk(clk),.rst(rst),.dip_switches(dip_switches),
            .key_press(press_event[1]),.key_short(short_event[1]),
            .key_decrease(decrease),.key_held(held[1]),
            .volume_selected(volume_selected),.brightness(brightness),
            .contrast(contrast),.menu_mode(menu_mode),.menu_step(menu_step));
    end else begin:g_legacy_menu
        assign volume_selected=1'b1;
        assign brightness=8'd255;
        assign contrast=8'd128;
        assign menu_mode=2'b00;
        assign menu_step=6'd1;
    end endgenerate
    always @(posedge clk or posedge rst) begin
        if(rst) begin volume<=INITIAL_VOLUME;volume_toggle<=0;volume_repeating<=0;repeat_count<=0;end
        else begin
            if(!held[1]) begin volume_repeating<=0;repeat_count<=0;end
            else if(long_event[1]) begin volume_repeating<=1;repeat_count<=0;end
            else if(volume_repeating) begin
                if(repeat_count==REPEAT_CYCLES-1) repeat_count<=0;
                else repeat_count<=repeat_count+1'b1;
            end
            if(short_event[1] && volume_selected) begin
                volume<=volume>255-VOLUME_STEP ? 8'd255 : volume+VOLUME_STEP;
                volume_toggle<=~volume_toggle;
            end else if(decrease && volume_selected) begin
                volume<=volume<VOLUME_STEP ? 8'd0 : volume-VOLUME_STEP;
                volume_toggle<=~volume_toggle;
            end
        end
    end
    initial begin
        if(REPEAT_CYCLES<1 || INITIAL_VOLUME<0 || INITIAL_VOLUME>255 ||
           VOLUME_STEP<1 || VOLUME_STEP>255) begin
            $display("PLAYER_KEY_CONFIG_ERROR");$finish;
        end
    end
endmodule

// KEY2/KEY4 share a chord arbiter after their existing synchronizers/debouncers.
// A chord owns both gestures until two all-up observations; the extra quiet
// cycle suppresses the release pulse generated one cycle after held falls.
// Context is captured at each debounced press, not at release/long threshold.
module player_thumbnail_key_router #(
    parameter integer CLK_FREQ_HZ=100_000_000,
    parameter integer LONG_PRESS_MS=1000,
    parameter integer REPEAT_MS=250
)(
    input clk,input rst,input thumbnail_context,
    input [1:0] held,input [1:0] short_event,input [1:0] long_event,
    output reg next_image,output reg previous_image,
    output reg auto_toggle,output reg next_music,
    output reg mode_event,output reg focus_next,output reg focus_prev,
    output reg confirm_event,output reg cancel_event
);
    localparam integer LC=(CLK_FREQ_HZ/1000)*LONG_PRESS_MS;
    localparam integer RC=(CLK_FREQ_HZ/1000)*REPEAT_MS;
    localparam integer LW=$clog2(LC+1)<1?1:$clog2(LC+1);
    localparam integer RW=$clog2(RC+1)<1?1:$clog2(RC+1);
    reg [1:0] held_previous,gesture_context,single_long_seen;
    reg chord_owned,chord_fired,chord_cancelled,all_up_seen;
    reg [LW-1:0] chord_count;
    reg focus_repeating;
    reg [RW-1:0] repeat_count;
    wire chord_start=(&held) && !chord_owned;
    wire chord_blocks=chord_owned || chord_start;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            held_previous<=0;gesture_context<=0;single_long_seen<=0;
            chord_owned<=0;chord_fired<=0;chord_cancelled<=0;all_up_seen<=0;
            chord_count<=0;focus_repeating<=0;repeat_count<=0;
            next_image<=0;previous_image<=0;auto_toggle<=0;next_music<=0;
            mode_event<=0;focus_next<=0;focus_prev<=0;confirm_event<=0;cancel_event<=0;
        end else begin
            held_previous<=held;
            next_image<=0;previous_image<=0;auto_toggle<=0;next_music<=0;
            mode_event<=0;focus_next<=0;focus_prev<=0;confirm_event<=0;cancel_event<=0;
            if(held[0] && !held_previous[0]) gesture_context[0]<=thumbnail_context;
            if(held[1] && !held_previous[1]) gesture_context[1]<=thumbnail_context;
            if(!held[0]) single_long_seen[0]<=0;
            if(!held[1]) single_long_seen[1]<=0;
            all_up_seen<=held==2'b00;
            if(chord_start) begin
                chord_owned<=1;chord_fired<=0;chord_count<=1;
                // An already delivered single-key action cannot be undone.
                // Such a late overlap is consumed but cannot toggle the mode.
                chord_cancelled<=|single_long_seen;
            end else if(chord_owned) begin
                if(held==2'b00 && all_up_seen) begin
                    chord_owned<=0;chord_fired<=0;chord_cancelled<=0;chord_count<=0;
                end else if(held!=2'b11) begin
                    chord_cancelled<=1;chord_count<=0;
                end else if(!chord_fired && !chord_cancelled) begin
                    if(chord_count==LC-1) begin mode_event<=1;chord_fired<=1;end
                    else chord_count<=chord_count+1'b1;
                end
            end
            if(!held[0] || !gesture_context[0] || chord_blocks) begin
                focus_repeating<=0;repeat_count<=0;
            end else if(focus_repeating) begin
                if(repeat_count==RC-1) begin repeat_count<=0;focus_prev<=1;end
                else repeat_count<=repeat_count+1'b1;
            end
            if(!chord_blocks) begin
                if(short_event[0]) begin
                    if(gesture_context[0]) focus_next<=1;else next_image<=1;
                end
                if(long_event[0]) begin
                    single_long_seen[0]<=1;
                    if(gesture_context[0]) begin focus_prev<=1;focus_repeating<=1;repeat_count<=0;end
                    else previous_image<=1;
                end
                if(short_event[1]) begin
                    if(gesture_context[1]) confirm_event<=1;else auto_toggle<=1;
                end
                if(long_event[1]) begin
                    single_long_seen[1]<=1;
                    if(gesture_context[1]) cancel_event<=1;else next_music<=1;
                end
            end
        end
    end
    initial if(LC<2 || RC<1) begin $display("THUMBNAIL_KEY_CONFIG_ERROR");$finish;end
endmodule

module player_key_gesture #(
    parameter integer CLK_FREQ_HZ=100_000_000,
    parameter integer DEBOUNCE_MS=20,
    parameter integer LONG_PRESS_MS=1000,
    parameter integer USE_SHARED_TICK=0
)(input clk,input rst,input key_n,output reg short_event,output reg long_event,
  output reg press_event,output wire held,input wire tick_1ms);
    localparam integer DB=(CLK_FREQ_HZ/1000)*DEBOUNCE_MS;
    localparam integer LC=(CLK_FREQ_HZ/1000)*LONG_PRESS_MS;
    localparam integer DB_LIMIT=USE_SHARED_TICK?DEBOUNCE_MS:DB;
    localparam integer HOLD_LIMIT=USE_SHARED_TICK?LONG_PRESS_MS:LC;
    localparam integer DW=$clog2(DB_LIMIT+1)<1?1:$clog2(DB_LIMIT+1);
    localparam integer LW=$clog2(HOLD_LIMIT+1)<1?1:$clog2(HOLD_LIMIT+1);
    // Keep these two synchronizers at the instance root for pad/CDC signoff.
    // tick_1ms is a clock enable, never a clock or a reduced-rate input sampler.
    (* async_reg="true" *) reg sync0,sync1;
    reg stable_n,previous_n,long_marked;
    reg [DW-1:0] db_count;
    reg [LW-1:0] hold_count;
    assign held=!stable_n;
    always @(posedge clk or posedge rst)begin
        if(rst)begin sync0<=1;sync1<=1;end
        else begin sync0<=key_n;sync1<=sync0;end
    end
    generate if(USE_SHARED_TICK!=0)begin:g_shared_tick
        always @(posedge clk or posedge rst)begin
            if(rst)begin
                stable_n<=1;previous_n<=1;long_marked<=0;
                db_count<=0;hold_count<=0;short_event<=0;long_event<=0;press_event<=0;
            end else begin
                previous_n<=stable_n;
                short_event<=0;long_event<=0;press_event<=0;
                // A brief bounce seen at full clock rate cancels accumulated
                // stability, even when the bounce lies between millisecond ticks.
                if(sync1==stable_n)db_count<=0;
                else if(tick_1ms)begin
                    // The first tick can be arbitrarily close to the edge.
                    // Require DB+1 ticks, guaranteeing >=DB complete milliseconds.
                    if(db_count==DEBOUNCE_MS)begin stable_n<=sync1;db_count<=0;end
                    else db_count<=db_count+1'b1;
                end
                if(previous_n && !stable_n)press_event<=1;
                if(!previous_n && stable_n && !long_marked)short_event<=1;
                if(stable_n)begin hold_count<=0;long_marked<=0;end
                else if(tick_1ms && !long_marked)begin
                    // stable_n changes only on a tick; the next LONG_PRESS_MS
                    // tick intervals therefore measure exactly the hold duration.
                    if(hold_count==LONG_PRESS_MS-1)begin long_event<=1;long_marked<=1;end
                    else hold_count<=hold_count+1'b1;
                end
            end
        end
    end else begin:g_legacy_cycles
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            stable_n<=1;previous_n<=1;long_marked<=0;
            db_count<=0;hold_count<=0;short_event<=0;long_event<=0;press_event<=0;
        end else begin
            previous_n<=stable_n;
            short_event<=0;long_event<=0;press_event<=0;
            if(sync1==stable_n) db_count<=0;
            else if(db_count==DB-1) begin stable_n<=sync1;db_count<=0;end
            else db_count<=db_count+1'b1;
            if(previous_n && !stable_n) press_event<=1;
            if(!previous_n && stable_n && !long_marked) short_event<=1;
            if(stable_n) begin hold_count<=0;long_marked<=0;end
            else if(!long_marked) begin
                if(hold_count==LC-1) begin long_event<=1;long_marked<=1;end
                else hold_count<=hold_count+1'b1;
            end
        end
    end
    end endgenerate
    initial if(DB<1 || LC<=DB || (USE_SHARED_TICK!=0 && LONG_PRESS_MS<=DEBOUNCE_MS))begin
        $display("PLAYER_GESTURE_CONFIG_ERROR");$finish;
    end
endmodule

// The source holds each volume value for at least a debounced key interval
// (20ms). Two payload stages settle before the three-stage event qualifies it.
module player_volume_cdc #(
    parameter integer INITIAL_VOLUME=96
)(input clk,input rst,input [7:0] source_volume,input source_toggle,
  output reg [7:0] volume);
    (* async_reg="true" *) reg [7:0] volume_meta,volume_sync;
    (* async_reg="true" *) reg [2:0] event_sync;
    reg seen;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            volume_meta<=INITIAL_VOLUME;volume_sync<=INITIAL_VOLUME;
            event_sync<=0;seen<=0;volume<=INITIAL_VOLUME;
        end else begin
            volume_meta<=source_volume;volume_sync<=volume_meta;
            event_sync<={event_sync[1:0],source_toggle};
            if(event_sync[2]!=seen) begin seen<=event_sync[2];volume<=volume_sync;end
        end
    end
endmodule
