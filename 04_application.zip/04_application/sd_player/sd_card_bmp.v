`timescale 1ns/1ps
module sd_card_bmp #(
    parameter integer CLK_FREQ_HZ       = 100_000_000,
    parameter [31:0]  SCAN_START_SECTOR = 32'd0,
    parameter [31:0]  SCAN_MAX_SECTOR   = 32'd131071,
    parameter [2:0]   SCAN_TARGET_COUNT = 3'd4,
    parameter integer AUTO_PLAY_MS      = 1000,
    parameter integer LONG_PRESS_MS     = 1000,
    parameter integer DEBOUNCE_MS       = 20
)(
    input                       clk,
    input                       rst,
    input                       key_next,
    input                       key_auto,
    output [3:0]                state_code,
    output reg [3:0]            image_number, // 0 before commit; 1..4 after reader ACK
    output [26:0]               debug_status,
    input  [15:0]               bmp_width,
    input  [15:0]               bmp_height,
    output reg                  display_valid,

    input                       write_finish_toggle,
    output reg [1:0]            write_buf_idx,
    output reg [1:0]            disp_buf_idx,
    output reg [1:0]            read_buf_req_idx,
    output reg                  read_switch_req_toggle,
    input                       read_switch_ack_toggle,
    input  [1:0]                read_switch_ack_idx,

    output                      write_req,
    input                       write_req_ack,
    output                      write_en,
    output [31:0]               write_data,
    output                      SD_nCS,
    output                      SD_DCLK,
    output                      SD_MOSI,
    input                       SD_MISO
);

wire key_next_press;
wire key_auto_stable;
reg  key_auto_previous;
reg [31:0] long_press_cnt;
reg        long_press_marked;
wire       key_auto_short;
wire       key_auto_long;

// Widen before multiplying: 30 s at 100 MHz needs 3,000,000,000 cycles.
localparam [63:0] AUTO_PLAY_CYCLES =
    (64'd1 * CLK_FREQ_HZ * AUTO_PLAY_MS + 64'd999) / 64'd1000;
localparam [63:0] LONG_PRESS_CYCLES =
    (64'd1 * CLK_FREQ_HZ * LONG_PRESS_MS + 64'd999) / 64'd1000;
initial begin
    if (CLK_FREQ_HZ <= 0 || AUTO_PLAY_MS <= 0 || LONG_PRESS_MS <= 0 ||
        AUTO_PLAY_CYCLES < 1 || AUTO_PLAY_CYCLES > 64'hffffffff ||
        LONG_PRESS_CYCLES < 1 || LONG_PRESS_CYCLES > 64'hffffffff ||
        SCAN_TARGET_COUNT < 1 || SCAN_TARGET_COUNT > 4) begin
        $display("SD_PLAYER_CONFIG_ERROR invalid timing or image count parameter");
        $finish;
    end
end

wire             sd_sec_read;
wire [31:0]      sd_sec_read_addr;
wire [7:0]       sd_sec_read_data;
wire             sd_sec_read_data_valid;
wire             sd_sec_read_end;
wire             bmp_data_wr_en;
wire [23:0]      bmp_data;
wire             sd_init_done;
wire             bmp_ready;
wire             scan_done;
wire             scan_found_valid;
wire [31:0]      scan_found_sector;
wire [2:0]       scan_found_total;

reg              scan_start_pulse;
reg              load_start_pulse;
reg [31:0]       load_sector;
reg              scan_kicked;
reg              first_image_committed;
reg              auto_play_en;
reg [31:0]       auto_cnt;
reg [2:0]        img_found_count;
reg [1:0]        img_idx;              // 当前真正显示中的图片编号
reg [1:0]        load_idx;             // 当前正在写入的图片编号
reg [1:0]        pending_buf_idx;      // 当前正在写入的目标缓冲区
reg [31:0]       img_sector0;
reg [31:0]       img_sector1;
reg [31:0]       img_sector2;
reg [31:0]       img_sector3;
reg              next_req_pending;
reg              prev_req_pending;
reg              load_busy;

// bmp_ready 先表示“源文件读取/送 FIFO 完成”；真正切显示要等 write_finish_toggle 同步后
reg              source_done_seen;
reg              source_active_seen;
reg              write_done_seen;
reg              switch_pending;
reg [2:0]        read_ack_tgl_sync;
reg [1:0]        read_ack_idx_d0;
reg [1:0]        read_ack_idx_d1;

// 同步 mem_clk 域的 write_finish_toggle
reg [2:0]        wrfin_tgl_sync;
wire             write_finish_pulse;

wire auto_tick;
wire [1:0] next_from_current;
wire [1:0] prev_from_current;

assign write_en   = bmp_data_wr_en;
assign write_data = {bmp_data[23:16], bmp_data[15:8], bmp_data[7:0], 8'b0};
assign auto_tick  = (auto_cnt == (AUTO_PLAY_CYCLES - 64'd1));
assign next_from_current = next_index_limited(img_idx, img_found_count);
assign prev_from_current = prev_index_limited(img_idx, img_found_count);
assign key_auto_short = !key_auto_previous && key_auto_stable && !long_press_marked;
assign key_auto_long = !key_auto_stable && !long_press_marked &&
                       (long_press_cnt == LONG_PRESS_CYCLES - 64'd1);
assign write_finish_pulse = wrfin_tgl_sync[2] ^ wrfin_tgl_sync[1];
// Read-only SD-domain status; sampled coherently by board_debug.
assign debug_status = {write_en,write_req,display_valid,read_buf_req_idx,
                      disp_buf_idx,write_buf_idx,switch_pending,write_done_seen,
                      source_done_seen,load_busy,auto_play_en,load_idx,img_idx,
                      img_found_count,scan_done,sd_init_done,state_code};

key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (DEBOUNCE_MS)
) u_key_next (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_next),
    .press_pulse(key_next_press)
);

key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (DEBOUNCE_MS)
) u_key_auto (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_auto),
    .press_pulse(),
    .button_stable_out(key_auto_stable)
);

// KEY4 short action is deferred until release. A long hold emits exactly
// one previous-image event at the threshold and suppresses its release action.
always @(posedge clk or posedge rst) begin
    if (rst) begin
        key_auto_previous <= 1'b1;
        long_press_cnt <= 32'd0;
        long_press_marked <= 1'b0;
    end else begin
        key_auto_previous <= key_auto_stable;
        if (!sd_init_done || key_auto_stable) begin
            long_press_cnt <= 32'd0;
            long_press_marked <= 1'b0;
        end else if (!long_press_marked) begin
            if (key_auto_long)
                long_press_marked <= 1'b1;
            else
                long_press_cnt <= long_press_cnt + 32'd1;
        end
    end
end

function [1:0] next_index_limited;
    input [1:0] cur;
    input [2:0] count;
    begin
        case (count)
            3'd0: next_index_limited = 2'd0;
            3'd1: next_index_limited = 2'd0;
            3'd2: next_index_limited = (cur == 2'd1) ? 2'd0 : (cur + 2'd1);
            3'd3: next_index_limited = (cur == 2'd2) ? 2'd0 : (cur + 2'd1);
            default: next_index_limited = (cur == 2'd3) ? 2'd0 : (cur + 2'd1);
        endcase
    end
endfunction

function [1:0] prev_index_limited;
    input [1:0] cur;
    input [2:0] count;
    begin
        case (count)
            3'd0, 3'd1: prev_index_limited = 2'd0;
            3'd2: prev_index_limited = (cur == 0) ? 2'd1 : (cur - 2'd1);
            3'd3: prev_index_limited = (cur == 0) ? 2'd2 : (cur - 2'd1);
            default: prev_index_limited = (cur == 0) ? 2'd3 : (cur - 2'd1);
        endcase
    end
endfunction

function [31:0] sector_lut;
    input [1:0] idx;
    begin
        case (idx)
            2'd0: sector_lut = img_sector0;
            2'd1: sector_lut = img_sector1;
            2'd2: sector_lut = img_sector2;
            2'd3: sector_lut = img_sector3;
            default: sector_lut = img_sector0;
        endcase
    end
endfunction

function [1:0] next_buf_lut;
    input [1:0] cur_disp_buf;
    input       valid_now;
    begin
        if (!valid_now)
            next_buf_lut = 2'd0;                 // 首图固定写 buffer0
        else if (cur_disp_buf == 2'd0)
            next_buf_lut = 2'd1;
        else
            next_buf_lut = 2'd0;
    end
endfunction

always @(posedge clk or posedge rst) begin
    if (rst) begin
        wrfin_tgl_sync        <= 3'b000;
        scan_start_pulse      <= 1'b0;
        load_start_pulse      <= 1'b0;
        load_sector           <= 32'd0;
        scan_kicked           <= 1'b0;
        first_image_committed <= 1'b0;
        auto_play_en          <= 1'b0;
        auto_cnt              <= 32'd0;
        img_found_count       <= 3'd0;
        img_idx               <= 2'd0;
        load_idx              <= 2'd0;
        pending_buf_idx       <= 2'd0;
        write_buf_idx         <= 2'd0;
        disp_buf_idx          <= 2'd0;
        read_buf_req_idx      <= 2'd0;
        read_switch_req_toggle <= 1'b0;
        img_sector0           <= 32'd0;
        img_sector1           <= 32'd0;
        img_sector2           <= 32'd0;
        img_sector3           <= 32'd0;
        next_req_pending      <= 1'b0;
        prev_req_pending      <= 1'b0;
        load_busy             <= 1'b0;
        source_done_seen      <= 1'b0;
        source_active_seen    <= 1'b0;
        write_done_seen       <= 1'b0;
        switch_pending        <= 1'b0;
        read_ack_tgl_sync     <= 3'b000;
        read_ack_idx_d0       <= 2'd0;
        read_ack_idx_d1       <= 2'd0;
        display_valid         <= 1'b0;
        image_number          <= 4'd0;
    end else begin
        wrfin_tgl_sync   <= {wrfin_tgl_sync[1:0], write_finish_toggle};
        // The bank is held stable until the request is acknowledged. Its two
        // synchronizer stages settle before the three-stage token arrives.
        read_ack_tgl_sync <= {read_ack_tgl_sync[1:0], read_switch_ack_toggle};
        read_ack_idx_d0   <= read_switch_ack_idx;
        read_ack_idx_d1   <= read_ack_idx_d0;
        scan_start_pulse <= 1'b0;
        load_start_pulse <= 1'b0;

        if (!sd_init_done) begin
            scan_kicked           <= 1'b0;
            first_image_committed <= 1'b0;
            auto_play_en          <= 1'b0;
            auto_cnt              <= 32'd0;
            img_found_count       <= 3'd0;
            img_idx               <= 2'd0;
            load_idx              <= 2'd0;
            pending_buf_idx       <= 2'd0;
            write_buf_idx         <= 2'd0;
            disp_buf_idx          <= 2'd0;
            read_buf_req_idx      <= 2'd0;
            read_switch_req_toggle <= 1'b0;
            img_sector0           <= 32'd0;
            img_sector1           <= 32'd0;
            img_sector2           <= 32'd0;
            img_sector3           <= 32'd0;
            next_req_pending      <= 1'b0;
            prev_req_pending      <= 1'b0;
            load_busy             <= 1'b0;
            source_done_seen      <= 1'b0;
            source_active_seen    <= 1'b0;
            write_done_seen       <= 1'b0;
            switch_pending        <= 1'b0;
            display_valid         <= 1'b0;
            image_number          <= 4'd0;
        end else begin
            // 扫描阶段缓存前 4 张图的起始 sector
            if (scan_found_valid) begin
                case (img_found_count)
                    3'd0: img_sector0 <= scan_found_sector;
                    3'd1: img_sector1 <= scan_found_sector;
                    3'd2: img_sector2 <= scan_found_sector;
                    3'd3: img_sector3 <= scan_found_sector;
                    default: ;
                endcase

                if (img_found_count < 3'd4)
                    img_found_count <= img_found_count + 3'd1;
            end

            // Observe ready going low first: ready is still high for one cycle
            // after load_start. Independently latch write completion because
            // the last pixels can reach SDRAM before the final sector ends.
            if (load_busy && !bmp_ready)
                source_active_seen <= 1'b1;
            if (load_busy && source_active_seen && bmp_ready)
                source_done_seen <= 1'b1;
            if (load_busy && write_finish_pulse)
                write_done_seen <= 1'b1;

            // Publish a new token only after both producer and writer finish.
            // The previous display bank remains owned by the reader until it
            // samples this request at the next frame boundary and echoes it.
            if (load_busy && source_done_seen && write_done_seen && !switch_pending) begin
                read_buf_req_idx       <= pending_buf_idx;
                read_switch_req_toggle <= ~read_switch_req_toggle;
                switch_pending         <= 1'b1;
            end

            if (load_busy && switch_pending &&
                (read_ack_tgl_sync[2] == read_switch_req_toggle) &&
                (read_ack_idx_d1 == pending_buf_idx)) begin
                load_busy             <= 1'b0;
                source_done_seen      <= 1'b0;
                source_active_seen    <= 1'b0;
                write_done_seen       <= 1'b0;
                switch_pending        <= 1'b0;
                disp_buf_idx          <= pending_buf_idx;
                img_idx               <= load_idx;
                image_number          <= {2'b00, load_idx} + 4'd1;
                display_valid         <= 1'b1;
                first_image_committed <= 1'b1;
            end

            // 上电后自动发起一次“扫描前 4 张 BMP”
            if (!scan_kicked && bmp_ready) begin
                scan_start_pulse      <= 1'b1;
                scan_kicked           <= 1'b1;
                first_image_committed <= 1'b0;
                auto_play_en          <= 1'b0;
                auto_cnt              <= 32'd0;
                img_found_count       <= 3'd0;
                img_idx               <= 2'd0;
                load_idx              <= 2'd0;
                pending_buf_idx       <= 2'd0;
                write_buf_idx         <= 2'd0;
                disp_buf_idx          <= 2'd0;
                read_buf_req_idx      <= 2'd0;
                next_req_pending      <= 1'b0;
                prev_req_pending      <= 1'b0;
                display_valid         <= 1'b0;
                image_number          <= 4'd0;
                load_busy             <= 1'b0;
                source_done_seen      <= 1'b0;
                source_active_seen    <= 1'b0;
                write_done_seen       <= 1'b0;
                switch_pending        <= 1'b0;
            end else begin
                // 忙的时候也只记 1 次“下一张”请求，不会累积成连跳两张
                if (key_next_press && scan_done && (img_found_count > 3'd1))
                    next_req_pending <= 1'b1;
                if (key_auto_long && scan_done && (img_found_count > 3'd1))
                    prev_req_pending <= 1'b1;

                // 自动播放开/关
                if (key_auto_short && scan_done && (img_found_count > 3'd1)) begin
                    auto_play_en <= ~auto_play_en;
                    auto_cnt     <= 32'd0;
                end

                // Dwell starts after the reader commits. Image loading and
                // the next frame-boundary ACK add to the commit-to-commit time.
                if (scan_done && auto_play_en && !key_auto_short && display_valid && !load_busy && first_image_committed && (img_found_count > 3'd1)) begin
                    if (auto_tick)
                        auto_cnt <= 32'd0;
                    else
                        auto_cnt <= auto_cnt + 32'd1;
                end else begin
                    auto_cnt <= 32'd0;
                end

                // 首图自动加载到 buffer0
                if (scan_done && !first_image_committed && bmp_ready && !load_busy && (img_found_count != 3'd0)) begin
                    load_idx         <= 2'd0;
                    load_sector      <= img_sector0;
                    pending_buf_idx  <= 2'd0;
                    write_buf_idx    <= 2'd0;
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    source_active_seen <= 1'b0;
                    write_done_seen    <= 1'b0;
                    switch_pending     <= 1'b0;
                    next_req_pending <= 1'b0;
                    prev_req_pending <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
                // 手动下一张优先：写到“非当前显示”的另一块 buffer
                else if (scan_done && bmp_ready && display_valid && !load_busy && (next_req_pending || key_next_press) && (img_found_count > 3'd1)) begin
                    load_idx         <= next_from_current;
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    source_active_seen <= 1'b0;
                    write_done_seen    <= 1'b0;
                    switch_pending     <= 1'b0;
                    next_req_pending <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
                // Previous has the same single pending slot and bank safety
                // as next. Simultaneous opposite actions keep next priority.
                else if (scan_done && bmp_ready && display_valid && !load_busy && (prev_req_pending || key_auto_long) && (img_found_count > 3'd1)) begin
                    load_idx         <= prev_from_current;
                    load_sector      <= sector_lut(prev_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    source_active_seen <= 1'b0;
                    write_done_seen    <= 1'b0;
                    switch_pending     <= 1'b0;
                    prev_req_pending <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
                // 自动播放下一张：同样写到“非当前显示”的另一块 buffer
                else if (scan_done && bmp_ready && display_valid && !load_busy && auto_play_en && !key_auto_short && auto_tick && (img_found_count > 3'd1)) begin
                    load_idx         <= next_from_current;
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    source_active_seen <= 1'b0;
                    write_done_seen    <= 1'b0;
                    switch_pending     <= 1'b0;
                    auto_cnt         <= 32'd0;
                end
            end
        end
    end
end

bmp_read bmp_read_m0(
    .clk                    (clk),
    .rst                    (rst),
    .ready                  (bmp_ready),

    .scan_start             (scan_start_pulse),
    .scan_start_sector      (SCAN_START_SECTOR),
    .scan_max_sector        (SCAN_MAX_SECTOR),
    .scan_target_count      (SCAN_TARGET_COUNT),
    .scan_done              (scan_done),
    .scan_found_valid       (scan_found_valid),
    .scan_found_sector      (scan_found_sector),
    .scan_found_total       (scan_found_total),

    .load_start             (load_start_pulse),
    .load_sector            (load_sector),

    .sd_init_done           (sd_init_done),
    .state_code             (state_code),
    .bmp_width              (bmp_width),
    .bmp_height             (bmp_height),
    .write_req              (write_req),
    .write_req_ack          (write_req_ack),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .bmp_data_wr_en         (bmp_data_wr_en),
    .bmp_data               (bmp_data)
);

sd_card_top sd_card_top_m0(
    .clk                    (clk),
    .rst                    (rst),
    .SD_nCS                 (SD_nCS),
    .SD_DCLK                (SD_DCLK),
    .SD_MOSI                (SD_MOSI),
    .SD_MISO                (SD_MISO),
    .sd_init_done           (sd_init_done),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .sd_sec_write           (1'b0),
    .sd_sec_write_addr      (32'd0),
    .sd_sec_write_data      (8'd0),
    .sd_sec_write_data_req  (),
    .sd_sec_write_end       ()
);

endmodule

module key_press_debounce #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst,
    input  wire button_in,    // 默认：松开=1，按下=0
    output reg  press_pulse,
    output wire button_stable_out
);

localparam [63:0] DEBOUNCE_CYCLES =
    (64'd1 * CLK_FREQ_HZ * DEBOUNCE_MS + 64'd999) / 64'd1000;
initial begin
    if (CLK_FREQ_HZ <= 0 || DEBOUNCE_MS <= 0 ||
        DEBOUNCE_CYCLES < 1 || DEBOUNCE_CYCLES > 64'hffffffff) begin
        $display("KEY_DEBOUNCE_CONFIG_ERROR invalid timing parameter");
        $finish;
    end
end

reg button_sync0;
reg button_sync1;
reg button_stable;
reg [31:0] cnt;
assign button_stable_out = button_stable;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        button_sync0  <= 1'b1;
        button_sync1  <= 1'b1;
        button_stable <= 1'b1;
        cnt           <= 32'd0;
        press_pulse   <= 1'b0;
    end else begin
        button_sync0 <= button_in;
        button_sync1 <= button_sync0;
        press_pulse  <= 1'b0;

        if (button_sync1 == button_stable) begin
            cnt <= 32'd0;
        end else begin
            if (cnt >= DEBOUNCE_CYCLES - 1) begin
                if (button_stable && !button_sync1)
                    press_pulse <= 1'b1;
                button_stable <= button_sync1;
                cnt           <= 32'd0;
            end else begin
                cnt <= cnt + 32'd1;
            end
        end
    end
end

endmodule
