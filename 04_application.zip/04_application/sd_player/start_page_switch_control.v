`timescale 1ns/1ps
// START and END are independent physical reader contexts; chapters retain3 bits.
// Every context owns a fresh token and waits for its matching reader ACK.
module start_page_switch_control #(parameter integer END_PAGE_ENABLE=0, parameter integer TRANSITION_DRAIN_ENABLE=0, parameter integer END_EFFECT_ENABLE=0)(
 input wire clk,rst,start_cached,start_failed,first_cached,
 input wire end_cached,end_failed,ending_requested,
 input wire adventure_started,
 input wire transition_request,input wire[2:0]transition_index,input wire transition_busy,
 input wire transition_is_end,input wire transition_player_token,
 input wire raw_ack_toggle,input wire[2:0]raw_ack_index,
 output wire admit_player,
 output reg read_enabled,read_request,output reg[2:0]read_index,
 output reg read_is_start,read_is_end,
 output reg player_ack_toggle,output reg[2:0]player_ack_index,
 output reg chapter_committed,ending_committed
);
 (* ASYNC_REG="TRUE" *) reg[2:0]raw_ack_sync;
 (* ASYNC_REG="TRUE" *) reg[2:0]raw_index_meta,raw_index_sync;
 reg busy,boot_sent,boot_acknowledged,logical_seen,logical_pending;
 wire drain_busy=TRANSITION_DRAIN_ENABLE!=0 && transition_busy;
 wire end_wanted=END_PAGE_ENABLE!=0 && ending_requested;
 wire end_available=END_PAGE_ENABLE!=0 && end_cached && !end_failed;
 assign admit_player=adventure_started && !end_wanted && first_cached &&
                     (boot_acknowledged || start_failed);
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   raw_ack_sync<=0;raw_index_meta<=0;raw_index_sync<=0;
   busy<=0;boot_sent<=0;boot_acknowledged<=0;logical_seen<=0;logical_pending<=0;
   read_enabled<=0;read_request<=0;read_index<=0;read_is_start<=0;read_is_end<=0;
   player_ack_toggle<=0;player_ack_index<=0;chapter_committed<=0;ending_committed<=0;
  end else begin
   raw_ack_sync<={raw_ack_sync[1:0],raw_ack_toggle};
   raw_index_meta<=raw_ack_index;raw_index_sync<=raw_index_meta;
   if(end_wanted || !adventure_started)chapter_committed<=0;
   if(!end_wanted)ending_committed<=0;
   // A cancelled navigation may be followed by another END request while
   // the same acknowledged physical END is still displayed.
   else if(!busy && read_enabled && read_is_end)ending_committed<=1;
   if(busy)begin
    if(raw_ack_sync[2]==read_request && raw_index_sync==read_index)begin
     busy<=0;
     if(read_is_end)begin ending_committed<=end_wanted;chapter_committed<=0;end
     else if(read_is_start)begin boot_acknowledged<=1;ending_committed<=0;chapter_committed<=0;end
     else begin
      player_ack_toggle<=logical_pending;player_ack_index<=raw_index_sync;
      chapter_committed<=adventure_started && !end_wanted;ending_committed<=0;
     end
    end
   end else if((END_EFFECT_ENABLE!=0 || admit_player || drain_busy) && transition_request!=logical_seen)begin
    // Finish an already-accepted transition before switching special context.
    // New requests are disabled in the transition controller while inactive.
    logical_seen<=transition_request;
    logical_pending<=END_EFFECT_ENABLE!=0 ? transition_player_token : transition_request;
    read_request<=~read_request;read_index<=transition_index;read_is_start<=0;
    read_is_end<=END_EFFECT_ENABLE!=0 && transition_is_end;
    read_enabled<=1;busy<=1;ending_committed<=0;
   end else if(END_EFFECT_ENABLE==0 && !drain_busy && end_wanted && end_available && (!read_enabled || !read_is_end))begin
    read_request<=~read_request;read_index<=0;read_is_start<=0;read_is_end<=1;
    read_enabled<=1;busy<=1;chapter_committed<=0;ending_committed<=0;
   end else if(!drain_busy && !end_wanted && !adventure_started && start_cached && (!read_enabled || !read_is_start))begin
    read_request<=~read_request;read_index<=0;read_is_start<=1;read_is_end<=0;
    read_enabled<=1;boot_sent<=1;busy<=1;chapter_committed<=0;ending_committed<=0;
   end else if(!boot_sent && start_cached && (END_EFFECT_ENABLE==0 ||
               (!drain_busy && (!end_wanted || !read_enabled))))begin
    read_request<=~read_request;read_index<=0;read_is_start<=1;read_is_end<=0;
    read_enabled<=1;boot_sent<=1;busy<=1;
   end
  end
 end
endmodule

// Serialize chapter and END requests into the existing transition mailbox.
// Its token alternates for every transaction, whereas player_token alternates
// for chapters only. A physical END ACK must never acknowledge a chapter.
module chapter_end_transition_dispatch(
    input wire clk, rst, player_admitted, player_request,
    input wire [2:0] player_index, input wire [3:0] player_kind,
    input wire ending_requested, end_available, reader_is_end,
    input wire [3:0] effect_sel, input wire transition_busy, forwarded_request,
    output reg request, output reg [3:0] target, kind, output reg player_token
);
    reg waiting_accept;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            request<=0; target<=0; kind<=4'hf; player_token<=0; waiting_accept<=0;
        end else if(waiting_accept) begin
            // The second condition also supports a zero-frame bypass build.
            if(transition_busy || forwarded_request==request) waiting_accept<=0;
        end else if(!transition_busy) begin
            if(ending_requested && end_available && !reader_is_end) begin
                request<=~request; target<=4'b1000; kind<=effect_sel; waiting_accept<=1;
            end else if(player_admitted && player_request!=player_token) begin
                request<=~request; target<={1'b0,player_index}; kind<=player_kind;
                player_token<=player_request; waiting_accept<=1;
            end
        end
    end
endmodule

// Both completion sources produce a single monotonically toggled SD-domain
// stream. Do not mux raw/joined levels when write_is_start changes, which would
// manufacture a finish edge between the startup load and the first chapter.
module start_write_completion_mux (
    input wire clk,input wire rst,input wire write_is_start,
    input wire full_finish_toggle,input wire joined_finish_toggle,
    output reg finish_toggle
);
    (* ASYNC_REG="TRUE" *) reg [2:0] full_finish_sync;
    reg full_seen,joined_seen;
    always @(posedge clk or posedge rst)begin
        if(rst)begin full_finish_sync<=0;full_seen<=0;joined_seen<=0;finish_toggle<=0;end
        else begin
            full_finish_sync<={full_finish_sync[1:0],full_finish_toggle};
            full_seen<=full_finish_sync[2];joined_seen<=joined_finish_toggle;
            if((write_is_start && full_finish_sync[2]!=full_seen) ||
               (!write_is_start && joined_finish_toggle!=joined_seen))
                finish_toggle<=~finish_toggle;
        end
    end
endmodule
