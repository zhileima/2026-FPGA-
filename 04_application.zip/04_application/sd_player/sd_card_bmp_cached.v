`timescale 1ns/1ps
// Immutable four-frame cache. Bank n contains its configured exact FAT filename
// lifetime of this system boot. Publish only complete banks; the reader
// commits bank/token at a frame boundary. Cached navigation never reads SD.
module sd_card_bmp_cached #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SPI_INIT_CLK_DIV = 250,
    parameter integer SPI_READ_CLK_DIV = 2,
    parameter [31:0] SCAN_START_SECTOR = 32'd0,
    parameter [31:0] SCAN_MAX_SECTOR = 32'd131071,
    parameter [3:0] SCAN_TARGET_COUNT = 4'd8,
    parameter integer AUTO_PLAY_MS = 1000,
    parameter integer LONG_PRESS_MS = 1000,
    parameter integer DEBOUNCE_MS = 20,
    // Stability limits are supplied by the centralized top-level policy.
    parameter integer SECTOR_TIMEOUT_MS = 500,
    parameter integer WRITE_ACK_TIMEOUT_MS = 500,
    parameter integer LOAD_TIMEOUT_MS = 5000,
    parameter integer MAX_FAST_SKIP_SECTORS = 16384,
    parameter integer MAX_RETRIES = 1,
    parameter integer FAST_BOOT_ENABLE = 1,
    parameter [87:0] FAT_NAME0="PIC1    BMP",
    parameter [87:0] FAT_NAME1="PIC2    BMP",
    parameter [87:0] FAT_NAME2="PIC3    BMP",
    parameter [87:0] FAT_NAME3="PIC4    BMP",
    parameter [87:0] FAT_NAME4="PIC5    BMP", FAT_NAME5="PIC6    BMP",
    parameter [87:0] FAT_NAME6="PIC7    BMP", FAT_NAME7="PIC8    BMP",
    parameter integer FAT_MAX_DIR_SECTORS=256,
    parameter integer FAT_MAX_FILE_CLUSTERS=8192,
    parameter integer RAW_AUDIO_ENABLE=0,
    parameter integer FAT_AUDIO_ENABLE=0,
    parameter integer MUSIC_TRACK_COUNT=1,
    parameter integer EXTERNAL_KEY_EVENTS=0,
    parameter integer IMAGE_SCALE_ENABLE=0, MAX_SOURCE_DIM=4096,
    parameter integer IMAGE_LONG_NAME_ENABLE=0,
    parameter integer THUMBNAIL_CONTROL_ENABLE=0,
    parameter integer SETTINGS_ENABLE=0,
    parameter integer DIRECT_MANUAL_ENABLE=0,
    parameter integer AUTO_ADVANCE_ENABLE=1,
    parameter integer EXTERNAL_SCHEDULER_ENABLE=0,
    parameter integer EARLY_ASSETS_ENABLE=0,
    parameter integer AUDIO_DWELL_ENABLE=0, START_PAGE_ENABLE=0, END_PAGE_ENABLE=0, END_PAGE_SEQUENCE_ENABLE=0
)(
    input clk, input rst, input key_next, input key_auto,
    input startup_assets_ready, input auto_audio_ready,input local_auto_enable,
    input end_page_active,output auto_end_event,auto_restart_event,
    output reg write_is_start, output reg start_cached, output reg [7:0] start_error,
    output reg write_is_end, output reg end_cached, output reg [7:0] end_error,
    output [3:0] state_code,
    output [3:0] image_number,
    output [26:0] debug_status,
    input [15:0] bmp_width, input [15:0] bmp_height,
    output display_valid,
    input write_finish_toggle,
    output reg [2:0] write_buf_idx, output [2:0] disp_buf_idx,
    output [2:0] read_buf_req_idx,
    output read_switch_req_toggle,
    output [3:0] read_switch_req_kind,
    input read_switch_ack_toggle, input [2:0] read_switch_ack_idx,
    output write_req, input write_req_ack,
    output write_en, output [31:0] write_data, input write_ready,
    output reg [15:0] source_width0,source_height0,source_width1,source_height1,
                      source_width2,source_height2,source_width3,source_height3,
                      source_width4,source_height4,source_width5,source_height5,
                      source_width6,source_height6,source_width7,source_height7,
    input osd_start,output osd_ready,output osd_present,output osd_valid,
    output [7:0] osd_byte,output [15:0] osd_offset,output osd_done,
    output [7:0] osd_error,input osd_byte_ready,
    input raw_req,input [31:0] raw_lba,output raw_ready,
    output raw_valid,output [7:0] raw_byte,output [8:0] raw_index,
    output raw_done,output [7:0] raw_error,input raw_byte_ready,
    output music_present,output [31:0] music_total_sectors,
    input [4:0] music_index,input music_stop,
    output [20:0] music_valid_mask,output music_idle,
    input nav_next_event,input nav_prev_event,input auto_toggle_event,input cue_event,
    output SD_nCS, output SD_DCLK, output SD_MOSI, input SD_MISO,
    output reg button_event_toggle,
    output reg cache_ready,
    output reg [7:0] last_error_code,
    output reg error_event_toggle,
    output reg [15:0] error_count,
    output reg [7:0] failed_mask,
    output [7:0] cache_valid_mask,
    output [1:0] recovery_state,
    output reg [3:0] retry_count,
    output scan_complete,
    output fs_mounted,output [7:0] fs_present_mask,
    output fs_fragment_seen,output fs_large_lba_seen,output sd_high_capacity,
    input [7:0] loader_memory_error,
    output loader_frame_commit,output loader_abort,output [7:0] control_error,
    input pause_navigation,input direct_select_valid,input [2:0] direct_select_index,input direct_select_manual,
    output direct_select_ready,output direct_select_done,
    input [2:0] period_sel,input [3:0] effect_sel,output auto_play_status
);
    localparam [63:0] AUTO_PLAY_CYCLES =
        (64'd1 * CLK_FREQ_HZ * AUTO_PLAY_MS + 999) / 1000;
    localparam [63:0] LONG_PRESS_CYCLES =
        (64'd1 * CLK_FREQ_HZ * LONG_PRESS_MS + 999) / 1000;
    localparam [63:0] LOAD_TIMEOUT_CYCLES =
        (64'd1 * CLK_FREQ_HZ * LOAD_TIMEOUT_MS + 999) / 1000;
    initial begin
        if (CLK_FREQ_HZ<=0 || AUTO_PLAY_MS<=0 || LONG_PRESS_MS<=0 ||
            AUTO_PLAY_CYCLES<1 || AUTO_PLAY_CYCLES>64'hffffffff ||
            LONG_PRESS_CYCLES<1 || LONG_PRESS_CYCLES>64'hffffffff ||
            SCAN_TARGET_COUNT<1 || SCAN_TARGET_COUNT>8 ||
            MAX_RETRIES<0 || MAX_RETRIES>15 ||
            LOAD_TIMEOUT_MS<=0 || LOAD_TIMEOUT_CYCLES<1 ||
            LOAD_TIMEOUT_CYCLES>64'hffffffffff) begin
            $display("SD_CACHED_CONFIG_ERROR invalid timing or image-count parameter");
            $finish;
        end
    end
    wire key_next_press,key_auto_press,key_auto_stable;
    wire sd_init_done;
    reg key_auto_previous,long_press_marked;
    reg [31:0] long_press_cnt;
    wire key_auto_short = !key_auto_previous && key_auto_stable && !long_press_marked;
    wire key_auto_long = !key_auto_stable && !long_press_marked &&
                        long_press_cnt==LONG_PRESS_CYCLES-1;
    cached_key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(DEBOUNCE_MS)) u_key_next(
        .clk(clk),.rst(rst),.button_in(key_next),.press_pulse(key_next_press),.button_stable_out());
    cached_key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(DEBOUNCE_MS)) u_key_auto(
        .clk(clk),.rst(rst),.button_in(key_auto),.press_pulse(key_auto_press),.button_stable_out(key_auto_stable));
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            key_auto_previous<=1; long_press_cnt<=0; long_press_marked<=0;
            button_event_toggle<=0;
        end else begin
            key_auto_previous<=key_auto_stable;
            // Both keys provide immediate press feedback, even while SD is
            // busy. KEY4's media policy still distinguishes hold/release.
            if(EXTERNAL_KEY_EVENTS!=0 ? cue_event : (key_next_press || key_auto_press))
                button_event_toggle<=~button_event_toggle;
            if(key_auto_stable) begin
                long_press_cnt<=0; long_press_marked<=0;
            end else if(!long_press_marked) begin
                if(key_auto_long) long_press_marked<=1;
                else long_press_cnt<=long_press_cnt+1'b1;
            end
        end
    end

    wire bmp_data_wr_en,bmp_ready,scan_done,scan_found_valid;
    wire [23:0] bmp_data;
    wire [31:0] scan_found_sector;
    wire [3:0] scan_found_total;
    wire [2:0] scan_found_slot;
    wire bmp_load_done,bmp_load_error,bmp_error_valid,bmp_error_is_scan,sd_abort_reset;
    wire [7:0] bmp_error_code;
    reg load_abort,retry_pending;
    localparam integer LOAD_TIMER_BITS=LOAD_TIMEOUT_CYCLES<2 ? 1 : $clog2(LOAD_TIMEOUT_CYCLES);
    reg [LOAD_TIMER_BITS-1:0] load_timeout_cnt;
    wire [15:0] loaded_source_width,loaded_source_height;
    // The scaled reader publishes only dimensions already checked against
    // MAX_SOURCE_DIM. Native mode keeps its original 16-bit input contract.
    localparam integer PUBLISHED_DIM_BITS=IMAGE_SCALE_ENABLE!=0 ? $clog2(MAX_SOURCE_DIM+1) : 16;
    wire [15:0] published_width={{(16-PUBLISHED_DIM_BITS){1'b0}},loaded_source_width[PUBLISHED_DIM_BITS-1:0]};
    wire [15:0] published_height={{(16-PUBLISHED_DIM_BITS){1'b0}},loaded_source_height[PUBLISHED_DIM_BITS-1:0]};
    reg writer_idle_seen,write_ack_seen,write_finish_armed;
    reg [2:0] write_arm_delay;
    localparam PREP_IDLE=2'd0, PREP_BANK=2'd1, PREP_LAUNCH=2'd2;
    reg [1:0] load_prepare_state;
    reg [2:0] prepared_bank;
    reg prepared_retry, prepared_start, prepared_end;
    wire start_present,end_present;
    wire end_pending=END_PAGE_ENABLE!=0 && !end_cached && end_error==0;
    // Last, after chapter frames: it does not delay first-picture/early OSD admission.
    wire start_pending=START_PAGE_ENABLE!=0 && !start_cached && start_error==0;
    wire start_load_available=start_pending && start_present;
    reg scan_start_pulse,load_start_pulse,scan_kicked;
    wire first_image_committed;
    // fat32_bmp_read publishes slot tokens 0..7, not image LBAs.
    // PREP_BANK already registers load_idx on the original token capture edge.

    reg [3:0] img_found_count;
    reg [2:0] load_idx;
    wire [31:0] load_sector={29'd0,load_idx};
    wire [2:0] img_idx,pending_display_idx;
    reg [7:0] cache_valid;
    reg [7:0] found_slots;
    reg load_busy,source_done_seen,source_active_seen,write_done_seen;
    wire switch_pending,next_req_pending,prev_req_pending,auto_req_pending,auto_play_en;
    assign auto_play_status=auto_play_en;
    wire [32:0] auto_cnt;
    (* ASYNC_REG = "TRUE" *) reg [2:0] wrfin_tgl_sync;
    wire write_finish_pulse=wrfin_tgl_sync[2]^wrfin_tgl_sync[1];
    wire loader_fault=write_ack_seen && (|loader_memory_error);
    assign loader_frame_commit=bmp_load_done;
    assign loader_abort=load_abort || bmp_load_error;
    wire [7:0] found_mask=found_slots;
    // A failed slot is terminal for this boot, so one bad image cannot hold
    // the ready indicator or autoplay hostage. Navigation excludes that slot.
    assign cache_valid_mask=cache_valid;
    assign scan_complete=scan_done;
    assign recovery_state=(retry_pending || (load_busy && retry_count!=0)) ? 2'd1 :
                          (failed_mask!=0 || (scan_done && img_found_count==0)) ? 2'd2 : 2'd0;
    assign write_en=bmp_data_wr_en && load_busy && !bmp_load_error && !load_abort;
    assign write_data={bmp_data,8'b0};
    // Original wire format retained. load_busy now means background SD fill,
    // and switch_pending independently means a cached reader-bank handshake.
    assign debug_status={19'b0,last_error_code};
    wire [7:0] available_mask=found_mask & ~failed_mask;
    function [7:0] lower_slots;
        input [2:0] slot;
        begin lower_slots=(8'h01<<slot)-1'b1; end
    endfunction
    reg fill_candidate_valid;
    wire end_load_available=end_pending && end_present && scan_done && !fill_candidate_valid && !start_pending;
    reg [2:0] fill_candidate;
    reg first_valid_found;
    reg [2:0] first_valid_index;
    integer candidate_n;
    always @* begin
        fill_candidate=0; fill_candidate_valid=0;
        first_valid_found=0; first_valid_index=0;
        // Fill in physical slot order. Waiting media actions remain queued;
        // preload selection does not need the navigation priority chain.
        for(candidate_n=0;candidate_n<8;candidate_n=candidate_n+1) begin
            if(!fill_candidate_valid && found_slots[candidate_n] &&
               !cache_valid[candidate_n] && !failed_mask[candidate_n]) begin
                fill_candidate=candidate_n; fill_candidate_valid=1;
            end
            if(!first_valid_found && cache_valid[candidate_n]) begin
                first_valid_found=1; first_valid_index=candidate_n;
            end
        end
    end
    // A directory may list PIC4 before PIC1. Until the first publication,
    // continue discovery unless every lower-numbered slot has failed or the
    // root scan has ended and proved those names absent. PIC1 can start early.
    wire startup_assets_pending=EARLY_ASSETS_ENABLE!=0 &&
        ((|cache_valid) || (START_PAGE_ENABLE!=0 && start_cached)) && !startup_assets_ready;
    wire startup_fill_allowed=first_image_committed || scan_done ||
        (failed_mask & lower_slots(fill_candidate))==lower_slots(fill_candidate);
    wire startup_publish_allowed=scan_done ||
        (failed_mask & lower_slots(first_valid_index))==lower_slots(first_valid_index);
    // FAT discovery yields at complete-sector boundaries. Once the lowest
    // eligible first image is found, loading preempts background discovery.
    // Direct eligibility avoids encoding a candidate and decoding its lower
    // slots again on the scanner pause/timeout path. A higher slot may preempt
    // discovery only when every lower slot failed, or discovery has completed.
    wire [7:0] preload_needed=found_slots & ~cache_valid & ~failed_mask;
    wire startup_preempt=preload_needed[0] ||
        (preload_needed[1] && failed_mask[0]) ||
        (preload_needed[2] && (&failed_mask[1:0])) ||
        (preload_needed[3] && (&failed_mask[2:0])) ||
        (preload_needed[4] && (&failed_mask[3:0])) ||
        (preload_needed[5] && (&failed_mask[4:0])) ||
        (preload_needed[6] && (&failed_mask[5:0])) ||
        (preload_needed[7] && (&failed_mask[6:0])) ||
        (scan_done && (|preload_needed));
    // The eight-slot startup eligibility tree is not part of the same-cycle
    // storage-ready/abort path. A newly discovered candidate is captured here
    // while PREP_IDLE selects its bank. Keep the immediate busy/retry/prepare
    // terms: an already-issued directory sector drains before PREP_LAUNCH can
    // observe bmp_ready and issue the single image-load pulse.
    reg startup_preempt_q;
    always @(posedge clk or posedge rst) begin
        if(rst) startup_preempt_q<=1'b0;
        else startup_preempt_q<=FAST_BOOT_ENABLE && !first_image_committed &&
            (START_PAGE_ENABLE!=0 ? (!startup_assets_pending &&
                (start_load_available || (!start_pending && startup_preempt))) : startup_preempt);
    end
    wire scan_pause=load_busy || retry_pending || load_prepare_state!=PREP_IDLE ||
                    startup_preempt_q;
    wire accepted_write_finish=write_finish_armed && write_finish_pulse;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            wrfin_tgl_sync<=0;
            scan_start_pulse<=0; load_start_pulse<=0; scan_kicked<=0;
            
            img_found_count<=0; load_idx<=0;

            cache_valid<=0;found_slots<=0; write_buf_idx<=0;
            source_width0<=0;source_height0<=0;source_width1<=0;source_height1<=0;
            source_width2<=0;source_height2<=0;source_width3<=0;source_height3<=0;
            source_width4<=0;source_height4<=0;source_width5<=0;source_height5<=0;
            source_width6<=0;source_height6<=0;source_width7<=0;source_height7<=0;
            load_busy<=0; source_done_seen<=0; source_active_seen<=0; write_done_seen<=0;
            
            failed_mask<=0; last_error_code<=0; error_event_toggle<=0; error_count<=0;
            cache_ready<=0;
            retry_pending<=0; retry_count<=0; load_abort<=0; load_timeout_cnt<=0;
            writer_idle_seen<=0; write_ack_seen<=0; write_finish_armed<=0; write_arm_delay<=0;
            load_prepare_state<=PREP_IDLE; prepared_bank<=0; prepared_retry<=0;prepared_start<=0;prepared_end<=0;
            write_is_start<=0;start_cached<=0;start_error<=0;write_is_end<=0;end_cached<=0;end_error<=0;
        end else begin
            wrfin_tgl_sync<={wrfin_tgl_sync[1:0],write_finish_toggle};
            scan_start_pulse<=0; load_start_pulse<=0; load_abort<=0;
            // Missing START is visible and terminal for this startup attempt.
            // No chapter valid bit is fabricated and normal chapter loading may proceed.
            if(start_pending && scan_done && !start_present && !load_busy) begin
                start_error<=8'ha0;last_error_code<=8'ha0;
                error_event_toggle<=~error_event_toggle;
                if(error_count!=16'hffff) error_count<=error_count+1'b1;
            end
            if(end_pending && scan_done && !end_present && !load_busy) begin
                end_error<=8'ha1;last_error_code<=8'ha1;
                error_event_toggle<=~error_event_toggle;
                if(error_count!=16'hffff) error_count<=error_count+1'b1;
            end
            // Register the terminal predicate: count/mask update together on
            // discovery and must not glitch ready when the final slot arrives.
            cache_ready<=scan_done && img_found_count==scan_found_total && cache_valid!=0 &&
                         (((cache_valid | failed_mask) & found_mask)==found_mask) && !end_pending;
            // Only system reset discards complete banks. A local SD recovery
            // may deassert init_done while HDMI keeps the last complete frame.
            if(bmp_error_valid) begin
                last_error_code<=bmp_error_code; error_event_toggle<=~error_event_toggle;
                if(error_count!=16'hffff) error_count<=error_count+1'b1;
                if(bmp_error_code==8'h3d) begin
                    // Reinitialization has reached its bounded terminal state.
                    // Stop waiting for an impossible retry; retain only banks
                    // already complete, until an explicit whole-system reset.
                    failed_mask<=failed_mask | (found_mask & ~cache_valid);
                    if(start_pending) start_error<=8'h3d;
                    if(end_pending) end_error<=8'h3d;
                    retry_pending<=0; retry_count<=0; load_busy<=0;
                    source_active_seen<=0; source_done_seen<=0; write_done_seen<=0;
                    write_finish_armed<=0;
                    load_prepare_state<=PREP_IDLE;
                end
            end
            begin
                if(sd_init_done && !scan_kicked && bmp_ready) begin
                    scan_start_pulse<=1; scan_kicked<=1;
                end
                if(scan_found_valid && !found_slots[scan_found_slot] && img_found_count<SCAN_TARGET_COUNT) begin
                    found_slots[scan_found_slot]<=1;
                    img_found_count<=img_found_count+1'b1;
                end
                if(load_busy) begin
                    if(!bmp_ready) source_active_seen<=1;
                    if(bmp_load_done) source_done_seen<=1;
                    // A new real writer ACK clears/resets the previous partial
                    // transfer. Ignore old finish toggles until its ACK drains
                    // and the synchronizer has settled for three extra clocks.
                    if(!write_req && !write_req_ack) writer_idle_seen<=1;
                    if(writer_idle_seen && write_req && write_req_ack) write_ack_seen<=1;
                    if(write_ack_seen && !write_req && !write_req_ack && !write_finish_armed) begin
                        if(write_arm_delay==3) write_finish_armed<=1;
                        else write_arm_delay<=write_arm_delay+1'b1;
                    end
                    if(accepted_write_finish) write_done_seen<=1;
                    if(load_timeout_cnt<LOAD_TIMEOUT_CYCLES-1)
                        load_timeout_cnt<=load_timeout_cnt+1'b1;
                    if(bmp_load_error || loader_fault) begin
                        if(loader_fault) begin
                            load_abort<=1; last_error_code<=loader_memory_error;
                            error_event_toggle<=~error_event_toggle;
                            if(error_count!=16'hffff) error_count<=error_count+1'b1;
                        end
                        load_busy<=0; source_active_seen<=0; source_done_seen<=0; write_done_seen<=0;
                        write_finish_armed<=0;
                        if(retry_count<MAX_RETRIES) begin
                            retry_count<=retry_count+1'b1; retry_pending<=1;
                        end else begin
                            if(write_is_end) end_error<=loader_fault ? loader_memory_error : bmp_error_code;
                            else if(write_is_start) start_error<=loader_fault ? loader_memory_error : bmp_error_code;
                            else failed_mask[load_idx]<=1;
                            retry_pending<=0;
                        end
                    end else if((source_done_seen || bmp_load_done) &&
                                (write_done_seen || accepted_write_finish)) begin
                        // Parser success alone is insufficient: the final SDRAM
                        // write must finish before a bank becomes publishable.
                        if(write_is_end) end_cached<=1;
                        else if(write_is_start) start_cached<=1;
                        else begin
                        cache_valid[load_idx]<=1;
                        // Publish dimensions with the same complete-bank bit.
                        case(load_idx)
                            0:begin source_width0<=published_width;source_height0<=published_height;end
                            1:begin source_width1<=published_width;source_height1<=published_height;end
                            2:begin source_width2<=published_width;source_height2<=published_height;end
                            3:begin source_width3<=published_width;source_height3<=published_height;end
                            4:begin source_width4<=published_width;source_height4<=published_height;end
                            5:begin source_width5<=published_width;source_height5<=published_height;end
                            6:begin source_width6<=published_width;source_height6<=published_height;end
                            7:begin source_width7<=published_width;source_height7<=published_height;end
                        endcase
                        end
                        load_busy<=0; source_active_seen<=0; source_done_seen<=0; write_done_seen<=0;
                        retry_pending<=0; retry_count<=0; write_finish_armed<=0;
                    end else if(load_timeout_cnt==LOAD_TIMEOUT_CYCLES-1) begin
                        load_abort<=1; load_busy<=0;
                        source_active_seen<=0; source_done_seen<=0; write_done_seen<=0;
                        write_finish_armed<=0;
                        last_error_code<=source_done_seen ? 8'h3c : 8'h3b;
                        error_event_toggle<=~error_event_toggle;
                        if(error_count!=16'hffff) error_count<=error_count+1'b1;
                        if(retry_count<MAX_RETRIES) begin
                            retry_count<=retry_count+1'b1; retry_pending<=1;
                        end else begin
                            if(write_is_end) end_error<=source_done_seen ? 8'h3c : 8'h3b;
                            else if(write_is_start) start_error<=source_done_seen ? 8'h3c : 8'h3b;
                            else failed_mask[load_idx]<=1;
                            retry_pending<=0;
                        end
                    end
                end
                // Select, lock the SDRAM bank/sector, then launch on separate
                // clock edges. No navigation/candidate logic drives the wide
                // sector register and all load-state enables in one cycle.
                if(!(bmp_error_valid && bmp_error_code==8'h3d)) begin
                    case(load_prepare_state)
                        PREP_IDLE:if(!load_busy && !load_abort && !startup_assets_pending && (scan_done || FAST_BOOT_ENABLE) &&
                                     (retry_pending || start_load_available || end_load_available || (!start_pending && fill_candidate_valid && startup_fill_allowed))) begin
                            prepared_start<=retry_pending ? write_is_start : start_load_available;
                            prepared_end<=retry_pending ? write_is_end : end_load_available;
                            prepared_bank<=retry_pending ? load_idx : ((start_load_available || end_load_available) ? 3'd0 : fill_candidate);
                            prepared_retry<=retry_pending; load_prepare_state<=PREP_BANK;
                        end
                        PREP_BANK:begin
                            if(startup_assets_pending || (prepared_end ? (!end_pending || !end_present) : prepared_start ?
                               (!start_pending || !start_present) :
                               (cache_valid[prepared_bank] || failed_mask[prepared_bank] ||
                                !found_slots[prepared_bank] || (display_valid && prepared_bank==disp_buf_idx))))
                                load_prepare_state<=PREP_IDLE;
                            else if(sd_init_done && bmp_ready && !load_abort) begin
                                load_idx<=prepared_bank; write_buf_idx<=prepared_bank;write_is_start<=prepared_start;write_is_end<=prepared_end;
                                load_prepare_state<=PREP_LAUNCH;
                            end
                        end
                        PREP_LAUNCH:begin
                            // Recheck after any simultaneous reader ACK or
                            // terminal error; an old prepared slot never writes
                            // a bank which has since become valid/displayed.
                            if(startup_assets_pending || (prepared_end ? (!end_pending || !end_present) : prepared_start ?
                               (!start_pending || !start_present) :
                               (cache_valid[prepared_bank] || failed_mask[prepared_bank] ||
                                (display_valid && prepared_bank==disp_buf_idx))))
                                load_prepare_state<=PREP_IDLE;
                            else if(sd_init_done && bmp_ready && !load_abort) begin
                                load_start_pulse<=1; load_busy<=1; retry_pending<=0;
                                if(!prepared_retry) retry_count<=0;
                                source_active_seen<=0; source_done_seen<=0; write_done_seen<=0;
                                load_timeout_cnt<=0; writer_idle_seen<=0; write_ack_seen<=0;
                                write_finish_armed<=0; write_arm_delay<=0;
                                load_prepare_state<=PREP_IDLE;
                            end
                        end
                        default:load_prepare_state<=PREP_IDLE;
                    endcase
                end
            end
        end
    end
    // Storage discovery/loading and navigation have independent state machines.
    // The controller publishes number/audio only after the reader echoes bank+token.
    media_player_control #(.END_PAGE_SEQUENCE_ENABLE(END_PAGE_SEQUENCE_ENABLE),.BANK_BITS(3),.DIRECT_MANUAL_ENABLE(DIRECT_MANUAL_ENABLE),.AUTO_ADVANCE_ENABLE(AUTO_ADVANCE_ENABLE),
        .EXTERNAL_SCHEDULER_ENABLE(EXTERNAL_SCHEDULER_ENABLE),.CLK_FREQ_HZ(CLK_FREQ_HZ),.AUTO_PLAY_MS(AUTO_PLAY_MS),
        .THUMBNAIL_CONTROL_ENABLE(THUMBNAIL_CONTROL_ENABLE),.SETTINGS_ENABLE(SETTINGS_ENABLE),
        .AUDIO_DWELL_ENABLE(AUDIO_DWELL_ENABLE)) u_player_control(
        .clk(clk),.rst(rst),.key_next_press(EXTERNAL_KEY_EVENTS!=0 ? nav_next_event : key_next_press),
        .key_auto_short(EXTERNAL_KEY_EVENTS!=0 ? auto_toggle_event : key_auto_short),
        .key_auto_long(EXTERNAL_KEY_EVENTS!=0 ? nav_prev_event : key_auto_long),
        .available_mask(available_mask),.cache_valid_mask(cache_valid),
        .first_publish_allowed(startup_publish_allowed),.first_valid_index(first_valid_index),
        .first_valid_found(first_valid_found),.cache_ready(cache_ready),
        .read_switch_ack_toggle(read_switch_ack_toggle),.read_switch_ack_idx(read_switch_ack_idx),
        .img_idx(img_idx),.image_number(image_number),.display_valid(display_valid),
        .first_image_committed(first_image_committed),.auto_play_en(auto_play_en),.auto_cnt(auto_cnt),
        .switch_pending(switch_pending),.read_buf_req_idx(read_buf_req_idx),
        .read_switch_req_toggle(read_switch_req_toggle),.read_switch_req_kind(read_switch_req_kind),.pending_display_idx(pending_display_idx),
        .disp_buf_idx(disp_buf_idx),.next_req_pending(next_req_pending),
        .prev_req_pending(prev_req_pending),.auto_req_pending(auto_req_pending),.control_error(control_error),
        .pause_navigation(pause_navigation),.direct_select_valid(direct_select_valid),
        .direct_select_index(direct_select_index),.direct_select_manual(direct_select_manual),.direct_select_ready(direct_select_ready),
        .direct_select_done(direct_select_done),.period_sel(period_sel),.effect_sel(effect_sel),
        .auto_audio_ready(auto_audio_ready),.local_auto_enable(local_auto_enable),
        .end_page_active(end_page_active),.auto_end_event(auto_end_event),.auto_restart_event(auto_restart_event));
    fat32_bmp_read #(.START_PAGE_ENABLE(START_PAGE_ENABLE),.END_PAGE_ENABLE(END_PAGE_ENABLE),.IMAGE_COUNT(8),.OSD_ENABLE(1),.IMAGE_LONG_NAME_ENABLE(IMAGE_LONG_NAME_ENABLE),
        .IMAGE_SCALE_ENABLE(IMAGE_SCALE_ENABLE),.MAX_SOURCE_DIM(MAX_SOURCE_DIM),.CLK_FREQ_HZ(CLK_FREQ_HZ),.SECTOR_TIMEOUT_MS(SECTOR_TIMEOUT_MS),
        .SPI_INIT_CLK_DIV(SPI_INIT_CLK_DIV),.SPI_READ_CLK_DIV(SPI_READ_CLK_DIV),
        .WRITE_ACK_TIMEOUT_MS(WRITE_ACK_TIMEOUT_MS),.LOAD_TIMEOUT_MS(LOAD_TIMEOUT_MS),
        .NAME0(FAT_NAME0),.NAME1(FAT_NAME1),.NAME2(FAT_NAME2),.NAME3(FAT_NAME3),
        .NAME4(FAT_NAME4),.NAME5(FAT_NAME5),.NAME6(FAT_NAME6),.NAME7(FAT_NAME7),
        .MAX_DIR_SECTORS(FAT_MAX_DIR_SECTORS),.MAX_FILE_CLUSTERS(FAT_MAX_FILE_CLUSTERS),
        .RAW_AUDIO_ENABLE(RAW_AUDIO_ENABLE),.FAT_AUDIO_ENABLE(FAT_AUDIO_ENABLE),
        .MUSIC_TRACK_COUNT(MUSIC_TRACK_COUNT)) bmp_read_m0(
        .clk(clk),.rst(rst),.ready(bmp_ready),.scan_start(scan_start_pulse),
        .scan_target_count(SCAN_TARGET_COUNT),.scan_done(scan_done),
        .scan_found_valid(scan_found_valid),.scan_found_sector(scan_found_sector),.scan_found_total(scan_found_total),
        .scan_found_slot(scan_found_slot),
        .load_start(load_start_pulse),.load_is_start(write_is_start),.start_present(start_present),.load_is_end(write_is_end),.end_present(end_present),.load_sector(load_sector),.sd_init_done(sd_init_done),
        .scan_pause(scan_pause),.load_abort(load_abort),.load_done(bmp_load_done),
        .load_error(bmp_load_error),.bmp_error(bmp_error_code),
        .error_valid(bmp_error_valid),.error_is_scan(bmp_error_is_scan),
        .state_code(state_code),.bmp_width(bmp_width),.bmp_height(bmp_height),
        .write_req(write_req),.write_req_ack(write_req_ack),
        .bmp_data_wr_en(bmp_data_wr_en),.bmp_data(bmp_data),
        .bmp_pixel_ready(write_ready),.source_width(loaded_source_width),.source_height(loaded_source_height),
        .fs_mounted(fs_mounted),.fs_present_mask(fs_present_mask),
        .fs_fragment_seen(fs_fragment_seen),.fs_large_lba_seen(fs_large_lba_seen),
        .sd_high_capacity(sd_high_capacity),
        .raw_enable((cache_ready || (EARLY_ASSETS_ENABLE!=0 && ((|cache_valid) || (START_PAGE_ENABLE!=0 && start_cached)))) && (FAT_AUDIO_ENABLE==0 || !music_stop)),
        .osd_start(osd_start),.osd_ready(osd_ready),.osd_present(osd_present),
        .osd_valid(osd_valid),.osd_byte(osd_byte),.osd_offset(osd_offset),
        .osd_done(osd_done),.osd_error(osd_error),.osd_byte_ready(osd_byte_ready),
        .raw_req(raw_req),.raw_lba(raw_lba),.raw_ready(raw_ready),
        .raw_valid(raw_valid),.raw_byte(raw_byte),.raw_index(raw_index),
        .raw_done(raw_done),.raw_error(raw_error),.raw_byte_ready(raw_byte_ready),
        .music_present(music_present),.music_total_sectors(music_total_sectors),
        .music_index(music_index),.music_valid_mask(music_valid_mask),.music_idle(music_idle),
        .SD_nCS(SD_nCS),.SD_DCLK(SD_DCLK),.SD_MOSI(SD_MOSI),.SD_MISO(SD_MISO));
endmodule

module cached_key_press_debounce #(
    parameter integer CLK_FREQ_HZ=100_000_000, parameter integer DEBOUNCE_MS=20
)(input clk,input rst,input button_in,output reg press_pulse,output wire button_stable_out);
    localparam [63:0] DEBOUNCE_CYCLES=(64'd1*CLK_FREQ_HZ*DEBOUNCE_MS+999)/1000;
    reg button_sync0,button_sync1,button_stable;
    reg [31:0] cnt;
    assign button_stable_out=button_stable;
    initial begin
        if(CLK_FREQ_HZ<=0 || DEBOUNCE_MS<=0 || DEBOUNCE_CYCLES<1 || DEBOUNCE_CYCLES>64'hffffffff) begin
            $display("CACHED_DEBOUNCE_CONFIG_ERROR invalid parameter"); $finish;
        end
    end
    always @(posedge clk or posedge rst) begin
        if(rst) begin button_sync0<=1;button_sync1<=1;button_stable<=1;cnt<=0;press_pulse<=0; end
        else begin
            button_sync0<=button_in;button_sync1<=button_sync0;press_pulse<=0;
            if(button_sync1==button_stable) cnt<=0;
            else if(cnt>=DEBOUNCE_CYCLES-1) begin
                if(button_stable && !button_sync1) press_pulse<=1;
                button_stable<=button_sync1;cnt<=0;
            end else cnt<=cnt+1'b1;
        end
    end
endmodule
