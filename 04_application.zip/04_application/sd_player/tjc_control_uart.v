`timescale 1ns/1ps
// Functional TJC transport only. No diagnostics, heartbeat or wall clock.
// RX: A5 command argument (A5 XOR command XOR argument) 5A.
// One-way control: the display owns its state; TX stays electrically idle.
// Legacy state inputs are retained for top-level compatibility and are unused.
module tjc_control_uart #(
    parameter integer EXTENDED_SETTINGS=0, CLK_HZ=50000000, BAUD=115200
)(
    input wire clk,rst,input wire rx,output wire tx,
    input wire [18:0] state0,input wire [20:0] state1,input wire [20:0] state2,
    input wire remote_ready,input wire settings_page_request,
    output reg remote_valid,output reg [7:0] remote_cmd,remote_arg
);
    localparam integer DIV=(CLK_HZ+BAUD/2)/BAUD;
    localparam integer CW=(DIV<2)?1:$clog2(DIV);
    (* ASYNC_REG="TRUE" *) reg rx_meta,rx_sync;
    always @(posedge clk or posedge rst)begin
        if(rst)begin rx_meta<=1;rx_sync<=1;end
        else begin rx_meta<=rx;rx_sync<=rx_meta;end
    end
    reg [1:0] rx_state;
    reg [CW-1:0] rx_count;
    reg [2:0] rx_bit;
    reg [7:0] rx_shift,rx_byte;
    reg rx_valid,rx_bad;
    always @(posedge clk or posedge rst)begin
        if(rst)begin rx_state<=0;rx_count<=0;rx_bit<=0;rx_shift<=0;rx_byte<=0;rx_valid<=0;rx_bad<=0;end
        else begin
            rx_valid<=0;rx_bad<=0;
            case(rx_state)
                0:if(!rx_sync)begin rx_count<=DIV/2-1;rx_state<=1;end
                1:if(rx_count!=0)rx_count<=rx_count-1'b1;
                  else if(rx_sync)rx_state<=0;
                  else begin rx_count<=DIV-1;rx_bit<=0;rx_state<=2;end
                2:if(rx_count!=0)rx_count<=rx_count-1'b1;
                  else begin
                      rx_shift[rx_bit]<=rx_sync;rx_count<=DIV-1;
                      if(rx_bit==7)rx_state<=3;else rx_bit<=rx_bit+1'b1;
                  end
                3:if(rx_count!=0)rx_count<=rx_count-1'b1;
                  else begin
                      rx_state<=0;
                      if(rx_sync)begin rx_byte<=rx_shift;rx_valid<=1;end
                      else rx_bad<=1;
                  end
            endcase
        end
    end
    // Relative/context actions retain ordering. Absolute chapter selection
    // supersedes stale context actions, so an unanswerable old confirmation
    // cannot block a newer page. Independent values have one latest slot each.
    reg [15:0] command_fifo[0:7];
    reg [2:0] read_ptr,write_ptr;
    reg [3:0] command_count;
    reg packet_push;
    reg [15:0] packet_value;
    reg head_valid,urgent_valid,jump_valid,parameter_valid,audition_valid,confirm_pending;
    reg [7:0] audition_cmd;
    reg [15:0] head_value,urgent_value,jump_value,parameter_value;
    reg [7:0] parameter_latest[0:5];
    reg [5:0] parameter_dirty;
    reg [2:0] parameter_scan;
    wire packet_parameter=(packet_value[15:8]>=8'h25 && packet_value[15:8]<=8'h27) ||
        (packet_value[15:8]>=8'h30 && packet_value[15:8]<=8'h32);
    wire [2:0] parameter_write_slot=packet_value[15:8]<8'h30 ?
        packet_value[10:8]-3'd5 : packet_value[10:8]+3'd3;
    wire parameter_offer=packet_push && packet_parameter;
    wire jump_offer=packet_push && packet_value[15:8]==8'h04;
    wire audition_offer=packet_push && (packet_value[15:8]==8'h10 || packet_value[15:8]==8'h11 || packet_value[15:8]==8'h13);
    wire confirm_offer=packet_push && packet_value[15:8]==8'h12;
    wire packet_urgent=(packet_value[15:8]>=8'h29 && packet_value[15:8]<=8'h2c) || packet_value[15:8]==8'h20 || packet_value[15:8]==8'h05;
    wire urgent_offer=packet_push && packet_urgent;
    wire urgent_reset=urgent_offer && packet_value[15:8]==8'h2c;
    // START/END are context boundaries, while numeric settings remain pending.
    wire urgent_context=urgent_reset || (urgent_offer && packet_value[15:8]==8'h05);
    wire urgent_accept=urgent_valid && remote_ready;
    wire parameter_accept=!urgent_valid && parameter_valid && remote_ready;
    wire jump_accept=!urgent_valid && !parameter_valid && jump_valid && remote_ready;
    wire urgent_push=urgent_offer && (!urgent_valid || urgent_accept || urgent_reset);
    wire priority_offer=urgent_offer || parameter_offer || jump_offer;
    wire story_port=!urgent_valid && !parameter_valid && !jump_valid && !head_valid && !priority_offer;
    wire audition_accept=story_port && audition_valid && remote_ready;
    wire confirm_accept=story_port && !audition_valid && confirm_pending && !audition_offer && remote_ready;
    always @*begin
        remote_valid=urgent_valid || parameter_valid || jump_valid || (head_valid && !priority_offer) ||
            (story_port && (audition_valid || (confirm_pending && !audition_offer)));
        {remote_cmd,remote_arg}=urgent_valid?urgent_value:
            parameter_valid?parameter_value:jump_valid?jump_value:head_valid?head_value:
            audition_valid?{audition_cmd,8'd0}:16'h1200;
    end
    wire command_accept=remote_valid && remote_ready;
    wire command_pop=command_accept && !urgent_valid && !parameter_valid && !jump_valid && head_valid;
    wire command_push=packet_push && !packet_urgent && !packet_parameter && !jump_offer && !audition_offer && !confirm_offer &&
        (command_count<8 || command_pop);
    always @(posedge clk or posedge rst)begin
        if(rst)begin urgent_valid<=0;urgent_value<=0;end
        else begin
            if(urgent_accept)urgent_valid<=0;
            if(urgent_push)begin urgent_valid<=1;urgent_value<=packet_value;end
        end
    end
    // A held output transaction never changes while backpressured. New writes
    // update the corresponding pending slot, and round-robin scans every slot.
    always @(posedge clk or posedge rst)begin
        if(rst)begin parameter_valid<=0;parameter_value<=0;parameter_dirty<=0;parameter_scan<=0;end
        else if(urgent_reset)begin parameter_valid<=0;parameter_dirty<=0;parameter_scan<=0;end
        else begin
            if(parameter_accept)parameter_valid<=0;
            if(!parameter_valid)begin
                parameter_scan<=parameter_scan==5?0:parameter_scan+1'b1;
                if(parameter_dirty[parameter_scan])begin
                    parameter_valid<=1;
                    parameter_value<={parameter_scan<3 ? 8'h25+{5'd0,parameter_scan} : 8'h2d+{5'd0,parameter_scan},parameter_latest[parameter_scan]};
                    parameter_dirty[parameter_scan]<=0;
                end
            end
            if(parameter_offer)begin
                parameter_latest[parameter_write_slot]<=packet_value[7:0];
                parameter_dirty[parameter_write_slot]<=1;
            end
        end
    end
    always @(posedge clk or posedge rst)begin
        if(rst)begin jump_valid<=0;jump_value<=0;end
        else if(urgent_context)jump_valid<=0;
        else begin
            if(jump_accept)jump_valid<=0;
            if(jump_offer)begin jump_valid<=1;jump_value<=packet_value;end
        end
    end
    // Choices/replay are latest intent, not an unbounded sequence of touches.
    // Confirm follows the newest audition. A later choice cancels an older
    // confirmation; a replay after a pending A/B retains that unplayed choice.
    always @(posedge clk or posedge rst)begin
        if(rst)begin audition_valid<=0;audition_cmd<=8'h10;confirm_pending<=0;end
        else if(urgent_context || jump_offer)begin audition_valid<=0;confirm_pending<=0;end
        else begin
            if(audition_accept)audition_valid<=0;
            if(confirm_accept)confirm_pending<=0;
            if(confirm_offer)confirm_pending<=1;
            if(audition_offer)begin
                audition_valid<=1;confirm_pending<=0;
                if(packet_value[15:8]!=8'h13 || !audition_valid || audition_accept)
                    audition_cmd<=packet_value[15:8];
            end
        end
    end
    wire [2:0] next_read_ptr=read_ptr+1'b1;
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            read_ptr<=0;write_ptr<=0;command_count<=0;head_valid<=0;head_value<=0;
        end else if(urgent_context || jump_offer)begin
            read_ptr<=0;write_ptr<=0;command_count<=0;head_valid<=0;head_value<=0;
        end else begin
            if(command_push)begin command_fifo[write_ptr]<=packet_value;write_ptr<=write_ptr+1'b1;end
            if(command_pop)read_ptr<=next_read_ptr;
            case({command_push,command_pop})
                2'b10:command_count<=command_count+1'b1;
                2'b01:command_count<=command_count-1'b1;
            endcase
            if(command_pop)begin
                if(command_count>1)begin head_value<=command_fifo[next_read_ptr];head_valid<=1;end
                else if(command_push)begin head_value<=packet_value;head_valid<=1;end
                else head_valid<=0;
            end else if(!head_valid && command_push)begin head_value<=packet_value;head_valid<=1;end
        end
    end
    localparam integer PACKET_GAP=DIV*480;
    localparam integer GAP_W=$clog2(PACKET_GAP+1);
    reg [GAP_W-1:0] packet_gap;
    reg [2:0] packet_state;
    // No query or reply gates reception. The first valid command after reset
    // enters the same held/ordered command paths as every later command.
    reg [7:0] packet_cmd,packet_arg;
    wire command_known=(packet_cmd>=1 && packet_cmd<=5) ||
        (packet_cmd>=8'h10 && packet_cmd<=8'h13) ||
        (EXTENDED_SETTINGS && packet_cmd>=8'h30 && packet_cmd<=8'h32) || packet_cmd==8'h20 || (packet_cmd>=8'h25 && packet_cmd<=8'h27) ||
        (packet_cmd>=8'h29 && packet_cmd<=8'h2d);
    wire argument_valid=(packet_cmd!=4 || packet_arg<8) &&
        (packet_cmd!=5 || packet_arg<=1) &&
        ((packet_cmd<8'h25 || packet_cmd>8'h27) || packet_arg<=100) &&
        (packet_cmd!=8'h29 || packet_arg<=1) &&
        (packet_cmd!=8'h2a || packet_arg<=5) &&
        (packet_cmd!=8'h2b || packet_arg<=9) &&
        (packet_cmd!=8'h2c || packet_arg==0) &&
        (packet_cmd!=8'h2d || packet_arg<=4) && (packet_cmd!=8'h30 || packet_arg<=4) &&
        ((packet_cmd!=8'h31 && packet_cmd!=8'h32) || packet_arg<=100);
    always @(posedge clk or posedge rst)begin
        if(rst)begin packet_state<=0;packet_cmd<=0;packet_arg<=0;packet_gap<=0;packet_push<=0;packet_value<=0;end
        else begin
            packet_push<=0;
            if(packet_state==0 || rx_valid || rx_bad)packet_gap<=0;
            else if(packet_gap<PACKET_GAP)packet_gap<=packet_gap+1'b1;
            if(rx_bad)packet_state<=0;
            else if(!rx_valid && packet_state!=0 && packet_gap==PACKET_GAP)packet_state<=0;
            else if(rx_valid)begin
                case(packet_state)
                    0:if(rx_byte==8'ha5)packet_state<=1;
                    1:begin packet_cmd<=rx_byte;packet_state<=2;end
                    2:begin packet_arg<=rx_byte;packet_state<=3;end
                    3:if(rx_byte==(8'ha5^packet_cmd^packet_arg))packet_state<=4;
                      else packet_state<=(rx_byte==8'ha5)?1:0;
                    4:begin
                        packet_state<=(rx_byte==8'ha5)?1:0;
                        if(rx_byte==8'h5a && command_known && argument_valid)begin
                            packet_value<={packet_cmd,packet_arg};packet_push<=1;
                        end
                    end
                    default:packet_state<=0;
                endcase
            end
        end
    end
    assign tx=1'b1;
    initial if(DIV<8)begin $display("TJC_UART_CONFIG_ERROR");$finish;end
endmodule
