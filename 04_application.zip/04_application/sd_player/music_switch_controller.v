`timescale 1ns/1ps
// Stop both storage and PCM FIFO, wait for their explicit drain acknowledgments,
// then change the held catalog selection. Late old responses cannot become new.
module music_switch_controller #(parameter integer PREVIOUS_ENABLE=0, TRACK_COUNT=3, INDEX_BITS=2, DIRECT_ENABLE=0, DIRECT_ONLY=0, RESTART_ENABLE=0)(
    input clk,input rst,input next_music,
    input [TRACK_COUNT-1:0] valid_mask,
    input player_idle,input storage_idle,
    output reg [INDEX_BITS-1:0] music_index,output reg music_stop,input previous_music, input direct_valid, input [INDEX_BITS-1:0] direct_index,input direct_restart
);
    wire restart_event=RESTART_ENABLE!=0 && direct_restart;
    localparam RUN=0,STOP=1,SELECT=2,RELEASE=3;
    reg [1:0] state;
    reg [INDEX_BITS-1:0] target;
    wire direct_event=DIRECT_ENABLE!=0 && direct_valid && direct_index<TRACK_COUNT &&
        (DIRECT_ONLY!=0 || valid_mask[direct_index]);
    function [INDEX_BITS-1:0] following;
        input [INDEX_BITS-1:0] current; input [TRACK_COUNT-1:0] mask;
        integer k;
        begin
            // Fixed mask taps avoid one variable-index mux per candidate.
            // First choose the lowest valid wrap target, then the lowest
            // valid entry strictly above current, when one exists.
            following=current;
            for(k=TRACK_COUNT-1;k>=0;k=k-1)
                if(mask[k]) following=k;
            for(k=TRACK_COUNT-1;k>=0;k=k-1)
                if(mask[k] && current<k) following=k;
        end
    endfunction
    wire previous_event=PREVIOUS_ENABLE!=0 && previous_music;
    function [INDEX_BITS-1:0] preceding;
        input [INDEX_BITS-1:0] current; input [TRACK_COUNT-1:0] mask;
        integer k;
        begin
            preceding=current;
            for(k=0;k<TRACK_COUNT;k=k+1)
                if(mask[k]) preceding=k;
            for(k=0;k<TRACK_COUNT;k=k+1)
                if(mask[k] && current>k) preceding=k;
        end
    endfunction
    wire [INDEX_BITS-1:0] navigation_origin =
        (state==STOP || state==SELECT) ? target : music_index;
    wire [INDEX_BITS-1:0] next_target=following(navigation_origin,valid_mask);
    wire [INDEX_BITS-1:0] previous_target=preceding(navigation_origin,valid_mask);
    generate if(DIRECT_ONLY!=0)begin: g_scene_only
        // A chapter owns its catalog index even when its PCM is absent. The
        // caller uses music_present to produce silence; never substitute a
        // different chapter's music and never retain the previous song.
        always @(posedge clk or posedge rst)begin
            if(rst)begin state<=RUN;music_index<=0;target<=0;music_stop<=0;end
            else case(state)
                RUN:if(direct_event && (direct_index!=music_index || restart_event))begin
                    target<=direct_index;music_stop<=1;state<=STOP;
                end
                STOP:begin
                    // Same-target repeats do not delay a completed drain.
                    if(direct_event && direct_index!=target)target<=direct_index;
                    else if(player_idle && storage_idle)state<=SELECT;
                end
                SELECT:begin
                    if(direct_event && direct_index!=target)target<=direct_index;
                    else begin music_index<=target;state<=RELEASE;end
                end
                RELEASE:begin
                    if(direct_event && (direct_index!=music_index || restart_event))begin
                        target<=direct_index;music_stop<=1;state<=STOP;
                    end else begin music_stop<=0;state<=RUN;end
                end
                default:begin music_stop<=1;state<=STOP;end
            endcase
        end
    end else begin: g_legacy
    always @(posedge clk or posedge rst) begin
        if(rst) begin state<=RUN;music_index<=0;target<=0;music_stop<=0;end
        else case(state)
            RUN:if(valid_mask!=0 && (!valid_mask[music_index] || next_music || previous_event || (direct_event && (direct_index!=music_index || restart_event)))) begin
                target<=direct_event ? direct_index : previous_event && !next_music ? previous_target : next_target;
                music_stop<=1;state<=STOP;
            end
            STOP:begin
                if(direct_event) target<=direct_index;
                else if(next_music) target<=next_target;
                else if(previous_event) target<=previous_target;
                else if(player_idle && storage_idle) state<=SELECT;
            end
            SELECT:begin
                // A debounced command can arrive on either drain-completion
                // cycle. Keep the player stopped until every queued direction
                // has been folded into the held target; never drop this pulse.
                if(direct_event) target<=direct_index;
                else if(next_music) target<=next_target;
                else if(previous_event) target<=previous_target;
                else begin music_index<=target;state<=RELEASE;end
            end
            RELEASE:begin
                if(next_music || previous_event || direct_event) begin
                    target<=direct_event ? direct_index : next_music ? next_target : previous_target;
                    music_stop<=1;state<=STOP;
                end else begin music_stop<=0;state<=RUN;end
            end
            default:begin music_stop<=1;state<=STOP;end
        endcase
    end
    end endgenerate
endmodule
