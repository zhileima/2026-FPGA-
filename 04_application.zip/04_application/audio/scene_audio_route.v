`timescale 1ns/1ps
// Reserve the animal track at request acceptance, before the ordinary WAV
// read-domain transaction can report its own stable session. The STOP/SELECT
// handshake distinguishes a fresh prefill from the previous audition's FIFO.
module audition_reservation (
    input wire clk, rst, eligible, request, music_stop, target_selected,
    input wire prefill_ready, terminal_error,
    output reg pending
);
    reg stop_seen;
    always @(posedge clk or posedge rst) begin
        if(rst) begin pending<=0;stop_seen<=0;end
        else if(!eligible) begin pending<=0;stop_seen<=0;end
        else if(request) begin pending<=1;stop_seen<=music_stop;end
        else if(pending && music_stop) stop_seen<=1;
        else if(pending && stop_seen && target_selected && (prefill_ready || terminal_error)) begin
            pending<=0;stop_seen<=0;
        end
    end
endmodule

// Select one source per accepted HDMI sample. Holding the animal FIFO while a
// cue owns the output preserves the first sample and resumes at its successor.
module scene_audio_route (
    input wire clk, rst, normal_audio,
    input wire visible_origin, input wire [5:0] visible_meta,
    input wire reader_start, reader_end, input wire [2:0] reader_chapter,
    input wire sample_tick, pcm_tap_valid,
    input wire audition_pending, wav_session, wav_valid,
    input wire [3:0] animal_track,
    input wire signed [15:0] faded_animal,
    input wire sfx_active, input wire signed [15:0] sfx_sample,
    input wire [2:0] cue_id, input wire cue_toggle,
    output wire animal_consume, output wire music_ready, output reg signed [15:0] sample,
    output wire visual_source_change
);
    reg page_valid;
    reg [3:0] page;
    wire [3:0] seen_page=visible_meta[5] ? 4'd9 : visible_meta[4] ? 4'd8 : {1'b0,visible_meta[3:1]};
    always @(posedge clk or posedge rst) begin
        if(rst) begin page_valid<=0;page<=8;end
        else if(visible_origin && !visible_meta[0]) begin page_valid<=1;page<=seen_page;end
        else if(page_valid && page==9 && !reader_end)page_valid<=0;
    end

    // Animal identity belongs to the real reader transaction, including while
    // a menu covers the page. A settings overlay cannot stall the animal FIFO.
    wire same_chapter=animal_track[3:1]==reader_chapter && !reader_start && !reader_end;
    // Keep the last fully shown idle arrangement across a crossfade or menu.
    // A one-shot ending must stop promptly when its physical page is left.
    wire score_enabled=page_valid && normal_audio && (page!=9 || reader_end);
    assign music_ready=score_enabled;
    wire animal_owned=normal_audio && !reader_end && !reader_start && (audition_pending || wav_session);
    // Track the actual FIFO transaction epoch, not a frame-delayed A/B UI
    // label. A replay of the same A track also starts a fresh visual history.
    reg was_session,session_epoch;
    always @(posedge clk or posedge rst) begin
        if(rst)begin was_session<=0;session_epoch<=0;end
        else begin
            was_session<=wav_session;
            if(wav_session && !was_session)session_epoch<=~session_epoch;
        end
    end
    wire signed [15:0] music_sample;
    scene_music u_scene_music(.clk(clk),.rst(rst),.page_enabled(score_enabled),.page_id(page),
        .sample_tick(sample_tick && !sfx_active && !animal_owned),.sample(music_sample));
    assign animal_consume=sample_tick && normal_audio && same_chapter && !sfx_active && !audition_pending && wav_session;

    reg [6:0] source_tag;
    always @* begin
        source_tag=7'h70;sample=0;
        if(sfx_active) begin
            source_tag={2'b10,1'b0,cue_toggle,cue_id};sample=sfx_sample;
        end else if(animal_owned) begin
            source_tag={2'b01,session_epoch,reader_chapter,1'b0};
            if(same_chapter && !audition_pending && wav_valid) sample=faded_animal;
        end else if(score_enabled) begin
            source_tag={2'b00,1'b0,page};sample=music_sample;
        end else if(!normal_audio && !reader_start && !reader_end) begin
            source_tag=7'h60;sample=faded_animal;
        end
    end
    // lesson3_pcm_source registers a sample and its gain on sample_tick.
    // Advance its tag at that same acceptance, and publish only at the real
    // post-volume PCM tap handshake, including backpressure and zero samples.
    reg [6:0] accepted_tag, last_published_tag;
    always @(posedge clk or posedge rst) begin
        if(rst) begin accepted_tag<=7'h70;last_published_tag<=7'h70;end
        else begin
            if(sample_tick) accepted_tag<=source_tag;
            if(pcm_tap_valid) last_published_tag<=accepted_tag;
        end
    end
    assign visual_source_change=pcm_tap_valid && accepted_tag!=last_published_tag;
endmodule
