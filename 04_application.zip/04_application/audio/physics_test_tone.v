`timescale 1ns/1ps
module physics_test_tone(
    input wire clk, input wire rst, input wire enable, input wire sample_tick,
    output wire signed [15:0] sample
);
    reg [23:0] phase;
    reg signed [15:0] sine;
    always @(posedge clk or posedge rst) begin
        if(rst) phase<=0;
        else if(!enable) phase<=0;
        else if(sample_tick) phase<=phase+24'd153791;
    end
    always @* begin
        case(phase[23:18])
            6'd0:sine=16'sh0000;
            6'd1:sine=16'sh0323;
            6'd2:sine=16'sh063e;
            6'd3:sine=16'sh094a;
            6'd4:sine=16'sh0c3f;
            6'd5:sine=16'sh0f15;
            6'd6:sine=16'sh11c7;
            6'd7:sine=16'sh144c;
            6'd8:sine=16'sh16a0;
            6'd9:sine=16'sh18bc;
            6'd10:sine=16'sh1a9b;
            6'd11:sine=16'sh1c38;
            6'd12:sine=16'sh1d8f;
            6'd13:sine=16'sh1e9e;
            6'd14:sine=16'sh1f62;
            6'd15:sine=16'sh1fd8;
            6'd16:sine=16'sh1fff;
            6'd17:sine=16'sh1fd8;
            6'd18:sine=16'sh1f62;
            6'd19:sine=16'sh1e9e;
            6'd20:sine=16'sh1d8f;
            6'd21:sine=16'sh1c38;
            6'd22:sine=16'sh1a9b;
            6'd23:sine=16'sh18bc;
            6'd24:sine=16'sh16a0;
            6'd25:sine=16'sh144c;
            6'd26:sine=16'sh11c7;
            6'd27:sine=16'sh0f15;
            6'd28:sine=16'sh0c3f;
            6'd29:sine=16'sh094a;
            6'd30:sine=16'sh063e;
            6'd31:sine=16'sh0323;
            6'd32:sine=16'sh0000;
            6'd33:sine=16'shfcdd;
            6'd34:sine=16'shf9c2;
            6'd35:sine=16'shf6b6;
            6'd36:sine=16'shf3c1;
            6'd37:sine=16'shf0eb;
            6'd38:sine=16'shee39;
            6'd39:sine=16'shebb4;
            6'd40:sine=16'she960;
            6'd41:sine=16'she744;
            6'd42:sine=16'she565;
            6'd43:sine=16'she3c8;
            6'd44:sine=16'she271;
            6'd45:sine=16'she162;
            6'd46:sine=16'she09e;
            6'd47:sine=16'she028;
            6'd48:sine=16'she001;
            6'd49:sine=16'she028;
            6'd50:sine=16'she09e;
            6'd51:sine=16'she162;
            6'd52:sine=16'she271;
            6'd53:sine=16'she3c8;
            6'd54:sine=16'she565;
            6'd55:sine=16'she744;
            6'd56:sine=16'she960;
            6'd57:sine=16'shebb4;
            6'd58:sine=16'shee39;
            6'd59:sine=16'shf0eb;
            6'd60:sine=16'shf3c1;
            6'd61:sine=16'shf6b6;
            6'd62:sine=16'shf9c2;
            6'd63:sine=16'shfcdd;
            default:sine=0;
        endcase
    end
    assign sample=enable?sine:16'sd0;
endmodule
