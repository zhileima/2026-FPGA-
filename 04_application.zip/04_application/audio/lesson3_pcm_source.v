`timescale 1ns/1ps

// Pixel-clock PCM source. The rate accumulator produces an exact average
// SAMPLE_HZ cadence; 25 MHz / 48 kHz therefore alternates 520/521 clocks.
// Source 0 = DDS test sine, 1 = image-linked melody, 2 = external PCM stream.
// Control changes ramp to zero before changing the source/media epoch.
// A pending output is NEVER changed while valid && !ready. Backpressure can
// lose real-time samples and is explicitly reported; there is no stale FIFO.
module lesson3_pcm_source #(
    parameter integer CLOCK_HZ = 25000000,
    parameter integer SAMPLE_HZ = 48000,
    parameter integer TEST_HZ = 440,
    parameter integer RAMP_SAMPLES = 256,
    parameter integer BLIP_HZ = 2000,
    parameter integer BLIP_SAMPLES = (SAMPLE_HZ * 3) / 10,
    parameter integer CUE_ON_COMMIT = 0,
    // 0 = original dual-burst cue, 1 = water drop, 2 = short keyboard keystroke.
    parameter integer CUE_STYLE = 0,
    parameter integer CUE_GAP_SAMPLES = SAMPLE_HZ / 25,
    parameter integer CUE_GAIN_SHIFT = 1,
    parameter integer NOTE_SAMPLES = SAMPLE_HZ / 4,
    parameter integer EXTERNAL_ONLY = 0
) (
    input wire clk,
    input wire rst_n,
    input wire enable,
    input wire [1:0] source_select,
    input wire [7:0] volume,
    input wire mute,
    input wire cue_trigger,
    input wire media_commit,
    input wire [1:0] media_id,
    input wire external_valid,
    output wire external_ready,
    input wire signed [15:0] external_left,
    input wire signed [15:0] external_right,
    output reg sample_valid,
    input wire sample_ready,
    output reg signed [15:0] sample_left,
    output reg signed [15:0] sample_right,
    output wire sample_tick,
    output reg overflow,
    output reg underrun,
    output wire blip_active,
    output reg [2:0] note_index,
    output reg [1:0] active_media_id,
    output reg [1:0] active_source
);
    localparam integer RATE_WIDTH = $clog2(CLOCK_HZ + 1);
    localparam integer NOTE_WIDTH = (NOTE_SAMPLES <= 1) ? 1 : $clog2(NOTE_SAMPLES);
    localparam integer BLIP_WIDTH = (BLIP_SAMPLES <= 1) ? 1 : $clog2(BLIP_SAMPLES + 1);
    localparam [1:0] RUN = 0, FADE_OUT = 1, FADE_IN = 2;
    localparam integer CUE_FIRST_SAMPLES = (BLIP_SAMPLES-CUE_GAP_SAMPLES)/2;
    // The explicit reference compatibility mode keeps the former continuous
    // commit-triggered cue. Production selects a button-triggered cue style.
    localparam integer LEGACY_CUE = CUE_ON_COMMIT != 0 &&
                                   CUE_GAP_SAMPLES == 0 && CUE_GAIN_SHIFT == 0;
    // Constant division is elaborated by the synthesis tool, not runtime logic.
    localparam [19:0] TEST_INC = (64'd1048576 * TEST_HZ + SAMPLE_HZ/2) / SAMPLE_HZ;
    localparam [19:0] BLIP_INC = (64'd1048576 * BLIP_HZ + SAMPLE_HZ/2) / SAMPLE_HZ;
    reg [RATE_WIDTH-1:0] rate_accumulator;
    reg [19:0] phase;
    localparam [19:0] DROP_END_INC = (64'd1048576 * 650 + SAMPLE_HZ/2) / SAMPLE_HZ;
    reg [19:0] drop_inc;
    wire [20:0] drop_delta = {1'b0,drop_inc}-{1'b0,DROP_END_INC};
    wire [20:0] drop_decrement = (drop_delta+21'd255)>>8;
    reg [NOTE_WIDTH-1:0] note_count;
    reg [BLIP_WIDTH-1:0] blip_count;
    reg [15:0] gain; // Q8.8: volume 96 means 96/256 amplitude after scaling.
    // External-only production path: one integer gain step per accepted
    // sample gives a bounded 5.32 ms full-scale ramp at 48 kHz. The low Q8
    // fractional bits and source/cue switching envelope are unnecessary here.
    reg [7:0] external_gain;
    wire [7:0] external_target=(!enable || mute) ? 8'd0 : volume;
    wire signed [24:0] external_scaled_left=external_left*$signed({1'b0,external_gain});
    wire signed [24:0] external_scaled_right=external_right*$signed({1'b0,external_gain});
    wire [16:0] drop_decay = ({1'b0,gain}+17'd511)>>9;
    // A deterministic, broadband key impact plus a small mechanical resonance.
    // The existing gain multipliers provide the envelope; no PCM ROM is needed.
    reg [15:0] click_noise;
    wire [16:0] click_decay = ({1'b0,gain}+17'd127)>>7;
    reg [15:0] fade_step;
    reg [1:0] envelope_state;
    reg [1:0] requested_source;
    reg [1:0] requested_media;
    reg pending_switch;
    reg pending_blip;
    reg cue_trigger_q;
    wire [15:0] target_gain = (!enable || mute) ? 16'd0 : {volume,8'd0};
    wire output_slot = !sample_valid || sample_ready;
    wire cue_event = cue_trigger && !cue_trigger_q && enable;
    wire [31:0] cue_elapsed = BLIP_SAMPLES - blip_count;
    wire cue_release = !LEGACY_CUE && blip_count != 0 &&
        (blip_count <= RAMP_SAMPLES || (CUE_GAP_SAMPLES != 0 &&
         cue_elapsed >= CUE_FIRST_SAMPLES-RAMP_SAMPLES &&
         cue_elapsed < CUE_FIRST_SAMPLES+CUE_GAP_SAMPLES));
    wire [15:0] cue_target_gain = cue_release ? 16'd0 : target_gain;
    assign sample_tick = rate_accumulator >= CLOCK_HZ - SAMPLE_HZ;
    // Keep accepting the old external stream during fade-out, until gain is
    // zero. Dropping it immediately would defeat the click-prevention ramp.
    assign external_ready = EXTERNAL_ONLY!=0 ?
                            sample_tick && output_slot && (enable || external_gain!=0) :
                            sample_tick && output_slot && (enable || gain != 0) &&
                            active_source == 2 && blip_count == 0;
    assign blip_active = EXTERNAL_ONLY!=0 ? 1'b0 : blip_count != 0;

    function [15:0] ramp_step;
        input [15:0] from_gain;
        reg [31:0] value;
        begin
            value = (from_gain + RAMP_SAMPLES - 1) / RAMP_SAMPLES;
            ramp_step = (value == 0) ? 16'd1 : value[15:0];
        end
    endfunction

    function [19:0] melody_inc;
        input [1:0] melody;
        input [2:0] note;
        begin
            case ({melody,note})
                5'b00_000,5'b01_001,5'b01_101,5'b10_000,5'b11_000,5'b11_011:
                    melody_inc = (64'd1048576 * 523 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b00_001,5'b00_101,5'b01_010,5'b01_100,5'b10_010,5'b11_010,5'b11_101:
                    melody_inc = (64'd1048576 * 659 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b00_010,5'b00_100,5'b10_011:
                    melody_inc = (64'd1048576 * 784 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b00_011,5'b10_101:
                    melody_inc = (64'd1048576 * 1046 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b01_000: melody_inc = (64'd1048576 * 440 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b01_011,5'b10_100: melody_inc = (64'd1048576 * 880 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b10_001: melody_inc = (64'd1048576 * 587 + SAMPLE_HZ/2) / SAMPLE_HZ;
                5'b11_001,5'b11_100: melody_inc = (64'd1048576 * 392 + SAMPLE_HZ/2) / SAMPLE_HZ;
                default: melody_inc = (64'd1048576 * 523 + SAMPLE_HZ/2) / SAMPLE_HZ;
            endcase
        end
    endfunction

    function [15:0] click_attack_step;
        input [15:0] from_gain;
        reg [16:0] value;
        begin
            value = ({1'b0,from_gain}+17'd15)>>4;
            click_attack_step = (value == 0) ? 16'd1 : value[15:0];
        end
    endfunction

    function signed [15:0] sine_sample;
        input [3:0] index;
        begin
            case (index)
                0,8: sine_sample = 0;
                1,7: sine_sample = 4592;
                2,6: sine_sample = 8485;
                3,5: sine_sample = 11087;
                4: sine_sample = 12000;
                9,15: sine_sample = -4592;
                10,14: sine_sample = -8485;
                11,13: sine_sample = -11087;
                default: sine_sample = -12000;
            endcase
        end
    endfunction

    // Short descending bubble resonance, 64 phase points. No sample buffer
    // and no extra multiplier; the existing PCM gain stage supplies envelope.
    function signed [15:0] drop_sine;
        input [5:0] index;
        begin
            case(index)
                6'd0: drop_sine = 16'sd0;
                6'd1: drop_sine = 16'sd1372;
                6'd2: drop_sine = 16'sd2731;
                6'd3: drop_sine = 16'sd4064;
                6'd4: drop_sine = 16'sd5358;
                6'd5: drop_sine = 16'sd6600;
                6'd6: drop_sine = 16'sd7778;
                6'd7: drop_sine = 16'sd8882;
                6'd8: drop_sine = 16'sd9899;
                6'd9: drop_sine = 16'sd10822;
                6'd10: drop_sine = 16'sd11641;
                6'd11: drop_sine = 16'sd12347;
                6'd12: drop_sine = 16'sd12934;
                6'd13: drop_sine = 16'sd13397;
                6'd14: drop_sine = 16'sd13731;
                6'd15: drop_sine = 16'sd13933;
                6'd16: drop_sine = 16'sd14000;
                6'd17: drop_sine = 16'sd13933;
                6'd18: drop_sine = 16'sd13731;
                6'd19: drop_sine = 16'sd13397;
                6'd20: drop_sine = 16'sd12934;
                6'd21: drop_sine = 16'sd12347;
                6'd22: drop_sine = 16'sd11641;
                6'd23: drop_sine = 16'sd10822;
                6'd24: drop_sine = 16'sd9899;
                6'd25: drop_sine = 16'sd8882;
                6'd26: drop_sine = 16'sd7778;
                6'd27: drop_sine = 16'sd6600;
                6'd28: drop_sine = 16'sd5358;
                6'd29: drop_sine = 16'sd4064;
                6'd30: drop_sine = 16'sd2731;
                6'd31: drop_sine = 16'sd1372;
                6'd32: drop_sine = 16'sd0;
                6'd33: drop_sine = -16'sd1372;
                6'd34: drop_sine = -16'sd2731;
                6'd35: drop_sine = -16'sd4064;
                6'd36: drop_sine = -16'sd5358;
                6'd37: drop_sine = -16'sd6600;
                6'd38: drop_sine = -16'sd7778;
                6'd39: drop_sine = -16'sd8882;
                6'd40: drop_sine = -16'sd9899;
                6'd41: drop_sine = -16'sd10822;
                6'd42: drop_sine = -16'sd11641;
                6'd43: drop_sine = -16'sd12347;
                6'd44: drop_sine = -16'sd12934;
                6'd45: drop_sine = -16'sd13397;
                6'd46: drop_sine = -16'sd13731;
                6'd47: drop_sine = -16'sd13933;
                6'd48: drop_sine = -16'sd14000;
                6'd49: drop_sine = -16'sd13933;
                6'd50: drop_sine = -16'sd13731;
                6'd51: drop_sine = -16'sd13397;
                6'd52: drop_sine = -16'sd12934;
                6'd53: drop_sine = -16'sd12347;
                6'd54: drop_sine = -16'sd11641;
                6'd55: drop_sine = -16'sd10822;
                6'd56: drop_sine = -16'sd9899;
                6'd57: drop_sine = -16'sd8882;
                6'd58: drop_sine = -16'sd7778;
                6'd59: drop_sine = -16'sd6600;
                6'd60: drop_sine = -16'sd5358;
                6'd61: drop_sine = -16'sd4064;
                6'd62: drop_sine = -16'sd2731;
                6'd63: drop_sine = -16'sd1372;
                default: drop_sine=0;
            endcase
        end
    endfunction

    wire signed [15:0] click_noise_signed = $signed(click_noise);
    wire signed [15:0] click_resonance = drop_sine(phase[19:14]);
    // Full texture for the first 2ms, then a quieter, damped key body. Both
    // terms are shifted before addition, so the sum cannot overflow int16.
    wire signed [15:0] click_sample =
        (cue_elapsed < SAMPLE_HZ/500 ? (click_noise_signed >>> 2) :
                                      (click_noise_signed >>> 3)) +
        (click_resonance >>> 2);
    wire signed [15:0] cue_raw = CUE_STYLE == 2 ? click_sample :
        (CUE_STYLE == 1 ? drop_sine(phase[19:14]) : sine_sample(phase[19:16]));
    wire [19:0] phase_inc = blip_count != 0 ? (CUE_STYLE == 1 ? drop_inc : BLIP_INC) :
                           (active_source == 0 ? TEST_INC : melody_inc(active_media_id,note_index));
    wire signed [15:0] raw_left = active_source == 2 && blip_count == 0 ?
        (external_valid && external_ready ? external_left : 16'sd0) :
        (blip_count != 0 ? cue_raw : sine_sample(phase[19:16]));
    wire signed [15:0] raw_right = active_source == 2 && blip_count == 0 ?
        (external_valid && external_ready ? external_right : 16'sd0) :
        (blip_count != 0 ? cue_raw : sine_sample(phase[19:16]));
    wire signed [32:0] scaled_left = raw_left * $signed({1'b0,gain});
    wire signed [32:0] scaled_right = raw_right * $signed({1'b0,gain});
    wire signed [35:0] cue_scaled_left = (scaled_left <<< CUE_GAIN_SHIFT) >>> 16;
    wire signed [35:0] cue_scaled_right = (scaled_right <<< CUE_GAIN_SHIFT) >>> 16;
    function signed [15:0] clamp_pcm;
        input signed [35:0] value;
        begin
            if (value > 32767) clamp_pcm = 32767;
            else if (value < -32768) clamp_pcm = -32768;
            else clamp_pcm = value[15:0];
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rate_accumulator <= 0;
            phase <= 0;
            drop_inc <= BLIP_INC;
            click_noise <= 16'hACE1;
            note_count <= 0;
            blip_count <= 0;
            gain <= 0;
            fade_step <= 1;
            envelope_state <= RUN;
            requested_source <= EXTERNAL_ONLY!=0 ? 2 : 1;
            requested_media <= 0;
            pending_switch <= 0;
            pending_blip <= 0;
            cue_trigger_q <= 0;
            active_source <= EXTERNAL_ONLY!=0 ? 2 : 1;
            active_media_id <= 0;
            note_index <= 0;
            sample_valid <= 0;
            sample_left <= 0;
            sample_right <= 0;
            overflow <= 0;
            underrun <= 0;
            external_gain <= 0;
        end else if(EXTERNAL_ONLY!=0) begin
            if(sample_tick)rate_accumulator<=rate_accumulator+SAMPLE_HZ-CLOCK_HZ;
            else rate_accumulator<=rate_accumulator+SAMPLE_HZ;
            if(sample_valid && sample_ready)sample_valid<=0;
            if(sample_tick)begin
                if(output_slot)begin
                    sample_valid<=1;
                    sample_left<=external_valid ? external_scaled_left>>>8 : 16'sd0;
                    sample_right<=external_valid ? external_scaled_right>>>8 : 16'sd0;
                    if(external_gain<external_target)external_gain<=external_gain+1'b1;
                    else if(external_gain>external_target)external_gain<=external_gain-1'b1;
                    if(enable && !mute && !external_valid)underrun<=1;
                end else overflow<=1;
            end
        end else begin
            cue_trigger_q <= cue_trigger;
            if (sample_tick)
                rate_accumulator <= rate_accumulator + SAMPLE_HZ - CLOCK_HZ;
            else
                rate_accumulator <= rate_accumulator + SAMPLE_HZ;

            if (sample_valid && sample_ready)
                sample_valid <= 0;

            if (sample_tick) begin
                if (output_slot) begin
                    sample_valid <= 1;
                    sample_left <= blip_count != 0 ? clamp_pcm(cue_scaled_left) : scaled_left >>> 16;
                    sample_right <= blip_count != 0 ? clamp_pcm(cue_scaled_right) : scaled_right >>> 16;
                    if (active_source == 2 && blip_count == 0 && enable && !external_valid && !pending_switch && envelope_state != FADE_OUT)
                        underrun <= 1;
                end else overflow <= 1;

                phase <= phase + phase_inc;
                if (CUE_STYLE == 2 && blip_count != 0)
                    click_noise <= {click_noise[14:0],click_noise[15] ^
                                    click_noise[13] ^ click_noise[12] ^ click_noise[10]};
                if (CUE_STYLE == 1) begin
                    if (blip_count == 0) drop_inc <= BLIP_INC;
                    else if (drop_inc > DROP_END_INC)
                        drop_inc <= drop_delta <= drop_decrement ? DROP_END_INC : drop_inc-drop_decrement;
                end
                if (blip_count != 0) begin
                    blip_count <= blip_count - 1'b1;
                    if (blip_count == 1 && !LEGACY_CUE) begin
                        phase <= 0;
                        note_count <= 0;
                        note_index <= 0;
                    end
                end else if (active_source == 1) begin
                    if (note_count == NOTE_SAMPLES-1) begin
                        note_count <= 0;
                        note_index <= note_index == 5 ? 0 : note_index + 1'b1;
                    end else note_count <= note_count + 1'b1;
                end

                // Ramps and epoch commits advance only when this sample can
                // actually enter the output stream. A long stall cannot skip
                // an entire fade while an old high-amplitude sample is held.
                // The clock/phase/note timers remain real-time; overflow still
                // reports lost ticks, so abnormal stalls are not click-free.
                if (output_slot) begin
                if (blip_count != 0 && envelope_state != FADE_OUT) begin
                    // Picture commits update only the selected melody during
                    // a cue. They do not restart or truncate its envelope.
                    // Style 0 ramps both burst edges and its central gap.
                    if (CUE_STYLE == 2 && cue_elapsed >= 16) begin
                        gain <= gain <= click_decay ? 16'd0 : gain-click_decay;
                    end else if (CUE_STYLE == 1 && cue_elapsed >= RAMP_SAMPLES) begin
                        // Smooth exponential ring-down; round up to guarantee
                        // exact zero, so the cue cannot leave a DC residue.
                        gain <= gain <= drop_decay ? 16'd0 : gain-drop_decay;
                    end else begin
                        if (gain < (CUE_STYLE != 0 ? target_gain : cue_target_gain))
                            gain <= (CUE_STYLE != 0 ? target_gain : cue_target_gain)-gain <= fade_step ?
                                (CUE_STYLE != 0 ? target_gain : cue_target_gain) : gain+fade_step;
                        else if (gain > (CUE_STYLE != 0 ? target_gain : cue_target_gain))
                            gain <= gain-(CUE_STYLE != 0 ? target_gain : cue_target_gain) <= fade_step ?
                                (CUE_STYLE != 0 ? target_gain : cue_target_gain) : gain-fade_step;
                    end
                    if (pending_switch && (pending_blip || requested_source != active_source)) begin
                        envelope_state <= FADE_OUT;
                        fade_step <= ramp_step(gain);
                    end
                    if (blip_count == 1 && !LEGACY_CUE) begin
                        gain <= 0;
                        envelope_state <= FADE_IN;
                        fade_step <= ramp_step(target_gain);
                    end
                end else begin
                case (envelope_state)
                    RUN: begin
                        // Runtime mute/volume/enable changes are also slewed.
                        if (pending_switch) begin
                            envelope_state <= FADE_OUT;
                            fade_step <= ramp_step(gain);
                        end else if (gain < target_gain)
                            gain <= target_gain-gain <= 256 ? target_gain : gain+256;
                        else if (gain > target_gain)
                            gain <= gain-target_gain <= 256 ? target_gain : gain-256;
                    end
                    FADE_OUT: begin
                        if (gain <= fade_step) begin
                            gain <= 0;
                            active_source <= requested_source;
                            active_media_id <= requested_media;
                            phase <= 0;
                            note_count <= 0;
                            note_index <= 0;
                            blip_count <= pending_blip ? BLIP_SAMPLES : 0;
                            if (CUE_STYLE == 1 && pending_blip) drop_inc <= BLIP_INC;
                            if (CUE_STYLE == 2 && pending_blip) click_noise <= 16'hACE1;
                            pending_switch <= 0;
                            pending_blip <= 0;
                            envelope_state <= FADE_IN;
                            fade_step <= CUE_STYLE == 2 && pending_blip ?
                                         click_attack_step(target_gain) : ramp_step(target_gain);
                        end else gain <= gain-fade_step;
                    end
                    default: begin
                        if (gain < target_gain)
                            gain <= target_gain-gain <= fade_step ? target_gain : gain+fade_step;
                        else if (gain > target_gain)
                            gain <= gain-target_gain <= fade_step ? target_gain : gain-fade_step;
                        if (gain == target_gain) envelope_state <= RUN;
                        if (pending_switch) begin
                            envelope_state <= FADE_OUT;
                            fade_step <= ramp_step(gain);
                        end
                    end
                endcase
                end
                end
                if (!enable && gain == 0 && !pending_switch) begin
                    phase <= 0;
                    note_count <= 0;
                    note_index <= 0;
                    blip_count <= 0;
                end
            end

            // Last assignments preserve events arriving on a sample boundary.
            if (source_select != requested_source) begin
                requested_source <= source_select;
                pending_switch <= 1;
                if (source_select == 1 && CUE_ON_COMMIT != 0) pending_blip <= 1;
            end
            if (media_commit) begin
                requested_media <= media_id;
                if (blip_count != 0 || pending_blip) begin
                    // ID changes only because of a real display commit. The
                    // current cue phase/countdown is deliberately untouched.
                    active_media_id <= media_id;
                    note_index <= 0;
                    note_count <= 0;
                end else if (source_select == 1) begin
                    pending_switch <= 1;
                    if (CUE_ON_COMMIT != 0) pending_blip <= 1;
                end
            end
            if (cue_event) begin
                pending_switch <= 1;
                pending_blip <= 1;
            end
        end
    end
endmodule
