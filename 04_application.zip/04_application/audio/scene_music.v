`timescale 1ns/1ps
// One 9K ROM contains all eight chapter motifs, the END score, three
// instrument waves and phase increments. Each original 48kHz PCM word is
// ready in twelve video clocks. The next HDMI tick is normally >500 clocks
// away. All ROM addresses are concatenations of existing small counters.
module scene_music (
    input wire clk, rst, page_enabled, input wire [3:0] page_id,
    input wire sample_tick, output reg signed [15:0] sample
);
    localparam [2:0] IDLE=0, SCORE=1, PHASE=2, WAVE=3, ACCUMULATE=4;
    reg [2:0] state;
    reg [1:0] voice;
    reg [5:0] slot;
    reg [11:0] slot_offset;
    reg [3:0] running_page;
    reg [17:0] phase[0:2];
    reg [5:0] gain[0:2], gain_pipe;
    reg restart_hold;
    (* use_dsp="yes" *) reg signed [14:0] product;
    reg signed [15:0] accumulator;
    function [3:0] tempo_block;
        input [3:0] page_id;
        begin case(page_id)
            4'd0: tempo_block=4'd15;
            4'd1: tempo_block=4'd9;
            4'd2: tempo_block=4'd15;
            4'd3: tempo_block=4'd7;
            4'd4: tempo_block=4'd13;
            4'd5: tempo_block=4'd8;
            4'd6: tempo_block=4'd11;
            4'd7: tempo_block=4'd10;
            default: tempo_block=15;
        endcase end
    endfunction
    wire [3:0] block_limit=tempo_block(running_page);
    wire [2:0] chapter=running_page[3] ? 3'd0 : running_page[2:0];
    function [8:0] score_addr;
        input [1:0] v;
        input [2:0] ch;
        input [5:0] s;
        input ending;
        begin
            if(ending)score_addr={1'b1,v,s};
            else case(v)
                0:score_addr={2'b00,ch,s[5:2]};
                1:score_addr={3'b010,ch,s[3:1]};
                default:score_addr={4'b0110,ch,s[5:4]};
            endcase
        end
    endfunction
    reg [8:0] address;
    wire [12:0] rom_word;
    scene_music_rom512 u_score_rom(.clk(clk),.address(address),.word(rom_word));
    wire first=voice==0 ? slot[1:0]==0 : voice==1 ? !slot[0] : slot[3:0]==0;
    wire last=voice==0 ? &slot[1:0] : voice==1 ? slot[0] : &slot[3:0];
    reg [5:0] idle_gain;
    always @* begin
        if(voice==0)case(slot[1:0])
            0:idle_gain=45;1:idle_gain=35;2:idle_gain=27;default:idle_gain=19;
        endcase
        else if(voice==1)idle_gain=slot[0]?20:29;
        else idle_gain=6'd32-{2'b00,slot[3:0]};
    end

    wire [12:0] instruction=running_page==9 ? rom_word : {first,last,rom_word[4:0],idle_gain};
    wire [4:0] pitch=instruction[10:6];
    wire restart_note=!pitch || (instruction[12] && slot_offset==0);
    wire [5:0] target_gain=instruction[11] && (slot_offset[11:8]>=block_limit-4'd3) ? 6'd0 : instruction[5:0];
    wire [5:0] held_gain = gain[voice];
    reg [5:0] next_gain;
    always @* begin
        next_gain = held_gain;
        if(restart_note) next_gain = 0;
        else if(slot_offset[4:0]==0) begin
            if(held_gain<target_gain)
                next_gain = held_gain+6'd1==target_gain ? target_gain : held_gain+6'd2;
            else if(held_gain>target_gain)
                next_gain = held_gain-6'd1==target_gain ? target_gain : held_gain-6'd2;
        end
    end

    wire [17:0] next_phase=restart_hold ? 18'd0 : phase[voice]+{5'd0,rom_word};
    wire signed [7:0] wave_value=$signed(rom_word[12:5]);
    wire signed [6:0] signed_gain=$signed({1'b0,gain_pipe});
    wire signed [15:0] mixed_voice=accumulator+$signed({product[14],product});
    always @* begin
        case(state)
            SCORE:address={4'b0111,pitch};
            PHASE:address={1'b0,voice,next_phase[17:12]};
            ACCUMULATE:address=score_addr(voice+1'b1,chapter,slot,running_page==9);
            default:address=score_addr(2'd0,chapter,slot,running_page==9);
        endcase
    end
    always @(posedge clk) begin
        if(rst || !page_enabled || running_page!=page_id) begin
            running_page<=page_id;state<=IDLE;voice<=0;slot<=0;slot_offset<=0;
            sample<=0;accumulator<=0;
        end else case(state)
            IDLE:if(sample_tick)begin state<=SCORE;voice<=0;accumulator<=0;end
            SCORE:begin
                restart_hold<=restart_note;
                gain[voice]<=next_gain;gain_pipe<=next_gain;state<=PHASE;
            end
            PHASE:begin phase[voice]<=next_phase;state<=WAVE;end
            WAVE:begin product<=wave_value*signed_gain;state<=ACCUMULATE;end
            ACCUMULATE:begin
                if(voice==2)begin
                    sample<=running_page==9 ? mixed_voice : $signed(mixed_voice)>>>1;
                    if((&slot_offset[7:0]) && slot_offset[11:8]==block_limit) begin
                        slot_offset<=0;
                        // The END cadence resolves in slot47. Restart its original
                        // first downbeat on the next accepted HDMI audio sample.
                        if(running_page==9 && slot==47)slot<=0;
                        else slot<=slot+1'b1;
                    end else slot_offset<=slot_offset+1'b1;
                    state<=IDLE;
                end else begin accumulator<=mixed_voice;voice<=voice+1'b1;state<=SCORE;end
            end
            default:state<=IDLE;
        endcase
    end
endmodule

// One physical EG4 9K block in DP8K mode. The two synchronous 9-bit read
// ports return adjacent bytes from the same 13-bit logical word. INIT_00..1F
// hold the complete ROM inside the synthesis source and configuration Bit.
module scene_music_rom512(input wire clk,input wire [8:0] address,output wire [12:0] word);
    wire [8:0] low_byte,high_byte;
    assign word={high_byte[4:0],low_byte[7:0]};
    EG_PHY_BRAM #(
        .MODE("DP8K"),.DATA_WIDTH_A("9"),.DATA_WIDTH_B("9"),
        .REGMODE_A("NOREG"),.REGMODE_B("NOREG"),
        .WRITEMODE_A("NORMAL"),.WRITEMODE_B("NORMAL"),.RESETMODE("SYNC"),
        .INIT_FILE("NONE"),
        .INIT_00(256'h0db00dd10e120e550e940ed20ed10e900e000d2d0bf00a310812059402f20010),
        .INIT_01(256'h0140028d03cc050e0650077108ae09ac0aac0b6d0c000c8e0cf00d2e0d400d8c),
        .INIT_02(256'h12c012eb132e1391141214b0156e166d176b18ae19d01b111c401d921ed0000e),
        .INIT_03(256'h1d301a91181315f5143712f51213119111401150119211d41217125412721290),
        .INIT_04(256'h0b8c0b6d0b8e0bd00c510cf20db00e6e0ec00ea90e0c0c8d0a4e075003ce000c),
        .INIT_05(256'h1fcb1fcd1fd0001100b0018002ad040b058d070e086009b00a8e0b2d0b800b8b),
        .INIT_06(256'h148014f01592167417b519131a901c0c1d701e921f60001400520050004d0009),
        .INIT_07(256'h1c4018d015d2139112131175115311b51260132d13d01452149414a014921494),
        .INIT_08(256'h0eaa0e8d0e2a0de70d890d2c0cc90c660bee0b2c0a2e08ca070d04eb028d0009),
        .INIT_09(256'h028f04ed070a08c70a300b2d0beb0c690cca0d2d0d8a0de70e2b0e8e0eab0ec8),
        .INIT_0A(256'h116b118e11eb1228128a12ed134a13a7142d14f015ed1749190e1b2c1d890006),
        .INIT_0B(256'h1d8e1b2c1909174615ed14eb142d13a9134912ec1289122611ed1190116d1149),
        .INIT_0C(256'h0004000200060004000300020005000300010002000400010004000200060004),
        .INIT_0D(256'h0004000200010004000400020001000400020005000300020001000200040001),
        .INIT_0E(256'h0bd40a890963085d07e507080644054504b1042e0384032202a2025902170000),
        .INIT_0F(256'h00000000000000000000000000001c21190f17a7151312c610ba0fc90e100c88),
        .INIT_10(256'h00000cac04b514be0d35153e0d75157e00000d2c0535153e0cb514be0c35143e),
        .INIT_11(256'h00000c6c0475147e0cf514fe0d75157e00000dec05f515fe0d75157e0cf514fe),
        .INIT_12(256'h0dc405ca05d305dc05e405ec05f515fe00000e2c0635163e0db515be0d35153e),
        .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_14(256'h0c1f142d0b9f13ad0adf12ed0a1f122d1b6d0adf12ed0c1f142d0b5f136d1a6d),
        .INIT_15(256'h0a9f12ad0b1f132d0b9f13ad0a9f12ad0b9f13ad0b1f132d0a5f126d099f11ad),
        .INIT_16(256'h0c1f142d0c9f14ad0b5f136d0a5f126d0bdf13ed0b5f136d0a9f12ad09df11ed),
        .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_18(256'h000008cd00d400da00de00e200e510e70000090d0114011a011e012201251127),
        .INIT_19(256'h0000094d0154015a015e0162016511670000084d0054005a005e006200651067),
        .INIT_1A(256'h0905010d0114011a011e0122012511270000088d0094009a009e00a200a510a7),
        .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
        .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000)
    ) u_music_rom9k(
        .clka(clk),.clkb(clk),.cea(1'b1),.ceb(1'b1),.ocea(1'b1),.oceb(1'b1),
        .csa(3'b111),.csb(3'b111),.wea(1'b0),.web(1'b0),.rsta(1'b0),.rstb(1'b0),
        .dia(9'd0),.dib(9'd0),.addra({address,4'b0000}),.addrb({address,4'b1000}),
        .doa(low_byte),.dob(high_byte));
endmodule
