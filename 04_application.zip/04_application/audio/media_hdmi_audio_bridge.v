`timescale 1ns/1ps
// Public PCM / packet / symbol path. The board PHY stays in top, making this
// entire bridge simulatable without vendor encrypted cores or PLL models.
module media_hdmi_audio_bridge #(
    parameter integer PIXEL_HZ = 25000000,
    parameter integer SAMPLE_HZ = 48000,
    parameter integer TEST_HZ = 440,
    parameter integer RAMP_SAMPLES = 256,
    parameter integer CUE_MS = 100,
    parameter integer CUE_STYLE = 1,
    parameter integer CUE_HZ = 2500,
    parameter integer WAV_FADE_ENABLE = 0,
    parameter integer EXTERNAL_ONLY = 0
) (
    input wire pixel_clk,
    input wire pixel_rst_n,
    input wire timing_locked,
    input wire video_hsync,
    input wire video_vsync,
    input wire video_de,
    input wire [9:0] video_x,
    input wire video_next_line_active,
    input wire [23:0] video_rgb,
    input wire media_valid,
    input wire media_commit,
    input wire cue_trigger,
    input wire [1:0] media_id,
    input wire [1:0] source_select,
    input wire [7:0] volume,
    input wire mute,
    input wire [7:0] fade_alpha,
    input wire external_valid,
    output wire external_ready,
    input wire signed [15:0] external_left,
    input wire signed [15:0] external_right,
    output wire [9:0] channel0_symbol,
    output wire [9:0] channel1_symbol,
    output wire [9:0] channel2_symbol,
    output wire sequence_error,
    output wire tone_overflow,
    output wire tone_underrun,
    output wire pcm_contract_error,
    output wire blip_active,
    output wire [1:0] active_media_id,
    output wire [1:0] active_source,
    output wire pcm_tap_valid,
    output wire signed [15:0] pcm_tap_left,
    output wire signed [15:0] pcm_tap_right,
    output wire pcm_ready,
    output wire packet_sent,
    output wire [7:0] packet_type,
    output wire [31:0] packet_count
);
    // Exact signed divide by 255 without a synthesized general divider.
    // For n=256*a+b: floor(n/255)=a+floor((a+b)/255). Here a+b<=32895,
    // so the second quotient uses the exact 16-bit add/shift identity.
    // Audio/alpha share the pixel clock; button cues bypass this PCM stage.
    function signed [15:0] fade_pcm;
        input signed [15:0] pcm;
        input [7:0] alpha;
        reg [15:0] magnitude,a;
        reg [23:0] product;
        reg [16:0] folded,small_div,total;
        begin
            magnitude=pcm[15] ? (~pcm+16'd1) : pcm;
            product=magnitude*alpha;
            a=product[23:8];
            folded={1'b0,a}+{9'd0,product[7:0]};
            small_div=folded+17'd1+{9'd0,folded[15:8]};
            total={1'b0,a}+{8'd0,small_div[16:8]};
            fade_pcm=pcm[15] ? -$signed(total[15:0]) : $signed(total[15:0]);
        end
    endfunction
    wire signed [15:0] faded_left=WAV_FADE_ENABLE!=0 ? fade_pcm(external_left,fade_alpha) : external_left;
    wire signed [15:0] faded_right=WAV_FADE_ENABLE!=0 ? fade_pcm(external_right,fade_alpha) : external_right;
    wire source_valid, source_ready, sample_valid;
    wire signed [15:0] source_left, source_right, sample_left, sample_right;
    reg video_hsync_q, video_vsync_q, video_de_q, next_line_q;
    reg [9:0] video_x_q;
    reg [23:0] video_rgb_q;
    wire audio_rst_n = pixel_rst_n && timing_locked;
    reg media_started;
    // A card may commit its first picture before the first VS calibration.
    // Reissue the current committed ID once the audio chain can actually run.
    wire effective_media_commit = media_valid && (media_commit || !media_started);
    always @(posedge pixel_clk or negedge pixel_rst_n) begin
        if (!pixel_rst_n) media_started <= 0;
        else if (!timing_locked || !media_valid) media_started <= 0;
        else media_started <= 1;
    end
    always @(posedge pixel_clk or negedge pixel_rst_n) begin
        if (!pixel_rst_n) begin
            video_hsync_q <= 1;
            video_vsync_q <= 1;
            video_de_q <= 0;
            next_line_q <= 0;
            video_x_q <= 0;
            video_rgb_q <= 0;
        end else begin
            video_hsync_q <= video_hsync;
            video_vsync_q <= video_vsync;
            video_de_q <= video_de && timing_locked;
            next_line_q <= video_next_line_active && timing_locked;
            video_x_q <= video_x;
            video_rgb_q <= video_de ? video_rgb : 24'd0;
        end
    end
    lesson3_pcm_source #(.CLOCK_HZ(PIXEL_HZ), .SAMPLE_HZ(SAMPLE_HZ),.EXTERNAL_ONLY(EXTERNAL_ONLY),
        .TEST_HZ(TEST_HZ), .RAMP_SAMPLES(RAMP_SAMPLES),
        .BLIP_HZ(CUE_HZ), .BLIP_SAMPLES((64'd1 * SAMPLE_HZ * CUE_MS) / 1000),
        .CUE_ON_COMMIT(0), .CUE_STYLE(CUE_STYLE),
        .CUE_GAP_SAMPLES(CUE_STYLE != 0 ? 0 : SAMPLE_HZ / 25), .CUE_GAIN_SHIFT(1)) u_tone (
        .clk(pixel_clk), .rst_n(audio_rst_n),
        .enable(media_valid && timing_locked), .source_select(source_select),
        .volume(volume), .mute(mute), .media_commit(effective_media_commit), .media_id(media_id),
        .cue_trigger(cue_trigger),
        .external_valid(external_valid), .external_ready(external_ready),
        .external_left(faded_left), .external_right(faded_right),
        .sample_valid(source_valid), .sample_ready(source_ready),
        .sample_left(source_left), .sample_right(source_right),
        .sample_tick(), .overflow(tone_overflow), .underrun(tone_underrun),
        .blip_active(blip_active), .note_index(),
        .active_media_id(active_media_id), .active_source(active_source)
    );
    m06_pcm_contract_adapter u_contract (
        .clk(pixel_clk), .rst_n(audio_rst_n),
        .source_valid(source_valid), .source_ready(source_ready),
        .source_left(source_left), .source_right(source_right),
        .pcm_valid(sample_valid), .pcm_ready(pcm_ready),
        .pcm_left(sample_left), .pcm_right(sample_right),
        .contract_error(pcm_contract_error)
    );
    hdmi_audio_symbol_core #(.PIXEL_HZ(PIXEL_HZ), .SAMPLE_HZ(SAMPLE_HZ)) u_symbol_core (
        .pixel_clk(pixel_clk), .rst_n(audio_rst_n),
        .video_hsync(video_hsync_q), .video_vsync(video_vsync_q),
        .video_de(video_de_q), .video_x(video_x_q),
        .video_next_line_active(next_line_q), .video_rgb(video_rgb_q),
        .sample_valid(sample_valid), .sample_ready(pcm_ready),
        .sample_left(sample_left), .sample_right(sample_right),
        .channel0_symbol(channel0_symbol), .channel1_symbol(channel1_symbol),
        .channel2_symbol(channel2_symbol), .sequence_error(sequence_error),
        .packet_sent(packet_sent), .packet_type(packet_type), .packet_count(packet_count)
    );
    assign pcm_tap_valid = sample_valid && pcm_ready;
    assign pcm_tap_left = sample_left;
    assign pcm_tap_right = sample_right;
endmodule
