# Lesson 8 frame request has three receiving stages and freezes bank/token.
# Touch volume uses an acknowledged held mailbox; bursts may be adjacent.
# Only receiving first stages cross domains; second/qualifier stages stay timed.
set_max_delay -datapath_only 39.7 -to [get_regs {u_volume_cdc/payload_meta[*]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_volume_cdc/request_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_volume_cdc/ack_sync[0]}]
set_max_delay -datapath_only 9.7 -from [get_regs {u_video_timing/read_req}] -to [get_regs {u_frame_reader/request_sync[0]}]

# SDRAM-ready is generated in the 100 MHz memory domain. Its only startup
# destination exception is the first 50 MHz SD-domain synchronizer stage.
# Keep the existing 9.7 ns first-stage datapath bound (stricter than 20 ns).
# The second stage and the same-domain TF reset gate retain normal timing.
set_max_delay -datapath_only 9.700 -from [get_regs {Sdr_init_done}] -to [get_regs {u_sdram_init_sync/s1}]

# Global reset uses asynchronous assertion and two-stage synchronous release.
# Exempt ONLY the physical asynchronous SR inputs connected to rst_async.
# This net feeds only the original reset_sync instances. TD can pack a reset FF
# with an unrelated LUT and name the slice after that LUT, so do not select by
# physical cell name. Select SR pins directly by their actual net and pin type.
# Do not match u_reset_tf:
# its SDRAM-ready gate is synchronous to the SD clock and remains checked.
# Reset stage D inputs, second-stage outputs, and all business-logic reset
# destinations retain ordinary setup/hold/recovery/removal checks.
# Use one top-level SDC command: TD does not execute arbitrary SDC control flow.
# No nested -of collections are used (empty -of can mean all objects in TD).
# Native Tcl signoff in updata/tools/reset_sr_signoff.tcl independently proves
# these pins belong exclusively to the four active reset synchronizers and
# that no business FF shares their SR. Any mismatch blocks Bit generation.
set_false_path -to [get_pins -hier -filter {NET_NAME == rst_async && REF_NAME == sr} *]

# Lesson 8: only explicitly identified CDC first data/control stages are bounded.
# Held frame/length/commit and completion/error payloads are sampled through two
# data stages, qualified by three request/event stages. The source keeps them
# stable until the corresponding transaction completes. received_d0 is used only
# after source_done freezes the counter and commit_sync[2] qualifies it.
# The reader holds each bank/token across drain, FIFO reset release and ACK.
# Native FIFO pointer/reset CDC remains covered by the generated IP constraints.
# All subsequent stages and ordinary paths retain normal setup/hold checks.
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/switch_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/bank_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/fifo_rd_done_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/ready_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/u_writer/write_req_d0}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/u_writer/write_addr_index_d0[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/commit_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/cancel_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/received_d0[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/length_d0[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/done_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/error_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/error_code_d0[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_loader/u_write_cdc/wr_ready_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {video_read_ack_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {sd_write_ack_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {sd_card_bmp_m0/wrfin_tgl_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {sd_card_bmp_m0/u_player_control/read_ack_tgl_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {sd_card_bmp_m0/u_player_control/read_ack_idx_d0[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {display_valid_video_sync[0]}]
# The loader bank-completion mirror is unconsumed in this integration. Its
# bank_d0/done_bank_d0 chains are removed by synthesis, so no empty CDC
# exceptions target them. The player's qualified frame-finish drives publish.

# The stable SDRAM bank precedes the FIFO-ready toggle; it is captured with
# the same token that arms first-pixel reads, before vertical blank ends.
set_max_delay -datapath_only 9.7 -from [get_regs {u_frame_reader/reader_index[*]}] -to [get_regs {u_frame_reader/pixel_bank_meta[*]}]

# Lesson10 held bank/kind/token mailbox. Third token stages qualify payload.
set_max_delay -datapath_only 39.7 -to [get_regs {u_transition/g_effect$payload_meta[*]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_transition/g_effect$request_sync[0]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_transition/g_effect$forwarded_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_transition/g_effect$arm_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_transition/g_effect$done_sync[0]}]

# Raw PCM FIFO: source-registered Gray pointers, plus single-bit run/EOF/arm.
# The source register to first receiving stage is bounded below the fastest
# source/destination period. All second stages retain normal timing checks.
set_max_delay -datapath_only 9.7 -from [get_regs {u_wav_player/wr_gray[*]}] -to [get_regs {u_wav_player/wr_gray_meta[*]}]
set_max_delay -datapath_only 9.7 -from [get_regs {u_wav_player/rd_gray[*]}] -to [get_regs {u_wav_player/rd_gray_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_wav_player/run_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_wav_player/finished_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_wav_player/rd_armed_meta}]

# Immutable image dimensions: the third valid stage qualifies two data stages.
# Bound only the first receiving registers; all later stages remain timed.
set_max_delay -datapath_only 9.7 -to [get_regs {u_resolution_cdc/dimensions_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_resolution_cdc/valid_meta[*]}]

# Lesson13: held request/ACK mailbox; only first receive stages cross clocks.
set_max_delay -datapath_only 39.7 -to [get_regs {u_image_adjust_cdc/payload_meta[*]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_image_adjust_cdc/request_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_image_adjust_cdc/ack_sync[0]}]
# SW1..4 are asynchronous external inputs. TD packs each first stage into
# its PAD input FF. No internal path exception is added for these switches;
# native guards prove PAD clock/reset/data and the timed second logic stage.

# Lesson14 held mailboxes and immutable thumbnail status. Only first stages.
set_max_delay -datapath_only 39.7 -to [get_regs {u_settings_cdc/payload_meta[*]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_settings_cdc/request_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_settings_cdc/ack_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_join/full_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/view_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_frame_reader/pixel_view_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/event_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/status_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/busy_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/context_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/select_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/index_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_ui/ack_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/request_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/commit_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/cancel_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/bank_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/ack_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/done_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/error_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/idle_sync[0]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/done_bank_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/done_epoch_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/error_epoch_meta}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/error_code_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_thumbnail_writer/u_write_cdc/wr_ready_sync[0]}]

# Dental assets: source tables and RAM are written only during startup. The
# completed-load qualifier crosses through two receiving registers before use.
# Scene music is a held payload qualified by the third toggle stage. Reader
# page follows the same held switch-token mailbox as bank and view mode.
set_max_delay -datapath_only 19.7 -to [get_regs {scene_music_meta[*]}]
set_max_delay -datapath_only 19.7 -to [get_regs {scene_toggle_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {assets_ready_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_dental_osd/ready_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_sfx_cache/ready_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_sfx_cache/valid_meta[*]}]

# Immutable startup metadata is captured directly after its ready qualifier.
# Bound only these exact SD-domain source registers to pixel-domain consumers;
# pixel-side address counters, mux select and all other logic remain timed.
# Palette infers native dual-port distributed RAM, not SD-domain flip-flops.
# Its SD write port and pixel read/capture port keep ordinary timing. The
# held-data guard proves the DPRAM implementation and synchronized ready gate;
# there is no nonexistent palette-FF or blanket spr2_rgb timing exception.
set_max_delay -datapath_only 39.7 -from [get_regs -hier -regexp {^u_sfx_cache/base[0-4]\[[0-9]+\](_dup_[0-9]+)?$}] -to [get_regs {u_sfx_cache/play_addr[*] u_sfx_cache/play_remaining[*] u_sfx_cache/active u_sfx_cache/fetch_wait[*]}]
set_max_delay -datapath_only 39.7 -from [get_regs -hier -regexp {^u_sfx_cache/len[0-4]\[[0-9]+\](_dup_[0-9]+)?$}] -to [get_regs {u_sfx_cache/play_addr[*] u_sfx_cache/play_remaining[*] u_sfx_cache/active u_sfx_cache/fetch_wait[*]}]

# Interactive story context: the four-bit held mailbox runs in the reverse
# direction to settings: video 25 MHz -> SD 50 MHz. Only first receivers
# cross domains; payload_sync, request_sync[1:2], ack_sync[1] remain timed.
set_max_delay -datapath_only 19.7 -to [get_regs {u_story_context_cdc/payload_meta[*]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_story_context_cdc/request_sync[0]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_story_context_cdc/ack_sync[0]}]

# Independent START.BMP frame: held single-bit boot payloads accompany the
# existing third-stage request/ready qualifiers. New ACK/finish toggles have
# three stages; read_enabled is a persistent level with two video stages.
# Only the exact first receivers below get a datapath bound. All second and
# qualifier stages keep ordinary setup/hold timing. No clock-group exception.
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_frame_loader/u_writer/boot_meta(_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_frame_reader/boot_meta(_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -from [get_regs -hier -regexp {^u_frame_reader/reader_boot(_dup_[0-9]+)?$}] -to [get_regs -hier -regexp {^u_frame_reader/pixel_boot_meta(_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_start_page_switch/raw_ack_sync\[0\](_dup_[0-9]+)?$}]
set_max_delay -datapath_only 19.7 -to [get_regs -hier -regexp {^start_read_enable_video_sync\[0\](_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_start_write_completion/full_finish_sync\[0\](_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_start_page_switch/raw_index_meta\[[0-2]\](_dup_[0-9]+)?$}]

# Functional TJC status mailbox: video25MHz -> SD50MHz. Exact first receivers
# only; following payload/qualifier stages and all old CDC constraints timed.
set_max_delay -datapath_only 19.7 -to [get_regs {u_tjc_status_cdc/payload_meta[*]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_tjc_status_cdc/request_sync[0]}]
set_max_delay -datapath_only 39.7 -to [get_regs {u_tjc_status_cdc/ack_sync[0]}]
# RX first FF packs into PAD. No false path cuts RX second stage or business.
# One-way control: tjc_tx is a constant-high output, with no launch clock path.
# Its physical pin/constant driver are checked by the native functional guard.

# Functional zoom held mailbox SD50MHz -> memory100MHz.
set_max_delay -datapath_only 9.7 -to [get_regs {u_zoom_cdc/payload_meta[*]}]
set_max_delay -datapath_only 9.7 -to [get_regs {u_zoom_cdc/request_sync[0]}]
set_max_delay -datapath_only 19.7 -to [get_regs {u_zoom_cdc/ack_sync[0]}]
# Frame crop metadata is held before the existing three-stage ready token.
set_max_delay -datapath_only 9.7 -from [get_regs {u_frame_reader/reader_zoom[*]}] -to [get_regs {u_frame_reader/pixel_zoom_meta[*]}]

# END held page tag: exact first receivers only; all later stages remain timed.
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_frame_loader/u_writer/end_meta(_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^u_frame_reader/end_meta(_dup_[0-9]+)?$}]
set_max_delay -datapath_only 9.7 -from [get_regs -hier -regexp {^u_frame_reader/reader_end(_dup_[0-9]+)?$}] -to [get_regs -hier -regexp {^u_frame_reader/pixel_end_meta(_dup_[0-9]+)?$}]

# Only the first video-domain FF receives this held asynchronous level.
set_max_delay -datapath_only 9.7 -to [get_regs -hier -regexp {^audition_pending_sync\[0\](_dup_[0-9]+)?$}]
