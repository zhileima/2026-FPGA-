
# ============================================================
# F1/constraints/timing.sdc
# 用于：TF 图片轮播 + HDMI(视频+音频) 整合工程
#
# 合并原则：
# 1) 保留 top.sdc 里的系统主时钟与 derive_clocks
# 2) 把 timing(2).sdc 里的 pixel/serial 时钟改成整合工程实际名字
# 3) 命名 SD、SDRAM、HDMI 视频/串行时钟
# 4) 不再对内部 net 直接 create_clock，避免和 derive_clocks 重复
# ============================================================

# ------------------------------------------------------------
# 1. 板级输入主时钟
#    你的原 top.sdc 里 clk=50MHz，所以这里仍然用 20ns
# ------------------------------------------------------------
create_clock -name clk -period 20 -waveform {0 10} [get_ports {clk}]

# ------------------------------------------------------------
# 2. 自动推导 PLL 输出时钟
# ------------------------------------------------------------
derive_clocks

# ------------------------------------------------------------
# 3. 给关键 PLL 输出命名
#    下面这些路径是按你当前工程实例名写的：
#      sys_pll      -> sys_pll_m0
#      video_pll    -> video_pll_m0
#      音频采样与封包复用 video_clk，无独立音频PLL
#
#    如果综合后实例路径略有不同，就按 Timing Analyzer 里的实际 pin 路径改。
# ------------------------------------------------------------
rename_clock -name {sd_card_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {sys_pll_m0/pll_inst.clkc[0]}]
rename_clock -name {ext_mem_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {sys_pll_m0/pll_inst.clkc[1]}]
rename_clock -name {ext_mem_clk_sft} -source [get_ports {clk}] -master_clock {clk} [get_pins {sys_pll_m0/pll_inst.clkc[2]}]
rename_clock -name {video_clk}   -source [get_ports {clk}] -master_clock {clk} [get_pins {video_pll_m0/pll_inst.clkc[0]}]
rename_clock -name {hdmi_5x_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {video_pll_m0/pll_inst.clkc[1]}]


# ------------------------------------------------------------
# 4. HDMI 像素/串行时钟关系
#    video_clk 与 hdmi_5x_clk 来自同一 PLL，显示时同时工作。
#    F1 副本已移除原来的 set_clock_groups -exclusive，保留两域之间的时序检查。
#    不应为了消除报告中的违例而把这两个时钟声明为互斥或异步。
# ------------------------------------------------------------



# ------------------------------------------------------------
# 5. 其余时钟与跨域路径核对
#    derive_clocks 从真实 PLL 参数推导周期，不用单独 create_clock 放宽约束。
#    2026-10-14：sys_pll C0 为 50 MHz，C1/C2 为 100 MHz；C2 正相移 8 ns：
#      sys_pll_m0/pll_inst.clkc[0]  -> sd_card_clk (50 MHz, 0 度)
#      sys_pll_m0/pll_inst.clkc[1]  -> ext_mem_clk (100 MHz, 0 度)
#      sys_pll_m0/pll_inst.clkc[2]  -> ext_mem_clk_sft (100 MHz, 288 度)
#      video_clk -> 精确平均48kHz PCM节拍，ACR N6144/CTS25000
#    源码层级与综合网表可能不同；需确认上述对象实际存在以及推导频率/相位。
#    跨域例外须逐条检查 FIFO、同步器和复位通路，本文件不启用全域异步分组。
# ------------------------------------------------------------

# ------------------------------------------------------------
# 6. 本文件尚未加入 Input/Output delay，不代表板级接口时序已完整覆盖。
#    应按实际外设、板级连接和 TD 报告补充；以重新综合、布线后的报告验收。
# ------------------------------------------------------------

# 100 MHz SiP reads deliberately capture the previous SDRAM beat.
# With the current 10 ns macros, sdram.v delays the core valid one cycle to
# match this input capture. Continuous read data still changes each cycle.
# Apply ONLY to hard-IP DQ -> controller read capture (32 inputs).
# Keep the advanced hold edge: hold=0, NOT the usual relaxed hold=1.
set_multicycle_path -setup 2 -from [get_pins {U3/sdram.dq[*]}] -to [get_clocks {ext_mem_clk}]
set_multicycle_path -hold 0 -from [get_pins {U3/sdram.dq[*]}] -to [get_clocks {ext_mem_clk}]


# The dental external-PCM path no longer consumes the committed-image melody
# mailbox. Native gate mapping removes its payload/request/ACK endpoints.
# No empty exception targets that retired mailbox. The live button event
# synchronizer and all following video/5x/SDRAM checks remain timed.
set_max_delay -datapath_only 39.7 -from [get_regs {sd_card_bmp_m0/button_event_toggle}] -to [get_regs {u_button_cue_sync/toggle_sync1}]

# Additional design margin, without changing any clock relationship.
# TD adds user uncertainty to its device default. The validated routed report
# uses setup 0.150 ns (default 0.100 + user 0.050) and hold 0.100 ns
# (default 0.100 + user 0.000). Do not reduce or cancel the default hold budget.
set_clock_uncertainty -setup 0.050 [get_clocks {clk sd_card_clk ext_mem_clk ext_mem_clk_sft video_clk hdmi_5x_clk}]
set_clock_uncertainty -hold 0.000 [get_clocks {clk sd_card_clk ext_mem_clk ext_mem_clk_sft video_clk hdmi_5x_clk}]

# Bound only the four implemented ODDR-to-pad paths, on both output edges.
# Eight real paths are checked by TD; this does not cut the 25/125 MHz
# serializer transfers or claim a complete board-level HDMI eye/skew budget.
set_max_delay -datapath_only 8.000 -from [get_clocks {hdmi_5x_clk}] -to [get_ports {HDMI_CLK_P HDMI_D0_P HDMI_D1_P HDMI_D2_P}]
