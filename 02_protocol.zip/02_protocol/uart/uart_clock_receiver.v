`timescale 1ns/1ps

// PC -> FPGA wall-clock setting packet, 115200 8N1 by default:
// A5 5A 54 07 HH MM SS tick[7:0] tick[15:8] tick[23:16] tick[31:24] XOR.
// HH/MM/SS are packed BCD; tick is the elapsed PIXEL_HZ fraction of a second.
// XOR covers type (54), payload length (07), and all seven payload bytes.
// A complete checked packet is the only event that publishes a new time.
module uart_clock_receiver #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 115200,
    parameter integer PIXEL_HZ = 25_000_000,
    parameter integer PACKET_TIMEOUT_CYCLES = 500000
) (
    input wire clk,
    input wire rst_n,
    input wire uart_rx,
    output reg set_valid,
    output reg [23:0] set_bcd,
    output reg [24:0] set_ticks,
    output reg [3:0] error_flags,
    output reg [15:0] valid_packet_count,
    output reg [15:0] error_packet_count
);
    localparam integer BIT_CYCLES = (CLK_HZ + BAUD/2) / BAUD;
    localparam integer HALF_CYCLES = BIT_CYCLES / 2;
    // After reset, a PC may still be sending the tail of an old packet.
    // Eleven uninterrupted idle bits cannot occur inside contiguous 8N1
    // bytes (at most eight data-one bits plus one stop bit). Qualify once,
    // then accept ordinary back-to-back bytes and retain all live faults.
    localparam integer STARTUP_IDLE_CYCLES = 11 * BIT_CYCLES;
    localparam integer IDLE_TIMER_BITS = $clog2(STARTUP_IDLE_CYCLES);
    reg [IDLE_TIMER_BITS-1:0] startup_idle_count;
    reg rx_armed;
    localparam [2:0] RX_IDLE=0, RX_START=1, RX_DATA=2, RX_STOP=3, RX_HIGH=4;
    localparam [2:0] P_A5=0, P_5A=1, P_TYPE=2, P_LEN=3, P_DATA=4, P_XOR=5;
    (* ASYNC_REG = "TRUE" *) reg rx_sync1, rx_sync2;
    reg [2:0] rx_state;
    reg [15:0] bit_count;
    reg [2:0] bit_index;
    reg [7:0] rx_shift, rx_byte;
    reg rx_byte_valid, rx_frame_error;
    reg [2:0] packet_state;
    reg [2:0] payload_index;
    reg [55:0] payload;
    reg [7:0] checksum;
    reg [31:0] wait_count;
    wire [7:0] packet_hh = payload[7:0];
    wire [7:0] packet_mm = payload[15:8];
    wire [7:0] packet_ss = payload[23:16];
    wire [31:0] packet_ticks = payload[55:24];
    wire packet_time_ok = packet_hh[3:0] <= 9 && packet_hh[7:4] <= 2 &&
        (packet_hh[7:4] != 2 || packet_hh[3:0] <= 3) &&
        packet_mm[7:4] <= 5 && packet_mm[3:0] <= 9 &&
        packet_ss[7:4] <= 5 && packet_ss[3:0] <= 9 &&
        packet_ticks < PIXEL_HZ;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_sync1 <= 1'b1; rx_sync2 <= 1'b1;
            startup_idle_count <= 0; rx_armed <= 0;
            rx_state <= RX_IDLE; bit_count <= 0; bit_index <= 0;
            rx_shift <= 0; rx_byte <= 0;
            rx_byte_valid <= 0; rx_frame_error <= 0;
        end else begin
            rx_sync1 <= uart_rx; rx_sync2 <= rx_sync1;
            rx_byte_valid <= 0; rx_frame_error <= 0;
            if (!rx_armed) begin
                rx_state <= RX_IDLE;
                if (!rx_sync2) startup_idle_count <= 0;
                else if (startup_idle_count == STARTUP_IDLE_CYCLES-1)
                    rx_armed <= 1;
                else startup_idle_count <= startup_idle_count+1'b1;
            end else begin
            case (rx_state)
                RX_IDLE: if (!rx_sync2) begin
                    bit_count <= HALF_CYCLES-1; rx_state <= RX_START;
                end
                RX_START: if (bit_count != 0) bit_count <= bit_count-1'b1;
                    else if (rx_sync2) rx_state <= RX_IDLE;
                    else begin bit_count <= BIT_CYCLES-1; bit_index <= 0; rx_state <= RX_DATA; end
                RX_DATA: if (bit_count != 0) bit_count <= bit_count-1'b1;
                    else begin
                        rx_shift[bit_index] <= rx_sync2;
                        bit_count <= BIT_CYCLES-1;
                        if (bit_index == 7) rx_state <= RX_STOP;
                        else bit_index <= bit_index+1'b1;
                    end
                RX_STOP: if (bit_count != 0) bit_count <= bit_count-1'b1;
                    else if (rx_sync2) begin
                        rx_byte <= rx_shift; rx_byte_valid <= 1; rx_state <= RX_IDLE;
                    end else begin
                        rx_frame_error <= 1; rx_state <= RX_HIGH;
                    end
                RX_HIGH: if (rx_sync2) rx_state <= RX_IDLE;
                default: rx_state <= RX_IDLE;
            endcase
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            set_valid <= 0; set_bcd <= 0; set_ticks <= 0;
            error_flags <= 0; valid_packet_count <= 0; error_packet_count <= 0;
            packet_state <= P_A5; payload_index <= 0; payload <= 0;
            checksum <= 0; wait_count <= 0;
        end else begin
            set_valid <= 0;
            if (rx_frame_error) begin
                error_flags[0] <= 1;
                if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                packet_state <= P_A5; wait_count <= 0;
            end else if (rx_byte_valid) begin
                wait_count <= 0;
                case (packet_state)
                    P_A5: if (rx_byte == 8'ha5) packet_state <= P_5A;
                    P_5A: if (rx_byte == 8'h5a) packet_state <= P_TYPE;
                        else if (rx_byte != 8'ha5) packet_state <= P_A5;
                    P_TYPE: if (rx_byte == 8'h54) begin
                        checksum <= rx_byte; packet_state <= P_LEN;
                    end else begin
                        error_flags[2] <= 1;
                        if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                        packet_state <= rx_byte == 8'ha5 ? P_5A : P_A5;
                    end
                    P_LEN: if (rx_byte == 8'h07) begin
                        checksum <= checksum ^ rx_byte; payload_index <= 0;
                        payload <= 0; packet_state <= P_DATA;
                    end else begin
                        error_flags[2] <= 1;
                        if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                        packet_state <= rx_byte == 8'ha5 ? P_5A : P_A5;
                    end
                    P_DATA: begin
                        payload[payload_index*8 +: 8] <= rx_byte;
                        checksum <= checksum ^ rx_byte;
                        if (payload_index == 6) packet_state <= P_XOR;
                        else payload_index <= payload_index+1'b1;
                    end
                    P_XOR: begin
                        if (rx_byte != checksum) begin
                            error_flags[1] <= 1;
                            if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                        end else if (!packet_time_ok) begin
                            error_flags[2] <= 1;
                            if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                        end else begin
                            set_bcd <= {packet_hh,packet_mm,packet_ss};
                            set_ticks <= packet_ticks[24:0]; set_valid <= 1;
                            if (valid_packet_count != 16'hffff) valid_packet_count <= valid_packet_count+1'b1;
                        end
                        packet_state <= P_A5;
                    end
                    default: packet_state <= P_A5;
                endcase
            end else if (packet_state != P_A5) begin
                if (wait_count >= PACKET_TIMEOUT_CYCLES-1) begin
                    error_flags[3] <= 1; wait_count <= 0; packet_state <= P_A5;
                    if (error_packet_count != 16'hffff) error_packet_count <= error_packet_count+1'b1;
                end else wait_count <= wait_count+1'b1;
            end else wait_count <= 0;
        end
    end
endmodule
