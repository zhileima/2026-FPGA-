`timescale 1ns/1ps
// Atomic 512-byte sector delivery: never expose bytes before CRC/status pass.
// A timed-out in-flight command resets the whole service, so late data cannot
// be mistaken for the next request. Reinitialization must show ready low/high.
module sd_sector_adapter #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SECTOR_TIMEOUT_MS = 500,
    parameter integer REINIT_TIMEOUT_MS = 1500,
    parameter integer ABORT_RESET_CYCLES = 16
) (
    input wire clk, input wire rst_n, input wire abort,
    input wire sector_req, input wire [31:0] sector_lba,
    output reg sector_busy, output wire sector_valid,
    output reg [7:0] sector_byte, output reg [8:0] sector_byte_index,
    input wire sector_byte_ready,
    output reg sector_done, output reg [7:0] sector_error,
    output reg reader_req, output reg [31:0] reader_lba,
    input wire reader_ready, input wire [7:0] reader_init_error,
    input wire reader_busy, input wire reader_valid,
    input wire [7:0] reader_byte, input wire [8:0] reader_byte_index,
    input wire reader_done, input wire [7:0] reader_error,
    output wire sd_abort_reset
);
    localparam [63:0] SECTOR_CYCLES = (64'd1*CLK_FREQ_HZ*SECTOR_TIMEOUT_MS+999)/1000;
    localparam [63:0] REINIT_CYCLES = (64'd1*CLK_FREQ_HZ*REINIT_TIMEOUT_MS+999)/1000;
    localparam [63:0] MAX_CYCLES = SECTOR_CYCLES > REINIT_CYCLES ? SECTOR_CYCLES : REINIT_CYCLES;
    localparam integer TIMER_BITS = MAX_CYCLES < 2 ? 1 : $clog2(MAX_CYCLES+1);
    localparam integer RESET_BITS = ABORT_RESET_CYCLES < 2 ? 1 : $clog2(ABORT_RESET_CYCLES);
    localparam [3:0] ST_IDLE=0, ST_READY=1, ST_CAPTURE=2, ST_FETCH=3,
        ST_REPLAY=4, ST_DONE=5, ST_RESET=6, ST_REINIT=7, ST_OFFLINE=8, ST_REPLAY_LATCH=9;
    localparam [7:0] ERR_CAPTURE=8'h48, ERR_TIMEOUT=8'h39,
        ERR_ABORT=8'h3e, ERR_REINIT=8'h3d;
    reg [3:0] state;
    (* ram_style = "block" *) reg [7:0] sector_mem [0:511];
    reg [7:0] ram_read_byte;
    reg [9:0] captured_count;
    reg [8:0] replay_index;
    reg capture_fault, ready_low_seen;
    // Publish the latched RAM byte with its own enable flop, avoiding a
    // high-fanout state decode through the downstream FAT/BMP byte enables.
    reg replay_valid;
    reg [TIMER_BITS-1:0] timer;
    reg [RESET_BITS-1:0] reset_count;
    wire byte_in_order = captured_count < 10'd512 &&
        reader_byte_index == captured_count[8:0];
    wire [10:0] count_after = {1'b0,captured_count} + (reader_valid ? 11'd1 : 11'd0);
    // Same-cycle Moore output held in its own flop. Updating alongside every
    // state transition removes the state-decode fanout from FAT/OSD ready.
    // This adds no handshake cycle and changes no timeout or abort behavior.
    assign sector_valid = replay_valid && !abort;
    assign sd_abort_reset = state == ST_RESET;

    initial begin
        if (CLK_FREQ_HZ < 1 || SECTOR_TIMEOUT_MS < 1 || REINIT_TIMEOUT_MS < 1 ||
            MAX_CYCLES > 64'h3fffffff || ABORT_RESET_CYCLES < 1) begin
            $display("SD_ADAPTER_CONFIG_ERROR invalid timeout parameters");
            $finish;
        end
    end
    // Keep the physical RAM out of the asynchronously reset control process.
    // CRC/length checking completes before any buffered byte is published.
    // A dedicated clocked read and latch state allow a native block RAM.
    always @(posedge clk) begin
        if (rst_n && !abort && state==ST_CAPTURE && reader_valid && byte_in_order)
            sector_mem[reader_byte_index] <= reader_byte;
        if (state==ST_FETCH) ram_read_byte <= sector_mem[replay_index];
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            begin state<=ST_IDLE;sector_busy<=1'b0;end replay_valid<=0; sector_byte<=0; sector_byte_index<=0;
            sector_done<=0; sector_error<=0; reader_req<=0; reader_lba<=0;
            captured_count<=0; replay_index<=0; capture_fault<=0;
            ready_low_seen<=0; timer<=0; reset_count<=0;
        end else begin
            sector_done<=0;
            reader_req<=0;
            if (abort && state!=ST_IDLE && state!=ST_OFFLINE &&
                state!=ST_RESET && state!=ST_REINIT) begin
                replay_valid<=0;
                sector_error<=ERR_ABORT;
                sector_done<=1;
                timer<=0;
                if (state==ST_CAPTURE || (state==ST_READY && reader_busy)) begin
                    begin state<=ST_RESET;sector_busy<=1'b1;end reset_count<=0; ready_low_seen<=0;
                end else begin state<=ST_IDLE;sector_busy<=1'b0;end
            end else case (state)
                ST_IDLE: if (sector_req && !abort) begin
                    reader_lba<=sector_lba; captured_count<=0; replay_index<=0;
                    capture_fault<=0; sector_error<=0; timer<=0; begin state<=ST_READY;sector_busy<=1'b1;end
                end
                ST_READY: begin
                    if (reader_ready && !reader_busy) begin
                        reader_req<=1; timer<=0; begin state<=ST_CAPTURE;sector_busy<=1'b1;end
                    end else if (reader_init_error!=0) begin
                        sector_error<=reader_init_error; sector_done<=1; begin state<=ST_OFFLINE;sector_busy<=1'b0;end
                    end else if (timer>=REINIT_CYCLES-1) begin
                        sector_error<=ERR_REINIT; sector_done<=1; begin state<=ST_OFFLINE;sector_busy<=1'b0;end
                    end else timer<=timer+1'b1;
                end
                ST_CAPTURE: begin
                    if (reader_valid) begin
                        if (!byte_in_order) capture_fault<=1;
                        if (captured_count<10'd513) captured_count<=captured_count+1'b1;
                    end
                    // Include a final data byte arriving on the same edge as done.
                    if (reader_done) begin
                        if (reader_error!=0) begin
                            sector_error<=reader_error; begin state<=ST_DONE;sector_busy<=1'b1;end
                        end else if (capture_fault ||
                            (reader_valid && !byte_in_order) || count_after!=11'd512) begin
                            sector_error<=ERR_CAPTURE; begin state<=ST_DONE;sector_busy<=1'b1;end
                        end else begin replay_index<=0; begin state<=ST_FETCH;sector_busy<=1'b1;end end
                    end else if (timer>=SECTOR_CYCLES-1) begin
                        sector_error<=ERR_TIMEOUT; sector_done<=1; begin state<=ST_RESET;sector_busy<=1'b1;end
                        reset_count<=0; ready_low_seen<=0; timer<=0;
                    end else timer<=timer+1'b1;
                end
                ST_FETCH: begin
                    sector_byte_index<=replay_index; begin state<=ST_REPLAY_LATCH;sector_busy<=1'b1;end
                end
                ST_REPLAY_LATCH: begin
                    sector_byte<=ram_read_byte; replay_valid<=1; begin state<=ST_REPLAY;sector_busy<=1'b1;end
                end
                ST_REPLAY: if (sector_byte_ready) begin
                    replay_valid<=0;
                    if (replay_index==9'd511) begin state<=ST_DONE;sector_busy<=1'b1;end
                    else begin replay_index<=replay_index+1'b1; begin state<=ST_FETCH;sector_busy<=1'b1;end end
                end
                ST_DONE: begin sector_done<=1; begin state<=ST_IDLE;sector_busy<=1'b0;end end
                ST_RESET: begin
                    if (!reader_ready) ready_low_seen<=1;
                    if (reset_count>=ABORT_RESET_CYCLES-1) begin
                        timer<=0; begin state<=ST_REINIT;sector_busy<=1'b1;end
                    end else reset_count<=reset_count+1'b1;
                end
                ST_REINIT: begin
                    if (!reader_ready) ready_low_seen<=1;
                    if (ready_low_seen && reader_ready && !reader_busy &&
                        !reader_valid && !reader_done) begin begin state<=ST_IDLE;sector_busy<=1'b0;end timer<=0; end
                    else if (reader_init_error!=0 || timer>=REINIT_CYCLES-1) begin
                        sector_error<=ERR_REINIT; begin state<=ST_OFFLINE;sector_busy<=1'b0;end
                    end else timer<=timer+1'b1;
                end
                ST_OFFLINE: if (sector_req && !abort) begin
                    sector_error<=ERR_REINIT; sector_done<=1;
                end
                default: begin replay_valid<=0; begin state<=ST_IDLE;sector_busy<=1'b0;end end
            endcase
        end
    end
endmodule
