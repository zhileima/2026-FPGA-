`timescale 1ns/1ps
// Error namespaces: raw reader 1..7 -> 41..47; raw init 1..15 -> 51..5f.
module sd_media_service #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SPI_INIT_CLK_DIV = 250,
    parameter integer SPI_READ_CLK_DIV = 2,
    parameter integer INIT_STARTUP_MS = 100,
    parameter AUTO_INIT = 1'b1,
    parameter integer POWER_UP_BYTES = 10,
    parameter integer MAX_RESPONSE_BYTES = 16,
    parameter integer MAX_ACMD41_ATTEMPTS = 2048,
    parameter integer MAX_R1_BYTES = 16,
    parameter integer MAX_TOKEN_BYTES = 4096,
    parameter CHECK_DATA_CRC = 1'b1
) (
    input wire clk, input wire rst_n, input wire init_start,
    output wire init_busy, output wire init_done, output wire init_ready,
    output wire [7:0] init_error,
    output wire card_high_capacity, output wire [31:0] card_ocr,
    output wire owner_reader,
    input wire sector_req, input wire [31:0] sector_lba,
    output wire sector_busy, output wire sector_done,
    output wire sector_valid, output wire [7:0] sector_byte,
    output wire [8:0] sector_byte_index, output wire [7:0] sector_error,
    output wire sd_cs_n, output wire sd_sclk, output wire sd_mosi,
    input wire sd_miso
);
    localparam [63:0] STARTUP_CYCLES = (64'd1 * CLK_FREQ_HZ * INIT_STARTUP_MS + 999) / 1000;
    reg auto_pending;
    wire init_cs_n, init_sclk, init_mosi;
    wire reader_cs_n, reader_sclk, reader_mosi;
    wire [7:0] init_raw_error, reader_raw_error;
    // Never seize the SPI bus while a sector transfer is active.
    wire selected_init_start = (auto_pending || init_start) && !sector_busy;
    assign owner_reader = init_ready;
    assign sd_cs_n = owner_reader ? reader_cs_n : init_cs_n;
    assign sd_sclk = owner_reader ? reader_sclk : init_sclk;
    assign sd_mosi = owner_reader ? reader_mosi : init_mosi;
    assign init_error = init_raw_error == 0 ? 8'd0 : 8'h50 + init_raw_error;
    assign sector_error = reader_raw_error == 0 ? 8'd0 : 8'h40 + reader_raw_error;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) auto_pending <= AUTO_INIT;
        else if (selected_init_start) auto_pending <= 1'b0;
    end
    initial begin
        if (CLK_FREQ_HZ < 1 || SPI_INIT_CLK_DIV < 2 || SPI_READ_CLK_DIV < 1 ||
            64'd1*CLK_FREQ_HZ > 64'd800000*SPI_INIT_CLK_DIV ||
            64'd1*CLK_FREQ_HZ > 64'd50000000*SPI_READ_CLK_DIV ||
            INIT_STARTUP_MS < 0 || STARTUP_CYCLES > 64'h3fffffff ||
            POWER_UP_BYTES < 10 || MAX_RESPONSE_BYTES < 1 ||
            MAX_ACMD41_ATTEMPTS < 1 || MAX_ACMD41_ATTEMPTS > 65535 ||
            MAX_R1_BYTES < 1 || MAX_TOKEN_BYTES < 1) begin
            $display("SD_MEDIA_CONFIG_ERROR invalid timing or response limits");
            $finish;
        end
    end
    sd_spi_init #(
        .SPI_CLK_DIV(SPI_INIT_CLK_DIV), .POWER_UP_BYTES(POWER_UP_BYTES),
        .MAX_RESPONSE_BYTES(MAX_RESPONSE_BYTES),
        .MAX_ACMD41_ATTEMPTS(MAX_ACMD41_ATTEMPTS),
        .STARTUP_DELAY_CYCLES(STARTUP_CYCLES)
    ) u_init (
        .clk(clk), .rst_n(rst_n), .init_start(selected_init_start),
        .init_busy(init_busy), .init_done(init_done), .init_ready(init_ready),
        .error_code(init_raw_error), .card_high_capacity(card_high_capacity),
        .ocr(card_ocr), .last_cmd(), .last_r1(), .acmd41_attempts(),
        .sd_cs_n(init_cs_n), .sd_sclk(init_sclk), .sd_mosi(init_mosi), .sd_miso(sd_miso)
    );
    sd_spi_sector_reader #(
        .SPI_CLK_DIV(SPI_READ_CLK_DIV), .MAX_R1_BYTES(MAX_R1_BYTES),
        .MAX_TOKEN_BYTES(MAX_TOKEN_BYTES), .CHECK_DATA_CRC(CHECK_DATA_CRC)
    ) u_reader (
        .clk(clk), .rst_n(rst_n), .init_ready(init_ready && !selected_init_start),
        .card_high_capacity(card_high_capacity), .sector_req(sector_req),
        .sector_lba(sector_lba), .sector_busy(sector_busy),
        .sector_done(sector_done), .sector_valid(sector_valid),
        .sector_byte(sector_byte), .sector_byte_index(sector_byte_index),
        .sector_error(reader_raw_error), .last_r1(),
        .sd_cs_n(reader_cs_n), .sd_sclk(reader_sclk), .sd_mosi(reader_mosi), .sd_miso(sd_miso)
    );
endmodule
