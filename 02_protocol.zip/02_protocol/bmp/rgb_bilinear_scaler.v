`timescale 1ns/1ps
// Streaming separable bilinear scaler. Pixels enter and leave in file-row
// order; BMP bottom-up correction remains the SDRAM writer's responsibility.
// Only two horizontally scaled rows are stored. No RAM contents are reset.
// Endpoint-aligned Q8 coordinates use quotient AND remainder accumulation,
// so truncating a fixed step never introduces accumulated coordinate drift.
module rgb_bilinear_scaler #(
    parameter integer OUT_WIDTH = 640,
    parameter integer OUT_HEIGHT = 480,
    parameter integer MAX_SOURCE_DIM = 4096
)(
    input wire clk, input wire rst, input wire start, input wire abort,
    input wire [15:0] src_width, input wire [15:0] src_height,
    input wire in_valid, output wire in_ready, input wire [23:0] in_rgb,
    output reg out_valid, input wire out_ready, output reg [23:0] out_rgb,
    output reg done, output wire busy, output reg error
);
    localparam integer SB = (MAX_SOURCE_DIM < 2) ? 1 : $clog2(MAX_SOURCE_DIM+1);
    localparam integer CB = SB+8;
    localparam integer XB = (OUT_WIDTH < 2) ? 1 : $clog2(OUT_WIDTH);
    localparam integer YB = (OUT_HEIGHT < 2) ? 1 : $clog2(OUT_HEIGHT);
    localparam integer XR = (OUT_WIDTH < 2) ? 1 : $clog2(OUT_WIDTH);
    localparam integer YR = (OUT_HEIGHT < 2) ? 1 : $clog2(OUT_HEIGHT);
    localparam [XR:0] X_DEN = (OUT_WIDTH < 2) ? 1 : OUT_WIDTH-1;
    localparam [YR:0] Y_DEN = (OUT_HEIGHT < 2) ? 1 : OUT_HEIGHT-1;
    localparam [3:0] IDLE=0, DIVIDE=1, H_INPUT=2, H_CHECK=3,
        BLEND_MULT=4, BLEND_STORE=5, H_DRAIN=6, ROW_CHECK=7,
        V_READ=8, V_SELECT=9, V_EMIT=10, FRAME_DRAIN=11,
        H_PREP=12, V_PREP=13;

    reg [3:0] state;
    // Store the final source indices once at frame start. Recomputing
    // width/height minus one in every availability decision created a long
    // subtract -> edge detect -> add -> compare -> register-enable path.
    reg [SB-1:0] width_last, height_last;
    reg [SB:0] horizontal_needed_q, vertical_needed_q;
    reg [SB-1:0] input_x, input_y, current_x, row_index;
    reg source_complete;
    reg [23:0] previous_rgb, current_rgb;
    reg current_present;
    reg [XB-1:0] horizontal_x, output_x;
    reg [YB-1:0] output_y;
    reg [CB-1:0] x_coord, y_coord;
    reg [XR-1:0] x_error, div_x_rem;
    reg [YR-1:0] y_error, div_y_rem;
    reg [CB-1:0] div_x_num, div_y_num;
    reg [$clog2(CB+1)-1:0] div_bits_left;
    wire [XR:0] div_x_trial={div_x_rem,div_x_num[CB-1]};
    wire [YR:0] div_y_trial={div_y_rem,div_y_num[CB-1]};
    wire div_x_subtract=div_x_trial>=X_DEN;
    wire div_y_subtract=div_y_trial>=Y_DEN;
    wire [XR:0] div_x_remainder=div_x_subtract ? div_x_trial-X_DEN : div_x_trial;
    wire [YR:0] div_y_remainder=div_y_subtract ? div_y_trial-Y_DEN : div_y_trial;
    wire [CB-1:0] div_x_quot_next={div_x_num[CB-2:0],div_x_subtract};
    wire [CB-1:0] div_y_quot_next={div_y_num[CB-2:0],div_y_subtract};
    // Restoring division shifts one numerator bit out per clock and writes
    // the quotient bit into that now-free low position. After exactly CB
    // clocks, div_*_num contains the complete quotient and div_*_rem the
    // final remainder. Neither register changes during pixel processing.
    // Reuse those completed values directly instead of copying them into
    // separate quotient/step/step-remainder banks with duplicate enables.
    wire [CB-1:0] x_step=(OUT_WIDTH==1) ? {CB{1'b0}} : div_x_num;
    wire [CB-1:0] y_step=(OUT_HEIGHT==1) ? {CB{1'b0}} : div_y_num;
    wire [XR-1:0] x_step_rem=(OUT_WIDTH==1) ? {XR{1'b0}} : div_x_rem;
    wire [YR-1:0] y_step_rem=(OUT_HEIGHT==1) ? {YR{1'b0}} : div_y_rem;
    wire [XR:0] next_x_error={1'b0,x_error}+{1'b0,x_step_rem};
    wire [YR:0] next_y_error={1'b0,y_error}+{1'b0,y_step_rem};
    wire x_carry=next_x_error>=X_DEN;
    wire y_carry=next_y_error>=Y_DEN;
    wire [SB-1:0] horizontal_floor=x_coord[CB-1:8];
    wire [SB-1:0] vertical_floor=y_coord[CB-1:8];
    wire h_needs_right=x_coord[7:0]!=0 && horizontal_floor!=width_last;
    wire v_needs_next=y_coord[7:0]!=0 && vertical_floor!=height_last;
    wire [SB:0] horizontal_needed={1'b0,horizontal_floor}+h_needs_right;
    wire [SB:0] vertical_needed={1'b0,vertical_floor}+v_needs_next;
    wire input_last=input_x==width_last && input_y==height_last;
    wire accept_input=in_valid && in_ready;

    (* ram_style = "block" *) reg [23:0] line0 [0:OUT_WIDTH-1];
    (* ram_style = "block" *) reg [23:0] line1 [0:OUT_WIDTH-1];
    reg [23:0] line0_q, line1_q;
    reg [23:0] blend_left, blend_right;
    reg [7:0] blend_weight;
    reg blend_vertical;
    wire signed [8:0] diff_r=$signed({1'b0,blend_right[23:16]})-$signed({1'b0,blend_left[23:16]});
    wire signed [8:0] diff_g=$signed({1'b0,blend_right[15:8]})-$signed({1'b0,blend_left[15:8]});
    wire signed [8:0] diff_b=$signed({1'b0,blend_right[7:0]})-$signed({1'b0,blend_left[7:0]});
    reg signed [17:0] product_r, product_g, product_b;
    wire signed [18:0] sum_r=$signed({3'b000,blend_left[23:16],8'b0})+$signed({product_r[17],product_r});
    wire signed [18:0] sum_g=$signed({3'b000,blend_left[15:8],8'b0})+$signed({product_g[17],product_g});
    wire signed [18:0] sum_b=$signed({3'b000,blend_left[7:0],8'b0})+$signed({product_b[17],product_b});
    wire [23:0] blended_rgb={sum_r[15:8],sum_g[15:8],sum_b[15:8]};

    assign busy=state!=IDLE;
    assign in_ready=!source_complete &&
                    (state==H_INPUT || state==H_DRAIN || state==FRAME_DRAIN);

    // Independent synchronous RAM ports: one row is written horizontally,
    // both rows are read at the same output column during vertical scaling.
    always @(posedge clk) begin
        if(!rst && !abort && !start) begin
            if(state==BLEND_STORE && !blend_vertical) begin
                if(row_index[0]) line1[horizontal_x]<=blended_rgb;
                else line0[horizontal_x]<=blended_rgb;
            end
            if(state==V_READ) begin
                line0_q<=line0[output_x];
                line1_q<=line1[output_x];
            end
        end
    end

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE;width_last<=0;height_last<=0;
            horizontal_needed_q<=0;vertical_needed_q<=0;
            input_x<=0;input_y<=0;current_x<=0;row_index<=0;source_complete<=0;
            previous_rgb<=0;current_rgb<=0;current_present<=0;
            horizontal_x<=0;output_x<=0;output_y<=0;
            x_coord<=0;y_coord<=0;
            x_error<=0;y_error<=0;
            div_x_rem<=0;div_y_rem<=0;div_x_num<=0;div_y_num<=0;
            div_bits_left<=0;
            blend_left<=0;blend_right<=0;blend_weight<=0;blend_vertical<=0;
            product_r<=0;product_g<=0;product_b<=0;
            out_valid<=0;out_rgb<=0;done<=0;error<=0;
        end else begin
            done<=0;
            if(start) begin
                out_valid<=0;error<=0;source_complete<=0;
                input_x<=0;input_y<=0;current_x<=0;row_index<=0;
                previous_rgb<=0;current_rgb<=0;current_present<=0;
                horizontal_x<=0;output_x<=0;output_y<=0;
                x_coord<=0;y_coord<=0;
                x_error<=0;y_error<=0;
                div_x_rem<=0;div_y_rem<=0;
                width_last<=src_width[SB-1:0]-1'b1;height_last<=src_height[SB-1:0]-1'b1;
                horizontal_needed_q<=0;vertical_needed_q<=0;
                div_x_num<=(src_width-16'd1)<<8;
                div_y_num<=(src_height-16'd1)<<8;
                div_bits_left<=CB;
                if(src_width==0 || src_height==0 ||
                   src_width>MAX_SOURCE_DIM || src_height>MAX_SOURCE_DIM) begin
                    error<=1;state<=IDLE;
                end else state<=DIVIDE;
            end else if(abort) begin
                state<=IDLE;out_valid<=0;source_complete<=0;
            end else begin
                if(accept_input) begin
                    if(input_x==width_last) begin
                        input_x<=0;
                        if(input_y==height_last) source_complete<=1;
                        else input_y<=input_y+1'b1;
                    end else input_x<=input_x+1'b1;
                end
                case(state)
                    DIVIDE:begin
                        div_x_num<=div_x_quot_next;div_y_num<=div_y_quot_next;
                        div_x_rem<=div_x_remainder[XR-1:0];
                        div_y_rem<=div_y_remainder[YR-1:0];
                        div_bits_left<=div_bits_left-1'b1;
                        if(div_bits_left==1) begin
                            state<=H_INPUT;
                        end
                    end
                    H_INPUT:if(accept_input) begin
                        previous_rgb<=current_rgb;current_rgb<=in_rgb;
                        current_x<=input_x;current_present<=1;state<=H_PREP;
                    end
                    // The required source index and its availability are
                    // evaluated on separate clocks. Coordinates are stable
                    // through PREP/CHECK and no input is accepted in either.
                    H_PREP:begin
                        horizontal_needed_q<=horizontal_needed;
                        state<=H_CHECK;
                    end
                    H_CHECK:begin
                        if(current_present && {1'b0,current_x}>=horizontal_needed_q) begin
                            blend_left<=(current_x==horizontal_floor) ? current_rgb : previous_rgb;
                            blend_right<=current_rgb;blend_weight<=x_coord[7:0];
                            blend_vertical<=0;state<=BLEND_MULT;
                        end else state<=H_INPUT;
                    end
                    BLEND_MULT:begin
                        // Shared three-channel multipliers for both axes.
                        product_r<=diff_r*$signed({1'b0,blend_weight});
                        product_g<=diff_g*$signed({1'b0,blend_weight});
                        product_b<=diff_b*$signed({1'b0,blend_weight});
                        state<=BLEND_STORE;
                    end
                    BLEND_STORE:begin
                        if(blend_vertical) begin
                            out_rgb<=blended_rgb;out_valid<=1;state<=V_EMIT;
                        end else if(horizontal_x==OUT_WIDTH-1) begin
                            if(current_x==width_last) state<=V_PREP;
                            else state<=H_DRAIN;
                        end else begin
                            horizontal_x<=horizontal_x+1'b1;
                            x_coord<=x_coord+x_step+x_carry;
                            x_error<=x_carry ? next_x_error-X_DEN : next_x_error;
                            state<=H_PREP;
                        end
                    end
                    H_DRAIN:if(accept_input && input_x==width_last) state<=V_PREP;
                    V_PREP:begin
                        vertical_needed_q<=vertical_needed;
                        state<=ROW_CHECK;
                    end
                    ROW_CHECK:begin
                        if({1'b0,row_index}>=vertical_needed_q) begin
                            output_x<=0;state<=V_READ;
                        end else begin
                            row_index<=row_index+1'b1;
                            current_present<=0;horizontal_x<=0;x_coord<=0;x_error<=0;
                            state<=H_INPUT;
                        end
                    end
                    V_READ:state<=V_SELECT;
                    V_SELECT:begin
                        if(row_index==vertical_floor) begin
                            blend_left<=row_index[0] ? line1_q : line0_q;
                            blend_right<=row_index[0] ? line1_q : line0_q;
                        end else begin
                            blend_left<=row_index[0] ? line0_q : line1_q;
                            blend_right<=row_index[0] ? line1_q : line0_q;
                        end
                        blend_weight<=y_coord[7:0];blend_vertical<=1;state<=BLEND_MULT;
                    end
                    V_EMIT:if(out_valid && out_ready) begin
                        out_valid<=0;
                        if(output_x==OUT_WIDTH-1) begin
                            if(output_y==OUT_HEIGHT-1) begin
                                if(source_complete) begin done<=1;state<=IDLE;end
                                else state<=FRAME_DRAIN;
                            end else begin
                                output_y<=output_y+1'b1;
                                y_coord<=y_coord+y_step+y_carry;
                                y_error<=y_carry ? next_y_error-Y_DEN : next_y_error;
                                state<=V_PREP;
                            end
                        end else begin output_x<=output_x+1'b1;state<=V_READ;end
                    end
                    FRAME_DRAIN:if(accept_input && input_last) begin done<=1;state<=IDLE;end
                    default:;
                endcase
            end
        end
    end

    initial begin
        if(OUT_WIDTH<1 || OUT_WIDTH>4096 || OUT_HEIGHT<1 || OUT_HEIGHT>4096 ||
           MAX_SOURCE_DIM<1 || MAX_SOURCE_DIM>65535) begin
            $display("ERROR: rgb_bilinear_scaler parameter range");$finish;
        end
    end
endmodule
