`timescale 1ns/1ps
// Named FAT32 resources, atomic CRC-checked sectors and strict BMP24 decoding.
// scan_found_sector is an opaque slot token 0..7, never a raw image LBA.
module fat32_bmp_read #(
    parameter integer CLK_FREQ_HZ=100_000_000,
    parameter integer SPI_INIT_CLK_DIV=250,
    parameter integer SPI_READ_CLK_DIV=2,
    parameter integer SECTOR_TIMEOUT_MS=500,
    parameter integer WRITE_ACK_TIMEOUT_MS=500,
    parameter integer LOAD_TIMEOUT_MS=5000,
    parameter integer REINIT_TIMEOUT_MS=1500,
    parameter [87:0] NAME0="PIC1    BMP",NAME1="PIC2    BMP",
    parameter [87:0] NAME2="PIC3    BMP",NAME3="PIC4    BMP",
    parameter [87:0] NAME4="PIC5    BMP",NAME5="PIC6    BMP",
    parameter [87:0] NAME6="PIC7    BMP",NAME7="PIC8    BMP",
    parameter integer IMAGE_COUNT=4, OSD_ENABLE=0,
    parameter integer MAX_DIR_SECTORS=256,
    parameter integer MAX_FILE_CLUSTERS=8192,
    parameter [31:0] MEDIA_LAST_LBA=32'hffffffff,
    parameter integer RAW_AUDIO_ENABLE=0,
    parameter integer FAT_AUDIO_ENABLE=0,
    parameter integer MUSIC_TRACK_COUNT=1,
    parameter integer IMAGE_SCALE_ENABLE=0, MAX_SOURCE_DIM=4096,
    parameter integer IMAGE_LONG_NAME_ENABLE=0, START_PAGE_ENABLE=0, END_PAGE_ENABLE=0
)(
    input clk,input rst,output ready,input scan_start,input [3:0] scan_target_count,
    output reg scan_done,output reg scan_found_valid,output reg [31:0] scan_found_sector,
    output reg [2:0] scan_found_slot,output reg [3:0] scan_found_total,
    input load_start,input load_is_start,output start_present,input load_is_end,output end_present,input [31:0] load_sector,output sd_init_done,
    input scan_pause,input load_abort,output reg load_done,output reg load_error,
    output reg [7:0] bmp_error,output reg error_valid,output reg error_is_scan,
    output [3:0] state_code,input [15:0] bmp_width,input [15:0] bmp_height,
    output write_req,input write_req_ack,output bmp_data_wr_en,output [23:0] bmp_data,
    input bmp_pixel_ready,output [15:0] source_width,source_height,
    output fs_mounted,output [7:0] fs_present_mask,output reg fs_fragment_seen,
    output reg fs_large_lba_seen,output sd_high_capacity,
    output music_present,output [31:0] music_total_sectors,
    input [4:0] music_index,output [20:0] music_valid_mask,output music_idle,
    // Byte-addressed OSD.BIN shares the same FAT streamer and physical SD owner.
    // Start is accepted only on osd_ready; successful done follows every byte and EOC.
    input osd_start,output osd_ready,output osd_present,
    output osd_valid,output [7:0] osd_byte,output [15:0] osd_offset,
    output reg osd_done,output reg [7:0] osd_error,input osd_byte_ready,
    // PCM and background image caching arbitrate the one CRC-checked sector service.
    input raw_enable,input raw_req,input [31:0] raw_lba,output raw_ready,
    output raw_valid,output [7:0] raw_byte,output [8:0] raw_index,
    output raw_done,output [7:0] raw_error,input raw_byte_ready,
    output SD_nCS,output SD_DCLK,output SD_MOSI,input SD_MISO
);
    localparam IDLE=0,START_FILE=1,LOADING=2,DRAIN=3,OFFLINE=4,
        OSD_START=8,OSD_RUN=9,OSD_DRAIN=10,METADATA_CAPTURE=11;
    localparam OWNER_NONE=0,OWNER_SCAN=1,OWNER_FILE=2,OWNER_AUDIO=3;
    localparam [63:0] ACK_CYCLES=(64'd1*CLK_FREQ_HZ*WRITE_ACK_TIMEOUT_MS+999)/1000;
    localparam [63:0] LOAD_CYCLES=(64'd1*CLK_FREQ_HZ*LOAD_TIMEOUT_MS+999)/1000;
    localparam [63:0] INIT_CYCLES=(64'd1*CLK_FREQ_HZ*REINIT_TIMEOUT_MS+999)/1000;
    // Preserve independent same-domain reset branches. The parent reset
    // already releases synchronously; each leaf releases one clock later.
    // Keep all business recovery/removal checks active in static timing.
    (* preserve = "true", keep = "true" *) reg [4:0] local_reset;
    always @(posedge clk or posedge rst) begin
        if(rst) local_reset<=5'b11111;
        else local_reset<=5'b00000;
    end
    reg [3:0] state;
    reg [1:0] owner;
    reg file_start,file_abort,decoder_abort,sector_abort;
    reg [31:0] selected_cluster,selected_size;
    reg [31:0] selected_budget;
    reg [4:0] descriptor_slot,descriptor_reply_slot;
    reg metadata_is_osd;
    // Separate small PCM context; image and PCM share one atomic SD sector.
    reg [27:0] music_cluster_cache;
    reg [22:0] music_sectors_cache;
    reg [4:0] music_cache_index,audio_open_index;
    reg music_cache_valid;
    wire audio_ready,audio_idle,audio_valid,audio_done,audio_fragment;
    wire audio_sector_wants,audio_sector_req,audio_sector_ready;
    wire [7:0] audio_byte,audio_error;
    wire [8:0] audio_index;
    wire [31:0] audio_sector_lba;
    localparam integer LOAD_TIMER_BITS=LOAD_CYCLES<2 ? 1 : $clog2(LOAD_CYCLES);
    reg [LOAD_TIMER_BITS-1:0] load_timer;
    reg load_expired;
    wire load_timeout = LOAD_CYCLES<2 ? 1'b1 : load_expired;
    reg [31:0] ack_timer,init_timer;
    reg scan_started,scan_terminal,init_fault_reported;
    reg [7:0] announced;
    wire [7:0] target_mask=scan_target_count>=8 ? 8'hff :
        (8'hff >> (8-scan_target_count));
    wire scan_busy,scan_done_pulse,scan_sector_req,scan_byte_ready;
    wire [7:0] scan_error,sectors_per_cluster;
    wire [31:0] fat_start_lba,data_start_lba,max_cluster,fat_sector_count,volume_last_lba;
    wire [7:0] resource_valid;
    wire scanner_osd_valid;
    wire scanner_start_valid,scanner_end_valid;
    wire opening_start=START_PAGE_ENABLE!=0 && load_is_start;
    wire opening_end=END_PAGE_ENABLE!=0 && load_is_end;
    assign start_present=START_PAGE_ENABLE!=0 && scanner_start_valid;
    assign end_present=END_PAGE_ENABLE!=0 && scanner_end_valid;
    wire scanner_music_valid;
    wire [20:0] scanner_music_mask;
    // The default one-file mode remains safe for legacy named-port callers
    // that leave the new selection input unconnected.
    wire [4:0] selected_music_index=MUSIC_TRACK_COUNT==1 ? 5'd0 : music_index;
    wire [4:0] music_descriptor_slot=5'd8+selected_music_index;
    // Music metadata stays cached while the synchronous one-port catalog
    // briefly serves an image/OSD open. Never expose those descriptor bytes
    // as the selected song length or falsely drop music_present.
    wire [4:0] descriptor_read_slot=state==METADATA_CAPTURE ? descriptor_slot :
        state==IDLE && load_start ? (opening_end ? 5'd31 : opening_start ? 5'd30 : {2'b0,load_sector[2:0]}) :
        state==IDLE && OSD_ENABLE!=0 && osd_start ? 5'd29 : music_descriptor_slot;
    wire [63:0] descriptor_read_data;
    wire descriptor_music_ready=descriptor_reply_slot==music_descriptor_slot;
    wire [31:0] selected_music_cluster=descriptor_read_data[63:32];
    wire [31:0] selected_music_size=descriptor_read_data[31:0];
    // Tag follows the synchronous catalog RAM read. A changed music index
    // cannot advertise the previous track's length for even one request.
    always @(posedge clk or posedge local_reset[4]) begin
        if(local_reset[4]) descriptor_reply_slot<=5'd31;
        else descriptor_reply_slot<=descriptor_read_slot;
    end
    wire [31:0] scan_sector_lba;
    wire file_busy,file_done,file_valid,file_pending,file_sector_req,file_sector_ready,file_fragment;
    wire [7:0] file_byte,file_error;
    wire [31:0] file_offset,file_sector_lba;
    wire stream_busy,stream_done,stream_valid,stream_byte_ready,queue_busy;
    wire [7:0] stream_byte,stream_error;
    wire [31:0] stream_offset;
    // The byte queue remains busy through its terminal pulse even if the
    // streamer has already returned to IDLE after the final FAT check.
    assign file_busy=stream_busy || queue_busy;
    wire decoder_ready,decoder_done,decoder_error_valid,decoder_busy;
    wire [7:0] decoder_error;
    wire sector_busy,sector_valid,sector_done,sector_byte_ready;
    wire [7:0] sector_byte,sector_error;
    wire [8:0] sector_index;
    wire reader_req,reader_busy,reader_valid,reader_done,reader_ready,sd_abort_reset;
    wire scan_wants=scan_sector_req && state==IDLE;
    wire legacy_raw_ready=RAW_AUDIO_ENABLE!=0 && raw_enable && reader_ready &&
        state==IDLE && scan_done && !scan_busy && owner==OWNER_NONE &&
        !sector_busy && !file_busy && !file_sector_req && !scan_wants;
    wire context_enable=FAT_AUDIO_ENABLE!=0 && raw_enable && scan_done && fs_mounted &&
        !scan_start && state!=OFFLINE &&
        (audio_idle || audio_open_index==selected_music_index);
    assign raw_ready=FAT_AUDIO_ENABLE!=0 ? audio_ready : legacy_raw_ready;
    wire logical_audio_request=FAT_AUDIO_ENABLE!=0 && raw_req && raw_ready;
    wire audio_wants=FAT_AUDIO_ENABLE!=0 ? audio_sector_req : legacy_raw_ready && raw_req;
    // A previously registered file/scan request wins. New image requests are
    // inhibited by audio_sector_wants, so audio waits at most that one sector.
    wire [31:0] sector_lba=file_sector_req ? file_sector_lba :
        scan_wants ? scan_sector_lba : FAT_AUDIO_ENABLE!=0 ? audio_sector_lba : raw_lba;
    wire sector_req=owner==OWNER_NONE && !sector_busy &&
        (file_sector_req || scan_wants || audio_wants);
    wire osd_session=OSD_ENABLE!=0 && (state==OSD_START || state==OSD_RUN || state==OSD_DRAIN);
    wire image_session=state==START_FILE || state==LOADING || state==DRAIN;
    assign osd_present=OSD_ENABLE!=0 && scan_done && scanner_osd_valid;
    assign osd_ready=OSD_ENABLE!=0 && scan_done && ready && !scan_busy && !raw_enable && !load_start;
    assign osd_valid=state==OSD_RUN && file_valid;
    assign osd_byte=file_byte;
    assign osd_offset=file_offset[15:0];
    wire file_queue_flush=file_abort || decoder_abort ||
        (state==LOADING && load_abort) || state==DRAIN || state==OSD_DRAIN || state==OFFLINE;
    // Exact image-side qualification of the registered queue head. DRAIN is
    // already cancelled, and OSD_DRAIN/OFFLINE cannot be image sessions. Keep
    // these unrelated state decodes out of the BMP byte-accept/error path.
    // Queue pop, error/flush priority and all external handshakes are unchanged.
    wire image_file_valid=file_pending && (state==START_FILE || state==LOADING) &&
        !local_reset[2] && !file_start && !file_abort && !decoder_abort &&
        !(state==LOADING && load_abort) && stream_error==0;
    assign raw_valid=FAT_AUDIO_ENABLE!=0 ? audio_valid : sector_valid && owner==OWNER_AUDIO;
    assign raw_byte=FAT_AUDIO_ENABLE!=0 ? audio_byte : sector_byte;
    assign raw_index=FAT_AUDIO_ENABLE!=0 ? audio_index : sector_index;
    assign raw_done=FAT_AUDIO_ENABLE!=0 ? audio_done : sector_done && owner==OWNER_AUDIO;
    assign raw_error=FAT_AUDIO_ENABLE!=0 ? (audio_done ? audio_error : 8'd0) :
        owner==OWNER_AUDIO ? sector_error : 8'd0;
    assign music_valid_mask=FAT_AUDIO_ENABLE!=0 && scan_done ? scanner_music_mask : 21'd0;
    assign music_present=music_cache_valid && music_cache_index==selected_music_index &&
        selected_music_index<MUSIC_TRACK_COUNT && selected_music_index<21 &&
        music_valid_mask[selected_music_index];
    assign music_total_sectors=music_present ? {9'b0,music_sectors_cache} : 32'd0;
    assign music_idle=FAT_AUDIO_ENABLE!=0 ? audio_idle && owner!=OWNER_AUDIO :
        state==IDLE && !file_busy && !sector_busy && owner==OWNER_NONE;
    always @(posedge clk or posedge local_reset[4]) begin
        if(local_reset[4]) begin
            music_cluster_cache<=0;music_sectors_cache<=0;music_cache_index<=0;
            music_cache_valid<=0;audio_open_index<=0;
        end else begin
            if(scan_start || !fs_mounted) music_cache_valid<=0;
            else if(descriptor_music_ready) begin
                music_cluster_cache<=selected_music_cluster[27:0];
                music_sectors_cache<=selected_music_size[31:9];
                music_cache_index<=selected_music_index;music_cache_valid<=1;
            end
            if(logical_audio_request && audio_idle) audio_open_index<=selected_music_index;
        end
    end
    wire [31:0] reader_lba,card_ocr;
    wire [7:0] reader_byte,reader_error,reader_init_error;
    wire [8:0] reader_index;
    wire scanner_paused=scan_pause || state!=IDLE;
    wire [7:0] new_found=(resource_valid & target_mask) & ~announced;
    assign sd_init_done=reader_ready;
    assign fs_present_mask=resource_valid & target_mask;
    assign ready=reader_ready && state==IDLE && owner==OWNER_NONE && !sector_busy && !file_busy &&
                 (!scan_busy || scanner_paused);
    assign state_code=state==OFFLINE ? 4'd12 : state==LOADING ? 4'd4 :
                      state==START_FILE ? 4'd3 : scan_busy ? 4'd1 : 4'd0;
    assign sector_byte_ready=owner==OWNER_SCAN ? scan_byte_ready :
        owner==OWNER_FILE ? (state==DRAIN ? 1'b1 : file_sector_ready) :
        owner==OWNER_AUDIO ? (FAT_AUDIO_ENABLE!=0 ? audio_sector_ready : raw_byte_ready) : 1'b0;
    task fail_load;
        input [7:0] code;
        begin
            bmp_error<=code;error_valid<=1;error_is_scan<=0;load_error<=1;
            file_abort<=1;decoder_abort<=1;state<=DRAIN;
        end
    endtask
    // Isolate the physical service reset from the high-fanout filesystem
    // reset. Abort still asserts immediately; release takes two SD clocks.
    // Business recovery/removal paths remain timed with no new exception.
    wire service_reset_async=rst || sd_abort_reset;
    (* async_reg = "true" *) reg [1:0] service_reset_pipe;
    always @(posedge clk or posedge service_reset_async) begin
        if(service_reset_async) service_reset_pipe<=2'b11;
        else service_reset_pipe<={service_reset_pipe[0],1'b0};
    end
    sd_media_service #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.SPI_INIT_CLK_DIV(SPI_INIT_CLK_DIV),
        .SPI_READ_CLK_DIV(SPI_READ_CLK_DIV),.INIT_STARTUP_MS(100),.AUTO_INIT(1),.CHECK_DATA_CRC(1)) u_sd_service(
        .clk(clk),.rst_n(!service_reset_pipe[1]),.init_start(1'b0),
        .init_busy(),.init_done(),.init_ready(reader_ready),.init_error(reader_init_error),
        .card_high_capacity(sd_high_capacity),.card_ocr(card_ocr),.owner_reader(),
        .sector_req(reader_req),.sector_lba(reader_lba),.sector_busy(reader_busy),
        .sector_done(reader_done),.sector_valid(reader_valid),.sector_byte(reader_byte),
        .sector_byte_index(reader_index),.sector_error(reader_error),
        .sd_cs_n(SD_nCS),.sd_sclk(SD_DCLK),.sd_mosi(SD_MOSI),.sd_miso(SD_MISO));
    sd_sector_adapter #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.SECTOR_TIMEOUT_MS(SECTOR_TIMEOUT_MS),
        .REINIT_TIMEOUT_MS(REINIT_TIMEOUT_MS)) u_atomic_sector(
        .clk(clk),.rst_n(!local_reset[0]),.abort(sector_abort),
        .sector_req(sector_req),.sector_lba(sector_lba),.sector_busy(sector_busy),
        .sector_valid(sector_valid),.sector_byte(sector_byte),.sector_byte_index(sector_index),
        .sector_done(sector_done),.sector_error(sector_error),.sector_byte_ready(sector_byte_ready),
        .reader_req(reader_req),.reader_lba(reader_lba),.reader_ready(reader_ready),
        .reader_init_error(reader_init_error),.reader_busy(reader_busy),.reader_valid(reader_valid),
        .reader_byte(reader_byte),.reader_byte_index(reader_index),.reader_done(reader_done),
        .reader_error(reader_error),.sd_abort_reset(sd_abort_reset));
    fat32_volume_scanner #(.IMAGE_LONG_NAME_ENABLE(IMAGE_LONG_NAME_ENABLE),
        .CLK_FREQ_HZ(CLK_FREQ_HZ),.SECTOR_TIMEOUT_MS(SECTOR_TIMEOUT_MS),
        .NAME0(NAME0),.NAME1(NAME1),.NAME2(NAME2),.NAME3(NAME3),
        .NAME4(NAME4),.NAME5(NAME5),.NAME6(NAME6),.NAME7(NAME7),
        .IMAGE_COUNT(IMAGE_COUNT),.OSD_ENABLE(OSD_ENABLE),.COMPACT_TABLE_ENABLE(1),
        .MUSIC_LOOKUP_ENABLE(FAT_AUDIO_ENABLE),.MUSIC_TRACK_COUNT(MUSIC_TRACK_COUNT),
        .MUSIC_NAME(MUSIC_TRACK_COUNT==1 ? "MUSIC   PCM" : "PCM1    PCM"),
        .START_PAGE_ENABLE(START_PAGE_ENABLE),.END_PAGE_ENABLE(END_PAGE_ENABLE),.MAX_DIR_SECTORS(MAX_DIR_SECTORS)) u_volume_scanner(
        .clk(clk),.rst_n(!local_reset[1]),.scan_start(scan_start),.scan_pause(scanner_paused),
        .scan_busy(scan_busy),.scan_done(scan_done_pulse),.fs_error(scan_error),.mounted(fs_mounted),
        .partition_lba(),.media_last_lba(MEDIA_LAST_LBA),.sectors_per_cluster(sectors_per_cluster),
        .fat_start_lba(fat_start_lba),.data_start_lba(data_start_lba),.max_cluster(max_cluster),
        .fat_sector_count(fat_sector_count),.volume_last_lba(volume_last_lba),
        .resource_valid(resource_valid),.osd_valid(scanner_osd_valid),.start_valid(scanner_start_valid),.end_valid(scanner_end_valid),
        .music_valid(scanner_music_valid),.music_valid_mask(scanner_music_mask),
        .descriptor_read_slot(descriptor_read_slot),.descriptor_read_data(descriptor_read_data),
        .sector_req(scan_sector_req),.sector_lba(scan_sector_lba),
        .sector_busy(sector_busy || owner!=OWNER_NONE || state!=IDLE),
        .sector_valid(sector_valid && owner==OWNER_SCAN),.sector_byte(sector_byte),
        .sector_byte_index(sector_index),.sector_done(sector_done && owner==OWNER_SCAN),
        .sector_error(sector_error),.sector_byte_ready(scan_byte_ready));
    // Only descriptors from the CRC-checked scanner catalog enter this path.
    // Its completed mount geometry is latched per file; generic users retain
    // the full validator through the streamer's default parameter value.
    fat32_file_streamer #(.VALIDATED_MOUNT_GEOMETRY(1),
        .CLK_FREQ_HZ(CLK_FREQ_HZ),.SECTOR_TIMEOUT_MS(SECTOR_TIMEOUT_MS),
        .MAX_VISITED_CLUSTERS(MAX_FILE_CLUSTERS),
        .RUNTIME_CLUSTER_BUDGET_ENABLE(FAT_AUDIO_ENABLE || OSD_ENABLE)) u_file_streamer(
        .clk(clk),.rst_n(!local_reset[2]),.file_start(file_start),.file_abort(file_abort),
        .first_cluster(selected_cluster),.file_size(selected_size),
        .file_cluster_budget(selected_budget),
        .sectors_per_cluster(sectors_per_cluster),.fat_start_lba(fat_start_lba),
        .data_start_lba(data_start_lba),.max_cluster(max_cluster),
        .fat_sector_count(fat_sector_count),.volume_last_lba(volume_last_lba),
        .file_busy(stream_busy),.file_done(stream_done),.file_valid(stream_valid),
        .file_byte(stream_byte),.file_byte_offset(stream_offset),.fs_error(stream_error),
        .byte_ready(stream_byte_ready),.fragment_seen(file_fragment),
        .sector_req(file_sector_req),.sector_lba(file_sector_lba),
        .sector_busy(sector_busy || owner!=OWNER_NONE || audio_sector_wants),
        .sector_valid(sector_valid && owner==OWNER_FILE),.sector_byte(sector_byte),
        .sector_byte_index(sector_index),.sector_done(sector_done && owner==OWNER_FILE),
        .sector_error(sector_error),.sector_byte_ready(file_sector_ready));
    // Keep the long sector-index/decoder and audio-ready/streamer paths on
    // opposite sides of registered byte and offset storage. A cancelled
    // session discards its buffered bytes before another file can open.
    fat32_file_byte_queue u_file_queue(
        .clk(clk),.rst(local_reset[2]),.start(file_start),.flush(file_queue_flush),
        .in_valid(stream_valid),.in_ready(stream_byte_ready),
        .in_byte(stream_byte),.in_offset(stream_offset),
        .in_done(stream_done),.in_error(stream_error),
        .out_valid(file_valid),.out_pending(file_pending),.out_ready(osd_session ? (state==OSD_RUN && osd_byte_ready) : decoder_ready),
        .out_byte(file_byte),.out_offset(file_offset),.out_done(file_done),
        .out_error(file_error),.busy(queue_busy));
    fat32_audio_sector_streamer #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.SECTOR_TIMEOUT_MS(SECTOR_TIMEOUT_MS)) u_audio_streamer(
        .clk(clk),.rst_n(!local_reset[2]),.enable(context_enable),
        .metadata_valid(music_present && reader_ready && !osd_session && !(OSD_ENABLE!=0 && osd_start)),
        .first_cluster({4'b0,music_cluster_cache}),.file_size({music_sectors_cache,9'b0}),
        .sectors_per_cluster(sectors_per_cluster),.fat_start_lba(fat_start_lba),
        .data_start_lba(data_start_lba),.max_cluster(max_cluster),
        .fat_sector_count(fat_sector_count),.volume_last_lba(volume_last_lba),
        .req(raw_req),.logical_lba(raw_lba),.ready(audio_ready),.idle(audio_idle),
        .valid(audio_valid),.data(audio_byte),.index(audio_index),.byte_ready(raw_byte_ready),
        .done(audio_done),.error(audio_error),.fragment_seen(audio_fragment),
        .sector_wants(audio_sector_wants),.sector_req(audio_sector_req),.sector_lba(audio_sector_lba),
        .sector_busy(sector_busy || owner!=OWNER_NONE || file_sector_req || scan_wants),
        .sector_valid(sector_valid && owner==OWNER_AUDIO),.sector_byte(sector_byte),
        .sector_index(sector_index),.sector_done(sector_done && owner==OWNER_AUDIO),
        .sector_error(sector_error),.sector_byte_ready(audio_sector_ready));
    wire legacy_ready,legacy_done,legacy_error_valid,legacy_busy,legacy_write_req,legacy_pixel_valid;
    wire [7:0] legacy_error;
    wire [23:0] legacy_rgb;
    fat32_bmp24_checked u_bmp24(
        .clk(clk),.rst(local_reset[3]),.start(file_start && image_session && IMAGE_SCALE_ENABLE==0),.abort(decoder_abort),
        .file_size(selected_size),.expected_width(bmp_width),.expected_height(bmp_height),
        .file_valid(image_file_valid),.file_ready(legacy_ready),.file_byte(file_byte),.file_offset(file_offset),
        .file_done(file_done && image_session),.file_error(file_error),.write_req(legacy_write_req),.write_req_ack(write_req_ack),
        .pixel_valid(legacy_pixel_valid),.pixel_rgb(legacy_rgb),.done(legacy_done),
        .error_valid(legacy_error_valid),.error_code(legacy_error),.busy(legacy_busy));
    generate if(IMAGE_SCALE_ENABLE!=0) begin : g_scaled_image
        bmp24_scaled_reader #(.OUT_WIDTH(640),.OUT_HEIGHT(480),.MAX_SOURCE_DIM(MAX_SOURCE_DIM)) u_bmp24_scaled(
            .clk(clk),.rst(local_reset[3]),.start(file_start && image_session),.abort(decoder_abort),
            .file_size(selected_size),.file_valid(image_file_valid),.file_ready(decoder_ready),
            .file_byte(file_byte),.file_offset(file_offset),.file_done(file_done && image_session),.file_error(file_error),
            .write_req(write_req),.write_req_ack(write_req_ack),.pixel_ready(bmp_pixel_ready),
            .pixel_valid(bmp_data_wr_en),.pixel_rgb(bmp_data),.source_width(source_width),.source_height(source_height),
            .header_valid(),.done(decoder_done),.error_valid(decoder_error_valid),.error_code(decoder_error),.busy(decoder_busy));
    end else begin : g_native_image
        assign decoder_ready=legacy_ready;
        assign decoder_done=legacy_done;
        assign decoder_error_valid=legacy_error_valid;
        assign decoder_error=legacy_error;
        assign decoder_busy=legacy_busy;
        assign write_req=legacy_write_req;
        assign bmp_data_wr_en=legacy_pixel_valid;
        assign bmp_data=legacy_rgb;
        assign source_width=bmp_width;
        assign source_height=bmp_height;
    end endgenerate
    // Register the terminal comparison one cycle before the deadline. Keep
    // the wide elapsed counter independent of decoder/abort priority logic;
    // LOADING cycle N still expires at exactly LOAD_CYCLES cycles.
    always @(posedge clk or posedge local_reset[4]) begin
        if(local_reset[4]) begin load_timer<=0;load_expired<=0;end
        else if(state==LOADING || state==OSD_RUN) begin
            load_timer<=load_timer+1'b1;
            if(LOAD_CYCLES<2 || load_timer>=LOAD_CYCLES-2) load_expired<=1;
        end else begin load_timer<=0;load_expired<=0;end
    end
    always @(posedge clk or posedge local_reset[4]) begin
        if(local_reset[4]) begin
            state<=IDLE;owner<=OWNER_NONE;file_start<=0;file_abort<=0;decoder_abort<=0;sector_abort<=0;
            selected_cluster<=0;selected_size<=0;ack_timer<=0;init_timer<=0;
            descriptor_slot<=0;metadata_is_osd<=0;
            selected_budget<=MAX_FILE_CLUSTERS;
            scan_started<=0;scan_terminal<=0;init_fault_reported<=0;announced<=0;
            scan_done<=0;scan_found_valid<=0;scan_found_sector<=0;scan_found_slot<=0;scan_found_total<=0;
            load_done<=0;load_error<=0;bmp_error<=0;error_valid<=0;error_is_scan<=0;
            fs_fragment_seen<=0;fs_large_lba_seen<=0;
            osd_done<=0;osd_error<=0;
        end else begin
            file_start<=0;file_abort<=0;decoder_abort<=0;sector_abort<=0;
            scan_found_valid<=0;load_done<=0;load_error<=0;error_valid<=0;osd_done<=0;
            if(sector_req) begin
                owner<=file_sector_req ? OWNER_FILE : scan_wants ? OWNER_SCAN : OWNER_AUDIO;
                if(!audio_wants && sector_lba>=32'd131072) fs_large_lba_seen<=1;
            end
            if(sector_done) owner<=OWNER_NONE;
            if(file_fragment || audio_fragment) fs_fragment_seen<=1;
            if(scan_start) begin
                scan_started<=1;scan_terminal<=0;scan_done<=0;announced<=0;scan_found_total<=0;
            end
            if(new_found!=0) begin
                scan_found_valid<=1;scan_found_total<=scan_found_total+1'b1;
                if(new_found[0]) begin announced[0]<=1;scan_found_slot<=0;scan_found_sector<=0;end
                else if(new_found[1]) begin announced[1]<=1;scan_found_slot<=1;scan_found_sector<=1;end
                else if(new_found[2]) begin announced[2]<=1;scan_found_slot<=2;scan_found_sector<=2;end
                else if(new_found[3]) begin announced[3]<=1;scan_found_slot<=3;scan_found_sector<=3;end
                else if(new_found[4]) begin announced[4]<=1;scan_found_slot<=4;scan_found_sector<=4;end
                else if(new_found[5]) begin announced[5]<=1;scan_found_slot<=5;scan_found_sector<=5;end
                else if(new_found[6]) begin announced[6]<=1;scan_found_slot<=6;scan_found_sector<=6;end
                else begin announced[7]<=1;scan_found_slot<=7;scan_found_sector<=7;end
            end
            if(scan_done_pulse) begin
                scan_terminal<=1;
                if(scan_error!=0) begin bmp_error<=scan_error;error_valid<=1;error_is_scan<=1;end
            end
            if(scan_terminal && new_found==0) scan_done<=1;
            if(reader_ready) init_timer<=0;
            else if(!sd_abort_reset && !init_fault_reported && state!=OFFLINE &&
                    !((RAW_AUDIO_ENABLE!=0 || FAT_AUDIO_ENABLE!=0) && raw_enable)) begin
                if(reader_init_error!=0 || init_timer>=INIT_CYCLES-1) begin
                    init_fault_reported<=1;bmp_error<=reader_init_error!=0 ? reader_init_error : 8'h3d;
                    error_valid<=1;error_is_scan<=1;scan_done<=1;scan_terminal<=1;state<=OFFLINE;
                end else init_timer<=init_timer+1'b1;
            end
            if(sector_error==8'h3d && sector_done && (owner!=OWNER_AUDIO || image_session)) begin
                bmp_error<=8'h3d;error_valid<=1;error_is_scan<=state!=LOADING;
                if(state==LOADING) load_error<=1;
                if(osd_session) begin osd_done<=1;osd_error<=8'h3d;end
                file_abort<=1;decoder_abort<=1;state<=OFFLINE;scan_done<=1;scan_terminal<=1;
            end else case(state)
                IDLE:begin
                    if(load_start && ready) begin
                        if(opening_end ? !end_present : opening_start ? !start_present :
                           (load_sector>7 || !fs_present_mask[load_sector[2:0]])) fail_load(8'h22);
                        else begin
                            descriptor_slot<=opening_end ? 5'd31 : opening_start ? 5'd30 : {2'b0,load_sector[2:0]};metadata_is_osd<=0;
                            state<=METADATA_CAPTURE;ack_timer<=0;
                        end
                    end else if(OSD_ENABLE!=0 && osd_start && osd_ready) begin
                        osd_error<=0;
                        if(!osd_present) begin osd_error<=8'h22;osd_done<=1;end
                        else begin descriptor_slot<=5'd29;metadata_is_osd<=1;state<=METADATA_CAPTURE;end
                    end
                end
                METADATA_CAPTURE:begin
                    selected_cluster<=descriptor_read_data[63:32];
                    selected_size<=descriptor_read_data[31:0];
                    selected_budget<=metadata_is_osd ? max_cluster-1'b1 : MAX_FILE_CLUSTERS;
                    if(!metadata_is_osd && load_abort) fail_load(8'h3b);
                    else state<=metadata_is_osd ? OSD_START : START_FILE;
                end
                START_FILE:begin file_start<=1;state<=LOADING;end
                LOADING:begin
                    if(decoder_error_valid) fail_load(decoder_error);
                    else if(decoder_done) begin load_done<=1;state<=DRAIN;end
                    else if(load_abort || load_timeout) begin
                        fail_load(8'h3b);sector_abort<=owner==OWNER_FILE;
                    end else if((write_req || write_req_ack) && ack_timer>=ACK_CYCLES-1) begin
                        fail_load(8'h3a);
                    end else begin
                        // Both halves of the request/acknowledge handshake are bounded.
                        if(write_req || write_req_ack) ack_timer<=ack_timer+1'b1;else ack_timer<=0;
                    end
                end
                DRAIN:if(!file_busy && !sector_busy && owner==OWNER_NONE) state<=IDLE;
                OSD_START:begin file_start<=1;state<=OSD_RUN;end
                OSD_RUN:begin
                    if(file_done) begin osd_done<=1;osd_error<=file_error;state<=OSD_DRAIN;end
                    else if(load_timeout) begin
                        file_abort<=1;sector_abort<=owner==OWNER_FILE;
                        osd_error<=8'h3b;osd_done<=1;state<=OSD_DRAIN;
                    end
                end
                OSD_DRAIN:begin
                    if(file_busy) file_abort<=1;
                    if(!file_busy && !sector_busy && owner==OWNER_NONE) state<=IDLE;
                end
                default:;
            endcase
        end
    end
endmodule

// Two registered entries cut both directions of the file byte handshake.
// There is deliberately no combinational ready bypass when the queue is full.
// The streamer holds in_error until its next start, so errors invalidate the
// queued tail immediately and their terminal pulse never waits for out_ready.
module fat32_file_byte_queue (
    input clk,input rst,input start,input flush,
    input in_valid,output in_ready,input [7:0] in_byte,input [31:0] in_offset,
    input in_done,input [7:0] in_error,
    output out_valid,output out_pending,input out_ready,output [7:0] out_byte,output [31:0] out_offset,
    output out_done,output [7:0] out_error,output busy
);
    reg [1:0] queued_count;
    reg [39:0] head_item,tail_item;
    reg pending_done,done_pulse;
    wire cancelled=rst || start || flush;
    assign in_ready=queued_count<2;
    assign out_pending=queued_count!=0;
    assign out_valid=out_pending && !cancelled && in_error==0;
    assign out_byte=head_item[7:0];
    assign out_offset=head_item[39:8];
    assign out_done=done_pulse && !cancelled;
    assign out_error=in_error;
    assign busy=queued_count!=0 || pending_done || done_pulse;
    wire push=in_valid && in_ready;
    wire pop=out_valid && out_ready;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            queued_count<=0;head_item<=0;tail_item<=0;
            pending_done<=0;done_pulse<=0;
        end else if(start || flush) begin
            queued_count<=0;pending_done<=0;done_pulse<=0;
        end else if(in_error!=0) begin
            queued_count<=0;pending_done<=0;done_pulse<=in_done;
        end else begin
            done_pulse<=0;
            if(in_done) pending_done<=1;
            // Test the old occupancy: the final pop must have completed in
            // an earlier cycle. Audio byte 511 can then set its completion
            // flag before the wrapper consumes this successful EOF pulse.
            if(pending_done && queued_count==0) begin
                pending_done<=0;done_pulse<=1;
            end
            case({push,pop})
                2'b10:begin
                    if(queued_count==0) head_item<={in_offset,in_byte};
                    else tail_item<={in_offset,in_byte};
                    queued_count<=queued_count+1'b1;
                end
                2'b01:begin
                    if(queued_count==2) head_item<=tail_item;
                    queued_count<=queued_count-1'b1;
                end
                2'b11:head_item<={in_offset,in_byte};
                default:;
            endcase
        end
    end
endmodule

// Strict byte-stream BMP24 decoder. A complete FAT file (including its final
// chain check) and exactly width*height RGB words are required for success.
// Positive-height rows remain in file order; frame_read_write flips rows.
module fat32_bmp24_checked (
    input clk,input rst,input start,input abort,
    input [31:0] file_size,input [15:0] expected_width,input [15:0] expected_height,
    input file_valid,output file_ready,input [7:0] file_byte,input [31:0] file_offset,
    input file_done,input [7:0] file_error,
    output reg write_req,input write_req_ack,
    output reg pixel_valid,output reg [23:0] pixel_rgb,
    output reg done,output reg error_valid,output reg [7:0] error_code,
    output busy
);
    localparam IDLE=0,HEADER=1,ROW=2,STRIDE=3,EXTENT=4,CHECK=5,
               ACK=6,DATA=7,ENDING=8,FAILED=9,ACK_RELEASE=10;
    reg [3:0] state;
    reg [7:0] sig0,sig1,blue,green;
    reg [31:0] dir_size,header_size,offset,dib,width,height,compression;
    reg [15:0] planes,bpp;
    reg [31:0] row_bytes,row_stride,expected_pixels,pixels_received;
    reg [32:0] dib_end;
    reg [63:0] required_size,required_end;
    reg [31:0] next_offset,byte_in_row,rows_received;
    reg [1:0] phase;
    wire take=file_valid && file_ready;
    assign file_ready=state==HEADER || state==DATA;
    assign busy=state!=IDLE && state!=FAILED;
    task fail;
        input [7:0] code;
        begin error_code<=code;error_valid<=1;write_req<=0;pixel_valid<=0;state<=FAILED;end
    endtask
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE;sig0<=0;sig1<=0;blue<=0;green<=0;
            dir_size<=0;header_size<=0;offset<=0;dib<=0;width<=0;height<=0;
            compression<=0;planes<=0;bpp<=0;row_bytes<=0;row_stride<=0;
            expected_pixels<=0;pixels_received<=0;dib_end<=0;required_size<=0;
            required_end<=0;next_offset<=0;byte_in_row<=0;rows_received<=0;phase<=0;
            write_req<=0;pixel_valid<=0;pixel_rgb<=0;done<=0;error_valid<=0;error_code<=0;
        end else begin
            pixel_valid<=0;done<=0;error_valid<=0;
            if(start) begin
                state<=HEADER;sig0<=0;sig1<=0;dir_size<=file_size;
                header_size<=0;offset<=0;dib<=0;width<=0;height<=0;
                compression<=0;planes<=0;bpp<=0;pixels_received<=0;
                next_offset<=0;byte_in_row<=0;rows_received<=0;phase<=0;
                write_req<=0;error_code<=0;
            end else if(busy && abort) fail(8'h3b);
            else if(busy && file_error!=0) fail(file_error);
            else if(take && file_offset!=next_offset) fail(8'h37);
            else begin
                if(take) begin
                    next_offset<=next_offset+1'b1;
                    if(state==HEADER) begin
                        case(file_offset)
                            0:sig0<=file_byte;1:sig1<=file_byte;
                            2:header_size[7:0]<=file_byte;3:header_size[15:8]<=file_byte;
                            4:header_size[23:16]<=file_byte;5:header_size[31:24]<=file_byte;
                            10:offset[7:0]<=file_byte;11:offset[15:8]<=file_byte;
                            12:offset[23:16]<=file_byte;13:offset[31:24]<=file_byte;
                            14:dib[7:0]<=file_byte;15:dib[15:8]<=file_byte;
                            16:dib[23:16]<=file_byte;17:dib[31:24]<=file_byte;
                            18:width[7:0]<=file_byte;19:width[15:8]<=file_byte;
                            20:width[23:16]<=file_byte;21:width[31:24]<=file_byte;
                            22:height[7:0]<=file_byte;23:height[15:8]<=file_byte;
                            24:height[23:16]<=file_byte;25:height[31:24]<=file_byte;
                            26:planes[7:0]<=file_byte;27:planes[15:8]<=file_byte;
                            28:bpp[7:0]<=file_byte;29:bpp[15:8]<=file_byte;
                            30:compression[7:0]<=file_byte;31:compression[15:8]<=file_byte;
                            32:compression[23:16]<=file_byte;33:compression[31:24]<=file_byte;
                            default:;
                        endcase
                        if(file_offset==53) state<=ROW;
                    end else if(file_offset>=offset && {32'd0,file_offset}<required_end) begin
                        if(byte_in_row<row_bytes) begin
                            case(phase)
                                0:begin blue<=file_byte;phase<=1;end
                                1:begin green<=file_byte;phase<=2;end
                                2:begin
                                    pixel_rgb<={file_byte,green,blue};pixel_valid<=1;
                                    pixels_received<=pixels_received+1'b1;phase<=0;
                                end
                                default:phase<=0;
                            endcase
                        end
                        if(byte_in_row==row_stride-1) begin
                            byte_in_row<=0;rows_received<=rows_received+1'b1;
                        end else byte_in_row<=byte_in_row+1'b1;
                    end
                end
                case(state)
                    ROW:begin
                        row_bytes<={16'd0,expected_width}*3;
                        expected_pixels<=expected_width*expected_height;
                        dib_end<={1'b0,dib}+33'd14;state<=STRIDE;
                    end
                    STRIDE:begin row_stride<=(row_bytes+3)&32'hfffffffc;state<=EXTENT;end
                    EXTENT:begin required_size<=row_stride*{32'd0,expected_height};state<=CHECK;end
                    CHECK:begin required_end<=required_size+{32'd0,offset};state<=ACK;end
                    ACK:begin
                        if(sig0!=8'h42 || sig1!=8'h4d) fail(8'h31);
                        else if(dib<40 || width!={16'd0,expected_width} ||
                                height!={16'd0,expected_height} || expected_width==0 || expected_height==0) fail(8'h32);
                        else if(planes!=1) fail(8'h33);
                        else if(bpp!=24) fail(8'h34);
                        else if(compression!=0) fail(8'h35);
                        else if(dib_end[32] || {1'b0,offset}<dib_end || offset<54 ||
                                required_end[63:32]!=0 || offset>=dir_size ||
                                header_size>dir_size || {32'd0,header_size}<required_end ||
                                {32'd0,dir_size}<required_end) fail(8'h36);
                        else begin
                            write_req<=1;
                            if(write_req && write_req_ack) begin write_req<=0;state<=ACK_RELEASE;end
                        end
                    end
                    // The memory writer keeps FIFO clear asserted until the
                    // synchronized request falls. Its returned ACK must also
                    // fall before any buffered file bytes may become pixels.
                    ACK_RELEASE:if(!write_req_ack) state<=DATA;
                    ENDING:begin
                        if(next_offset!=dir_size || pixels_received!=expected_pixels ||
                           rows_received!={16'd0,expected_height} || byte_in_row!=0 || phase!=0) fail(8'h37);
                        else begin done<=1;state<=IDLE;end
                    end
                    default:;
                endcase
                // Separate final checks from the last byte's nonblocking RGB
                // and count updates, including a final byte+done same cycle.
                if(file_done && busy) begin
                    if(state==DATA) state<=ENDING;
                    else if(state!=ENDING) fail(8'h37);
                end
            end
        end
    end
endmodule
