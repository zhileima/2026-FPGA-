`timescale 1ns/1ps
// A load is published only by load_done, never by ready alone. The memory
// writer already reverses positive-height BMP rows (top-down is rejected).
module bmp_read #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SECTOR_TIMEOUT_MS = 500,
    parameter integer WRITE_ACK_TIMEOUT_MS = 500,
    parameter integer LOAD_TIMEOUT_MS = 5000,
    parameter integer MAX_FAST_SKIP_SECTORS = 16384
)(
    input clk, input rst, output ready,
    input scan_start, input [31:0] scan_start_sector,
    input [31:0] scan_max_sector, input [2:0] scan_target_count,
    output reg scan_done, output reg scan_found_valid,
    output reg [31:0] scan_found_sector, output reg [2:0] scan_found_total,
    input load_start, input [31:0] load_sector,
    input sd_init_done, output reg [3:0] state_code,
    input [15:0] bmp_width, input [15:0] bmp_height,
    output reg write_req, input write_req_ack,
    output reg sd_sec_read, output reg [31:0] sd_sec_read_addr,
    input [7:0] sd_sec_read_data, input sd_sec_read_data_valid,
    input sd_sec_read_end,
    output reg bmp_data_wr_en, output reg [23:0] bmp_data,
    input scan_pause, input load_abort,
    output reg load_done, output reg load_error,
    output reg [7:0] bmp_error,
    output reg error_valid, output reg error_is_scan,
    output reg sd_abort_reset
);
    localparam [7:0] ERR_NONE=8'h00, ERR_SIGNATURE=8'h31,
        ERR_DIMENSIONS=8'h32, ERR_PLANES=8'h33, ERR_BPP=8'h34,
        ERR_COMPRESSION=8'h35, ERR_OFFSET=8'h36, ERR_TRUNCATED=8'h37,
        ERR_UPSTREAM=8'h38, ERR_SECTOR_TIMEOUT=8'h39,
        ERR_ACK_TIMEOUT=8'h3a, ERR_LOAD_TIMEOUT=8'h3b,
        ERR_REINIT_TIMEOUT=8'h3d;
    localparam [3:0] ST_IDLE=0, ST_SCAN=1, ST_LOAD_HDR=2,
        ST_LOAD_WAIT=3, ST_LOAD_DATA=4, ST_MATH=5, ST_RANGE=6,
        ST_RANGE_END=7, ST_CHECK=8, ST_GAP=9, ST_RESET_SD=10,
        ST_REINIT=11, ST_OFFLINE=12, ST_STRIDE=13, ST_VALIDATE=14,
        ST_SECTOR_CHECK=15;
    localparam [63:0] SECTOR_CYCLES=(64'd1*CLK_FREQ_HZ*SECTOR_TIMEOUT_MS+999)/1000;
    localparam [63:0] ACK_CYCLES=(64'd1*CLK_FREQ_HZ*WRITE_ACK_TIMEOUT_MS+999)/1000;
    localparam [63:0] LOAD_CYCLES=(64'd1*CLK_FREQ_HZ*LOAD_TIMEOUT_MS+999)/1000;
    localparam integer SECTOR_TIMER_BITS=SECTOR_CYCLES<2 ? 1 : $clog2(SECTOR_CYCLES);
    localparam integer ACK_TIMER_BITS=ACK_CYCLES<2 ? 1 : $clog2(ACK_CYCLES);
    localparam integer LOAD_TIMER_BITS=LOAD_CYCLES<2 ? 1 : $clog2(LOAD_CYCLES);
    localparam [63:0] SECTOR_PRETERM=SECTOR_CYCLES>1 ? SECTOR_CYCLES-2 : 0;
    localparam [63:0] ACK_PRETERM=ACK_CYCLES>1 ? ACK_CYCLES-2 : 0;
    localparam [63:0] LOAD_PRETERM=LOAD_CYCLES>1 ? LOAD_CYCLES-2 : 0;

    reg [3:0] state, gap_next_state;
    reg [1:0] gap_count;
    reg scan_active, header_is_scan, load_running;
    reg [31:0] scan_sector, load_sector_latched;
    reg [9:0] sector_bytes;
    reg [7:0] header_0,header_1;
    reg [31:0] file_len,pixel_offset,dib_size,width,height,compression;
    reg [15:0] planes,bit_count;
    reg source_bpp32;
    reg [31:0] row_bytes,row_stride,expected_pixels;
    reg [63:0] required_bytes;
    reg [64:0] required_end;
    reg [32:0] dib_end,file_sector_count,file_last_sector,next_scan_sector;
    reg [31:0] file_byte_count,byte_in_row,pixel_count;
    reg file_byte_overflow,ending_payload;
    reg [1:0] color_phase;
    reg [SECTOR_TIMER_BITS-1:0] sector_timer;
    reg [ACK_TIMER_BITS-1:0] ack_timer;
    reg [LOAD_TIMER_BITS-1:0] load_timer;
    reg sector_timeout_reached,ack_timeout_reached,load_timeout_reached;
    reg [4:0] reset_count;
    reg recovery_saw_init_low, recovery_is_scan;
    wire sector_active=state==ST_SCAN || state==ST_LOAD_HDR || state==ST_LOAD_DATA;
    // ST_VALIDATE guarantees required_end[64:32]==0 before any payload.
    // Keep the byte-stream critical path at 32 bits; saturation records a
    // final sector crossing the 32-bit byte limit without silently wrapping.
    wire data_in_payload=state==ST_LOAD_DATA && sd_sec_read_data_valid &&
        !file_byte_overflow && file_byte_count>=pixel_offset &&
        file_byte_count<required_end[31:0];
    wire signature_ok=header_0==8'h42 && header_1==8'h4d;
    wire basic_extent_ok=dib_size>=40 && !dib_end[32] &&
        {1'b0,pixel_offset}>=dib_end && pixel_offset>=54 && pixel_offset<file_len &&
        !required_end[64] && required_end[63:32]==0 &&
        {33'd0,file_len}>=required_end && !file_last_sector[32];
    wire safe_fast_skip=signature_ok && basic_extent_ok && planes==1 &&
        (bit_count==24 || bit_count==32) && compression==0 && width>0 && width<=4096 &&
        height>0 && height<=4096 && file_sector_count>0 &&
        file_sector_count<=MAX_FAST_SKIP_SECTORS &&
        file_last_sector<={1'b0,scan_max_sector};
    reg [7:0] header_error;
    reg [7:0] header_error_q;
    reg safe_fast_skip_q;
    always @* begin
        header_error=ERR_NONE;
        if(!signature_ok) header_error=ERR_SIGNATURE;
        // Check every dimension bit, including the signed-height bit.
        else if(dib_size<40 || width!={16'd0,bmp_width} ||
                height!={16'd0,bmp_height} || bmp_width==0 || bmp_height==0)
            header_error=ERR_DIMENSIONS;
        else if(planes!=1) header_error=ERR_PLANES;
        else if(bit_count!=24) header_error=ERR_BPP;
        else if(compression!=0) header_error=ERR_COMPRESSION;
        else if(!basic_extent_ok || (header_is_scan &&
                file_last_sector>{1'b0,scan_max_sector})) header_error=ERR_OFFSET;
    end
    assign ready=state==ST_IDLE && sd_init_done;

    initial begin
        if(CLK_FREQ_HZ<=0 || SECTOR_TIMEOUT_MS<=0 || WRITE_ACK_TIMEOUT_MS<=0 ||
           LOAD_TIMEOUT_MS<=0 || SECTOR_CYCLES<1 || ACK_CYCLES<1 || LOAD_CYCLES<1 ||
           SECTOR_CYCLES>64'hffffffff || ACK_CYCLES>64'hffffffff ||
           LOAD_CYCLES>64'hffffffff || MAX_FAST_SKIP_SECTORS<1) begin
            $display("BMP_CONFIG_ERROR invalid timeout/clock/skip parameter"); $finish;
        end
    end

    task clear_header;
        begin
            sector_bytes<=0; header_0<=0;header_1<=0;file_len<=0;
            pixel_offset<=0;dib_size<=0;width<=0;height<=0;planes<=0;
            bit_count<=0;compression<=0;sector_timer<=0;source_bpp32<=0;
            sector_timeout_reached<=SECTOR_CYCLES==1;
        end
    endtask
    task report_failure;
        input [7:0] code;
        input is_scan;
        begin
            bmp_error<=code;error_valid<=1;error_is_scan<=is_scan;
            if(!is_scan) load_error<=1;
            load_done<=0;
            load_running<=0;write_req<=0;sd_sec_read<=0;bmp_data_wr_en<=0;
        end
    endtask
    task abort_sd_transaction;
        input [7:0] code;
        input is_scan;
        begin
            report_failure(code,is_scan);
            sd_abort_reset<=1;reset_count<=0;sector_timer<=0;
            sector_timeout_reached<=SECTOR_CYCLES==1;
            recovery_saw_init_low<=0;recovery_is_scan<=is_scan;state<=ST_RESET_SD;
            // Reset the physical SD FSM before another task accepts bytes.
            if(is_scan) begin
                if(scan_sector>=scan_max_sector || scan_sector==32'hffffffff) begin
                    scan_done<=1;scan_active<=0;
                end else scan_sector<=scan_sector+1'b1;
            end
        end
    endtask

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=ST_IDLE;gap_next_state<=ST_IDLE;gap_count<=0;
            scan_active<=0;header_is_scan<=0;load_running<=0;
            scan_done<=0;scan_found_valid<=0;scan_found_sector<=0;scan_found_total<=0;
            scan_sector<=0;load_sector_latched<=0;sd_sec_read_addr<=0;
            sd_sec_read<=0;write_req<=0;state_code<=0;
            bmp_data_wr_en<=0;bmp_data<=0;load_done<=0;load_error<=0;
            bmp_error<=ERR_NONE;error_valid<=0;error_is_scan<=0;sd_abort_reset<=0;
            row_bytes<=0;row_stride<=0;expected_pixels<=0;required_bytes<=0;
            required_end<=0;dib_end<=0;file_sector_count<=0;file_last_sector<=0;
            next_scan_sector<=0;file_byte_count<=0;byte_in_row<=0;pixel_count<=0;
            file_byte_overflow<=0;ending_payload<=0;
            color_phase<=0;ack_timer<=0;load_timer<=0;reset_count<=0;
            recovery_saw_init_low<=0;recovery_is_scan<=0;clear_header();
            load_timeout_reached<=LOAD_CYCLES==1;ack_timeout_reached<=ACK_CYCLES==1;
            header_error_q<=ERR_NONE;safe_fast_skip_q<=0;
        end else begin
            scan_found_valid<=0;bmp_data_wr_en<=0;load_done<=0;load_error<=0;error_valid<=0;
            // Compare one cycle before expiration, then consume the registered
            // terminal flag at the original deadline. This separates the wide
            // equality/carry logic from failure muxes and output write gating.
            if(load_running) begin
                load_timeout_reached<=load_timer>=LOAD_PRETERM;
                if(!load_timeout_reached) load_timer<=load_timer+1'b1;
            end
            if(sector_active) begin
                sector_timeout_reached<=sector_timer>=SECTOR_PRETERM;
                if(!sector_timeout_reached) sector_timer<=sector_timer+1'b1;
            end
            if(sector_active && sd_sec_read_data_valid) begin
                if(sector_bytes<513) sector_bytes<=sector_bytes+1'b1;
                if(state==ST_SCAN || state==ST_LOAD_HDR) begin
                    case(sector_bytes)
                        0:header_0<=sd_sec_read_data;1:header_1<=sd_sec_read_data;
                        2:file_len[7:0]<=sd_sec_read_data;3:file_len[15:8]<=sd_sec_read_data;
                        4:file_len[23:16]<=sd_sec_read_data;5:file_len[31:24]<=sd_sec_read_data;
                        10:pixel_offset[7:0]<=sd_sec_read_data;11:pixel_offset[15:8]<=sd_sec_read_data;
                        12:pixel_offset[23:16]<=sd_sec_read_data;13:pixel_offset[31:24]<=sd_sec_read_data;
                        14:dib_size[7:0]<=sd_sec_read_data;15:dib_size[15:8]<=sd_sec_read_data;
                        16:dib_size[23:16]<=sd_sec_read_data;17:dib_size[31:24]<=sd_sec_read_data;
                        18:width[7:0]<=sd_sec_read_data;19:width[15:8]<=sd_sec_read_data;
                        20:width[23:16]<=sd_sec_read_data;21:width[31:24]<=sd_sec_read_data;
                        22:height[7:0]<=sd_sec_read_data;23:height[15:8]<=sd_sec_read_data;
                        24:height[23:16]<=sd_sec_read_data;25:height[31:24]<=sd_sec_read_data;
                        26:planes[7:0]<=sd_sec_read_data;27:planes[15:8]<=sd_sec_read_data;
                        28:bit_count[7:0]<=sd_sec_read_data;29:bit_count[15:8]<=sd_sec_read_data;
                        30:compression[7:0]<=sd_sec_read_data;31:compression[15:8]<=sd_sec_read_data;
                        32:compression[23:16]<=sd_sec_read_data;33:compression[31:24]<=sd_sec_read_data;
                        default:;
                    endcase
                end else begin
                    if(!file_byte_overflow) begin
                        if(file_byte_count==32'hffffffff) file_byte_overflow<=1;
                        else file_byte_count<=file_byte_count+1'b1;
                    end
                    if(data_in_payload) begin
                        if(byte_in_row<row_bytes) begin
                            case(color_phase)
                                0:begin bmp_data[7:0]<=sd_sec_read_data;color_phase<=1;end
                                1:begin bmp_data[15:8]<=sd_sec_read_data;color_phase<=2;end
                                default:begin
                                    bmp_data[23:16]<=sd_sec_read_data;bmp_data_wr_en<=1;
                                    color_phase<=0;pixel_count<=pixel_count+1'b1;
                                end
                            endcase
                        end
                        if(byte_in_row==row_stride-1) begin byte_in_row<=0;color_phase<=0;end
                        else byte_in_row<=byte_in_row+1'b1;
                    end
                end
            end

            case(state)
                ST_IDLE:begin
                    state_code<=sd_init_done ? 4'd1 : 4'd0;
                    sd_sec_read<=0;write_req<=0;load_timer<=0;
                    load_timeout_reached<=LOAD_CYCLES==1;
                    if(sd_init_done) begin
                        if(load_start) begin
                            clear_header();header_is_scan<=0;load_running<=1;bmp_error<=ERR_NONE;
                            load_sector_latched<=load_sector;sd_sec_read_addr<=load_sector;
                            file_byte_count<=0;byte_in_row<=0;pixel_count<=0;color_phase<=0;
                            file_byte_overflow<=0;
                            state<=ST_LOAD_HDR;
                        end else if(scan_start) begin
                            scan_done<=0;scan_found_total<=0;scan_sector<=scan_start_sector;
                            bmp_error<=ERR_NONE;
                            if(scan_start_sector>scan_max_sector || scan_target_count==0) begin
                                scan_done<=1;scan_active<=0;
                            end else scan_active<=1;
                        end else if(scan_active && scan_pause!==1'b1) begin
                            clear_header();header_is_scan<=1;sd_sec_read_addr<=scan_sector;state<=ST_SCAN;
                        end
                    end
                end
                ST_SCAN,ST_LOAD_HDR:begin
                    state_code<=2;sd_sec_read<=1;
                    if(sd_sec_read_end) begin
                        sd_sec_read<=0;sector_timer<=0;
                        sector_timeout_reached<=SECTOR_CYCLES==1;
                        ending_payload<=0;state<=ST_SECTOR_CHECK;
                    end else if(sector_timeout_reached)
                        abort_sd_transaction(ERR_SECTOR_TIMEOUT,header_is_scan);
                end
                // Separate multiply/add/compare stages for 100 MHz timing.
                ST_MATH:begin
                    // Explicit 18-bit shift/add prevents inference of a
                    // variable 3/4 DSP multiplier on the row-stride path.
                    row_bytes<=source_bpp32 ? {width[15:0],2'b00} :
                        ({1'b0,width[15:0],1'b0}+{2'b00,width[15:0]});
                    expected_pixels<=bmp_width*bmp_height;state<=ST_STRIDE;
                end
                ST_STRIDE:begin
                    // The rounding carry is after the row_bytes register.
                    row_stride<=(row_bytes+32'd3)&32'hfffffffc;state<=ST_RANGE;
                end
                ST_RANGE:begin
                    required_bytes<=64'd1*row_stride*height[15:0];
                    dib_end<={1'b0,dib_size}+33'd14;
                    file_sector_count<=({1'b0,file_len}+33'd511)>>9;state<=ST_RANGE_END;
                end
                ST_RANGE_END:begin
                    required_end<={33'd0,pixel_offset}+{1'b0,required_bytes};
                    file_last_sector<={1'b0,(header_is_scan ? scan_sector : load_sector_latched)}+
                        file_sector_count-1'b1;
                    next_scan_sector<={1'b0,scan_sector}+file_sector_count;state<=ST_VALIDATE;
                end
                ST_VALIDATE:begin
                    // Capture range validation before the high-fanout scanner
                    // cursor and request muxes use the decision on the next edge.
                    header_error_q<=header_error;safe_fast_skip_q<=safe_fast_skip;state<=ST_CHECK;
                end
                ST_CHECK:begin
                    if(header_is_scan) begin
                        if(header_error_q==ERR_NONE) begin
                            scan_found_valid<=1;scan_found_sector<=scan_sector;
                            scan_found_total<=scan_found_total+1'b1;
                        end else if(signature_ok) begin
                            bmp_error<=header_error_q;error_valid<=1;error_is_scan<=1;
                        end
                        if((header_error_q==ERR_NONE && scan_found_total+1'b1>=scan_target_count) ||
                           scan_sector>=scan_max_sector) begin scan_done<=1;scan_active<=0;end
                        else if(header_error_q==ERR_NONE || safe_fast_skip_q) begin
                            if(next_scan_sector[32] || next_scan_sector>{1'b0,scan_max_sector}) begin
                                scan_done<=1;scan_active<=0;
                            end else scan_sector<=next_scan_sector[31:0];
                        end else scan_sector<=scan_sector+1'b1;
                        // Let the parent latch found before issuing another sector.
                        gap_count<=1;gap_next_state<=ST_IDLE;state<=ST_GAP;
                    end else if(header_error_q!=ERR_NONE) begin
                        report_failure(header_error_q,1'b0);state<=ST_IDLE;
                    end else begin
                        write_req<=1;ack_timer<=0;sd_sec_read_addr<=load_sector_latched;
                        ack_timeout_reached<=ACK_CYCLES==1;
                        state<=ST_LOAD_WAIT;
                    end
                end
                ST_LOAD_WAIT:begin
                    state_code<=3;
                    if(write_req_ack) begin
                        write_req<=0;file_byte_count<=0;byte_in_row<=0;color_phase<=0;
                        file_byte_overflow<=0;
                        pixel_count<=0;sector_bytes<=0;sector_timer<=0;
                        sector_timeout_reached<=SECTOR_CYCLES==1;
                        gap_count<=0;gap_next_state<=ST_LOAD_DATA;state<=ST_GAP;
                    end else if(ack_timeout_reached) begin
                        report_failure(ERR_ACK_TIMEOUT,1'b0);state<=ST_IDLE;
                    end else begin
                        ack_timer<=ack_timer+1'b1;ack_timeout_reached<=ack_timer>=ACK_PRETERM;
                    end
                end
                ST_LOAD_DATA:begin
                    state_code<=4;sd_sec_read<=1;
                    if(sd_sec_read_end) begin
                        sd_sec_read<=0;sector_timer<=0;
                        sector_timeout_reached<=SECTOR_CYCLES==1;
                        ending_payload<=1;state<=ST_SECTOR_CHECK;
                    end else if(sector_timeout_reached)
                        abort_sd_transaction(ERR_SECTOR_TIMEOUT,1'b0);
                end
                ST_SECTOR_CHECK:begin
                    // The end edge still consumes its final valid byte above.
                    // Check only the updated registers on the following edge;
                    // no payload comparison -> pixel increment -> commit chain.
                    sd_sec_read<=0;
                    if(sector_bytes!=512) begin
                        report_failure(ERR_TRUNCATED,ending_payload ? 1'b0 : header_is_scan);
                        if(!ending_payload && header_is_scan) begin
                            if(scan_sector>=scan_max_sector) begin scan_done<=1;scan_active<=0;end
                            else scan_sector<=scan_sector+1'b1;
                        end
                        gap_count<=1;gap_next_state<=ST_IDLE;state<=ST_GAP;
                    end else if(!ending_payload) begin
                        source_bpp32<=bit_count==16'd32;state<=ST_MATH;
                    end else if(file_byte_overflow || file_byte_count>=required_end[31:0]) begin
                        if(pixel_count==expected_pixels) begin
                            load_done<=1;load_running<=0;bmp_error<=ERR_NONE;state<=ST_IDLE;
                        end else begin report_failure(ERR_TRUNCATED,1'b0);state<=ST_IDLE;end
                    end else if(sd_sec_read_addr==32'hffffffff) begin
                        report_failure(ERR_OFFSET,1'b0);state<=ST_IDLE;
                    end else begin
                        sd_sec_read_addr<=sd_sec_read_addr+1'b1;sector_bytes<=0;
                        gap_count<=0;gap_next_state<=ST_LOAD_DATA;state<=ST_GAP;
                    end
                end
                ST_GAP:begin
                    sd_sec_read<=0;
                    if(gap_count==0) state<=gap_next_state;
                    else gap_count<=gap_count-1'b1;
                end
                ST_RESET_SD:begin
                    state_code<=5;sd_sec_read<=0;write_req<=0;bmp_data_wr_en<=0;
                    if(!sd_init_done) recovery_saw_init_low<=1;
                    if(reset_count==15) begin
                        sd_abort_reset<=0;sector_timer<=0;load_timer<=0;state<=ST_REINIT;
                        load_timeout_reached<=LOAD_CYCLES==1;
                    end else reset_count<=reset_count+1'b1;
                end
                ST_REINIT:begin
                    state_code<=5;
                    if(!sd_init_done) recovery_saw_init_low<=1;
                    if(recovery_saw_init_low && sd_init_done) begin state<=ST_IDLE;sector_timer<=0;end
                    else if(load_timeout_reached) begin
                        bmp_error<=ERR_REINIT_TIMEOUT;error_valid<=1;error_is_scan<=recovery_is_scan;
                        scan_active<=0;scan_done<=1;state<=ST_OFFLINE;
                    end else begin
                        load_timer<=load_timer+1'b1;load_timeout_reached<=load_timer>=LOAD_PRETERM;
                    end
                end
                ST_OFFLINE:begin
                    state_code<=6;sd_sec_read<=0;write_req<=0;bmp_data_wr_en<=0;
                    if(recovery_saw_init_low && sd_init_done) state<=ST_IDLE;
                end
                default:begin state<=ST_IDLE;sd_sec_read<=0;write_req<=0;end
            endcase
            if(load_running && (load_abort===1'b1 || load_timeout_reached))
                abort_sd_transaction(ERR_LOAD_TIMEOUT,1'b0);
            else if(sector_active && !sd_init_done)
                abort_sd_transaction(ERR_UPSTREAM,header_is_scan);
        end
    end
endmodule
