`timescale 1ns/1ps
// Checked BMP24 file stream -> normalized frame. All rows retain the BMP's
// bottom-up file order; the existing SDRAM writer performs the vertical flip.
// File success still requires the complete directory extent and FAT EOF.
module bmp24_scaled_reader #(
    parameter integer OUT_WIDTH=640, OUT_HEIGHT=480, MAX_SOURCE_DIM=4096
)(
    input wire clk, rst, start, abort,
    input wire [31:0] file_size,
    input wire file_valid, output wire file_ready,
    input wire [7:0] file_byte, input wire [31:0] file_offset,
    input wire file_done, input wire [7:0] file_error,
    output reg write_req, input wire write_req_ack,
    input wire pixel_ready, output wire pixel_valid, output wire [23:0] pixel_rgb,
    output reg [15:0] source_width, source_height, output reg header_valid,
    output reg done, error_valid, output reg [7:0] error_code, output wire busy
);
    localparam IDLE=0, HEADER=1, FORMAT=2, STRIDE=3, MUL_INIT=4, MULTIPLY=5,
        EXTENT=6, BOUNDS=7, ACK=8, ACK_RELEASE=9, DATA=10, ENDING=11, FAILED=12,
        FORMAT_FLAGS=13, DIM_PUBLISH=14, BOUNDS_FLAGS=15;
    localparam [31:0] OUTPUT_PIXELS=OUT_WIDTH*OUT_HEIGHT;
    reg [3:0] state;
    // Header byte ordering is validated before these writes. Keep exact
    // equality predicates for constant fields and reject all high dimension
    // bits before publishing the 13-bit value (MAX_SOURCE_DIM <= 4096).
    // Error priority and every transaction/state clock remain unchanged.
    reg [7:0] blue,green;
    reg sig0_good,sig1_good,planes_good,bpp_good,compression_zero;
    reg [12:0] width,height;
    reg width_high_nonzero,height_high_nonzero;
    reg [31:0] dir_size,header_size,offset,dib;
    reg [8:0] format_bad;
    reg [7:0] bounds_bad;
    // Freeze source-accounting checks after EOF, when file_ready is low.
    // A file_done coincident with the final accepted byte is counted before
    // this snapshot. The decision gains at most one terminal clock.
    reg [4:0] ending_bad;
    reg ending_flags_valid;
    reg [13:0] row_bytes,row_stride,row_last,byte_in_row;
    // Derive bounds from the checked MAX_SOURCE_DIM parameter (1..4096).
    localparam integer ROW_COUNT_BITS=$clog2(MAX_SOURCE_DIM+1);
    localparam integer SOURCE_PIXEL_BITS=$clog2(MAX_SOURCE_DIM*MAX_SOURCE_DIM+1);
    localparam integer MAX_PADDED_ROW=(MAX_SOURCE_DIM*3+3)&~3;
    localparam integer EXTENT_BITS=$clog2(MAX_PADDED_ROW*MAX_SOURCE_DIM+1);
    reg [ROW_COUNT_BITS-1:0] rows_received;
    reg [31:0] next_offset;
    reg [SOURCE_PIXEL_BITS-1:0] expected_pixels,pixels_received;
    // Include one extra count for stale output on a cancelled/restarted stream.
    localparam integer OUTPUT_COUNT_BITS=$clog2(OUTPUT_PIXELS+2);
    reg [OUTPUT_COUNT_BITS-1:0] output_received;
    reg [32:0] dib_end,required_end;
    // Unused high shifted terms may wrap after the last set multiplier bit;
    // the complete non-negative product fits these derived bounds exactly.
    // Header fields, offsets and 33-bit overflow checks retain full width.
    reg [EXTENT_BITS-1:0] extent_bytes;
    // Native 18x18 multipliers replace serial shift/add datapaths. Header
    // validation guarantees source dimensions <=4096 before MUL_INIT. Keep
    // all 13 MULTIPLY clocks so external handshakes remain cycle-exact.
    wire [26:0] extent_product;
    wire [25:0] pixel_product;
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(14),.INPUT_WIDTH_B(13),.OUTPUT_WIDTH(27),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_extent_product (
        .a(row_stride),.b(source_height[12:0]),.p(extent_product),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(13),.INPUT_WIDTH_B(13),.OUTPUT_WIDTH(26),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_pixel_product (
        .a(source_width[12:0]),.b(source_height[12:0]),.p(pixel_product),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    reg [3:0] multiply_count;
    reg [1:0] phase;
    reg payload_started;
    reg raw_valid,scale_start,scale_abort,file_finished,scale_finished;
    reg [23:0] raw_rgb;
    wire raw_ready,scaled_valid,scale_done,scale_busy,scale_error;
    wire take=file_valid && file_ready;
    wire output_take=scaled_valid && pixel_ready && state!=FAILED && state!=IDLE && !abort;
    assign busy=state!=IDLE && state!=FAILED;
    assign file_ready=state==HEADER || (state==DATA && !raw_valid);
    assign pixel_valid=output_take;
    rgb_bilinear_scaler #(.OUT_WIDTH(OUT_WIDTH),.OUT_HEIGHT(OUT_HEIGHT),
        .MAX_SOURCE_DIM(MAX_SOURCE_DIM)) u_scaler(
        .clk(clk),.rst(rst),.start(scale_start),.abort(scale_abort || abort),
        .src_width(source_width),.src_height(source_height),
        .in_valid(raw_valid),.in_ready(raw_ready),.in_rgb(raw_rgb),
        .out_valid(scaled_valid),.out_ready(pixel_ready && busy && !abort),.out_rgb(pixel_rgb),
        .done(scale_done),.busy(scale_busy),.error(scale_error));
    initial begin
        if(MAX_SOURCE_DIM<1 || MAX_SOURCE_DIM>4096 || OUT_WIDTH<1 || OUT_HEIGHT<1) begin
            $display("BMP_SCALE_CONFIG_ERROR invalid dimensions"); $finish;
        end
    end
    task fail;
        input [7:0] code;
        begin
            error_code<=code;error_valid<=1;write_req<=0;raw_valid<=0;
            scale_abort<=1;ending_flags_valid<=0;state<=FAILED;
        end
    endtask
    // Header storage and checked predicates are transaction-local payloads.
    // Keep their enables independent of the global abort/error priority chain.
    // HEADER is always ready, so HEADER && file_valid is exactly its byte
    // acceptance condition. On a failing edge these payloads may update, but
    // the unchanged control FSM enters FAILED and cannot publish them. A new
    // start clears all fields before another HEADER/FORMAT/BOUNDS transaction.
    // Pixel, write_req, EOF, CRC, offset checks and state timing stay unchanged.
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            sig0_good<=0;sig1_good<=0;dir_size<=0;
            header_size<=0;offset<=0;dib<=0;width<=0;height<=0;
            compression_zero<=1;planes_good<=0;bpp_good<=0;
            width_high_nonzero<=0;height_high_nonzero<=0;
            format_bad<=0;bounds_bad<=0;
        end else if(start) begin
            sig0_good<=0;sig1_good<=0;dir_size<=file_size;
            header_size<=0;offset<=0;dib<=0;width<=0;height<=0;
            compression_zero<=1;planes_good<=0;bpp_good<=0;
            width_high_nonzero<=0;height_high_nonzero<=0;
            format_bad<=0;bounds_bad<=0;
        end else begin
            if(state==HEADER && file_valid) begin
                        case(file_offset)
                            0:sig0_good<=file_byte==8'h42;1:sig1_good<=file_byte==8'h4d;
                            2:header_size[7:0]<=file_byte;3:header_size[15:8]<=file_byte;
                            4:header_size[23:16]<=file_byte;5:header_size[31:24]<=file_byte;
                            10:offset[7:0]<=file_byte;11:offset[15:8]<=file_byte;
                            12:offset[23:16]<=file_byte;13:offset[31:24]<=file_byte;
                            14:dib[7:0]<=file_byte;15:dib[15:8]<=file_byte;
                            16:dib[23:16]<=file_byte;17:dib[31:24]<=file_byte;
                            18:width[7:0]<=file_byte;
                            19:begin width[12:8]<=file_byte[4:0];width_high_nonzero<=|file_byte[7:5];end
                            20,21:width_high_nonzero<=width_high_nonzero || (file_byte!=0);
                            22:height[7:0]<=file_byte;
                            23:begin height[12:8]<=file_byte[4:0];height_high_nonzero<=|file_byte[7:5];end
                            24,25:height_high_nonzero<=height_high_nonzero || (file_byte!=0);
                            26:planes_good<=file_byte==8'd1;27:planes_good<=planes_good && file_byte==0;
                            28:bpp_good<=file_byte==8'd24;29:bpp_good<=bpp_good && file_byte==0;
                            30:compression_zero<=file_byte==0;
                            31,32,33:compression_zero<=compression_zero && file_byte==0;
                            default:;
                        endcase
            end
            if(state==FORMAT_FLAGS) begin
                        // Register independent wide comparisons before their
                        // priority reduction. Header values no longer feed a
                        // compare/reduce chain and the published dimension CE.
                        format_bad[0]<=!sig0_good || !sig1_good;
                        format_bad[1]<=dib<32'd40;
                        format_bad[2]<=width==0 && !width_high_nonzero;
                        format_bad[3]<=height==0 && !height_high_nonzero;
                        format_bad[4]<=width_high_nonzero || width>MAX_SOURCE_DIM;
                        format_bad[5]<=height_high_nonzero || height>MAX_SOURCE_DIM;
                        format_bad[6]<=!planes_good;
                        format_bad[7]<=!bpp_good;
                        format_bad[8]<=!compression_zero;
            end
            if(state==BOUNDS_FLAGS) begin
                        bounds_bad[0]<=dib_end[32];
                        bounds_bad[1]<={1'b0,offset}<dib_end;
                        bounds_bad[2]<=offset<32'd54;
                        bounds_bad[3]<=required_end[32];
                        bounds_bad[4]<=offset>=dir_size;
                        bounds_bad[5]<=header_size>dir_size;
                        bounds_bad[6]<={1'b0,header_size}<required_end;
                        bounds_bad[7]<={1'b0,dir_size}<required_end;
            end
        end
    end
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE;blue<=0;green<=0;
            
            ending_bad<=0;ending_flags_valid<=0;
            row_bytes<=0;row_stride<=0;row_last<=0;
            byte_in_row<=0;rows_received<=0;next_offset<=0;expected_pixels<=0;
            pixels_received<=0;output_received<=0;dib_end<=0;required_end<=0;
            extent_bytes<=0;multiply_count<=0;
            phase<=0;payload_started<=0;raw_valid<=0;raw_rgb<=0;scale_start<=0;scale_abort<=0;
            file_finished<=0;scale_finished<=0;source_width<=0;source_height<=0;header_valid<=0;
            write_req<=0;done<=0;error_valid<=0;error_code<=0;
        end else begin
            done<=0;error_valid<=0;header_valid<=0;scale_start<=0;scale_abort<=0;
            if(raw_valid && raw_ready) raw_valid<=0;
            if(output_take) output_received<=output_received+1'b1;
            if(scale_done) scale_finished<=1;
            if(start) begin
                state<=HEADER;
                
                ending_bad<=0;ending_flags_valid<=0;
                pixels_received<=0;output_received<=0;
                next_offset<=0;byte_in_row<=0;rows_received<=0;phase<=0;payload_started<=0;
                raw_valid<=0;scale_abort<=1;file_finished<=0;scale_finished<=0;
                source_width<=0;source_height<=0;write_req<=0;error_code<=0;
            end else if(busy && abort) fail(8'h3b);
            else if(busy && file_error!=0) fail(file_error);
            else if((state==DATA || state==ENDING) && !scale_start && scale_error) fail(8'h38);
            else if(take && file_offset!=next_offset) fail(8'h37);
            else begin
                if(take) begin
                    next_offset<=next_offset+1'b1;
                    if(state==HEADER) begin
                        if(file_offset==53) state<=FORMAT_FLAGS;
                    end else if((payload_started || next_offset==offset) && rows_received<source_height) begin
                        // Offsets are checked above. Once the first payload byte
                        // is reached, exact row accounting bounds the image extent.
                        payload_started<=1;
                        if(byte_in_row<row_bytes) begin
                            case(phase)
                                0:begin blue<=file_byte;phase<=1;end
                                1:begin green<=file_byte;phase<=2;end
                                2:begin raw_rgb<={file_byte,green,blue};raw_valid<=1;
                                    pixels_received<=pixels_received+1'b1;phase<=0;end
                                default:phase<=0;
                            endcase
                        end
                        if(byte_in_row==row_last) begin
                            byte_in_row<=0;rows_received<=rows_received+1'b1;
                        end else byte_in_row<=byte_in_row+1'b1;
                    end
                end
                case(state)
                    FORMAT_FLAGS:state<=FORMAT;
                    FORMAT:begin
                        if(format_bad[0]) fail(8'h31);
                        else if(|format_bad[5:1]) fail(8'h32);
                        else if(format_bad[6]) fail(8'h33);
                        else if(format_bad[7]) fail(8'h34);
                        else if(format_bad[8]) fail(8'h35);
                        else state<=DIM_PUBLISH;
                    end
                    DIM_PUBLISH:begin
                        source_width<={3'd0,width};source_height<={3'd0,height};
                        row_bytes<=({1'b0,width[12:0]}<<1)+{1'b0,width[12:0]};
                        dib_end<={1'b0,dib}+33'd14;state<=STRIDE;
                    end
                    STRIDE:begin row_stride<=(row_bytes+14'd3)&14'h3ffc;state<=MUL_INIT;end
                    MUL_INIT:begin
                        // The stride is fixed for this file. Precompute its
                        // final byte before streaming so row bookkeeping has
                        // only a 14-bit equality, not a subtraction plus compare.
                        row_last<=row_stride-14'd1;
                        extent_bytes<=extent_product[EXTENT_BITS-1:0];
                        expected_pixels<=pixel_product[SOURCE_PIXEL_BITS-1:0];
                        multiply_count<=0;state<=MULTIPLY;
                    end
                    MULTIPLY:begin
                        if(multiply_count==12) state<=EXTENT;
                        else multiply_count<=multiply_count+1'b1;
                    end
                    EXTENT:begin required_end<={1'b0,extent_bytes}+{1'b0,offset};state<=BOUNDS_FLAGS;end
                    BOUNDS_FLAGS:state<=BOUNDS;
                    BOUNDS:begin
                        if(|bounds_bad) fail(8'h36);
                        else begin write_req<=1;header_valid<=1;state<=ACK;end
                    end
                    ACK:if(write_req_ack) begin write_req<=0;state<=ACK_RELEASE;end
                    ACK_RELEASE:if(!write_req_ack) begin scale_start<=1;state<=DATA;end
                    ENDING:begin
                        if(!ending_flags_valid) begin
                            ending_bad[0]<=next_offset!=dir_size;
                            ending_bad[1]<=pixels_received!=expected_pixels;
                            ending_bad[2]<=rows_received!=source_height;
                            ending_bad[3]<=byte_in_row!=0;
                            ending_bad[4]<=phase!=0;
                            ending_flags_valid<=1;
                        end else if(|ending_bad) fail(8'h37);
                        else if(file_finished && (scale_finished || scale_done) && !raw_valid) begin
                            if(output_received!=OUTPUT_PIXELS) fail(8'h37);
                            else begin done<=1;state<=IDLE;end
                        end
                    end
                    default:;
                endcase
                if(file_done && busy) begin
                    if(state==DATA) begin file_finished<=1;state<=ENDING;end
                    else if(state!=ENDING) fail(8'h37);
                end
            end
        end
    end
endmodule
