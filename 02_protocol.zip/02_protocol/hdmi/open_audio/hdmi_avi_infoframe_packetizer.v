`timescale 1ns/1ps

// Fixed 640x480 RGB, full range, 4:3. VIC=0 because this project's
// 25 MHz / 800 / 525 = 59.52 Hz is not the exact CTA VIC 1 clock.
module hdmi_avi_infoframe_packetizer (
    input wire clk, rst_n, emit,
    output reg packet_valid,
    input wire packet_ready,
    output wire [23:0] packet_header,
    output wire [7:0] packet_header_ecc,
    output wire [223:0] packet_body,
    output wire [31:0] packet_body_ecc
);
    wire [7:0] ecc0, ecc1, ecc2, ecc3;
    assign packet_header = 24'h0d0282;
    // PB0 checksum; PB1 RGB; PB2 4:3; PB3 full range; VIC/repeat=0.
    assign packet_body = {192'd0, 8'h08, 8'h10, 8'h00, 8'h57};
    hdmi_bch8 #(.DATA_BYTES(3)) u_header_bch (.data(packet_header), .ecc(packet_header_ecc));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body0_bch (.data(packet_body[55:0]), .ecc(ecc0));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body1_bch (.data(packet_body[111:56]), .ecc(ecc1));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body2_bch (.data(packet_body[167:112]), .ecc(ecc2));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body3_bch (.data(packet_body[223:168]), .ecc(ecc3));
    assign packet_body_ecc = {ecc3, ecc2, ecc1, ecc0};
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) packet_valid <= 1'b1;
        else if (emit) packet_valid <= 1'b1;
        else if (packet_ready) packet_valid <= 1'b0;
    end
endmodule
