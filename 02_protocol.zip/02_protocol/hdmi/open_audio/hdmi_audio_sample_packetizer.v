`timescale 1ns/1ps

// Layout 0: publish available stereo samples for the next legal island.
module hdmi_audio_sample_packetizer (
    input wire clk, rst_n,
    input wire sample_valid,
    output wire sample_ready,
    input wire signed [15:0] sample_left, sample_right,
    output wire packet_valid,
    input wire packet_lock,
    input wire packet_ready,
    output reg [23:0] packet_header,
    output wire [7:0] packet_header_ecc,
    output reg [223:0] packet_body,
    output wire [31:0] packet_body_ecc,
    output reg [7:0] packet_frame_base
);
    reg [2:0] collect_count;
    reg [7:0] next_frame;
    reg locked;
    wire [7:0] ecc0, ecc1, ecc2, ecc3;
    assign packet_valid = collect_count != 0;
    // Do not accept another sample on the packet snapshot edge.
    assign sample_ready = !locked && !packet_lock && collect_count < 4;

    function [55:0] make_subpacket;
        input signed [15:0] left_sample, right_sample;
        input [7:0] frame_index;
        reg [23:0] left_word, right_word;
        reg channel_status;
        reg left_parity, right_parity;
        begin
            left_word = {left_sample, 8'h00};
            right_word = {right_sample, 8'h00};
            // Consumer linear PCM: C25=48 kHz, C33=16 bits.
            channel_status = (frame_index == 8'd25) ||
                             (frame_index == 8'd33);
            left_parity = ^{left_word, channel_status};
            right_parity = ^{right_word, channel_status};
            make_subpacket = {right_parity, channel_status, 2'b00,
                              left_parity, channel_status, 2'b00,
                              right_word, left_word};
        end
    endfunction
    hdmi_bch8 #(.DATA_BYTES(3)) u_header_bch (
        .data(packet_header), .ecc(packet_header_ecc));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body0_bch (
        .data(packet_body[55:0]), .ecc(ecc0));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body1_bch (
        .data(packet_body[111:56]), .ecc(ecc1));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body2_bch (
        .data(packet_body[167:112]), .ecc(ecc2));
    hdmi_bch8 #(.DATA_BYTES(7)) u_body3_bch (
        .data(packet_body[223:168]), .ecc(ecc3));
    assign packet_body_ecc = {ecc3, ecc2, ecc1, ecc0};
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            collect_count <= 0;
            next_frame <= 0;
            locked <= 0;
            packet_header <= 24'h000002;
            packet_body <= 0;
            packet_frame_base <= 0;
        end else if (packet_ready && packet_valid) begin
            collect_count <= 0;
            locked <= 0;
            packet_header <= 24'h000002;
            packet_body <= 0;
        end else begin
            if (packet_lock && packet_valid) locked <= 1;
            if (sample_valid && sample_ready) begin
                if (collect_count == 0) packet_frame_base <= next_frame;
                case (collect_count)
                    0: packet_body[55:0] <= make_subpacket(sample_left, sample_right, next_frame);
                    1: packet_body[111:56] <= make_subpacket(sample_left, sample_right, next_frame);
                    2: packet_body[167:112] <= make_subpacket(sample_left, sample_right, next_frame);
                    3: packet_body[223:168] <= make_subpacket(sample_left, sample_right, next_frame);
                endcase
                packet_header[8 + collect_count] <= 1'b1;
                packet_header[20 + collect_count] <= next_frame == 0;
                collect_count <= collect_count + 1'b1;
                next_frame <= next_frame == 191 ? 8'd0 : next_frame + 1'b1;
            end
        end
    end
endmodule
