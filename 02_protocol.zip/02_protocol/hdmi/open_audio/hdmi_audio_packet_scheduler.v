`timescale 1ns/1ps

module hdmi_audio_packet_scheduler (
    input wire clk, rst_n,
    input wire acr_valid,
    output wire acr_ready,
    input wire [23:0] acr_header,
    input wire [7:0] acr_header_ecc,
    input wire [223:0] acr_body,
    input wire [31:0] acr_body_ecc,
    input wire info_valid,
    output wire info_ready,
    input wire [23:0] info_header,
    input wire [7:0] info_header_ecc,
    input wire [223:0] info_body,
    input wire [31:0] info_body_ecc,
    input wire audio_valid,
    output wire audio_ready,
    input wire [23:0] audio_header,
    input wire [7:0] audio_header_ecc,
    input wire [223:0] audio_body,
    input wire [31:0] audio_body_ecc,
    input wire avi_valid,
    output wire avi_ready,
    input wire [23:0] avi_header,
    input wire [7:0] avi_header_ecc,
    input wire [223:0] avi_body,
    input wire [31:0] avi_body_ecc,
    output wire packet_valid,
    input wire packet_lock,
    input wire packet_ready,
    output reg [1:0] packet_source,
    output reg [23:0] packet_header,
    output reg [7:0] packet_header_ecc,
    output reg [223:0] packet_body,
    output reg [31:0] packet_body_ecc
);
    reg locked;
    reg [1:0] locked_source;
    // At 25 MHz/800 there are 62.5k island slots/s, above 48k PCM
    // frames/s. Audio delivery gets priority; unused slots carry metadata.
    wire [1:0] chosen = audio_valid ? 2'd2 : acr_valid ? 2'd0 :
                        avi_valid ? 2'd3 : 2'd1;
    wire [1:0] selected = locked ? locked_source : chosen;
    assign packet_valid = selected == 0 ? acr_valid :
                          selected == 1 ? info_valid :
                          selected == 2 ? audio_valid : avi_valid;
    assign acr_ready = packet_ready && packet_valid && selected == 0;
    assign info_ready = packet_ready && packet_valid && selected == 1;
    assign audio_ready = packet_ready && packet_valid && selected == 2;
    assign avi_ready = packet_ready && packet_valid && selected == 3;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin locked <= 0; locked_source <= 0; end
        else if (packet_ready) locked <= 0;
        else if (packet_lock && packet_valid) begin
            locked <= 1;
            locked_source <= chosen;
        end
    end
    always @* begin
        packet_source = selected;
        packet_header = 0;
        packet_header_ecc = 0;
        packet_body = 0;
        packet_body_ecc = 0;
        case (selected)
            0: begin
                packet_header = acr_header;
                packet_header_ecc = acr_header_ecc;
                packet_body = acr_body;
                packet_body_ecc = acr_body_ecc;
            end
            1: begin
                packet_header = info_header;
                packet_header_ecc = info_header_ecc;
                packet_body = info_body;
                packet_body_ecc = info_body_ecc;
            end
            2: begin
                packet_header = audio_header;
                packet_header_ecc = audio_header_ecc;
                packet_body = audio_body;
                packet_body_ecc = audio_body_ecc;
            end
            3: begin
                packet_header = avi_header;
                packet_header_ecc = avi_header_ecc;
                packet_body = avi_body;
                packet_body_ecc = avi_body_ecc;
            end
        endcase
    end
endmodule
