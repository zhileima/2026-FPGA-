`timescale 1ns/1ps

module hdmi_bch8 #(
    parameter integer DATA_BYTES = 3
) (
    input  wire [DATA_BYTES*8-1:0] data,
    output reg  [7:0]              ecc
);
    integer byte_index;
    integer bit_index;
    reg [7:0] remainder;
    reg feedback;

    // HDMI 1.3 section 5.2.3.4: the link transmits bit 0 first in each
    // byte, with bytes SB0/HB0 first. This reflected LFSR uses 8'h83
    // for G(x)=1+x^6+x^7+x^8; its low bit is sent first as well.
    always @* begin
        remainder = 8'h00;
        feedback = 1'b0;
        for (byte_index = 0; byte_index < DATA_BYTES;
             byte_index = byte_index + 1) begin
            for (bit_index = 0; bit_index < 8;
                 bit_index = bit_index + 1) begin
                feedback = data[byte_index*8 + bit_index] ^ remainder[0];
                remainder = {1'b0, remainder[7:1]};
                if (feedback)
                    remainder = remainder ^ 8'h83;
            end
        end
        ecc = remainder;
    end
endmodule
