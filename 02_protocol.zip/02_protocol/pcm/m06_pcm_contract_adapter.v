`timescale 1ns/1ps
// One elastic PCM register isolates the source and HDMI packetizer. The
// monitor checks the entire stalled transaction, including its acceptance
// cycle; valid must not disappear before that transaction is accepted.
module m06_pcm_contract_adapter (
    input wire clk,
    input wire rst_n,
    input wire source_valid,
    output wire source_ready,
    input wire signed [15:0] source_left,
    input wire signed [15:0] source_right,
    output reg pcm_valid,
    input wire pcm_ready,
    output reg signed [15:0] pcm_left,
    output reg signed [15:0] pcm_right,
    output reg contract_error
);
    reg stalled;
    reg signed [15:0] held_left, held_right;
    assign source_ready = !pcm_valid || pcm_ready;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pcm_valid <= 0;
            pcm_left <= 0;
            pcm_right <= 0;
            stalled <= 0;
            held_left <= 0;
            held_right <= 0;
            contract_error <= 0;
        end else begin
            if (stalled && (!source_valid || source_left !== held_left || source_right !== held_right))
                contract_error <= 1;
            stalled <= source_valid && !source_ready;
            if (source_valid && !source_ready) begin
                held_left <= source_left;
                held_right <= source_right;
            end
            if (source_ready) begin
                pcm_valid <= source_valid;
                if (source_valid) begin
                    pcm_left <= source_left;
                    pcm_right <= source_right;
                end
            end
        end
    end
endmodule
