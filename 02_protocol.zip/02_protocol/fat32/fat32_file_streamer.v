`timescale 1ns/1ps
// Read-only file stream. A validated-sector replay adapter owns the one 512B
// buffer. file_valid/file_byte/file_byte_offset hold until byte_ready; no byte
// past directory file_size is emitted. The remaining allocated FAT tail is
// checked to EOC without reading or emitting extra file data.
module fat32_file_streamer #(
    // Set only when the captured mount geometry satisfies the scanner contract
    // documented in MOUNT_GEOMETRY_PROOF.md. Default retains all generic checks.
    parameter integer VALIDATED_MOUNT_GEOMETRY = 0,
    parameter integer MAX_VISITED_CLUSTERS = 8192,
    parameter integer RUNTIME_CLUSTER_BUDGET_ENABLE = 0,
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SECTOR_TIMEOUT_MS = 500,
    parameter integer STALL_TIMEOUT_MS = 1000
) (
    input wire clk, rst_n, file_start, file_abort,
    input wire [31:0] first_cluster, file_size,
    input wire [31:0] file_cluster_budget,
    input wire [7:0] sectors_per_cluster,
    input wire [31:0] fat_start_lba, data_start_lba, max_cluster,
    input wire [31:0] fat_sector_count, volume_last_lba,
    input wire byte_ready,
    output wire file_busy,
    output reg file_done,
    output wire file_valid,
    output wire [7:0] file_byte,
    output wire [31:0] file_byte_offset,
    output reg [7:0] fs_error,
    output reg fragment_seen,
    output reg sector_req,
    output reg [31:0] sector_lba,
    input wire sector_busy, sector_valid,
    input wire [7:0] sector_byte,
    input wire [8:0] sector_byte_index,
    input wire sector_done,
    input wire [7:0] sector_error,
    output wire sector_byte_ready
);
    localparam [7:0] E_TIMEOUT=8'h11, E_FRAME=8'h12, E_LOOP=8'h23,
        E_CLUSTER=8'h24, E_EARLY=8'h25, E_BUDGET=8'h26,
        E_BAD=8'h27, E_RESERVED=8'h28, E_RANGE=8'h29,
        E_STALL=8'h2b, E_ABORT=8'h2d;
    localparam [4:0] IDLE=0, START_CHECK=1, CAPACITY=2, CAP_CHECK=3,
        CL_SUB=4, CL_SHIFT=5, CL_ADD=6, CL_LAST=7, CL_CHECK=8,
        DATA_REQ=9, DATA_RX=10, DATA_CHECK=11, FAT_ADDR=12,
        FAT_CHECK=13, FAT_REQ=14, FAT_RX=15, FAT_SECTOR_CHECK=16,
        FAT_PARSE=17, FINISH=18, FAT_FLAGS=19,
        START_FLAGS=20, START_MATH=21, CAP_FLAGS=22;
    localparam integer TC_RAW=(CLK_FREQ_HZ/1000)*SECTOR_TIMEOUT_MS;
    localparam integer TC=(TC_RAW<2)?2:TC_RAW;
    localparam integer TW=($clog2(TC+1)<1)?1:$clog2(TC+1);
    localparam integer SC_RAW=(CLK_FREQ_HZ/1000)*STALL_TIMEOUT_MS;
    localparam integer SC=(SC_RAW<2)?2:SC_RAW;
    localparam integer SW=($clog2(SC+1)<1)?1:$clog2(SC+1);
    reg [4:0] state;
    reg [31:0] current_cluster, remaining, emitted, size_latched;
    // Exact registered mirror of remaining!=0. Only accepted file bytes
    // decrement remaining, so clear this flag on its last-byte transition.
    // This removes the 32-bit zero reduction from downstream BMP valid/CE.
    reg remaining_nonzero;
    reg [31:0] fat_base, data_base, last_lba, last_cluster, fat_size;
    reg [7:0] spc, sector_in_cluster;
    reg [2:0] spc_log2;
    reg [31:0] cluster_delta;
    reg [38:0] cluster_offset;
    // Multiply by an exact one-hot factor. Using log2 rather than spc also
    // preserves the generic/error-path arithmetic for malformed geometry.
    wire [7:0] shift_factor = 8'h01 << spc_log2;
    wire [23:0] offset_low_product,offset_high_product;
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(16),.INPUT_WIDTH_B(8),.OUTPUT_WIDTH(24),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_shift_low (
        .a(cluster_delta[15:0]),.b(shift_factor),.p(offset_low_product),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(16),.INPUT_WIDTH_B(8),.OUTPUT_WIDTH(24),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_shift_high (
        .a(cluster_delta[31:16]),.b(shift_factor),.p(offset_high_product),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    // For a one-hot multiplier the two overlapping slices are disjoint.
    // The discarded product bit23 is zero for every 16-bit value and n<=7.
    wire [38:0] shifted_offset = {offset_high_product[22:0],16'd0} |
                                 {15'd0,offset_low_product};
    reg [32:0] cluster_base_wide, cluster_last_wide, fat_addr_wide, fat_last_wide;
    reg [8:0] fat_offset;
    reg [31:0] fat_value, chain_count, chain_anchor, chain_power, chain_period;
    reg [31:0] cluster_budget;
    reg [9:0] received;
    reg sequence_error;
    reg [7:0] received_error;
    reg abort_pending;
    reg [TW-1:0] timer;
    reg [SW-1:0] stall_timer;
    reg timeout_flag, stall_flag;
    // Classify a held FAT entry in parallel, then apply the original ordered
    // policy one cycle later. This breaks next_cluster -> validator priority
    // -> Brent anchor/power/count register enables without changing the chain.
    reg fat_is_eoc, fat_is_bad, fat_is_reserved, fat_out_of_range;
    reg fat_is_loop, fat_budget_exhausted, fat_is_fragment, fat_reanchor;
    // Parallel validity policy: keep the ordered error code mux separate
    // from the decision to enter FINISH. Same FLAGS/PARSE cycle boundary.
    reg fat_policy_fail;
    reg start_empty, start_empty_has_cluster;
    reg [8:0] start_invalid;
    reg [3:0] capacity_invalid;
    // Geometry is still captured per file. The optimized mode does not alias
    // live scanner buses or change any file/FAT/CRC/error/timeout policy.
    // Elaboration removes only arithmetic/registers used solely by proven
    // invariant checks; all original states and transaction timing remain.
    wire receiving=state==DATA_RX || state==FAT_RX;
    wire valid_index=received<512 && sector_byte_index==received[8:0];
    wire take=receiving && sector_valid && sector_byte_ready;
    wire delivering=state==DATA_RX && remaining_nonzero && !abort_pending && !file_abort;
    wire blocked=delivering && sector_valid && !byte_ready;
    wire [31:0] next_cluster={4'b0,fat_value[27:0]};
    assign file_busy=state!=IDLE;
    assign file_valid=delivering && sector_valid && valid_index;
    assign file_byte=sector_byte;
    assign file_byte_offset=emitted;
    // Sink unsolicited/late data outside an owned RX state, never parse it.
    // Requests still require busy=0 before a fresh transaction is armed.
    assign sector_byte_ready=delivering ? byte_ready : 1'b1;
    function good_spc;
        input [7:0] value;
        begin case(value)
            1,2,4,8,16,32,64,128:good_spc=1'b1;
            default:good_spc=1'b0;
        endcase end
    endfunction
    function [2:0] log_spc;
        input [7:0] value;
        begin case(value)
            2:log_spc=1;4:log_spc=2;8:log_spc=3;16:log_spc=4;
            32:log_spc=5;64:log_spc=6;128:log_spc=7;default:log_spc=0;
        endcase end
    endfunction
    task fail;
        input [7:0] code;
        begin fs_error<=code;state<=FINISH;end
    endtask
    // Control and externally qualified status retain asynchronous reset.
    // The fail task writes only this process's state/error registers.
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;file_done<=0;fs_error<=0;fragment_seen<=0;sector_req<=0;
            remaining_nonzero<=0;abort_pending<=0;timeout_flag<=0;stall_flag<=0;
        end else begin
            file_done<=0;sector_req<=0;
            if((receiving && !take && !blocked) || ((state==DATA_REQ || state==FAT_REQ) && sector_busy))
                timeout_flag<=timer>=TC-2;
            else timeout_flag<=0;
            if(blocked) stall_flag<=stall_timer>=SC-2;
            else stall_flag<=0;
            if(file_abort && state!=IDLE) abort_pending<=1;
            if(take && state==DATA_RX && file_valid && byte_ready && remaining==1)
                remaining_nonzero<=0;
            case(state)
                IDLE:if(file_start) begin
                    fs_error<=0;fragment_seen<=0;remaining_nonzero<=file_size!=0;
                    abort_pending<=0;state<=START_FLAGS;
                end
                START_FLAGS:state<=START_CHECK;
                START_CHECK:begin
                    if(start_empty) begin
                        if(start_empty_has_cluster) fail(E_CLUSTER);else state<=FINISH;
                    end else if(|start_invalid) fail(E_CLUSTER);
                    else state<=START_MATH;
                end
                START_MATH:state<=CAPACITY;
                CAPACITY,CL_SHIFT:state<=state==CAPACITY ? CAP_FLAGS : CL_ADD;
                CAP_FLAGS:state<=CAP_CHECK;
                CAP_CHECK:if(|capacity_invalid) fail(E_RANGE);else state<=CL_SUB;
                CL_SUB:state<=CL_SHIFT;
                CL_ADD:state<=CL_LAST;
                CL_LAST:state<=CL_CHECK;
                CL_CHECK:if(VALIDATED_MOUNT_GEOMETRY==0 && (|cluster_offset[38:32] || cluster_base_wide[32] || cluster_last_wide[32] ||
                    cluster_last_wide[31:0]>last_lba)) fail(E_RANGE);
                    else state<=DATA_REQ;
                DATA_REQ:if(!sector_busy) begin sector_req<=1;state<=DATA_RX;end
                DATA_RX:if(sector_done) state<=DATA_CHECK;
                DATA_CHECK:begin
                    if(received_error!=0) fail(received_error);
                    else if(received!=512 || sequence_error) fail(E_FRAME);
                    else if(abort_pending || file_abort) fail(E_ABORT);
                    else if(!remaining_nonzero) state<=FAT_ADDR;
                    else if(sector_in_cluster+1'b1<spc) state<=DATA_REQ;
                    else state<=FAT_ADDR;
                end
                FAT_ADDR:state<=FAT_CHECK;
                FAT_CHECK:if(VALIDATED_MOUNT_GEOMETRY==0 && ((current_cluster>>7)>=fat_size || fat_addr_wide[32] ||
                    fat_addr_wide[31:0]>fat_last_wide[31:0])) fail(E_RANGE);
                    else state<=FAT_REQ;
                FAT_REQ:if(!sector_busy) begin sector_req<=1;state<=FAT_RX;end
                FAT_RX:if(sector_done) state<=FAT_SECTOR_CHECK;
                FAT_SECTOR_CHECK:if(received_error!=0) fail(received_error);
                    else if(received!=512 || sequence_error) fail(E_FRAME);
                    else if(abort_pending || file_abort) fail(E_ABORT);
                    else state<=FAT_FLAGS;
                FAT_FLAGS:state<=FAT_PARSE;
                FAT_PARSE:begin
                    if(fat_policy_fail) begin
                        state<=FINISH;
                        if(fat_is_eoc) fs_error<=E_EARLY;
                        else if(fat_is_bad) fs_error<=E_BAD;
                        else if(fat_is_reserved) fs_error<=E_RESERVED;
                        else if(fat_out_of_range) fs_error<=E_CLUSTER;
                        else if(fat_is_loop) fs_error<=E_LOOP;
                        else fs_error<=E_BUDGET;
                    end else if(fat_is_eoc) state<=FINISH;
                    else begin
                        if(fat_is_fragment) fragment_seen<=1;
                        if(!remaining_nonzero) state<=FAT_ADDR;else state<=CL_SUB;
                    end
                end
                FINISH:begin file_done<=1;state<=IDLE;end
                default:state<=IDLE;
            endcase
            // Preserve ordered abort/timeout/stall overrides and replay drain.
            if((abort_pending || file_abort) && state!=IDLE && state!=FINISH && !receiving)
                fail(E_ABORT);
            if((receiving || state==DATA_REQ || state==FAT_REQ) && timeout_flag) fail(E_TIMEOUT);
            if(receiving && stall_flag) fail(E_STALL);
        end
    end

    // Transaction-owned datapath. Every value is written before a qualified
    // use: IDLE captures file geometry/Brent state; FLAGS/MATH stages prepare
    // their next stage; a request clears receive accounting; a validated FAT
    // sector supplies all four fat_value bytes before FLAGS/PARSE can run.
    // Timers clear in IDLE before any request state, while their published
    // timeout/stall flags remain asynchronously reset above. Payload has no
    // defined meaning during reset or when file_valid/sector_req are low.
    always @(posedge clk) begin
        if(rst_n) begin
            if((receiving && !take && !blocked) || ((state==DATA_REQ || state==FAT_REQ) && sector_busy))
                timer<=timer+1'b1;
            else timer<=0;
            if(blocked) stall_timer<=stall_timer+1'b1;
            else stall_timer<=0;
            if(take) begin
                if(!valid_index) sequence_error<=1;
                if(received<513) received<=received+1'b1;
                if(state==DATA_RX && file_valid && byte_ready) begin
                    emitted<=emitted+1'b1;remaining<=remaining-1'b1;
                end
                if(state==FAT_RX && valid_index && sector_byte_index[8:2]==fat_offset[8:2]) begin
                    case(sector_byte_index[1:0])
                        0:fat_value[7:0]<=sector_byte;1:fat_value[15:8]<=sector_byte;
                        2:fat_value[23:16]<=sector_byte;3:fat_value[31:24]<=sector_byte;
                    endcase
                end
            end
            case(state)
                IDLE:if(file_start) begin
                    emitted<=0;remaining<=file_size;size_latched<=file_size;
                    current_cluster<=first_cluster;fat_base<=fat_start_lba;data_base<=data_start_lba;
                    cluster_budget<=RUNTIME_CLUSTER_BUDGET_ENABLE!=0 ? file_cluster_budget : MAX_VISITED_CLUSTERS;
                    last_lba<=volume_last_lba;last_cluster<=max_cluster;fat_size<=fat_sector_count;
                    spc<=sectors_per_cluster;spc_log2<=log_spc(sectors_per_cluster);
                    sector_in_cluster<=0;chain_count<=1;chain_anchor<=first_cluster;
                    chain_power<=1;chain_period<=0;
                end
                START_FLAGS:begin
                    start_empty<=size_latched==0;
                    start_empty_has_cluster<=current_cluster!=0;
                    start_invalid[0]<=VALIDATED_MOUNT_GEOMETRY==0 && (!good_spc(spc));
                    start_invalid[1]<=current_cluster<2;
                    start_invalid[2]<=current_cluster>last_cluster;
                    start_invalid[3]<=VALIDATED_MOUNT_GEOMETRY==0 && (last_cluster<2);
                    start_invalid[4]<=VALIDATED_MOUNT_GEOMETRY==0 && (last_cluster>=32'h0ffffff0);
                    start_invalid[5]<=VALIDATED_MOUNT_GEOMETRY==0 && (fat_size==0);
                    start_invalid[6]<=VALIDATED_MOUNT_GEOMETRY==0 && (fat_base>=data_base);
                    start_invalid[7]<=VALIDATED_MOUNT_GEOMETRY==0 && (data_base>last_lba);
                    start_invalid[8]<=cluster_budget<1;
                end
                START_MATH:begin
                    cluster_delta<=last_cluster-1'b1;
                    fat_last_wide<={1'b0,fat_base}+{1'b0,fat_size}-1'b1;
                end
                // Shared 39-bit offset keeps all 48 capacity bits (<<9).
                CAPACITY,CL_SHIFT:cluster_offset<=shifted_offset;
                CAP_FLAGS:begin
                    capacity_invalid[0]<=VALIDATED_MOUNT_GEOMETRY==0 && (fat_last_wide[32]);
                    capacity_invalid[1]<=VALIDATED_MOUNT_GEOMETRY==0 && (fat_last_wide[31:0]>=data_base);
                    capacity_invalid[2]<=VALIDATED_MOUNT_GEOMETRY==0 && ((last_cluster>>7)>=fat_size);
                    capacity_invalid[3]<={16'b0,size_latched}>{cluster_offset,9'b0};
                end
                CL_SUB:cluster_delta<=current_cluster-2;
                CL_ADD:cluster_base_wide<={1'b0,data_base}+{1'b0,cluster_offset[31:0]};
                CL_LAST:cluster_last_wide<=cluster_base_wide+{25'b0,spc}-1'b1;
                CL_CHECK:if(VALIDATED_MOUNT_GEOMETRY!=0 || !(|cluster_offset[38:32] || cluster_base_wide[32] || cluster_last_wide[32] ||
                    cluster_last_wide[31:0]>last_lba)) sector_lba<=cluster_base_wide[31:0];
                DATA_REQ,FAT_REQ:if(!sector_busy) begin
                    received<=0;sequence_error<=0;received_error<=0;
                end
                DATA_RX,FAT_RX:if(sector_done) received_error<=sector_error;
                DATA_CHECK:if(received_error==0 && received==512 && !sequence_error &&
                    !abort_pending && !file_abort && remaining_nonzero) begin
                    if(sector_in_cluster+1'b1<spc) begin
                        sector_in_cluster<=sector_in_cluster+1'b1;sector_lba<=sector_lba+1'b1;
                    end else sector_in_cluster<=0;
                end
                FAT_ADDR:begin
                    fat_addr_wide<={1'b0,fat_base}+{1'b0,current_cluster[31:7]};
                    fat_offset<={current_cluster[6:0],2'b0};
                end
                FAT_CHECK:if(VALIDATED_MOUNT_GEOMETRY!=0 || !((current_cluster>>7)>=fat_size || fat_addr_wide[32] ||
                    fat_addr_wide[31:0]>fat_last_wide[31:0])) sector_lba<=fat_addr_wide[31:0];
                FAT_FLAGS:begin
                    fat_policy_fail <= next_cluster>=32'h0ffffff8 ? remaining_nonzero :
                        (next_cluster<2 || next_cluster>=32'h0ffffff0 || next_cluster>last_cluster ||
                         next_cluster==chain_anchor || next_cluster==current_cluster ||
                         chain_count>=cluster_budget);
                    fat_is_eoc<=next_cluster>=32'h0ffffff8;
                    fat_is_bad<=next_cluster==32'h0ffffff7;
                    fat_is_reserved<=next_cluster==1 || next_cluster>=32'h0ffffff0;
                    fat_out_of_range<=next_cluster<2 || next_cluster>last_cluster;
                    fat_is_loop<=next_cluster==chain_anchor || next_cluster==current_cluster;
                    fat_budget_exhausted<=chain_count>=cluster_budget;
                    fat_is_fragment<=next_cluster!=current_cluster+1'b1;
                    fat_reanchor<=chain_period+1'b1==chain_power;
                end
                FAT_PARSE:if(!fat_policy_fail && !fat_is_eoc) begin
                    chain_count<=chain_count+1'b1;current_cluster<=next_cluster;
                    if(fat_reanchor) begin chain_anchor<=next_cluster;chain_power<=chain_power<<1;chain_period<=0;end
                    else chain_period<=chain_period+1'b1;
                end
            endcase
        end
    end
endmodule
