`timescale 1ns/1ps
// Read-only FAT32, root-directory exact short-name or VFAT image-name lookup.
// VFAT image targets are ASCII names up to 26 characters (two LFN entries).
// The sector provider
// must atomically validate a physical sector before replaying its 512 bytes.
// valid/byte/index remain stable until sector_byte_ready; done follows the
// final handshake (same-cycle final byte+done is also supported).
module fat32_volume_scanner #(
    parameter [87:0] NAME0 = "PIC1    BMP",
    parameter [87:0] NAME1 = "PIC2    BMP",
    parameter [87:0] NAME2 = "PIC3    BMP",
    parameter [87:0] NAME3 = "PIC4    BMP",
    parameter [87:0] NAME4 = "PIC5    BMP", NAME5 = "PIC6    BMP",
    parameter [87:0] NAME6 = "PIC7    BMP", NAME7 = "PIC8    BMP",
    parameter integer IMAGE_COUNT = 4, OSD_ENABLE = 0,
    parameter integer COMPACT_TABLE_ENABLE = 0,
    parameter integer START_PAGE_ENABLE = 0, END_PAGE_ENABLE = 0,
    parameter integer IMAGE_LONG_NAME_ENABLE = 0,
    parameter [207:0] IMAGE_LONG_NAME0 = "PIC1_320x240.BMP",
    parameter [207:0] IMAGE_LONG_NAME1 = "PIC2_640x480.BMP",
    parameter [207:0] IMAGE_LONG_NAME2 = "PIC3_1024x768.BMP",
    parameter [207:0] IMAGE_LONG_NAME3 = "PIC4_1920x1080.BMP",
    parameter integer IMAGE_LONG_LEN0 = 16,
    parameter integer IMAGE_LONG_LEN1 = 16,
    parameter integer IMAGE_LONG_LEN2 = 17,
    parameter integer IMAGE_LONG_LEN3 = 18,
    parameter integer MUSIC_LOOKUP_ENABLE = 0,
    parameter integer MUSIC_TRACK_COUNT = 1,
    parameter [87:0] MUSIC_NAME = "MUSIC   PCM",
    parameter [87:0] MUSIC_NAME1 = "PCM2    PCM",
    parameter [87:0] MUSIC_NAME2 = "PCM3    PCM",
    parameter integer MAX_ROOT_CLUSTERS = 4096,
    parameter integer MAX_DIR_SECTORS = 256,
    parameter integer REQUIRE_ALL_RESOURCES = 0,
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer SECTOR_TIMEOUT_MS = 500
) (
    input wire clk, rst_n, scan_start, scan_pause,
    input wire [31:0] media_last_lba,
    output wire scan_busy,
    output reg scan_done, mounted,
    output reg [7:0] fs_error,
    output reg [31:0] partition_lba,
    output reg [7:0] sectors_per_cluster,
    output reg [31:0] fat_start_lba, data_start_lba, max_cluster,
    output reg [31:0] fat_sector_count, volume_last_lba,
    output reg [7:0] resource_valid,
    output reg [31:0] resource0_cluster, resource1_cluster, resource2_cluster, resource3_cluster,
    output reg [31:0] resource0_size, resource1_size, resource2_size, resource3_size,
    output reg [31:0] resource4_cluster, resource5_cluster, resource6_cluster, resource7_cluster,
    output reg [31:0] resource4_size, resource5_size, resource6_size, resource7_size,
    output reg start_valid, output reg end_valid,
    output reg osd_valid,
    output reg [31:0] osd_cluster, osd_size,
    output wire music_valid,
    output reg [20:0] music_valid_mask,
    output reg [31:0] music_cluster, music_size,
    output reg [31:0] music1_cluster, music1_size, music2_cluster, music2_size,
    // Audio slots 3..15 are PCM4..16; slots 16..20 are SFX1..5.
    // Metadata is consumed only with its atomically published valid bit.
    output reg [575:0] music_extra_clusters, music_extra_sizes,
    // Compact catalog: slots 0..7 PIC, 8..28 PCM/SFX, 29 OSD, 30 START, 31 END.
    // One-clock synchronous read. Valid masks qualify all descriptor data.
    input wire [4:0] descriptor_read_slot,
    output wire [63:0] descriptor_read_data,
    output reg sector_req,
    output reg [31:0] sector_lba,
    input wire sector_busy, sector_valid,
    input wire [7:0] sector_byte,
    input wire [8:0] sector_byte_index,
    input wire sector_done,
    input wire [7:0] sector_error,
    output wire sector_byte_ready
);
    localparam [7:0] E_SECTOR=8'h10, E_TIMEOUT=8'h11, E_FRAME=8'h12,
        E_SIGNATURE=8'h20, E_BPB=8'h21, E_MISSING=8'h22, E_LOOP=8'h23,
        E_CLUSTER=8'h24, E_BUDGET=8'h26, E_BAD=8'h27, E_RESERVED=8'h28,
        E_RANGE=8'h29, E_ENTRY=8'h2a;
    localparam [5:0] IDLE=0, REQ=1, RX=2, CHECK=3, CLASSIFY=4, MBR=5,
        PART_END=6, PART_CHECK=7, BPB=8, LAYOUT0=9, LAYOUT1=10,
        LAYOUT2=11, LAYOUT3=12, LAYOUT4=13, LAYOUT5=14, GEOMETRY=15,
        CL_SUB=16, CL_SHIFT=17, CL_ADD=18, CL_LAST=19, CL_CHECK=20,
        ROOT_NEXT=21, FAT_ADDR=22, FAT_CHECK=23, FAT_PARSE=24, FINISH=25,
        FAT_FLAGS=26, FAT_POLICY=27, BPB_FLAGS=28, LAYOUT_FLAGS=29,
        CHECK_FLAGS=30, ROOT_PUBLISH=31, GEOMETRY_FLAGS=32;
    localparam [1:0] K_ZERO=0, K_BOOT=1, K_ROOT=2, K_FAT=3;
    localparam integer TC_RAW=(CLK_FREQ_HZ/1000)*SECTOR_TIMEOUT_MS;
    localparam integer TC=(TC_RAW<2)?2:TC_RAW;
    localparam integer TW=($clog2(TC+1)<1)?1:$clog2(TC+1);
    // An accepted FAT step increments count only while count < its budget.
    // Brent's power is the highest power of two <= count; period < power.
    // Thus all three fit the inclusive budget, including power-of-two limits.
    // Keep the legacy 32-bit behavior for nonpositive root-budget parameters.
    localparam integer ROOT_COUNT_BITS=MAX_ROOT_CLUSTERS<1 ? 32 :
        $clog2(64'd1+MAX_ROOT_CLUSTERS);
    localparam integer DIR_COUNT_BITS=MAX_DIR_SECTORS<0 ? 32 :
        (MAX_DIR_SECTORS<2 ? 1 : $clog2(64'd1+MAX_DIR_SECTORS));
    reg [5:0] state;
    reg [1:0] kind;
    reg [TW-1:0] timer;
    reg timeout_flag;
    reg [9:0] received;
    reg sequence_error;
    reg [7:0] received_error;
    reg checked_sector_good;
    reg [7:0] checked_sector_error;
    reg classify_signature_bad, classify_is_vbr;
    reg [3:0] mbr_candidate_flags, mbr_empty_flags;
    // Complete valid sectors overwrite low then high bytes before consumers.
    // Keep only constant-match predicates; preserve state/error ordering.
    reg jump_good, signature0_good, signature1_good;
    reg bps_good, rootents_zero, tot16_zero, fat16_zero, version_zero;
    reg [7:0] bpb_spc, bpb_nfats;
    reg [15:0] bpb_reserved, bpb_flags;
    reg [31:0] bpb_total, bpb_fatsz, bpb_root;
    // Predecode geometry checks before the state/error priority mux. This keeps
    // wide BPB comparisons off the shared state and destination-register enables.
    reg bpb_signature_bad, bpb_shape_bad, bpb_tables_bad, bpb_extension_bad, bpb_root_bad;
    reg layout_volume_bad, layout_partition_bad, layout_data_bad, layout_fat_bad;
    reg layout_count_bad, layout_root_range_bad, layout_fat_capacity_bad;
    // One streaming entry and the earliest type/status-qualified candidate.
    // A candidate with an empty/range-invalid extent is retained: it must
    // raise E_RANGE rather than silently falling through to a later entry.
    reg [31:0] mbr_entry_start,mbr_entry_size;
    reg [7:0] mbr_entry_type,mbr_entry_status;
    reg [31:0] mbr_first_start,mbr_first_size;
    reg mbr_first_found;
    reg [2:0] partition_index, spc_log2;
    reg has_partition;
    reg [31:0] partition_size, media_limit;
    reg [32:0] partition_end_wide, volume_end_wide, fat_span_wide,
        base_fat_wide, active_fat_wide;
    reg [33:0] reserved_fat_wide, data_base_wide;
    reg [31:0] data_sectors, cluster_count, current_cluster, cluster_delta;
    reg [38:0] cluster_offset;
    // Pure predecode payload, consumed only in LAYOUT5 after GEOMETRY_FLAGS.
    // That one mount-time settling cycle separates the max_cluster update
    // from these comparisons and the shared state/error decision. Reset
    // invalidates state, not these unconsumed data-only registers.
    always @(posedge clk) begin
        layout_count_bad<=cluster_count<65525 || cluster_count>32'h0fffffee;
        layout_root_range_bad<=bpb_root>max_cluster;
        layout_fat_capacity_bad<=(max_cluster>>7)>=fat_sector_count;
    end
    // The two geometry states never execute simultaneously. A shared exact
    // one-hot multiplier replaces the independent wide left/right shifters.
    // Reverse-bit wiring turns a logical right shift into a low-32-bit left
    // shift and reversal; the ordinary left mode preserves all 39 bits.
    function [31:0] reverse_geometry_bits;
        input [31:0] value;
        integer bit_index;
        begin
            for(bit_index=0;bit_index<32;bit_index=bit_index+1)
                reverse_geometry_bits[bit_index]=value[31-bit_index];
        end
    endfunction
    wire [31:0] geometry_shift_source=state==LAYOUT3 ?
        reverse_geometry_bits(data_sectors) : cluster_delta;
    wire [7:0] geometry_shift_factor=8'h01 << spc_log2;
    wire [23:0] geometry_product_low,geometry_product_high;
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(16),.INPUT_WIDTH_B(8),.OUTPUT_WIDTH(24),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_geometry_shift_low (
        .a(geometry_shift_source[15:0]),.b(geometry_shift_factor),.p(geometry_product_low),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    EG_LOGIC_MULT #(.INPUT_WIDTH_A(16),.INPUT_WIDTH_B(8),.OUTPUT_WIDTH(24),
        .INPUTFORMAT("UNSIGNED"),.INPUTREGA("DISABLE"),.INPUTREGB("DISABLE"),
        .OUTPUTREG("DISABLE"),.IMPLEMENT("AUTO"),.SRMODE("ASYNC")) u_geometry_shift_high (
        .a(geometry_shift_source[31:16]),.b(geometry_shift_factor),.p(geometry_product_high),
        .cea(1'b1),.ceb(1'b1),.cepd(1'b1),.clk(clk),
        .rstan(1'b1),.rstbn(1'b1),.rstpdn(1'b1));
    // For every factor 1..128, the limbs' overlapping bits are disjoint.
    // A 16-bit unsigned limb times 128 never sets product bit23.
    wire [38:0] geometry_shift_result={geometry_product_high[22:0],16'd0} |
                                      {15'd0,geometry_product_low};
    wire [31:0] geometry_right_result=reverse_geometry_bits(geometry_shift_result[31:0]);

    reg [32:0] cluster_base_wide, cluster_last_wide, fat_addr_wide;
    reg [7:0] sector_in_cluster;
    reg [ROOT_COUNT_BITS-1:0] root_chain_count, chain_power, chain_period;
    reg [31:0] chain_anchor;
    reg [DIR_COUNT_BITS-1:0] directory_sectors;
    reg [8:0] fat_offset;
    reg [31:0] fat_value;
    // Classify the held FAT entry, then register the ordered policy before
    // changing Brent counters. The wide next-cluster comparisons no longer
    // feed the chain power/anchor register enables in the same clock cycle.
    reg fat_is_eoc, fat_is_bad, fat_is_reserved, fat_out_of_range;
    reg fat_is_loop, fat_budget_exhausted, fat_reanchor;
    reg fat_policy_continue;
    reg [7:0] fat_policy_error;
    reg [7:0] entry_match, pending_valid;
    reg [20:0] entry_music_match, pending_music_valid;
    reg entry_osd_match, pending_osd_valid;
    reg entry_start_match, pending_start_valid;
    reg entry_end_match, pending_end_valid;
    reg [31:0] pending_music_cluster, pending_music_size;
    reg [31:0] pending_music1_cluster, pending_music1_size;
    reg [31:0] pending_music2_cluster, pending_music2_size;
    reg entry_regular, directory_end;
    reg [31:0] entry_cluster, entry_size;
    // Cluster bytes are complete at ordered entry byte27. Byte28 registers
    // this range predicate before byte31 can commit the descriptor, even
    // with contiguous sector bytes. Pauses only add settling cycles. A bad
    // byte index cannot commit, and CRC/framing publication stays unchanged.
    // No reset is needed: no valid entry reaches byte31 before bytes20/21/26/27.
    reg entry_cluster_in_range;
    always @(posedge clk)
        entry_cluster_in_range<=entry_cluster>=2 && entry_cluster<=max_cluster;
    integer i;
    wire take=sector_valid && sector_byte_ready && state==RX;
    wire valid_index=received<512 && sector_byte_index==received[8:0];
    wire [31:0] next_cluster={4'b0,fat_value[27:0]};
    reg descriptor_write;
    reg [4:0] descriptor_write_slot;
    reg [63:0] descriptor_write_data;
    generate if(COMPACT_TABLE_ENABLE!=0) begin : g_descriptor_ram
        // No RAM reset: unvalidated sectors never publish their valid bits.
        // Native 9K BRAM replaces 31 wide FF banks and their read multiplexers.
        (* ram_style="bram" *) reg [63:0] descriptors[0:31];
        reg [63:0] read_data;
        // Reversible size-bit encoding adds real write-port logic on the
        // short size[6] hold path. Decode after the synchronous read; public
        // descriptors, latency, strobe, capacity and CRC publication are unchanged.
        wire [63:0] encoded_write_data={descriptor_write_data[63:7],
            descriptor_write_data[6]^descriptor_write_data[9],descriptor_write_data[5:0]};
        always @(posedge clk) begin
            if(descriptor_write) descriptors[descriptor_write_slot]<=encoded_write_data;
            read_data<=descriptors[descriptor_read_slot];
        end
        assign descriptor_read_data={read_data[63:7],read_data[6]^read_data[9],read_data[5:0]};
    end else begin : g_descriptor_unused
        assign descriptor_read_data=64'd0;
    end endgenerate
    task save_descriptor;
        input [4:0] slot;
        input [31:0] cluster, size;
        begin
            descriptor_write<=1'b1;

        end
    endtask
    wire [7:0] combined_valid=resource_valid|pending_valid;
    wire [3:0] long_image_match;
    wire [7:0] selected_image_match=IMAGE_LONG_NAME_ENABLE!=0 ? {4'b0,long_image_match} : entry_match;
    wire [20:0] combined_music_valid=music_valid_mask|pending_music_valid;
    localparam [20:0] REQUIRED_MUSIC_MASK=(21'h1fffff >> (21-MUSIC_TRACK_COUNT));
    localparam [7:0] REQUIRED_IMAGE_MASK=(8'hff >> (8-IMAGE_COUNT));
    wire combined_osd_valid=osd_valid|pending_osd_valid;
    wire combined_start_valid=start_valid|pending_start_valid;
    wire combined_end_valid=end_valid|pending_end_valid;
    wire [5:0] mbr_offset=sector_byte_index-9'd446;
    assign scan_busy=(state!=IDLE);
    assign music_valid=music_valid_mask[0];
    // Outside RX, sink a late response without parsing it. New requests always
    // wait for busy=0, so an expired transaction cannot enter a fresh parser.
    assign sector_byte_ready=1'b1;
    function good_spc;
        input [7:0] value;
        begin good_spc=value!=0 && (value&(value-1'b1))==0; end
    endfunction
    function [2:0] log_spc;
        input [7:0] value;
        begin case(value)
            2:log_spc=1;4:log_spc=2;8:log_spc=3;16:log_spc=4;
            32:log_spc=5;64:log_spc=6;128:log_spc=7;default:log_spc=0;
        endcase end
    endfunction
    function [7:0] name_byte;
        input [87:0] name;
        input [3:0] index;
        begin name_byte=name >> ((10-index)*8); end
    endfunction
    function [7:0] ascii_upper;
        input [7:0] value;
        begin ascii_upper=(value>=8'h61 && value<=8'h7a)?value-8'h20:value; end
    endfunction
    // Expected UTF-16 byte, including the exact terminator and FFFF padding.
    // A name of exactly 13/26 characters fills its entries without a terminator.
    function [7:0] long_name_byte;
        input [207:0] name;
        input integer length;
        input [4:0] character;
        input high_byte;
        reg [7:0] letter;
        begin
            letter=name >> ((length-1-character)*8);
            if(character<length) long_name_byte=high_byte ? 8'h00 : ascii_upper(letter);
            else if(character==length) long_name_byte=8'h00;
            else long_name_byte=8'hff;
        end
    endfunction
    generate if(IMAGE_LONG_NAME_ENABLE!=0) begin : g_image_long_name
        reg active, entry_good, entry_is_lfn;
        reg [1:0] expected_ordinal, entry_ordinal;
        reg entry_last;
        reg [7:0] chain_checksum, entry_checksum, short_checksum;
        reg [3:0] chain_match, fragment_match, short_match;
        wire [4:0] offset=sector_byte_index[4:0];
        wire character_byte=(offset>=1 && offset<=10) ||
            (offset>=14 && offset<=25) || offset>=28;
        wire high_byte=(offset<=10)?!offset[0]:offset[0];
        wire [7:0] compare_byte=high_byte?sector_byte:ascii_upper(sector_byte);
        // Direct constant-byte table: no offset subtraction, ordinal*13 add,
        // or variable character-index arithmetic in the per-byte match path.
        // Every constant still uses the same exact name/terminator/padding rule.
        function [7:0] fragment_byte;
            input [207:0] name;
            input integer length;
            input second_fragment;
            input [4:0] byte_offset;
            begin
                case ({second_fragment,byte_offset})
                    6'd1: fragment_byte=long_name_byte(name,length,5'd0,1'b0);
                    6'd2: fragment_byte=long_name_byte(name,length,5'd0,1'b1);
                    6'd3: fragment_byte=long_name_byte(name,length,5'd1,1'b0);
                    6'd4: fragment_byte=long_name_byte(name,length,5'd1,1'b1);
                    6'd5: fragment_byte=long_name_byte(name,length,5'd2,1'b0);
                    6'd6: fragment_byte=long_name_byte(name,length,5'd2,1'b1);
                    6'd7: fragment_byte=long_name_byte(name,length,5'd3,1'b0);
                    6'd8: fragment_byte=long_name_byte(name,length,5'd3,1'b1);
                    6'd9: fragment_byte=long_name_byte(name,length,5'd4,1'b0);
                    6'd10: fragment_byte=long_name_byte(name,length,5'd4,1'b1);
                    6'd14: fragment_byte=long_name_byte(name,length,5'd5,1'b0);
                    6'd15: fragment_byte=long_name_byte(name,length,5'd5,1'b1);
                    6'd16: fragment_byte=long_name_byte(name,length,5'd6,1'b0);
                    6'd17: fragment_byte=long_name_byte(name,length,5'd6,1'b1);
                    6'd18: fragment_byte=long_name_byte(name,length,5'd7,1'b0);
                    6'd19: fragment_byte=long_name_byte(name,length,5'd7,1'b1);
                    6'd20: fragment_byte=long_name_byte(name,length,5'd8,1'b0);
                    6'd21: fragment_byte=long_name_byte(name,length,5'd8,1'b1);
                    6'd22: fragment_byte=long_name_byte(name,length,5'd9,1'b0);
                    6'd23: fragment_byte=long_name_byte(name,length,5'd9,1'b1);
                    6'd24: fragment_byte=long_name_byte(name,length,5'd10,1'b0);
                    6'd25: fragment_byte=long_name_byte(name,length,5'd10,1'b1);
                    6'd28: fragment_byte=long_name_byte(name,length,5'd11,1'b0);
                    6'd29: fragment_byte=long_name_byte(name,length,5'd11,1'b1);
                    6'd30: fragment_byte=long_name_byte(name,length,5'd12,1'b0);
                    6'd31: fragment_byte=long_name_byte(name,length,5'd12,1'b1);
                    6'd33: fragment_byte=long_name_byte(name,length,5'd13,1'b0);
                    6'd34: fragment_byte=long_name_byte(name,length,5'd13,1'b1);
                    6'd35: fragment_byte=long_name_byte(name,length,5'd14,1'b0);
                    6'd36: fragment_byte=long_name_byte(name,length,5'd14,1'b1);
                    6'd37: fragment_byte=long_name_byte(name,length,5'd15,1'b0);
                    6'd38: fragment_byte=long_name_byte(name,length,5'd15,1'b1);
                    6'd39: fragment_byte=long_name_byte(name,length,5'd16,1'b0);
                    6'd40: fragment_byte=long_name_byte(name,length,5'd16,1'b1);
                    6'd41: fragment_byte=long_name_byte(name,length,5'd17,1'b0);
                    6'd42: fragment_byte=long_name_byte(name,length,5'd17,1'b1);
                    6'd46: fragment_byte=long_name_byte(name,length,5'd18,1'b0);
                    6'd47: fragment_byte=long_name_byte(name,length,5'd18,1'b1);
                    6'd48: fragment_byte=long_name_byte(name,length,5'd19,1'b0);
                    6'd49: fragment_byte=long_name_byte(name,length,5'd19,1'b1);
                    6'd50: fragment_byte=long_name_byte(name,length,5'd20,1'b0);
                    6'd51: fragment_byte=long_name_byte(name,length,5'd20,1'b1);
                    6'd52: fragment_byte=long_name_byte(name,length,5'd21,1'b0);
                    6'd53: fragment_byte=long_name_byte(name,length,5'd21,1'b1);
                    6'd54: fragment_byte=long_name_byte(name,length,5'd22,1'b0);
                    6'd55: fragment_byte=long_name_byte(name,length,5'd22,1'b1);
                    6'd56: fragment_byte=long_name_byte(name,length,5'd23,1'b0);
                    6'd57: fragment_byte=long_name_byte(name,length,5'd23,1'b1);
                    6'd60: fragment_byte=long_name_byte(name,length,5'd24,1'b0);
                    6'd61: fragment_byte=long_name_byte(name,length,5'd24,1'b1);
                    6'd62: fragment_byte=long_name_byte(name,length,5'd25,1'b0);
                    6'd63: fragment_byte=long_name_byte(name,length,5'd25,1'b1);
                    default: fragment_byte=8'hff;
                endcase
            end
        endfunction
        wire second_fragment=(entry_ordinal==2);
        wire [3:0] char_matches={
            compare_byte==fragment_byte(IMAGE_LONG_NAME3,IMAGE_LONG_LEN3,second_fragment,offset),
            compare_byte==fragment_byte(IMAGE_LONG_NAME2,IMAGE_LONG_LEN2,second_fragment,offset),
            compare_byte==fragment_byte(IMAGE_LONG_NAME1,IMAGE_LONG_LEN1,second_fragment,offset),
            compare_byte==fragment_byte(IMAGE_LONG_NAME0,IMAGE_LONG_LEN0,second_fragment,offset)};
        assign long_image_match=short_match;
        // State is deliberately preserved across ROOT sectors, FAT traversal,
        // and scan_pause. Only the immediately following valid short entry can
        // consume a complete LFN chain; aliases are never guessed or matched.
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                active<=0;entry_good<=0;entry_is_lfn<=0;expected_ordinal<=0;
                entry_ordinal<=0;entry_last<=0;chain_checksum<=0;entry_checksum<=0;
                short_checksum<=0;chain_match<=0;fragment_match<=0;short_match<=0;
            end else if(state==IDLE && scan_start) begin
                active<=0;entry_good<=0;entry_is_lfn<=0;expected_ordinal<=0;
                chain_match<=0;fragment_match<=0;short_match<=0;
            end else if(take && valid_index && kind==K_ROOT && !directory_end) begin
                if(offset==0) begin
                    short_match<=0;entry_is_lfn<=0;entry_checksum<=0;
                    short_checksum<=sector_byte;
                    entry_ordinal<=sector_byte[1:0];entry_last<=sector_byte[6];
                    entry_good<=(sector_byte==8'h41 || sector_byte==8'h42) ||
                        (sector_byte==8'h01 && active && expected_ordinal==1);
                    if(sector_byte==8'h41 || sector_byte==8'h42)
                        fragment_match<={
                            IMAGE_LONG_LEN3>=1 && IMAGE_LONG_LEN3<=26 && ((IMAGE_LONG_LEN3+12)/13)==sector_byte[1:0],
                            IMAGE_LONG_LEN2>=1 && IMAGE_LONG_LEN2<=26 && ((IMAGE_LONG_LEN2+12)/13)==sector_byte[1:0],
                            IMAGE_LONG_LEN1>=1 && IMAGE_LONG_LEN1<=26 && ((IMAGE_LONG_LEN1+12)/13)==sector_byte[1:0],
                            IMAGE_LONG_LEN0>=1 && IMAGE_LONG_LEN0<=26 && ((IMAGE_LONG_LEN0+12)/13)==sector_byte[1:0]};
                    else fragment_match<=chain_match;
                end else begin
                    if(offset<=10)
                        short_checksum<={short_checksum[0],short_checksum[7:1]}+sector_byte;
                    if(character_byte) fragment_match<=fragment_match & char_matches;
                    case(offset)
                        11:begin
                            entry_is_lfn<=sector_byte==8'h0f;
                            if(sector_byte!=8'h0f) begin
                                // short_checksum already includes all 11 bytes.
                                short_match<=(active && expected_ordinal==0 &&
                                    short_checksum==chain_checksum)?chain_match:4'b0;
                                active<=0;chain_match<=0;
                            end
                        end
                        12:if(sector_byte!=0) entry_good<=0;
                        13:begin
                            entry_checksum<=sector_byte;
                            if(!entry_last && sector_byte!=chain_checksum) entry_good<=0;
                        end
                        26,27:if(sector_byte!=0) entry_good<=0;
                        31:if(entry_is_lfn) begin
                            active<=entry_good;
                            expected_ordinal<=entry_ordinal-1'b1;
                            chain_checksum<=entry_checksum;
                            // Byte31 is the final UTF-16 high byte and must be
                            // included now, not the prior fragment_match value.
                            chain_match<=entry_good ? (fragment_match & char_matches) : 4'b0;
                        end
                        default:begin end
                    endcase
                end
            end
        end
    end else begin : g_image_short_name
        assign long_image_match=4'b0;
    end endgenerate
    // Constant-index callers synthesize fixed short-name comparators.
    function [87:0] audio_name;
        input integer slot;
        begin case(slot)
            0:audio_name=MUSIC_NAME;1:audio_name=MUSIC_NAME1;2:audio_name=MUSIC_NAME2;
            3:audio_name="PCM4    PCM";4:audio_name="PCM5    PCM";5:audio_name="PCM6    PCM";
            6:audio_name="PCM7    PCM";7:audio_name="PCM8    PCM";8:audio_name="PCM9    PCM";
            9:audio_name="PCM10   PCM";
            10:audio_name="PCM11   PCM";
            11:audio_name="PCM12   PCM";
            12:audio_name="PCM13   PCM";
            13:audio_name="PCM14   PCM";
            14:audio_name="PCM15   PCM";
            15:audio_name="PCM16   PCM";
            16:audio_name="SFX1    PCM";17:audio_name="SFX2    PCM";18:audio_name="SFX3    PCM";
            19:audio_name="SFX4    PCM";20:audio_name="SFX5    PCM";default:audio_name=88'd0;
        endcase end
    endfunction
    task fail;
        input [7:0] code;
        begin fs_error<=code;state<=FINISH;end
    endtask
    task finish_directory;
        input [7:0] valid_mask;
        begin
            if(valid_mask==0 || (REQUIRE_ALL_RESOURCES!=0 && valid_mask!=REQUIRED_IMAGE_MASK))
                fs_error<=E_MISSING;
            state<=FINISH;
        end
    endtask

    // Pure parser payload has no reset tree. Complete ordered sectors/entries
    // overwrite every consumed bit before the retained valid/state controls
    // permit publication. Reset forces state=IDLE, which makes take false.
    // Descriptor RAM only consumes these held words on descriptor_write;
    // its strobe and every pending/committed validity bit still reset.
    integer payload_i;
    always @(posedge clk) begin
        if(take && valid_index) begin
            if(kind==K_ZERO || kind==K_BOOT) begin
                case(sector_byte_index)
                    13:bpb_spc<=sector_byte;
                    14:bpb_reserved[7:0]<=sector_byte;15:bpb_reserved[15:8]<=sector_byte;
                    16:bpb_nfats<=sector_byte;
                    32:bpb_total[7:0]<=sector_byte;33:bpb_total[15:8]<=sector_byte;
                    34:bpb_total[23:16]<=sector_byte;35:bpb_total[31:24]<=sector_byte;
                    36:bpb_fatsz[7:0]<=sector_byte;37:bpb_fatsz[15:8]<=sector_byte;
                    38:bpb_fatsz[23:16]<=sector_byte;39:bpb_fatsz[31:24]<=sector_byte;
                    40:bpb_flags[7:0]<=sector_byte;41:bpb_flags[15:8]<=sector_byte;
                    44:bpb_root[7:0]<=sector_byte;45:bpb_root[15:8]<=sector_byte;
                    46:bpb_root[23:16]<=sector_byte;47:bpb_root[31:24]<=sector_byte;
                    default:begin end
                endcase
                if(kind==K_ZERO && sector_byte_index>=446 && sector_byte_index<510)begin
                    case(mbr_offset[3:0])
                        0:mbr_entry_status<=sector_byte;4:mbr_entry_type<=sector_byte;
                        8:mbr_entry_start[7:0]<=sector_byte;9:mbr_entry_start[15:8]<=sector_byte;
                        10:mbr_entry_start[23:16]<=sector_byte;11:mbr_entry_start[31:24]<=sector_byte;
                        12:mbr_entry_size[7:0]<=sector_byte;13:mbr_entry_size[15:8]<=sector_byte;
                        14:mbr_entry_size[23:16]<=sector_byte;
                        15:begin
                            mbr_entry_size[31:24]<=sector_byte;
                            if(!mbr_first_found && (mbr_entry_type==8'h0b || mbr_entry_type==8'h0c) &&
                               (mbr_entry_status==0 || mbr_entry_status==8'h80))begin
                                mbr_first_start<=mbr_entry_start;
                                mbr_first_size<={sector_byte,mbr_entry_size[23:0]};
                            end
                        end
                        default:begin end
                    endcase
                end
            end else if(kind==K_FAT)begin
                if(sector_byte_index[8:2]==fat_offset[8:2])case(sector_byte_index[1:0])
                    0:fat_value[7:0]<=sector_byte;1:fat_value[15:8]<=sector_byte;
                    2:fat_value[23:16]<=sector_byte;3:fat_value[31:24]<=sector_byte;
                endcase
            end else if(kind==K_ROOT && !directory_end)begin
                case(sector_byte_index[4:0])
                    20:entry_cluster[23:16]<=sector_byte;21:entry_cluster[31:24]<=sector_byte;
                    26:entry_cluster[7:0]<=sector_byte;27:entry_cluster[15:8]<=sector_byte;
                    28:entry_size[7:0]<=sector_byte;29:entry_size[15:8]<=sector_byte;
                    30:entry_size[23:16]<=sector_byte;
                    31:begin
                        // Every descriptor kind commits this same payload. Capture
                        // it on the ordered entry boundary, independently of the
                        // name/size/priority selection. descriptor_write still
                        // qualifies every RAM write and sector publication still
                        // follows CRC/framing validation. No latency is added.
                        descriptor_write_data<={entry_cluster,sector_byte,entry_size[23:0]};
                        // Preserve original ordered assignment priority even
                        // for customized overlapping resource names.
                        if(entry_regular && entry_music_match!=0 && entry_cluster_in_range && {sector_byte,entry_size[23:0]}!=0 &&
                           entry_size[8:0]==0 && COMPACT_TABLE_ENABLE!=0)
                            for(payload_i=0;payload_i<21;payload_i=payload_i+1)
                                if(entry_music_match[payload_i] && !combined_music_valid[payload_i])begin
                                    descriptor_write_slot<=5'd8+payload_i;

                                end
                        if(entry_regular && entry_osd_match && !combined_osd_valid &&
                           entry_cluster_in_range &&
                           {sector_byte,entry_size[23:0]}!=0 && {sector_byte,entry_size[23:0]}<=65536 &&
                           COMPACT_TABLE_ENABLE!=0)begin
                            descriptor_write_slot<=5'd29;

                        end
                        if(entry_regular && entry_start_match && !combined_start_valid &&
                           entry_cluster_in_range &&
                           {sector_byte,entry_size[23:0]}!=0)begin
                            descriptor_write_slot<=5'd30;

                        end
                        if(entry_regular && entry_end_match && !combined_end_valid &&
                           entry_cluster_in_range &&
                           {sector_byte,entry_size[23:0]}!=0)begin
                            descriptor_write_slot<=5'd31;

                        end
                        if(entry_regular && selected_image_match!=0 && entry_cluster_in_range && {sector_byte,entry_size[23:0]}!=0 &&
                           COMPACT_TABLE_ENABLE!=0)
                            for(payload_i=0;payload_i<8;payload_i=payload_i+1)
                                if(selected_image_match[payload_i] && !combined_valid[payload_i])begin
                                    descriptor_write_slot<=payload_i;

                                end
                    end
                    default:begin end
                endcase
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            descriptor_write<=0;
            state<=IDLE;kind<=K_ZERO;scan_done<=0;mounted<=0;fs_error<=0;
            partition_lba<=0;sectors_per_cluster<=0;fat_start_lba<=0;
            data_start_lba<=0;max_cluster<=0;fat_sector_count<=0;volume_last_lba<=0;
            resource_valid<=0;resource0_cluster<=0;resource1_cluster<=0;
            resource2_cluster<=0;resource3_cluster<=0;
            resource4_cluster<=0;resource5_cluster<=0;resource6_cluster<=0;resource7_cluster<=0;
            resource4_size<=0;resource5_size<=0;resource6_size<=0;resource7_size<=0;
            start_valid<=0;pending_start_valid<=0;entry_start_match<=0;
            end_valid<=0;pending_end_valid<=0;entry_end_match<=0;
            osd_valid<=0;pending_osd_valid<=0;entry_osd_match<=0;osd_cluster<=0;osd_size<=0;
            music_extra_clusters<=0;music_extra_sizes<=0;
            resource0_size<=0;resource1_size<=0;resource2_size<=0;resource3_size<=0;
            music_valid_mask<=0;music_cluster<=0;music_size<=0;
            music1_cluster<=0;music1_size<=0;music2_cluster<=0;music2_size<=0;
            entry_music_match<=0;pending_music_valid<=0;
            pending_music_cluster<=0;pending_music_size<=0;
            pending_music1_cluster<=0;pending_music1_size<=0;
            pending_music2_cluster<=0;pending_music2_size<=0;
            sector_req<=0;sector_lba<=0;timer<=0;timeout_flag<=0;
            received<=0;sequence_error<=0;received_error<=0;
            checked_sector_good<=0;checked_sector_error<=0;
            classify_signature_bad<=0;classify_is_vbr<=0;
            mbr_candidate_flags<=0;mbr_empty_flags<=0;
            jump_good<=0;signature0_good<=0;signature1_good<=0;
            bps_good<=0;rootents_zero<=1;tot16_zero<=1;fat16_zero<=1;
            version_zero<=1;
            bpb_signature_bad<=0;bpb_shape_bad<=0;bpb_tables_bad<=0;
            bpb_extension_bad<=0;bpb_root_bad<=0;
            layout_volume_bad<=0;layout_partition_bad<=0;layout_data_bad<=0;layout_fat_bad<=0;

            mbr_first_found<=0;
            partition_index<=0;spc_log2<=0;has_partition<=0;partition_size<=0;media_limit<=0;
            partition_end_wide<=0;volume_end_wide<=0;fat_span_wide<=0;reserved_fat_wide<=0;
            base_fat_wide<=0;data_base_wide<=0;active_fat_wide<=0;
            data_sectors<=0;cluster_count<=0;current_cluster<=0;cluster_delta<=0;
            cluster_offset<=0;cluster_base_wide<=0;cluster_last_wide<=0;fat_addr_wide<=0;
            sector_in_cluster<=0;root_chain_count<=0;chain_anchor<=0;chain_power<=0;chain_period<=0;
            directory_sectors<=0;
            fat_offset<=0;entry_match<=0;pending_valid<=0;
            fat_is_eoc<=0;fat_is_bad<=0;fat_is_reserved<=0;fat_out_of_range<=0;
            fat_is_loop<=0;fat_budget_exhausted<=0;fat_reanchor<=0;
            fat_policy_continue<=0;fat_policy_error<=0;
            entry_regular<=0;directory_end<=0;
        end else begin
            descriptor_write<=0;
            scan_done<=0;sector_req<=0;
            if((state==RX && !take) || (state==REQ && !scan_pause && sector_busy)) begin
                if(timer<TC-1) timer<=timer+1'b1;
                timeout_flag<=(timer>=TC-2);
            end else begin timer<=0;timeout_flag<=0;end
            if(take) begin
                if(!valid_index) sequence_error<=1;
                if(received<513) received<=received+1'b1;
                if(valid_index) begin
                    if(kind==K_ZERO || kind==K_BOOT) begin
                        case(sector_byte_index)
                            0:jump_good<=sector_byte==8'heb || sector_byte==8'he9;
                            11:bps_good<=sector_byte==8'h00;12:bps_good<=bps_good && sector_byte==8'h02;
                            17:rootents_zero<=sector_byte==0;18:rootents_zero<=rootents_zero && sector_byte==0;
                            19:tot16_zero<=sector_byte==0;20:tot16_zero<=tot16_zero && sector_byte==0;
                            22:fat16_zero<=sector_byte==0;23:fat16_zero<=fat16_zero && sector_byte==0;
                            42:version_zero<=sector_byte==0;43:version_zero<=version_zero && sector_byte==0;
                            510:signature0_good<=sector_byte==8'h55;511:signature1_good<=sector_byte==8'haa;
                            default:begin end
                        endcase
                        if(kind==K_ZERO && sector_byte_index>=446 && sector_byte_index<510) begin
                            case(mbr_offset[3:0])
                                15:begin

                                    mbr_candidate_flags[mbr_offset[5:4]]<=
                                        (mbr_entry_type==8'h0b || mbr_entry_type==8'h0c) &&
                                        (mbr_entry_status==0 || mbr_entry_status==8'h80);
                                    mbr_empty_flags[mbr_offset[5:4]]<=mbr_entry_start==0 ||
                                        {sector_byte,mbr_entry_size[23:0]}==0;
                                    if(!mbr_first_found &&
                                        (mbr_entry_type==8'h0b || mbr_entry_type==8'h0c) &&
                                        (mbr_entry_status==0 || mbr_entry_status==8'h80)) begin
                                        mbr_first_found<=1;

                                    end
                                end
                                default:begin end
                            endcase
                        end
                    end else if(kind==K_ROOT && !directory_end) begin
                        if(sector_byte_index[4:0]==0) begin
                            entry_match<={sector_byte==name_byte(NAME7,0),sector_byte==name_byte(NAME6,0),
                                sector_byte==name_byte(NAME5,0),sector_byte==name_byte(NAME4,0),
                                sector_byte==name_byte(NAME3,0),sector_byte==name_byte(NAME2,0),
                                sector_byte==name_byte(NAME1,0),sector_byte==name_byte(NAME0,0)} & REQUIRED_IMAGE_MASK;
                            for(i=0;i<21;i=i+1) entry_music_match[i]<=
                                MUSIC_LOOKUP_ENABLE!=0 && i<MUSIC_TRACK_COUNT && sector_byte==name_byte(audio_name(i),0);
                            entry_osd_match<=OSD_ENABLE!=0 && sector_byte==name_byte("OSD     BIN",0);
                            entry_start_match<=START_PAGE_ENABLE!=0 && COMPACT_TABLE_ENABLE!=0 &&
                                               sector_byte==name_byte("START   BMP",0);
                            entry_end_match<=END_PAGE_ENABLE!=0 && COMPACT_TABLE_ENABLE!=0 &&
                                               sector_byte==name_byte("END     BMP",0);
                            entry_regular<=sector_byte!=8'he5 && sector_byte!=0;
                            if(sector_byte==0) directory_end<=1;
                        end else if(sector_byte_index[4:0]<=10) begin
                            entry_match<=entry_match & {
                                sector_byte==name_byte(NAME7,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME6,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME5,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME4,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME3,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME2,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME1,sector_byte_index[3:0]),
                                sector_byte==name_byte(NAME0,sector_byte_index[3:0])};
                            for(i=0;i<21;i=i+1) entry_music_match[i]<=entry_music_match[i] &&
                                sector_byte==name_byte(audio_name(i),sector_byte_index[3:0]);
                            entry_osd_match<=entry_osd_match && sector_byte==name_byte("OSD     BIN",sector_byte_index[3:0]);
                            entry_start_match<=entry_start_match && sector_byte==name_byte("START   BMP",sector_byte_index[3:0]);
                            entry_end_match<=entry_end_match && sector_byte==name_byte("END     BMP",sector_byte_index[3:0]);
                        end
                        case(sector_byte_index[4:0])
                            11:entry_regular<=entry_regular && (sector_byte&8'h18)==0;
                            31:begin
                              // Optional music is accepted only as a nonempty,
                              // sector-padded S16_LE corpus. Bad music never
                              // turns a valid picture directory into an error.
                              if(entry_regular && entry_music_match!=0 &&
                                  entry_cluster_in_range &&
                                  {sector_byte,entry_size[23:0]}!=0 && entry_size[8:0]==0) begin
                                  if(COMPACT_TABLE_ENABLE!=0) begin
                                      for(i=0;i<21;i=i+1) if(entry_music_match[i] && !combined_music_valid[i]) begin
                                          pending_music_valid[i]<=1;
                                          save_descriptor(5'd8+i,entry_cluster,{sector_byte,entry_size[23:0]});
                                      end
                                  end else begin
                                  if(entry_music_match[0] && !combined_music_valid[0]) begin
                                      pending_music_valid[0]<=1;pending_music_cluster<=entry_cluster;
                                      pending_music_size<={sector_byte,entry_size[23:0]};
                                  end
                                  if(entry_music_match[1] && !combined_music_valid[1]) begin
                                      pending_music_valid[1]<=1;pending_music1_cluster<=entry_cluster;
                                      pending_music1_size<={sector_byte,entry_size[23:0]};
                                  end
                                  if(entry_music_match[2] && !combined_music_valid[2]) begin
                                      pending_music_valid[2]<=1;pending_music2_cluster<=entry_cluster;
                                      pending_music2_size<={sector_byte,entry_size[23:0]};
                                  end
                                  for(i=3;i<21;i=i+1) if(entry_music_match[i] && !combined_music_valid[i]) begin
                                      pending_music_valid[i]<=1;
                                      music_extra_clusters[(i-3)*32 +: 32]<=entry_cluster;
                                      music_extra_sizes[(i-3)*32 +: 32]<={sector_byte,entry_size[23:0]};
                                  end
                                  end
                              end
                              // The byte-oriented package may end in a partial sector.
                              // Its 16-bit consumer address permits at most 64 KiB.
                              if(entry_regular && entry_osd_match && !combined_osd_valid &&
                                  entry_cluster_in_range &&
                                  {sector_byte,entry_size[23:0]}!=0 && {sector_byte,entry_size[23:0]}<=65536) begin
                                  pending_osd_valid<=1;
                                  if(COMPACT_TABLE_ENABLE!=0)
                                      save_descriptor(5'd29,entry_cluster,{sector_byte,entry_size[23:0]});
                                  else begin osd_cluster<=entry_cluster;osd_size<={sector_byte,entry_size[23:0]};end
                              end
                              // START is a separate resource, never a ninth chapter. Its descriptor
                              // is harmless until the entire root sector passes CRC/framing.
                              if(entry_regular && entry_start_match && !combined_start_valid &&
                                 entry_cluster_in_range &&
                                 {sector_byte,entry_size[23:0]}!=0) begin
                                  pending_start_valid<=1;
                                  save_descriptor(5'd30,entry_cluster,{sector_byte,entry_size[23:0]});
                              end
                              if(entry_regular && entry_end_match && !combined_end_valid &&
                                 entry_cluster_in_range &&
                                 {sector_byte,entry_size[23:0]}!=0) begin
                                  pending_end_valid<=1;
                                  save_descriptor(5'd31,entry_cluster,{sector_byte,entry_size[23:0]});
                              end
                              if(entry_regular && selected_image_match!=0) begin
                                if(!entry_cluster_in_range || {sector_byte,entry_size[23:0]}==0)
                                    fs_error<=E_ENTRY;
                                else begin
                                    if(COMPACT_TABLE_ENABLE!=0) begin
                                        for(i=0;i<8;i=i+1) if(selected_image_match[i] && !combined_valid[i]) begin
                                            pending_valid[i]<=1;
                                            save_descriptor(i,entry_cluster,{sector_byte,entry_size[23:0]});
                                        end
                                    end else begin
                                    if(selected_image_match[0] && !combined_valid[0]) begin pending_valid[0]<=1;resource0_cluster<=entry_cluster;resource0_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[1] && !combined_valid[1]) begin pending_valid[1]<=1;resource1_cluster<=entry_cluster;resource1_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[2] && !combined_valid[2]) begin pending_valid[2]<=1;resource2_cluster<=entry_cluster;resource2_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[3] && !combined_valid[3]) begin pending_valid[3]<=1;resource3_cluster<=entry_cluster;resource3_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[4] && !combined_valid[4]) begin pending_valid[4]<=1;resource4_cluster<=entry_cluster;resource4_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[5] && !combined_valid[5]) begin pending_valid[5]<=1;resource5_cluster<=entry_cluster;resource5_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[6] && !combined_valid[6]) begin pending_valid[6]<=1;resource6_cluster<=entry_cluster;resource6_size<={sector_byte,entry_size[23:0]};end
                                    if(selected_image_match[7] && !combined_valid[7]) begin pending_valid[7]<=1;resource7_cluster<=entry_cluster;resource7_size<={sector_byte,entry_size[23:0]};end
                                    end
                                end
                              end
                            end
                            default:begin end
                        endcase
                    end
                end
            end
            case(state)
                IDLE:if(scan_start) begin
                    fs_error<=0;mounted<=0;resource_valid<=0;pending_valid<=0;partition_lba<=0;
                    osd_valid<=0;pending_osd_valid<=0;start_valid<=0;pending_start_valid<=0;end_valid<=0;pending_end_valid<=0;
                    music_valid_mask<=0;music_cluster<=0;music_size<=0;pending_music_valid<=0;
                    music1_cluster<=0;music1_size<=0;music2_cluster<=0;music2_size<=0;
                    has_partition<=0;partition_size<=0;media_limit<=media_last_lba;directory_sectors<=0;
                    kind<=K_ZERO;sector_lba<=0;state<=REQ;
                end
                REQ:begin
                    if(!scan_pause && !sector_busy) begin
                        if(kind==K_ROOT && directory_sectors>=MAX_DIR_SECTORS) begin
                            if(MUSIC_LOOKUP_ENABLE!=0 && resource_valid==REQUIRED_IMAGE_MASK)
                                finish_directory(resource_valid);
                            else fail(E_BUDGET);
                        end
                        else begin
                            sector_req<=1;received<=0;sequence_error<=0;received_error<=0;
                            if(kind==K_ZERO) mbr_first_found<=0;
                            if(kind==K_ROOT) begin pending_valid<=0;pending_music_valid<=0;pending_osd_valid<=0;pending_start_valid<=0;pending_end_valid<=0;directory_sectors<=directory_sectors+1'b1;end
                            state<=RX;
                        end
                    end
                    // Keep the original last-assignment timeout priority and
                    // same-edge request/count side effects when busy releases.
                    if(!scan_pause && timeout_flag) fail(E_TIMEOUT);
                end
                RX:begin
                    if(sector_done) begin received_error<=sector_error;state<=CHECK_FLAGS;end
                    // A final byte/DONE still updates its captured registers;
                    // an already pending timeout overrides only state/error.
                    if(timeout_flag) fail(E_TIMEOUT);
                end
                CHECK_FLAGS:begin
                    // The final byte may share the sector_done edge. Capturing
                    // here sees its updated count/index/error and preserves the
                    // original provider-error-before-framing-error priority.
                    checked_sector_good<=received_error==0 && received==512 && !sequence_error;
                    checked_sector_error<=received_error!=0 ? received_error : E_FRAME;
                    // Header fields include the final accepted byte here.
                    // Predecode classification before its state/error mux.
                    classify_signature_bad<=!signature0_good || !signature1_good;
                    classify_is_vbr<=jump_good && bps_good &&
                        good_spc(bpb_spc) && bpb_reserved!=0 && rootents_zero && fat16_zero;
                    state<=CHECK;
                end
                CHECK:begin
                    if(!checked_sector_good) fail(checked_sector_error);
                    else case(kind)
                        K_ZERO:state<=CLASSIFY;
                        K_BOOT:state<=BPB_FLAGS;
                        K_FAT:state<=FAT_FLAGS;
                        K_ROOT:state<=ROOT_PUBLISH;
                    endcase
                end
                // Wide descriptors are enabled by a simple publication state,
                // after complete sector validation, not by received comparisons.
                ROOT_PUBLISH:begin
                            resource_valid<=combined_valid;
                            // Publish the directory entry only after all 512
                            // bytes and the atomic provider result agree.
                            music_valid_mask<=combined_music_valid;
                            osd_valid<=combined_osd_valid;
                            start_valid<=combined_start_valid;end_valid<=combined_end_valid;
                            if(COMPACT_TABLE_ENABLE==0 && pending_music_valid[0]) begin
                                music_cluster<=pending_music_cluster;
                                music_size<=pending_music_size;
                            end
                            if(COMPACT_TABLE_ENABLE==0 && pending_music_valid[1]) begin
                                music1_cluster<=pending_music1_cluster;music1_size<=pending_music1_size;
                            end
                            if(COMPACT_TABLE_ENABLE==0 && pending_music_valid[2]) begin
                                music2_cluster<=pending_music2_cluster;music2_size<=pending_music2_size;
                            end
                            if((combined_valid==REQUIRED_IMAGE_MASK &&
                                (MUSIC_LOOKUP_ENABLE==0 ||
                                 (combined_music_valid & REQUIRED_MUSIC_MASK)==REQUIRED_MUSIC_MASK) &&
                                (OSD_ENABLE==0 || combined_osd_valid) &&
                                (START_PAGE_ENABLE==0 || combined_start_valid) &&
                                (END_PAGE_ENABLE==0 || combined_end_valid)) || directory_end)
                                finish_directory(combined_valid);
                            else state<=ROOT_NEXT;
                end
                CLASSIFY:begin
                    // Receive-time predicates are consumed only after CHECK has
                    // validated all 512 ordered bytes and the provider result.
                    // Keep CLASSIFY and the original four-slot MBR walk cycles.
                    if(classify_signature_bad) fail(E_SIGNATURE);
                    // A legal MBR may also begin with a jump. Recognize a VBR by
                    // its FAT32 BPB shape, not its first byte alone.
                    else if(classify_is_vbr)
                        state<=BPB_FLAGS;
                    else begin partition_index<=0;state<=MBR;end
                end
                MBR:begin
                    if(partition_index==4) fail(E_BPB);
                    else if(mbr_candidate_flags[partition_index]) begin
                        if(mbr_empty_flags[partition_index]) fail(E_RANGE);
                        else begin partition_lba<=mbr_first_start;partition_size<=mbr_first_size;has_partition<=1;state<=PART_END;end
                    end else partition_index<=partition_index+1'b1;
                end
                PART_END:begin partition_end_wide<={1'b0,partition_lba}+{1'b0,partition_size}-1'b1;state<=PART_CHECK;end
                PART_CHECK:if(partition_end_wide[32] || partition_end_wide[31:0]>media_limit) fail(E_RANGE);
                    else begin sector_lba<=partition_lba;kind<=K_BOOT;state<=REQ;end
                BPB_FLAGS:begin
                    bpb_signature_bad<=!signature0_good || !signature1_good;
                    bpb_shape_bad<=!jump_good ||
                        !bps_good || !good_spc(bpb_spc) || bpb_reserved==0;
                    bpb_tables_bad<=(bpb_nfats!=1 && bpb_nfats!=2) || !rootents_zero ||
                        !fat16_zero || !tot16_zero || bpb_total==0 || bpb_fatsz==0;
                    bpb_extension_bad<=!version_zero || (bpb_flags&16'hff70)!=0 ||
                        (bpb_flags[7] && bpb_flags[3:0]>=bpb_nfats);
                    bpb_root_bad<=bpb_root<2 || bpb_root>=32'h0ffffff0;
                    state<=BPB;
                end
                BPB:begin
                    if(bpb_signature_bad) fail(E_SIGNATURE);
                    else if(bpb_shape_bad || bpb_tables_bad || bpb_extension_bad || bpb_root_bad) fail(E_BPB);
                    else begin
                        sectors_per_cluster<=bpb_spc;spc_log2<=log_spc(bpb_spc);
                        fat_sector_count<=bpb_fatsz;
                        fat_span_wide<=bpb_nfats==2 ? {bpb_fatsz,1'b0}:{1'b0,bpb_fatsz};
                        base_fat_wide<={1'b0,partition_lba}+{17'b0,bpb_reserved};
                        volume_end_wide<={1'b0,partition_lba}+{1'b0,bpb_total}-1'b1;
                        state<=LAYOUT0;
                    end
                end
                LAYOUT0:begin
                    reserved_fat_wide<={18'b0,bpb_reserved}+{1'b0,fat_span_wide};
                    active_fat_wide<=base_fat_wide+((bpb_flags[7] && bpb_flags[3:0]==1)?{1'b0,bpb_fatsz}:33'd0);
                    state<=LAYOUT1;
                end
                LAYOUT1:begin data_base_wide<={2'b0,partition_lba}+reserved_fat_wide;state<=LAYOUT_FLAGS;end
                LAYOUT_FLAGS:begin
                    layout_volume_bad<=volume_end_wide[32] || volume_end_wide[31:0]>media_limit;
                    layout_partition_bad<=has_partition && bpb_total>partition_size;
                    layout_data_bad<=reserved_fat_wide>={2'b0,bpb_total} || |data_base_wide[33:32];
                    layout_fat_bad<=base_fat_wide[32] || active_fat_wide[32];
                    state<=LAYOUT2;
                end
                LAYOUT2:begin
                    if(layout_volume_bad || layout_partition_bad || layout_data_bad || layout_fat_bad) fail(E_RANGE);
                    else begin
                        volume_last_lba<=volume_end_wide[31:0];fat_start_lba<=active_fat_wide[31:0];
                        data_start_lba<=data_base_wide[31:0];data_sectors<=bpb_total-reserved_fat_wide[31:0];state<=LAYOUT3;
                    end
                end
                LAYOUT3:begin cluster_count<=geometry_right_result;state<=LAYOUT4;end
                LAYOUT4:begin
                    max_cluster<=cluster_count+1'b1;
                    state<=GEOMETRY_FLAGS;
                end
                GEOMETRY_FLAGS:state<=LAYOUT5;
                LAYOUT5:if(layout_count_bad || layout_fat_capacity_bad || layout_root_range_bad) fail(E_BPB);
                    else state<=GEOMETRY;
                GEOMETRY:begin
                    mounted<=1;current_cluster<=bpb_root;sector_in_cluster<=0;directory_end<=0;
                    root_chain_count<=1;chain_anchor<=bpb_root;chain_power<=1;chain_period<=0;state<=CL_SUB;
                end
                CL_SUB:begin cluster_delta<=current_cluster-2;state<=CL_SHIFT;end
                CL_SHIFT:begin cluster_offset<=geometry_shift_result;state<=CL_ADD;end
                CL_ADD:begin cluster_base_wide<={1'b0,data_start_lba}+{1'b0,cluster_offset[31:0]};state<=CL_LAST;end
                CL_LAST:begin cluster_last_wide<=cluster_base_wide+{25'b0,sectors_per_cluster}-1'b1;state<=CL_CHECK;end
                // LAYOUT2/5 prove that every cluster 2..max_cluster lies
                // wholly inside the mounted volume. GEOMETRY/FAT_POLICY are
                // the only ways to enter this walk, and enforce that range.
                // Retain this state so request/publication timing is unchanged.
                CL_CHECK:begin sector_lba<=cluster_base_wide[31:0];kind<=K_ROOT;state<=REQ;end
                ROOT_NEXT:if(sector_in_cluster+1'b1<sectors_per_cluster) begin
                    sector_in_cluster<=sector_in_cluster+1'b1;sector_lba<=sector_lba+1'b1;kind<=K_ROOT;state<=REQ;
                end else begin sector_in_cluster<=0;state<=FAT_ADDR;end
                FAT_ADDR:begin
                    fat_addr_wide<={1'b0,fat_start_lba}+{1'b0,current_cluster[31:7]};
                    fat_offset<={current_cluster[6:0],2'b0};state<=FAT_CHECK;
                end
                // LAYOUT5 proves (max_cluster >> 7) < fat_sector_count;
                // validated active-FAT selection places that complete table
                // before data_start_lba. No valid root link can exceed it.
                FAT_CHECK:begin sector_lba<=fat_addr_wide[31:0];kind<=K_FAT;state<=REQ;end
                FAT_FLAGS:begin
                    fat_is_eoc<=next_cluster>=32'h0ffffff8;
                    fat_is_bad<=next_cluster==32'h0ffffff7;
                    fat_is_reserved<=next_cluster==1 || next_cluster>=32'h0ffffff0;
                    fat_out_of_range<=next_cluster<2 || next_cluster>max_cluster;
                    fat_is_loop<=next_cluster==chain_anchor || next_cluster==current_cluster;
                    fat_budget_exhausted<=root_chain_count>=MAX_ROOT_CLUSTERS;
                    fat_reanchor<=chain_period+1'b1==chain_power;
                    state<=FAT_POLICY;
                end
                FAT_POLICY:begin
                    // Parallel continue decision and separate error mux keep
                    // error priority independent of the wide register enables.
                    fat_policy_continue<=!(fat_is_eoc || fat_is_bad || fat_is_reserved ||
                        fat_out_of_range || fat_is_loop || fat_budget_exhausted);
                    if(fat_is_bad) fat_policy_error<=E_BAD;
                    else if(fat_is_reserved) fat_policy_error<=E_RESERVED;
                    else if(fat_out_of_range) fat_policy_error<=E_CLUSTER;
                    else if(fat_is_loop) fat_policy_error<=E_LOOP;
                    else fat_policy_error<=E_BUDGET;
                    state<=FAT_PARSE;
                end
                FAT_PARSE:begin
                    if(fat_is_eoc) finish_directory(resource_valid);
                    else if(!fat_policy_continue) fail(fat_policy_error);
                    else begin
                        root_chain_count<=root_chain_count+1'b1;current_cluster<=next_cluster;
                        if(fat_reanchor) begin chain_anchor<=next_cluster;chain_power<=chain_power<<1;chain_period<=0;end
                        else chain_period<=chain_period+1'b1;
                        state<=CL_SUB;
                    end
                end
                FINISH:begin scan_done<=1;state<=IDLE;end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
