`timescale 1ns/1ps
// PCM-only sequential FAT32 reader. The mounted geometry must remain stable
// while enable=1; remount/reset must cancel this context. metadata_valid must
// ONLY be asserted for descriptors published by fat32_volume_scanner after
// GEOMETRY and its complete CRC-checked catalog scan. That scanner proves
// legal SPC, FAT span, active FAT, capacity, and max_cluster within volume.
// Runtime cluster comparisons below therefore imply physical address bounds;
// they do not duplicate the scanner's immutable mount geometry checker.
// All physical bytes
// arrive from the existing CRC-atomic sector adapter, never raw SPI.
// Directory size must be a positive multiple of 512. Logical requests are
// 1..size/512. The last done waits for validation of the entire allocated tail.
module fat32_audio_sector_streamer #(
    parameter integer CLK_FREQ_HZ=50000000,
    parameter integer SECTOR_TIMEOUT_MS=500,
    parameter integer STALL_TIMEOUT_MS=1000
)(
    input clk,rst_n,enable,metadata_valid,
    input [31:0] first_cluster,file_size,
    input [7:0] sectors_per_cluster,
    input [31:0] fat_start_lba,data_start_lba,max_cluster,
    input [31:0] fat_sector_count,volume_last_lba,
    input req,input [31:0] logical_lba,output ready,output idle,
    output valid,output [7:0] data,output [8:0] index,input byte_ready,
    output reg done,output reg [7:0] error,output reg fragment_seen,
    output sector_wants,output sector_req,output reg [31:0] sector_lba,
    input sector_busy,sector_valid,input [7:0] sector_byte,
    input [8:0] sector_index,input sector_done,input [7:0] sector_error,
    output sector_byte_ready
);
    localparam IDLE=0,OPEN=1,CAPACITY=2,ADDRESS=3,ADDR_CHECK=4,
        WAIT_REQ=5,DATA_REQ=6,DATA_RX=7,DATA_CHECK=8,
        FAT_ADDR=9,FAT_REQ=10,FAT_RX=11,FAT_CHECK=12,FAT_PARSE=13,
        COMPLETE=14,FAIL=15,DRAIN=16,SHIFT=17,ERROR_WAIT=18,OPEN_CHECK=19,REQUEST_CHECK=20,FAT_COMMIT=21;
    localparam [7:0] E_TIMEOUT=8'h11,E_FRAME=8'h12,E_LOOP=8'h23,
        E_CLUSTER=8'h24,E_EARLY=8'h25,E_BUDGET=8'h26,E_BAD=8'h27,
        E_RESERVED=8'h28,E_RANGE=8'h29,E_STALL=8'h2b,E_ABORT=8'h2d;
    localparam integer TC0=(CLK_FREQ_HZ/1000)*SECTOR_TIMEOUT_MS;
    localparam integer SC0=(CLK_FREQ_HZ/1000)*STALL_TIMEOUT_MS;
    localparam integer TC=TC0<2?2:TC0,SC=SC0<2?2:SC0;
    localparam integer CW=$clog2((TC>SC?TC:SC)+1);
    reg [4:0] state;
    reg [27:0] cluster,anchor,power,period,visited,fat_value;
    reg [22:0] remaining,next_logical;
    reg [6:0] in_cluster;
    reg [2:0] shift;
    reg [2:0] shift_left;
    reg shifting_capacity;
    reg [31:0] offset;
    reg [9:0] received;
    reg sequence_error;
    reg [7:0] rx_error;
    reg abort_pending;
    reg address_pending;
    reg between_requests;
    // Capture these predicates independently of req/ready. On an accepted
    // request they describe the same edge's inputs; the following check state
    // consumes them. The long upstream eligibility path ends at acceptance.
    reg request_bad_lba,request_bad_metadata;
    // End the upstream catalog/ready/request cone at this single register.
    // An accepted request immediately removes ready/idle and freezes its
    // payload; only the following clock enters the existing check state.
    reg request_accepted;
    // The completed capacity shift is stable before OPEN consumes this flag.
    reg capacity_bad;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) request_accepted<=0;
        else request_accepted<=req && ready;
    end
    // Geometry is fixed for the enabled mounted context. visited changes
    // only in IDLE/FAT_COMMIT, and every subsequent FAT_PARSE follows a full
    // FAT sector transaction. Precompute the budget predicate separately
    // from the FAT_PARSE error priority and wide payload enables.
    reg budget_exhausted;
    // Classify the completed FAT entry before any wide chain-register enable.
    // FAT_PARSE follows the final replay byte, including byte+done coincidence.
    // These transaction-local flags need no reset: FAT_COMMIT is reachable only
    // through a CRC/framing/abort-checked FAT_PARSE clock. One extra SD clock
    // per link does not change logical request or sector replay handshakes.
    reg fat_eoc,fat_bad,fat_reserved,fat_cluster_ok,fat_loop;
    reg fat_fragment,fat_period_roll;
    reg [CW-1:0] timer;
    reg timer_was_blocked;
    wire receiving=state==DATA_RX || state==FAT_RX;
    wire delivering=state==DATA_RX && enable && !abort_pending;
    wire correct_index=received<512 && sector_index==received[8:0];
    wire take=receiving && sector_valid && sector_byte_ready;
    wire blocked=delivering && sector_valid && !byte_ready;
    wire waiting=(receiving && !take) || (sector_wants && sector_busy);
    wire [31:0] next_cluster={4'b0,fat_value};
    wire [31:0] address_add_a=state==FAT_ADDR ? fat_start_lba : state==CAPACITY ? data_start_lba : sector_lba;
    wire [31:0] address_add_b=state==FAT_ADDR ? {11'b0,cluster[27:7]} : state==CAPACITY ? offset : 32'd1;
    wire [31:0] address_sum=address_add_a+address_add_b;
    assign idle=state==IDLE && !request_accepted;
    assign ready=enable && !request_accepted && ((state==IDLE && metadata_valid) || state==WAIT_REQ || state==ERROR_WAIT);
    assign valid=delivering && sector_valid && correct_index;
    assign data=sector_byte;
    assign index=sector_index;
    assign sector_wants=enable && !abort_pending && (state==DATA_REQ || state==FAT_REQ);
    assign sector_req=sector_wants && !sector_busy;
    assign sector_byte_ready=delivering ? byte_ready : 1'b1;
    function [2:0] log_spc;
        input [7:0] v;
        begin case(v)
            2:log_spc=1;4:log_spc=2;8:log_spc=3;16:log_spc=4;
            32:log_spc=5;64:log_spc=6;128:log_spc=7;default:log_spc=0;
        endcase end
    endfunction
    task fail;
        input [7:0] code;
        begin error<=code;state<=between_requests && state!=WAIT_REQ && state!=IDLE ? ERROR_WAIT : FAIL;end
    endtask
    // Only externally observable control needs asynchronous reset. Payload
    // registers are initialized by a file request or a physical-sector grant.
    // No request/data-valid is exposed until those initializations complete.
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;
            abort_pending<=0;
            timer_was_blocked<=0;
            done<=0;
            error<=0;
            fragment_seen<=0;
        end else begin
            done<=0;
            timer_was_blocked<=blocked;
            if(!enable && state!=IDLE) abort_pending<=1;
            case(state)
                IDLE:if(request_accepted) begin
                    error<=0;
                    fragment_seen<=0;
                    abort_pending<=0;
                    state<=OPEN_CHECK;
                end
                OPEN_CHECK:begin
                    if(request_bad_lba) fail(E_RANGE);
                    else if(request_bad_metadata) fail(E_CLUSTER);
                    else state<=SHIFT;
                end
                OPEN:begin
                    if(capacity_bad) fail(E_RANGE);
                    else state<=ADDRESS;
                end
                ADDRESS:state<=SHIFT;
                SHIFT:if(shift_left==0) state<=shifting_capacity ? OPEN : CAPACITY;
                CAPACITY:state<=ADDR_CHECK;
                ADDR_CHECK:state<=DATA_REQ;
                WAIT_REQ:if(request_accepted) begin
                    error<=0;
                    state<=REQUEST_CHECK;
                end
                REQUEST_CHECK:begin
                    if(request_bad_lba) fail(E_RANGE);
                    else state<=address_pending ? ADDRESS : DATA_REQ;
                end
                DATA_REQ,FAT_REQ:if(sector_req) state<=state==DATA_REQ ? DATA_RX : FAT_RX;
                DATA_RX:if(sector_done) state<=DATA_CHECK;
                DATA_CHECK:begin
                    if(rx_error!=0) fail(rx_error);
                    else if(received!=512 || sequence_error) fail(E_FRAME);
                    else if(abort_pending || !enable) fail(E_ABORT);
                    else if(remaining==1) state<=FAT_ADDR;
                    else if({1'b0,in_cluster}+8'd1>=sectors_per_cluster) begin
                        // A CRC-checked data sector succeeds now; any following
                        // FAT-link error is reported on the next logical request.
                        done<=1;
                        state<=FAT_ADDR;
                    end else state<=COMPLETE;
                end
                FAT_ADDR:state<=FAT_CHECK;
                FAT_CHECK:state<=FAT_REQ;
                FAT_RX:if(sector_done) state<=FAT_PARSE;
                FAT_PARSE:begin
                    if(rx_error!=0) fail(rx_error);
                    else if(received!=512 || sequence_error) fail(E_FRAME);
                    else if(abort_pending || !enable) fail(E_ABORT);
                    else state<=FAT_COMMIT;
                end
                FAT_COMMIT:begin
                    // Cancellation may arrive in the added pipeline cycle.
                    if(abort_pending || !enable) fail(E_ABORT);
                    else if(fat_eoc) begin
                        if(remaining!=0) fail(E_EARLY);
                        else begin done<=1;state<=IDLE;end
                    end else if(fat_bad) fail(E_BAD);
                    else if(fat_reserved) fail(E_RESERVED);
                    else if(!fat_cluster_ok) fail(E_CLUSTER);
                    else if(fat_loop) fail(E_LOOP);
                    else if(budget_exhausted) fail(E_BUDGET);
                    else begin
                        if(fat_fragment) fragment_seen<=1;
                        // Validate an allocated tail through EOC without
                        // delivering it beyond the directory file size.
                        state<=remaining==0 ? FAT_ADDR : WAIT_REQ;
                    end
                end
                COMPLETE:begin done<=1;state<=WAIT_REQ;end
                ERROR_WAIT:if(request_accepted) state<=FAIL;
                FAIL:begin done<=1;state<=DRAIN;end
                DRAIN:if(!sector_busy) begin abort_pending<=0;state<=IDLE;end
                default:state<=IDLE;
            endcase
            if((abort_pending || !enable) && state!=IDLE && state!=DRAIN &&
               state!=FAIL && !receiving &&
               !((state==DATA_CHECK || state==FAT_PARSE) && rx_error!=0)) begin
                // WAIT_REQ may contain an already accepted request for one
                // pipeline clock; it still owns exactly one terminal result.
                if((state==WAIT_REQ && !request_accepted) || between_requests) begin error<=E_ABORT;state<=DRAIN;end
                else fail(E_ABORT);
            end
            if(waiting && timer_was_blocked==blocked && timer>=(blocked?SC-1:TC-1))
                fail(blocked?E_STALL:E_TIMEOUT);
        end
    end

    // Every payload below has a transaction-local initializer:
    // * IDLE request: FAT chain detector, file size, position and cluster shift.
    // * DATA/FAT_REQ grant: byte count, framing flag and returned error.
    // * FAT_RX: all four FAT-entry bytes before FAT_PARSE can inspect them.
    // * ADDRESS/CAPACITY: address before DATA_REQ; FAT_ADDR before FAT_REQ.
    // The watchdog clears during IDLE before any wait state is entered.
    // Holding this block during reset avoids a large unnecessary reset tree.
    always @(posedge clk) begin
        if(rst_n) begin
            budget_exhausted<={4'b0,visited}>=max_cluster-1'b1;
            // A single counter covers mutually exclusive bus wait/sink stall;
            // a change of reason starts a fresh corresponding timeout.
            if(waiting) begin
                if(blocked!=timer_was_blocked) timer<=0;
                else timer<=timer+1'b1;
            end else timer<=0;
            if(take) begin
                if(!correct_index) sequence_error<=1;
                if(received<513) received<=received+1'b1;
                if(state==FAT_RX && correct_index && sector_index[8:2]==cluster[6:0])
                    case(sector_index[1:0])
                        0:fat_value[7:0]<=sector_byte;
                        1:fat_value[15:8]<=sector_byte;
                        2:fat_value[23:16]<=sector_byte;
                        3:fat_value[27:24]<=sector_byte[3:0];
                    endcase
            end
            if(state==IDLE && !request_accepted) begin
                request_bad_lba<=logical_lba!=1;
                request_bad_metadata<=file_size==0 || file_size[8:0]!=0 ||
                    first_cluster<2 || first_cluster>max_cluster;
            end else if(state==WAIT_REQ && !request_accepted)
                request_bad_lba<=logical_lba!={9'b0,next_logical} || logical_lba==0;
            case(state)
                // Payload preloads while idle. The accepting clock is the
                // last preload, so descriptors are frozen at acceptance.
                // No wide payload register depends on the req/ready chain.
                IDLE:if(!request_accepted) begin
                    address_pending<=0;
                    between_requests<=0;
                    cluster<=first_cluster[27:0];
                    anchor<=first_cluster[27:0];
                    power<=1;
                    period<=0;
                    visited<=1;
                    in_cluster<=0;
                    remaining<=file_size[31:9];
                    next_logical<=2;
                    shift<=log_spc(sectors_per_cluster);
                    // Invalid descriptors are rejected before these payloads
                    // can produce a physical request.
                    offset<=max_cluster-1'b1;
                    shift_left<=log_spc(sectors_per_cluster);
                    shifting_capacity<=1;
                end
                ADDRESS:begin
                    offset<={4'b0,cluster-28'd2};
                    shift_left<=shift;
                    shifting_capacity<=0;
                end
                SHIFT:if(shift_left!=0) begin
                    offset<=offset<<1;
                    shift_left<=shift_left-1'b1;
                end else if(shifting_capacity)
                    capacity_bad<={9'b0,remaining}>offset;
                CAPACITY:sector_lba<=address_sum;
                ADDR_CHECK:address_pending<=0;
                WAIT_REQ:if(req && ready) between_requests<=0;
                REQUEST_CHECK:if(!request_bad_lba)
                    next_logical<=next_logical+1'b1;
                DATA_REQ,FAT_REQ:if(sector_req) begin
                    received<=0;
                    sequence_error<=0;
                    rx_error<=0;
                end
                DATA_RX,FAT_RX:if(sector_done) rx_error<=sector_error;
                DATA_CHECK:if(rx_error==0 && received==512 && !sequence_error &&
                              !abort_pending && enable) begin
                    remaining<=remaining-1'b1;
                    if(remaining!=1) begin
                        if({1'b0,in_cluster}+8'd1>=sectors_per_cluster)
                            between_requests<=1;
                        else begin
                            in_cluster<=in_cluster+1'b1;
                            sector_lba<=address_sum;
                        end
                    end
                end
                FAT_ADDR:sector_lba<=address_sum;
                FAT_PARSE:begin
                    fat_eoc<=next_cluster>=32'h0ffffff8;
                    fat_bad<=next_cluster==32'h0ffffff7;
                    fat_reserved<=next_cluster==1 || next_cluster>=32'h0ffffff0;
                    fat_cluster_ok<=next_cluster>=2 && next_cluster<32'h0ffffff0 &&
                                    next_cluster<=max_cluster;
                    fat_loop<=fat_value==anchor || fat_value==cluster;
                    fat_fragment<=fat_value!=cluster+1'b1;
                    fat_period_roll<=period+1'b1==power;
                end
                FAT_COMMIT:if(!abort_pending && enable && fat_cluster_ok &&
                              !fat_loop && !budget_exhausted) begin
                    cluster<=fat_value;
                    visited<=visited+1'b1;
                    in_cluster<=0;
                    if(fat_period_roll) begin
                        anchor<=fat_value;
                        power<=power<<1;
                        period<=0;
                    end else period<=period+1'b1;
                    // Data for a new cluster waits for the next logical request.
                    if(remaining!=0) address_pending<=1;
                end
                ERROR_WAIT:if(req && ready) between_requests<=0;
            endcase
        end
    end
endmodule
