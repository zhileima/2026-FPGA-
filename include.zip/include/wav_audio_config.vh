// FAT32 root MUSIC.PCM supplies its length and fragmented cluster chain.
// Legacy raw extent below is used only when FAT32 mode is explicitly disabled.
`ifndef F1_WAV_AUDIO_CONFIG_VH
`define F1_WAV_AUDIO_CONFIG_VH
`define F1_WAV_ENABLE 1'b1
`define F1_WAV_FAT32_ENABLE 1'b1
`define F1_WAV_START_LBA 32'd2048
`define F1_WAV_TOTAL_SECTORS 32'd3750
`endif
