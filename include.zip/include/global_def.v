


`define   DATA_WIDTH                        32
`define   ADDR_WIDTH                        21
`define   DM_WIDTH                          4

`define   ROW_WIDTH                        11
`define   BA_WIDTH                        2

// Keep the period expression grouped when it is expanded into other macros.
`define   SDR_CLK_PERIOD                    (1000000000 / 100000000)
// EM638325 requires 4096 refresh commands per 64 ms even though ROW_WIDTH is 11.
// init_cnt counts 0 through SELF_REFRESH_INTERVAL, inclusive: subtract one.
`define   SDR_REFRESH_COMMANDS              4096
`define   SELF_REFRESH_INTERVAL             ((64000000 / (`SDR_CLK_PERIOD) / (`SDR_REFRESH_COMMANDS)) - 1)

